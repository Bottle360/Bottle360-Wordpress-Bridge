<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class OrderController extends RestBase
{
    /**
     * Size cap for a receipt PDF passed through from core: 2 MB. A receipt is
     * tens of kilobytes; anything near this is not one.
     */
    private const RECEIPT_MAX_BYTES = 2097152;

    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/orders', [
            'methods'             => 'GET',
            'callback'            => [$this, 'list_orders'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/orders/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'order_detail'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/orders/(?P<id>\d+)/receipt', [
            'methods'             => 'GET',
            'callback'            => [$this, 'order_receipt'],
            'permission_callback' => '__return_true',
        ]);

        // REMOVE ONE RELEASE AFTER BD-4943 SHIPS. Recreate Order is gone, but a
        // page cached before the update can still carry the old bundle, whose
        // button POSTs here. Without this stub that click gets WordPress's
        // generic "No route was found" 404; with it the shopper is told to
        // refresh. See recreate_order_gone().
        register_rest_route(self::NAMESPACE, '/orders/(?P<id>\d+)/recreate', [
            'methods'             => 'POST',
            'callback'            => [$this, 'recreate_order_gone'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function list_orders(WP_REST_Request $request)
    {
        $params = [
            'page'     => max(1, (int) ($request->get_param('page') ?? 1)),
            'per_page' => min(100, max(1, (int) ($request->get_param('per_page') ?? 20))),
        ];

        return $this->proxy_get('order/history', $params);
    }

    public function order_detail(WP_REST_Request $request)
    {
        $orderId = absint($request->get_param('id'));

        if ($orderId <= 0) {
            return $this->error('order_id is required', 400);
        }

        return $this->proxy_get('order/detail', ['order_id' => $orderId]);
    }

    /**
     * GET /orders/{id}/receipt: the customer's own order as a PDF (BD-4943).
     *
     * A read, so no nonce, like the other order GETs. Core decides who may
     * have the file exactly as it does for order/detail: the request carries
     * the visitor's Bridge session, and a signed-out visitor gets core's JSON
     * 401, never a PDF.
     *
     * Three things are settled here, before core is called:
     *   - HEAD is refused (405). WordPress routes HEAD to the GET callback;
     *     nothing needs a receipt's headers, and answering would cost core a
     *     full render.
     *   - A cross-site read is refused (403). The session cookie is
     *     SameSite=Lax, so it does ride along on a top-level navigation from
     *     another site; Sec-Fetch-Site says where the request came from. Only
     *     `same-origin` (the storefront itself) and `none` (typed, bookmarked)
     *     pass. Browsers that do not send the header, and non-browser clients,
     *     proceed as before: the header is a browser's own statement, so its
     *     absence proves nothing either way.
     *   - The order id comes from the URL path only. get_param() would let a
     *     query string `?id=` override the path segment; every other query
     *     parameter (the client's cache-busting `_`) is ignored.
     *
     * Not forwarded: core's Retry-After on a 429. The SPA shows a fixed
     * "wait a minute" message and never retries on its own.
     */
    public function order_receipt(WP_REST_Request $request)
    {
        if (strtoupper((string) $request->get_method()) !== 'GET') {
            return $this->error('GET required.', 405, 'b360_method_not_allowed');
        }

        $site = strtolower(trim((string) $request->get_header('Sec-Fetch-Site')));
        if ($site !== '' && $site !== 'same-origin' && $site !== 'none') {
            return $this->error('Cross-site requests are not allowed.', 403, 'b360_cross_site');
        }

        $urlParams = $request->get_url_params();
        $orderId = absint($urlParams['id'] ?? 0);

        if ($orderId <= 0) {
            return $this->error('order_id is required', 400);
        }

        return $this->proxy_binary_get('order/receipt', ['order_id' => $orderId], [
            'accept'           => 'application/pdf',
            'magic'            => '%PDF-',
            'max_bytes'        => self::RECEIPT_MAX_BYTES,
            // A receipt must never open the store-wide circuit breaker: core
            // answers 500 RECEIPT_UNAVAILABLE / DOWNLOAD_UNAVAILABLE when it
            // cannot produce this one file, and a slow render can time out,
            // while the store itself is healthy. The timeout is the ordinary
            // GET timeout inside the ordinary per-request budget.
            'breaker'          => false,
            'filename'         => 'receipt-' . $orderId . '.pdf',
            'filename_pattern' => '/\Areceipt-[0-9]{1,20}\.pdf\z/',
        ]);
    }

    /**
     * POST /orders/{id}/recreate: a tombstone for stale cached bundles.
     * REMOVE ONE RELEASE AFTER BD-4943 SHIPS (with its route above, its guard
     * allowance in OrderDetail.receipt.test.ts and the pinned totals in
     * routeMap.test.ts).
     *
     * Calls nothing upstream and changes nothing: it only answers 410 with a
     * message the old client shows as its error text.
     *
     * No nonce check, on purpose. The nonce exists to stop a forged request
     * from changing state, and there is no state here to change: every caller
     * gets the same fixed answer whoever they are. Checking it would only
     * make the old client pay a 403, a nonce refresh and a retry before it
     * could show the message.
     */
    public function recreate_order_gone(WP_REST_Request $request)
    {
        return $this->error('Reordering is no longer available here. Please refresh the page.', 410, 'b360_gone');
    }
}
