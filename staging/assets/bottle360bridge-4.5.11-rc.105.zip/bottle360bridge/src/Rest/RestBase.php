<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Api\BridgeApiClient;
use Bottle360\Bridge\Support\Nonce;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

if (!defined('ABSPATH')) exit;

abstract class RestBase
{
    protected const NAMESPACE = 'b360/v1';

    abstract public function register_routes(): void;

    public function register(): void
    {
        add_action('rest_api_init', [$this, 'register_routes']);
        // Only wire the no-cache filter once; it's namespace-wide, not per-controller.
        if (!has_filter('rest_post_dispatch', [self::class, 'force_nocache'])) {
            add_filter('rest_post_dispatch', [self::class, 'force_nocache'], 10, 3);
        }
    }

    /**
     * Managed WP hosts (WP Engine, Kinsta, Pantheon) default to caching REST
     * responses at the edge unless the response explicitly forbids it. A cached
     * REST response is catastrophic for us because:
     *   1) the cached body is shared across visitors, leaking cart/auth data, and
     *   2) the cached Set-Cookie header is replayed to later visitors, which
     *      overwrites their real session token and silently logs them out.
     *
     * WP core doesn't send no-store by default, so we stamp the headers ourselves
     * on every response in our namespace. Runs late in the dispatch so our values
     * win over any earlier filter.
     */
    public static function force_nocache($response, $server, $request)
    {
        if (!($response instanceof \WP_REST_Response) && !($response instanceof \WP_HTTP_Response)) {
            return $response;
        }
        // Only our namespace, don't override other plugins' caching decisions.
        $route = $request instanceof \WP_REST_Request ? (string) $request->get_route() : '';
        if (strpos($route, '/' . self::NAMESPACE . '/') !== 0) {
            return $response;
        }
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0, private');
        $response->header('Pragma', 'no-cache');
        $response->header('Expires', 'Wed, 11 Jan 1984 05:00:00 GMT');
        // WP Engine / nginx respect X-Accel-Expires for edge caching.
        $response->header('X-Accel-Expires', '0');
        // Belt-and-braces for a cache that ignores no-store but honours Vary:
        // the answer depends on the session cookie, never share it across cookies.
        $response->header('Vary', 'Cookie');
        return $response;
    }

    protected function success($data, int $status = 200): WP_REST_Response
    {
        return new WP_REST_Response($data, $status);
    }

    /**
     * Build a WP_Error response. Optional $context is merged flat into the error
     * data array so the frontend can read fields like `address_id` directly off
     * `errorData.<key>` (matching the bridge admin's error.context shape after
     * WP serializes WP_Error into `{code, message, data:{status, ...context}}`).
     */
    protected function error(string $message, int $status = 400, string $code = 'b360_error', array $context = []): WP_Error
    {
        $data = ['status' => $status];
        if (!empty($context)) {
            // Context keys win over status if they collide, but the only reserved
            // key is 'status', and bridge endpoints don't put 'status' in context.
            $data = array_merge($data, $context);
        }
        return new WP_Error($code, $message, $data);
    }

    protected function check_nonce(WP_REST_Request $request): ?WP_Error
    {
        $nonce = $request->get_header('X-B360-Nonce');
        if (!$nonce || !wp_verify_nonce($nonce, Nonce::ACTION)) {
            return $this->error('Invalid or missing nonce', 403, 'b360_invalid_nonce');
        }
        return null;
    }

    /**
     * Lift the reCAPTCHA v3 headers off the incoming WP REST request so
     * controllers don't have to plumb them manually on every proxy_* call.
     * Merges with any explicit opts the caller set (explicit values win).
     */
    protected function withRecaptcha(WP_REST_Request $request, array $opts = []): array
    {
        $token  = trim((string) $request->get_header('X-Recaptcha-Token'));
        $action = trim((string) $request->get_header('X-Recaptcha-Action'));
        if ($token !== '' && !isset($opts['recaptcha_token'])) {
            $opts['recaptcha_token'] = $token;
        }
        if ($action !== '' && !isset($opts['recaptcha_action'])) {
            $opts['recaptcha_action'] = $action;
        }
        return $opts;
    }

    protected function proxy_get(string $route, array $params = [], array $opts = [])
    {
        $result = BridgeApiClient::instance()->get($route, $params, $opts);
        return $this->proxy_result($result);
    }

    /**
     * Build a WP_Error from a BridgeApiClient result, preserving the upstream
     * error code (BRIDGE_NOT_CONFIGURED, INVALID_PASSWORD, etc.) so the SPA
     * can branch on it. Use this from controllers that handle success
     * themselves but want proxy_result-style error passthrough on failure.
     */
    protected function proxy_error(array $result, string $fallbackMessage, int $fallbackStatus): WP_Error
    {
        $code = $result['error_code'] ?? 'b360_error';
        $context = is_array($result['error_context'] ?? null) ? $result['error_context'] : [];
        return $this->error(
            $result['error'] ?? $fallbackMessage,
            $result['status'] ?: $fallbackStatus,
            $code,
            $context
        );
    }

    protected function proxy_post(string $route, array $body = [], array $opts = [])
    {
        $result = BridgeApiClient::instance()->post($route, $body, $opts);
        return $this->proxy_result($result);
    }

    /**
     * Proxy a binary document (for example a PDF receipt) from the bridge API
     * to the browser, byte for byte.
     *
     * Failure is the same WP_Error the JSON proxies return (upstream status,
     * upstream code), so the SPA's error and 401 handling is unchanged.
     *
     * @param string $route  Bridge route, e.g. 'order/receipt'.
     * @param array  $params Query params.
     * @param array  $opts   BridgeApiClient::getBinary options ('accept', 'magic',
     *                       'max_bytes', 'breaker'), plus:
     *                       'filename'         the download filename to use when
     *                                          upstream's is missing or refused;
     *                       'filename_pattern' regex the upstream
     *                                          Content-Disposition filename must
     *                                          match to be passed through.
     */
    protected function proxy_binary_get(string $route, array $params = [], array $opts = [])
    {
        $result = BridgeApiClient::instance()->getBinary($route, $params, $opts);

        if (!$result['ok'] || !isset($result['binary']) || !is_string($result['binary'])) {
            $err = $this->proxy_error($result, 'Request failed', 500);
            $this->emitServerTiming($result);
            return $err;
        }

        $filename = self::binary_filename(
            (string) ($result['content_disposition'] ?? ''),
            (string) ($opts['filename_pattern'] ?? ''),
            (string) ($opts['filename'] ?? 'download')
        );

        $response = $this->binary_response(
            $result['binary'],
            (string) ($opts['accept'] ?? 'application/octet-stream'),
            $filename
        );
        $this->emitServerTiming($result, $response);
        return $response;
    }

    /**
     * The download filename: upstream's, but only when it matches the pattern
     * the caller allows. Anything else (absent, a path, quotes, CR/LF, another
     * extension) is replaced by the caller's own fallback, so nothing upstream
     * says can reach the Content-Disposition header unchecked.
     */
    public static function binary_filename(string $disposition, string $pattern, string $fallback): string
    {
        if ($pattern !== '' && preg_match('/;\s*filename\s*=\s*"([^"]*)"/i', $disposition, $m)) {
            if (preg_match($pattern, $m[1]) === 1) {
                return $m[1];
            }
        }
        // The fallback is ours, but it still lands in a header: keep it to a
        // safe subset.
        $safe = trim((string) preg_replace('/[^A-Za-z0-9._-]+/', '-', $fallback), '.-');
        return $safe !== '' ? $safe : 'download';
    }

    /**
     * A REST response whose body is raw bytes instead of JSON.
     *
     * WP_REST_Server JSON-encodes whatever a callback returns. The supported
     * way around that is the `rest_pre_serve_request` filter: return true from
     * it and the server sends nothing itself. The headers still travel on the
     * WP_REST_Response (the server emits them, replacing its own JSON
     * Content-Type), so force_nocache and every other rest_post_dispatch
     * filter apply to this response like any other.
     *
     * The filter is scoped by object identity: it serves bytes only for the
     * exact response object built here. If something replaces that object
     * (the `_envelope` query flag, another plugin's rest_post_dispatch filter)
     * the server falls back to its JSON body, which is `null`: never a
     * half-PDF.
     */
    protected function binary_response(string $bytes, string $contentType, string $filename): WP_REST_Response
    {
        $response = new WP_REST_Response(null, 200);
        $response->header('Content-Type', $contentType);
        $response->header('Content-Disposition', 'attachment; filename="' . $filename . '"');
        $response->header('Content-Length', (string) self::byte_length($bytes));
        $response->header('X-Content-Type-Options', 'nosniff');
        // force_nocache replaces this with its stricter superset in production;
        // set here so the response is private and unstorable on its own too.
        $response->header('Cache-Control', 'private, no-store');
        // Two caches force_nocache does not address, and a customer's document
        // must never sit in either: LiteSpeed's page cache (which can cache
        // REST responses and reads only its own header) and CDNs that honor
        // CDN-Cache-Control over Cache-Control.
        $response->header('X-LiteSpeed-Cache-Control', 'no-cache');
        $response->header('CDN-Cache-Control', 'no-store');

        add_filter('rest_pre_serve_request', static function ($served, $result = null) use ($response, $bytes) {
            if ($served || $result !== $response) {
                return $served;
            }
            return self::emit_binary($bytes);
        }, 10, 2);

        return $response;
    }

    /**
     * Write the bytes as the whole response body. Always returns true (the
     * request is served): the caller must never append a JSON body.
     *
     * What keeps the document intact:
     *   - If output has already started, nothing is written. Our headers did
     *     not go out in that case, so the browser sees a non-PDF answer and
     *     the SPA reports a failed download instead of saving a corrupt file.
     *   - Every open output buffer is discarded first, so a notice, a BOM or
     *     whitespace printed earlier in the request, or a caching /
     *     optimization plugin's output handler, cannot prepend to or rewrite
     *     the bytes. Bounded loop: a buffer that refuses to close is emptied
     *     instead, never retried forever.
     *   - PHP-level compression is off for this response and Content-Length
     *     is restated after the cleanup, so the length on the wire is the
     *     length of the document.
     *   - Whatever the rest of the request prints (a shutdown handler, a debug
     *     footer) goes into a buffer that drops it, so nothing trails the file.
     */
    public static function emit_binary(string $bytes): bool
    {
        if (headers_sent()) {
            return true;
        }

        @ini_set('zlib.output_compression', '0');
        if (function_exists('apache_setenv')) {
            @apache_setenv('no-gzip', '1');
        }

        for ($level = ob_get_level(); $level > 0; $level--) {
            if (!@ob_end_clean()) {
                @ob_clean();
                break;
            }
        }

        header_remove('Content-Encoding');
        header('Content-Length: ' . self::byte_length($bytes));

        echo $bytes;

        ob_start([self::class, 'discard_output']);

        return true;
    }

    /** Output-buffer callback that drops everything it is given. */
    public static function discard_output($buffer): string
    {
        return '';
    }

    /** Length in bytes, correct even where mbstring overloads strlen (PHP 7.4). */
    private static function byte_length(string $bytes): int
    {
        return function_exists('mb_strlen') ? (int) mb_strlen($bytes, '8bit') : strlen($bytes);
    }

    private function proxy_result(array $result)
    {
        if (!$result['ok']) {
            // Forward the upstream error code (e.g. LEGACY_ADDRESS_PHONE_MISSING)
            // and context (e.g. {address_id: 12518}) so the Vue frontend can
            // branch on them. WP would otherwise collapse the rich error envelope
            // into {code:'b360_error', message, data:{status}} and lose both.
            $upstreamCode = $result['error_code'] ?? 'b360_error';
            $context = is_array($result['error_context'] ?? null) ? $result['error_context'] : [];
            $err = $this->error(
                $result['error'] ?? 'Request failed',
                $result['status'] ?: 500,
                $upstreamCode,
                $context
            );
            // Timing header fires even on error paths so we can see whether
            // the slow leg was the upstream call or local work.
            $this->emitServerTiming($result);
            return $err;
        }

        $data = $result['data'];

        // Include pagination meta in both body and headers
        if (!empty($result['meta'])) {
            if (is_array($data)) {
                $data['meta'] = $result['meta'];
            }
        }

        $response = $this->success($data);

        if (!empty($result['meta'])) {
            if (isset($result['meta']['total_items'])) {
                $response->header('X-WP-Total', (string) $result['meta']['total_items']);
            }
            if (isset($result['meta']['total_pages'])) {
                $response->header('X-WP-TotalPages', (string) $result['meta']['total_pages']);
            }
        }

        $this->emitServerTiming($result, $response);
        return $response;
    }

    /**
     * Emit a Server-Timing response header so latency shows up in browser
     * devtools natively. Fields:
     *   - wp=<ms>         wall-clock around wp_remote_* (WP↔admin network+admin total)
     *   - <admin fields>  whatever the admin site emitted in its own Server-Timing,
     *                     re-emitted verbatim so breakdowns like
     *                     "recaptcha=450, service=800, total=1350" appear inline.
     *
     * If the admin didn't set its own Server-Timing (older build), only wp=
     * is emitted. Works whether we're emitting on success (WP_REST_Response)
     * or error (WP_Error, we have to hook rest_post_dispatch instead since
     * WP_Error has no header API).
     */
    private function emitServerTiming(array $result, $response = null): void
    {
        $timing = isset($result['timing']) && is_array($result['timing']) ? $result['timing'] : [];
        if (empty($timing)) return;

        $parts = [];
        $parts[] = 'wp;dur=' . (int) ($timing['wp_remote_ms'] ?? 0);
        $admin = trim((string) ($timing['admin_server_timing'] ?? ''));
        $header = implode(', ', $parts) . ($admin !== '' ? ', ' . $admin : '');

        if ($response instanceof \WP_REST_Response) {
            $response->header('Server-Timing', $header);
            return;
        }
        // Error path: WP_Error has no header API. Piggy-back on the
        // rest_post_dispatch filter to set it once the final response is
        // materialized, by then we have a WP_HTTP_Response we can mutate.
        add_filter('rest_post_dispatch', function ($resp) use ($header) {
            if ($resp instanceof \WP_HTTP_Response) {
                $resp->header('Server-Timing', $header);
            }
            return $resp;
        }, 99);
    }
}
