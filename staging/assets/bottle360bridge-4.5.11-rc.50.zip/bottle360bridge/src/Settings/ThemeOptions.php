<?php

namespace Bottle360\Bridge\Settings;

if (!defined('ABSPATH')) exit;

/**
 * V2 Bridge theme options. Stores a full BridgeThemeV2-shaped array
 * under the `b360_theme_v2` WP option. The legacy V1 option key
 * (`b360_theme`) is deleted on activation, see Lifecycle\Activator.
 */
final class ThemeOptions
{
    const OPTION_KEY     = 'b360_theme_v2';
    const SCHEMA_VERSION = 2;

    public static function defaults()
    {
        return [
            'name'    => 'Estate Default',
            'version' => 2,
            'colors'  => [
                'brandPrimary'          => '#1A2438',
                'brandSecondary'        => '#7C5C3C',
                'brandAccent'           => '#8B6F47',
                'brandAccentFade'       => '#C9A876',
                'actionPrimary'         => '#7A1730',
                'actionPrimaryHover'    => '#641226',
                'actionPrimaryText'     => '#FFFFFF',
                'actionSecondary'       => '#FFFFFF',
                'actionSecondaryText'   => '#1A2438',
                'linkText'              => '#1A2438',
                'surfacePage'           => '#FAF8F3',
                'surfaceCard'           => '#FFFFFF',
                'surfaceElevated'       => '#F7F4ED',
                'surfaceMuted'          => '#F3EEE8',
                'surfaceInverse'        => '#1A2438',
                'surfaceDisabled'       => '#F1EFE8',
                'textPrimary'           => '#171717',
                'textSecondary'         => '#4F4A45',
                'textMuted'             => '#6B6660',
                'textSubtle'            => '#8C867E',
                'textOnInverse'         => '#FFFFFF',
                'textOnInverseMuted'    => 'rgba(255,255,255,0.68)',
                'textAccent'            => '#8B6F47',
                'borderSubtle'          => '#EAE5D9',
                'borderStrong'          => '#CFC2B5',
                'borderFocus'           => '#8B6F47',
                'divider'               => '#E9E4DE',
                'selectedSurface'       => '#FFF7F8',
                'selectedBorder'        => '#7A1730',
                'focusRing'             => 'rgba(122, 23, 48, 0.18)',
                'success'               => '#2E7D32',
                'successSoft'           => '#EAF4EC',
                'successText'           => '#FFFFFF',
                'warning'               => '#8A6B0F',
                'warningSoft'           => '#F7EED2',
                'warningText'           => '#FFFFFF',
                'error'                 => '#B03A2E',
                'errorSoft'             => '#F8E7E4',
                'errorText'             => '#FFFFFF',
                'info'                  => '#1A4A7A',
                'infoSoft'              => '#E8F0FA',
                'infoText'              => '#FFFFFF',
                'priceText'             => '#171717',
                'discountText'          => '#2E7D32',
                'surfaceInverseOverlay' => 'rgba(0,0,0,0.18)',
                'borderOnInverse'       => 'rgba(255,255,255,0.14)',
            ],
            'typography' => [
                'fontSans'      => 'inherit',
                'fontSerif'     => 'Georgia, Cambria, "Times New Roman", serif',
                'fontMono'      => 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                'bodyWeight'    => 400,
                'labelWeight'   => 600,
                'headingWeight' => 650,
                'titleWeight'   => 700,
                'headingTransform'     => 'none',
                'headingLetterSpacing' => 'normal',
                // Imported web fonts (Styling Studio → Typography → Google Fonts).
                'webFonts'             => [
                    'provider' => 'none',
                    'h1' => null, 'h2' => null, 'h3' => null,
                    'h4' => null, 'h5' => null, 'h6' => null,
                    'accent' => null, 'body' => null,
                ],
            ],
            'density' => 'default',
            'radius'  => [
                'xs'      => '4px',
                'sm'      => '6px',
                'control' => '10px',
                'card'    => '14px',
                'panel'   => '18px',
                'pill'    => '999px',
            ],
            'shadow' => [
                'none'    => 'none',
                'sm'      => '0 1px 2px rgba(23, 23, 23, 0.06), 0 6px 16px rgba(23, 23, 23, 0.04)',
                'md'      => '0 2px 6px rgba(23, 23, 23, 0.08), 0 12px 32px rgba(23, 23, 23, 0.06)',
                'lg'      => '0 8px 24px rgba(23, 23, 23, 0.10), 0 20px 56px rgba(23, 23, 23, 0.08)',
                'overlay' => '0 8px 24px -8px rgba(26, 36, 56, 0.18)',
            ],
            'widths' => [
                'form'            => '520px',
                'reading'         => '720px',
                'content'         => '960px',
                'account'         => '1120px',
                'wide'            => '1180px',
                'store'           => '1280px',
                'checkout'        => '1200px',
                'studio'          => '1440px',
                'readableMeasure' => '68ch',
            ],
            'components' => [
                'button' => [
                    'textTransform' => 'none',
                    'letterSpacing' => 'normal',
                ],
                'productCard' => [
                    'actionsLayout' => 'inline',
                    'showTeaser'    => false,
                    'showBuyCase'   => false,
                    'showQty'       => false,
                    'showCasePrice' => false,
                ],
                'surfaces' => [
                    'card'        => ['border' => true,  'shadow' => 'sm'],
                    'elevated'    => ['border' => true,  'shadow' => 'md'],
                    'productCard' => ['border' => false, 'shadow' => 'sm'],
                ],
                'tabs' => [
                    'indicator'          => 'scale-center',
                    'indicatorThickness' => 3,
                    'indicatorColor'     => null,
                    'indicatorRadius'    => 'rounded',
                    'overflow'           => 'scroll',
                ],
                'storeListing' => [
                    'categoryHeader'          => 'page-title',
                    'showCategoryDescription' => true,
                    // LEGACY all-in-one bar switch, kept as the migration
                    // fallback for the three per-control flags. Those flags
                    // (showProductSearch / showProductFilter /
                    // showProductSort) are DELIBERATELY ABSENT from these
                    // defaults: get() deep-merges stored over defaults, so a
                    // default here would materialize on every legacy theme
                    // and clobber the client's read-time fallback onto this
                    // key (resolveFilterBarControls in useStoreFilters.ts).
                    'showProductFilterBar'    => false,
                    // 'backend-order' = no client-side sort; the grid keeps
                    // the B360 backend's own product order. DELIBERATE
                    // change from BD-4621's 'name-asc': sites running the
                    // bar without an explicitly saved sort now load in
                    // backend order. Mirrors StoreProductSortKey in
                    // shared/theme/types.ts.
                    'defaultProductSort'      => 'backend-order',
                    'showCategoriesMenu'      => true,
                    'productColumns'          => 'auto',
                    'lockedCategoryTreatment' => 'inline-banner',
                ],
                'loyalty' => [
                    'showEarnOnCatalog' => false,
                    'showEarnOnDetail'  => false,
                ],
                'clubDetail' => [
                    'showWineTypes' => true,
                ],
                'shipmentManifest' => [
                    'enabled'    => true,
                    'density'    => 'comfortable',
                    'dividers'   => true,
                    'thumbnails' => true,
                    'addedLabel' => 'Added',
                    'addedColor' => null,
                ],
                'expressPay' => [
                    'enabled'      => true,
                    'buttonColor'  => 'auto',
                    'buttonType'   => 'buy',
                    'dividerLabel' => 'Express checkout',
                    'showDivider'  => true,
                ],
            ],
            'assets' => [
                'checkoutLogoUrl'     => '',
                'checkoutLogoLinkUrl' => '',
            ],
            'motion' => [
                'intensity'          => null,
                'reducedMotion'      => null,
                'routeTransition'    => null,
                'loadingStyle'       => null,
                'celebrationsEnabled' => null,
                'baseDuration'       => null,
            ],
            '_overrides'               => [],
            '_appliedVibeId'           => null,
            '_appliedTypographyPairId' => null,
            // Provenance metadata (NOT a CSS variable, never emitted by
            // Assets.php). Default 'manual' so an unset/existing theme is
            // treated as hand-tuned and never auto-clobbered by a style-match
            // re-run. Stamped 'auto' when a match result is applied.
            'theme_source'             => 'manual',
        ];
    }

    public static function get()
    {
        $stored = get_option(self::OPTION_KEY, []);
        if (!is_array($stored)) $stored = [];
        return self::migrate_legacy_web_fonts(self::deep_merge(self::defaults(), $stored));
    }

    /**
     * Levels a LEGACY single `webFonts.heading` font migrates onto.
     *
     * H1-H3 ONLY, and the omission of h4-h6 is deliberate. The old importer's
     * one heading font reached the storefront solely through `fontSerif` →
     * `--b360-font-serif`, and the only primitives consuming that were
     * `.b360-display` (h1), `.b360-page-title` (h2) and the section titles (h3).
     * `.b360-card-title` (h4) and `.b360-eyebrow` (h5) inherited the BODY font,
     * and bare h6 inherited too. Fanning the legacy font across all six would
     * therefore restyle card titles and eyebrows on every existing site, a
     * visible regression dressed up as a migration.
     *
     * Levels left null still render identically, because each rule's var()
     * fallback reproduces its pre-importer value: `.b360-club-card__title` falls
     * back to `--b360-font-serif` (so it keeps the legacy face), while
     * `.b360-card-title` falls back to `inherit` (so it keeps the body face).
     */
    private const LEGACY_HEADING_LEVELS = ['h1', 'h2', 'h3'];

    /**
     * Migrate a LEGACY single `webFonts.heading` font on READ.
     *
     * The sanitizer migrates on save, but a site that hasn't re-saved would hit a
     * half-state: `fontSerif` still names the family, so headings still *ask* for
     * e.g. Cormorant Garamond, while Assets.php, which iterates the new roles,
     * would no longer emit the <link> that downloads it. The family silently
     * degrades to the Georgia fallback.
     *
     * Doing it here means the REST response, the storefront and the studio all
     * see one shape. `heading` is dropped so nothing downstream handles both.
     */
    private static function migrate_legacy_web_fonts(array $theme)
    {
        if (!isset($theme['typography']['webFonts']) || !is_array($theme['typography']['webFonts'])) {
            return $theme;
        }
        $wf = $theme['typography']['webFonts'];
        if (!isset($wf['heading'])) return $theme;

        $legacy = is_array($wf['heading']) ? self::sanitize_web_font($wf['heading']) : null;
        if ($legacy !== null) {
            foreach (self::LEGACY_HEADING_LEVELS as $role) {
                // An explicit per-level value always wins over the legacy font.
                if (empty($wf[$role])) $wf[$role] = $legacy;
            }
        }
        unset($wf['heading']);

        $theme['typography']['webFonts'] = $wf;
        return $theme;
    }

    public static function save(array $input)
    {
        $sanitized = self::sanitize($input);
        $merged    = self::deep_merge(self::defaults(), $sanitized);
        update_option(self::OPTION_KEY, $merged, false);
        return $merged;
    }

    public static function reset()
    {
        delete_option(self::OPTION_KEY);
        return self::defaults();
    }

    /** Sanitise a partial BridgeThemeV2 payload. Unknown keys are dropped. */
    private static function sanitize(array $input)
    {
        $out = [];

        if (isset($input['name']) && is_string($input['name'])) {
            $out['name'] = sanitize_text_field(substr($input['name'], 0, 80));
        }

        if (isset($input['colors']) && is_array($input['colors'])) {
            $colors = [];
            foreach ($input['colors'] as $k => $v) {
                if (!is_string($v)) continue;
                $clean = self::sanitize_color_value($v);
                if ($clean !== null) $colors[$k] = $clean;
            }
            if (!empty($colors)) $out['colors'] = $colors;
        }

        if (isset($input['typography']) && is_array($input['typography'])) {
            $typo = [];
            $string_keys = ['fontSans', 'fontSerif', 'fontMono'];
            foreach ($string_keys as $k) {
                if (isset($input['typography'][$k]) && is_string($input['typography'][$k])) {
                    $typo[$k] = self::sanitize_font_stack($input['typography'][$k]);
                }
            }
            $int_keys = ['bodyWeight', 'labelWeight', 'headingWeight', 'titleWeight'];
            foreach ($int_keys as $k) {
                if (isset($input['typography'][$k])) {
                    $typo[$k] = max(100, min(900, (int) $input['typography'][$k]));
                }
            }
            // Heading-only display traits, strict enums (readability-bounded).
            $enum_keys = [
                'headingTransform'     => ['none', 'uppercase', 'lowercase', 'capitalize'],
                'headingLetterSpacing' => ['normal', 'tight', 'wide', 'wider', 'widest'],
            ];
            foreach ($enum_keys as $k => $allowed) {
                if (isset($input['typography'][$k]) && in_array($input['typography'][$k], $allowed, true)) {
                    $typo[$k] = $input['typography'][$k];
                }
            }
            if (isset($input['typography']['webFonts']) && is_array($input['typography']['webFonts'])) {
                $wf = self::sanitize_web_fonts($input['typography']['webFonts']);
                if ($wf !== null) $typo['webFonts'] = $wf;
            }
            if (!empty($typo)) $out['typography'] = $typo;
        }

        if (isset($input['density']) && in_array($input['density'], ['compact', 'default', 'airy'], true)) {
            $out['density'] = $input['density'];
        }

        if (isset($input['radius']) && is_array($input['radius'])) {
            $radius = [];
            foreach (['xs', 'sm', 'control', 'card', 'panel', 'pill'] as $k) {
                if (isset($input['radius'][$k]) && is_string($input['radius'][$k])) {
                    $radius[$k] = self::sanitize_length($input['radius'][$k]);
                }
            }
            if (!empty($radius)) $out['radius'] = $radius;
        }

        if (isset($input['shadow']) && is_array($input['shadow'])) {
            $shadow = [];
            foreach (['none', 'sm', 'md', 'lg', 'overlay'] as $k) {
                if (isset($input['shadow'][$k]) && is_string($input['shadow'][$k])) {
                    $shadow[$k] = sanitize_text_field(substr($input['shadow'][$k], 0, 240));
                }
            }
            if (!empty($shadow)) $out['shadow'] = $shadow;
        }

        if (isset($input['widths']) && is_array($input['widths'])) {
            $widths = [];
            foreach (['form', 'reading', 'content', 'account', 'wide', 'store', 'checkout', 'studio', 'readableMeasure'] as $k) {
                if (isset($input['widths'][$k]) && is_string($input['widths'][$k])) {
                    $widths[$k] = self::sanitize_length($input['widths'][$k]);
                }
            }
            if (!empty($widths)) $out['widths'] = $widths;
        }

        if (isset($input['components']) && is_array($input['components'])) {
            $comp = [];
            if (isset($input['components']['button']) && is_array($input['components']['button'])) {
                $bt = $input['components']['button'];
                $cleanBt = [];
                if (isset($bt['textTransform']) && in_array($bt['textTransform'], ['none', 'uppercase'], true)) {
                    $cleanBt['textTransform'] = $bt['textTransform'];
                }
                if (isset($bt['letterSpacing']) && in_array($bt['letterSpacing'], ['normal', 'wide', 'wider'], true)) {
                    $cleanBt['letterSpacing'] = $bt['letterSpacing'];
                }
                if (!empty($cleanBt)) $comp['button'] = $cleanBt;
            }
            if (isset($input['components']['productCard']) && is_array($input['components']['productCard'])) {
                $pc = $input['components']['productCard'];
                $cleanPc = [];
                if (isset($pc['actionsLayout']) && in_array($pc['actionsLayout'], ['inline', 'hover'], true)) {
                    $cleanPc['actionsLayout'] = $pc['actionsLayout'];
                }
                if (isset($pc['showTeaser']))    $cleanPc['showTeaser']    = (bool) $pc['showTeaser'];
                if (isset($pc['showBuyCase']))   $cleanPc['showBuyCase']   = (bool) $pc['showBuyCase'];
                if (isset($pc['showQty']))       $cleanPc['showQty']       = (bool) $pc['showQty'];
                if (isset($pc['showCasePrice'])) $cleanPc['showCasePrice'] = (bool) $pc['showCasePrice'];
                if (!empty($cleanPc)) $comp['productCard'] = $cleanPc;
            }
            if (isset($input['components']['surfaces']) && is_array($input['components']['surfaces'])) {
                $cleanSurfaces = [];
                foreach (['card', 'elevated', 'productCard'] as $family) {
                    if (!isset($input['components']['surfaces'][$family]) || !is_array($input['components']['surfaces'][$family])) {
                        continue;
                    }
                    $fam   = $input['components']['surfaces'][$family];
                    $clean = [];
                    if (isset($fam['border'])) {
                        $clean['border'] = (bool) $fam['border'];
                    }
                    if (isset($fam['shadow']) && in_array($fam['shadow'], ['none', 'sm', 'md', 'lg'], true)) {
                        $clean['shadow'] = $fam['shadow'];
                    }
                    if (!empty($clean)) $cleanSurfaces[$family] = $clean;
                }
                if (!empty($cleanSurfaces)) $comp['surfaces'] = $cleanSurfaces;
            }
            if (isset($input['components']['tabs']) && is_array($input['components']['tabs'])) {
                $tb = $input['components']['tabs'];
                $cleanTb = [];
                if (isset($tb['indicator']) && in_array($tb['indicator'], ['scale-center', 'slide', 'fade', 'none'], true)) {
                    $cleanTb['indicator'] = $tb['indicator'];
                }
                if (isset($tb['indicatorThickness'])) {
                    $cleanTb['indicatorThickness'] = max(2, min(5, (int) $tb['indicatorThickness']));
                }
                if (array_key_exists('indicatorColor', $tb)) {
                    if ($tb['indicatorColor'] === null || $tb['indicatorColor'] === '') {
                        $cleanTb['indicatorColor'] = null;
                    } elseif (is_string($tb['indicatorColor'])) {
                        $clean = self::sanitize_color_value($tb['indicatorColor']);
                        if ($clean !== null) $cleanTb['indicatorColor'] = $clean;
                    }
                }
                if (isset($tb['indicatorRadius']) && in_array($tb['indicatorRadius'], ['flat', 'rounded', 'capsule'], true)) {
                    $cleanTb['indicatorRadius'] = $tb['indicatorRadius'];
                }
                if (isset($tb['overflow']) && in_array($tb['overflow'], ['scroll', 'wrap'], true)) {
                    $cleanTb['overflow'] = $tb['overflow'];
                }
                if (array_key_exists('animationDuration', $tb)) {
                    if ($tb['animationDuration'] === null || $tb['animationDuration'] === '') {
                        $cleanTb['animationDuration'] = null;
                    } elseif (in_array($tb['animationDuration'], ['150ms', '280ms', '400ms'], true)) {
                        $cleanTb['animationDuration'] = $tb['animationDuration'];
                    }
                }
                if (!empty($cleanTb)) $comp['tabs'] = $cleanTb;
            }
            if (isset($input['components']['storeListing']) && is_array($input['components']['storeListing'])) {
                $sl = $input['components']['storeListing'];
                $cleanSl = [];
                if (isset($sl['categoryHeader']) && in_array($sl['categoryHeader'], ['page-title', 'compact', 'hidden', 'with-lock-banner'], true)) {
                    $cleanSl['categoryHeader'] = $sl['categoryHeader'];
                }
                if (isset($sl['showCategoryDescription'])) {
                    $cleanSl['showCategoryDescription'] = (bool) $sl['showCategoryDescription'];
                }
                // Legacy all-in-one bar switch, still sanitized and stored:
                // it's the fallback each per-control flag inherits when absent.
                if (isset($sl['showProductFilterBar'])) {
                    $cleanSl['showProductFilterBar'] = (bool) $sl['showProductFilterBar'];
                }
                // Per-control flags for the bar (search box / Filter menu /
                // Sort dropdown). Only stored when the studio actually sent
                // them, so an untouched flag stays absent and keeps falling
                // back to showProductFilterBar on read.
                if (isset($sl['showProductSearch'])) {
                    $cleanSl['showProductSearch'] = (bool) $sl['showProductSearch'];
                }
                if (isset($sl['showProductFilter'])) {
                    $cleanSl['showProductFilter'] = (bool) $sl['showProductFilter'];
                }
                if (isset($sl['showProductSort'])) {
                    $cleanSl['showProductSort'] = (bool) $sl['showProductSort'];
                }
                if (isset($sl['defaultProductSort'])) {
                    // Strict whitelist: this string is consumed as a lookup
                    // key on the frontend, so anything outside the nine
                    // known sorts collapses to 'backend-order' (no client-
                    // side sort, the B360 backend's own order) rather than
                    // being stored as-is. Mirrors StoreProductSortKey in
                    // shared/theme/types.ts.
                    $validSorts = [
                        'backend-order',
                        'name-asc', 'name-desc',
                        'price-asc', 'price-desc',
                        'vintage-desc', 'vintage-asc',
                        'varietal-asc', 'newest',
                    ];
                    $cleanSl['defaultProductSort'] = in_array($sl['defaultProductSort'], $validSorts, true)
                        ? $sl['defaultProductSort']
                        : 'backend-order';
                }
                if (isset($sl['showCategoriesMenu'])) {
                    $cleanSl['showCategoriesMenu'] = (bool) $sl['showCategoriesMenu'];
                }
                // Stored as a STRING enum, not an int: 'auto' has to be a valid
                // value, and mixing 'auto' with numerics in one field invites
                // sloppy truthiness checks downstream.
                if (isset($sl['productColumns']) && in_array((string) $sl['productColumns'], ['auto', '2', '3', '4'], true)) {
                    $cleanSl['productColumns'] = (string) $sl['productColumns'];
                }
                if (isset($sl['lockedCategoryTreatment']) && in_array($sl['lockedCategoryTreatment'], ['inline-banner', 'icon-only', 'redirect'], true)) {
                    $cleanSl['lockedCategoryTreatment'] = $sl['lockedCategoryTreatment'];
                }
                if (!empty($cleanSl)) $comp['storeListing'] = $cleanSl;
            }
            if (isset($input['components']['loyalty']) && is_array($input['components']['loyalty'])) {
                $ly = $input['components']['loyalty'];
                $cleanLy = [];
                if (isset($ly['showEarnOnCatalog'])) {
                    $cleanLy['showEarnOnCatalog'] = (bool) $ly['showEarnOnCatalog'];
                }
                if (isset($ly['showEarnOnDetail'])) {
                    $cleanLy['showEarnOnDetail'] = (bool) $ly['showEarnOnDetail'];
                }
                if (!empty($cleanLy)) $comp['loyalty'] = $cleanLy;
            }
            if (isset($input['components']['clubDetail']) && is_array($input['components']['clubDetail'])) {
                $cd = $input['components']['clubDetail'];
                $cleanCd = [];
                if (isset($cd['showWineTypes'])) {
                    $cleanCd['showWineTypes'] = (bool) $cd['showWineTypes'];
                }
                if (!empty($cleanCd)) $comp['clubDetail'] = $cleanCd;
            }
            if (isset($input['components']['shipmentManifest']) && is_array($input['components']['shipmentManifest'])) {
                $sm = $input['components']['shipmentManifest'];
                $cleanSm = [];
                if (isset($sm['enabled']))    $cleanSm['enabled']    = (bool) $sm['enabled'];
                if (isset($sm['density']) && in_array($sm['density'], ['comfortable', 'compact'], true)) {
                    $cleanSm['density'] = $sm['density'];
                }
                if (isset($sm['dividers']))   $cleanSm['dividers']   = (bool) $sm['dividers'];
                if (isset($sm['thumbnails'])) $cleanSm['thumbnails'] = (bool) $sm['thumbnails'];
                if (isset($sm['addedLabel']) && is_string($sm['addedLabel'])) {
                    // Plain text only, trimmed, capped ~24 chars; empty falls back to 'Added'.
                    $label = trim(strip_tags($sm['addedLabel']));
                    $label = sanitize_text_field(substr($label, 0, 24));
                    $cleanSm['addedLabel'] = $label === '' ? 'Added' : $label;
                }
                // Accent for the Added tag: null (or empty) = inherit action-primary
                // via the var() fallback (emit no CSS var); else a valid colour.
                if (array_key_exists('addedColor', $sm)) {
                    if ($sm['addedColor'] === null || $sm['addedColor'] === '') {
                        $cleanSm['addedColor'] = null;
                    } elseif (is_string($sm['addedColor'])) {
                        $clean = self::sanitize_color_value($sm['addedColor']);
                        if ($clean !== null) $cleanSm['addedColor'] = $clean;
                    }
                }
                if (!empty($cleanSm)) $comp['shipmentManifest'] = $cleanSm;
            }
            if (isset($input['components']['expressPay']) && is_array($input['components']['expressPay'])) {
                $ep = $input['components']['expressPay'];
                $cleanEp = [];
                if (isset($ep['enabled']))     $cleanEp['enabled']     = (bool) $ep['enabled'];
                if (isset($ep['showDivider'])) $cleanEp['showDivider'] = (bool) $ep['showDivider'];
                if (isset($ep['buttonColor']) && in_array($ep['buttonColor'], ['auto', 'black', 'white'], true)) {
                    $cleanEp['buttonColor'] = $ep['buttonColor'];
                }
                if (isset($ep['buttonType']) && in_array($ep['buttonType'], ['buy', 'plain'], true)) {
                    $cleanEp['buttonType'] = $ep['buttonType'];
                }
                if (array_key_exists('dividerLabel', $ep) && is_string($ep['dividerLabel'])) {
                    // Plain text only, trimmed, capped ~40 chars. An empty label is
                    // KEPT as '' (it hides the divider, same as showDivider off),
                    // not snapped to a default, since a winery may want no label.
                    $label = trim(strip_tags($ep['dividerLabel']));
                    $cleanEp['dividerLabel'] = sanitize_text_field(substr($label, 0, 40));
                }
                if (!empty($cleanEp)) $comp['expressPay'] = $cleanEp;
            }
            if (!empty($comp)) $out['components'] = $comp;
        }

        if (isset($input['assets']) && is_array($input['assets'])) {
            $assets = [];
            if (isset($input['assets']['checkoutLogoUrl']) && is_string($input['assets']['checkoutLogoUrl'])) {
                $url = esc_url_raw(trim($input['assets']['checkoutLogoUrl']));
                if ($url !== '' || $input['assets']['checkoutLogoUrl'] === '') $assets['checkoutLogoUrl'] = $url;
            }
            if (isset($input['assets']['checkoutLogoLinkUrl']) && is_string($input['assets']['checkoutLogoLinkUrl'])) {
                $url = esc_url_raw(trim($input['assets']['checkoutLogoLinkUrl']));
                if ($url !== '' || $input['assets']['checkoutLogoLinkUrl'] === '') $assets['checkoutLogoLinkUrl'] = $url;
            }
            if (!empty($assets)) $out['assets'] = $assets;
        }

        if (isset($input['motion']) && is_array($input['motion'])) {
            $out['motion'] = self::sanitize_motion($input['motion']);
        }

        if (isset($input['_overrides']) && is_array($input['_overrides'])) {
            $overrides = [];
            foreach ($input['_overrides'] as $key) {
                if (is_string($key) && preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,40}$/', $key)) {
                    $overrides[] = $key;
                }
            }
            $out['_overrides'] = array_values(array_unique($overrides));
        }

        // Applied vibe / typography pair ids, short kebab-ish identifiers
        // stamped by the frontend when the user clicks a preset card. Either
        // a string up to 64 chars matching [a-z0-9-_], or null.
        if (array_key_exists('_appliedVibeId', $input)) {
            $out['_appliedVibeId'] = self::sanitize_preset_id($input['_appliedVibeId']);
        }
        if (array_key_exists('_appliedTypographyPairId', $input)) {
            $out['_appliedTypographyPairId'] = self::sanitize_preset_id($input['_appliedTypographyPairId']);
        }

        // Provenance enum, 'auto' | 'manual'. Anything else is dropped, so the
        // default ('manual') stands via deep_merge and an existing hand-tuned
        // theme is never silently downgraded by a malformed payload.
        if (isset($input['theme_source']) && in_array($input['theme_source'], ['auto', 'manual'], true)) {
            $out['theme_source'] = $input['theme_source'];
        }

        return $out;
    }

    /**
     * Sanitize the motion block. Unknown keys are silently dropped.
     * All fields default to null (omit-when-unset pattern).
     *
     * @param array $m
     * @return array
     */
    private static function sanitize_motion(array $m)
    {
        $out = [];

        if (array_key_exists('intensity', $m)) {
            if ($m['intensity'] === null || $m['intensity'] === '') {
                $out['intensity'] = null;
            } elseif (in_array($m['intensity'], ['calm', 'standard', 'lively'], true)) {
                $out['intensity'] = $m['intensity'];
            }
        }

        if (array_key_exists('reducedMotion', $m)) {
            if ($m['reducedMotion'] === null || $m['reducedMotion'] === '') {
                $out['reducedMotion'] = null;
            } elseif (in_array($m['reducedMotion'], ['respect-system', 'always-on', 'always-off'], true)) {
                $out['reducedMotion'] = $m['reducedMotion'];
            }
        }

        if (array_key_exists('routeTransition', $m)) {
            if ($m['routeTransition'] === null || $m['routeTransition'] === '') {
                $out['routeTransition'] = null;
            } elseif (in_array($m['routeTransition'], ['fade', 'slide', 'crossfade', 'none'], true)) {
                $out['routeTransition'] = $m['routeTransition'];
            }
        }

        if (array_key_exists('loadingStyle', $m)) {
            if ($m['loadingStyle'] === null || $m['loadingStyle'] === '') {
                $out['loadingStyle'] = null;
            } elseif (in_array($m['loadingStyle'], ['skeleton', 'spinner', 'inline-shimmer'], true)) {
                $out['loadingStyle'] = $m['loadingStyle'];
            }
        }

        if (array_key_exists('celebrationsEnabled', $m)) {
            if ($m['celebrationsEnabled'] === null) {
                $out['celebrationsEnabled'] = null;
            } else {
                $out['celebrationsEnabled'] = (bool) $m['celebrationsEnabled'];
            }
        }

        if (array_key_exists('baseDuration', $m)) {
            if ($m['baseDuration'] === null || $m['baseDuration'] === '') {
                $out['baseDuration'] = null;
            } else {
                $val = (int) $m['baseDuration'];
                if ($val >= 160 && $val <= 560) {
                    $out['baseDuration'] = $val;
                }
            }
        }

        return $out;
    }

    /**
     * Accept a kebab-case-ish preset id (a–z, 0–9, -, _) up to 64 chars,
     * or null. Anything else collapses to null.
     *
     * @param mixed $v
     * @return string|null
     */
    private static function sanitize_preset_id($v)
    {
        if ($v === null || $v === '') return null;
        if (!is_string($v)) return null;
        if (strlen($v) > 64) return null;
        if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $v)) return null;
        return $v;
    }

    /** Accept #RGB, #RRGGBB, rgb(...), rgba(...). Returns null when invalid. */
    private static function sanitize_color_value($v)
    {
        $v = trim((string) $v);
        if (preg_match('/^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/', $v)) {
            return $v;
        }
        if (preg_match('/^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(?:,\s*(?:0|1|0?\.\d+)\s*)?\)$/', $v)) {
            return $v;
        }
        return null;
    }

    /** Trim and bound a font stack to 240 chars; strip control characters. */
    /**
     * Validate an imported-web-fonts block.
     *
     * Deliberately strict: these values are interpolated into a stylesheet URL
     * (Assets.php) and into a CSS font-family declaration, so anything that is
     * not a plain family name or a numeric weight is dropped rather than escaped.
     * Google family names are letters, digits and spaces only, which is exactly
     * what the catalogue endpoint already filters on.
     */
    /**
     * The assignable roles. `h1`-`h6` are SEMANTIC LEVELS mapped onto the
     * storefront's heading primitives, not literal tag selectors, see
     * bridge-typography.css and the WebFontsConfig docblock in theme/types.ts.
     */
    public const WEB_FONT_ROLES = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'accent', 'body'];

    private static function sanitize_web_fonts($wf)
    {
        if (!is_array($wf)) return null;

        $provider = isset($wf['provider']) && $wf['provider'] === 'google' ? 'google' : 'none';

        $out = ['provider' => $provider];
        foreach (self::WEB_FONT_ROLES as $role) $out[$role] = null;

        // LEGACY: themes saved before the per-level importer carry a single
        // `heading` font. Migrate it onto H1-H3 only, see
        // LEGACY_HEADING_LEVELS for why h4-h6 are deliberately excluded. An
        // explicit per-level value below always wins over this.
        $legacy = null;
        if (isset($wf['heading']) && is_array($wf['heading'])) {
            $legacy = self::sanitize_web_font($wf['heading']);
        }
        if ($legacy !== null) {
            foreach (self::LEGACY_HEADING_LEVELS as $role) $out[$role] = $legacy;
        }

        foreach (self::WEB_FONT_ROLES as $role) {
            if (!isset($wf[$role]) || !is_array($wf[$role])) continue;
            $font = self::sanitize_web_font($wf[$role]);
            if ($font !== null) $out[$role] = $font;
        }

        // No usable selection anywhere means nothing to import.
        $any = false;
        foreach (self::WEB_FONT_ROLES as $role) {
            if ($out[$role] !== null) { $any = true; break; }
        }
        if (!$any) $out['provider'] = 'none';

        return $out;
    }

    /**
     * Validate ONE role's font: `{family, weights[], weight}`, or null if the
     * family is unusable.
     *
     * Enforces the invariant that the RENDER weight is also in the DOWNLOAD
     * list. Without it the browser synthesises a fake bold from whatever face
     * did load, which looks subtly wrong in a way that is very hard to
     * attribute back to a settings screen.
     */
    private static function sanitize_web_font($raw)
    {
        if (!is_array($raw)) return null;

        $family = isset($raw['family']) ? trim((string) $raw['family']) : '';
        if ($family === '' || strlen($family) > 80 || !preg_match('/^[A-Za-z0-9 ]+$/', $family)) {
            return null;
        }

        $weights = [];
        foreach ((array) ($raw['weights'] ?? []) as $w) {
            $w = (int) $w;
            // 100..900 in steps of 100, the CSS weight scale.
            if ($w >= 100 && $w <= 900 && $w % 100 === 0) $weights[] = $w;
        }
        $weights = array_values(array_unique($weights));
        sort($weights);
        if (empty($weights)) $weights = [400];
        // Cap the number of weights: each one is a real font file for visitors.
        if (count($weights) > 6) $weights = array_slice($weights, 0, 6);

        $weight = isset($raw['weight']) ? (int) $raw['weight'] : 0;
        if ($weight < 100 || $weight > 900 || $weight % 100 !== 0) {
            $weight = 0;
        }
        if ($weight === 0 || !in_array($weight, $weights, true)) {
            // Prefer 400 when it is being downloaded, else the lightest loaded face.
            $weight = in_array(400, $weights, true) ? 400 : $weights[0];
        }

        return ['family' => $family, 'weights' => $weights, 'weight' => $weight];
    }

    private static function sanitize_font_stack($v)
    {
        $v = preg_replace('/[\x00-\x1F\x7F]/', '', (string) $v);
        return sanitize_text_field(substr($v, 0, 240));
    }

    /** Accept CSS length-like values (number+unit, ch, %, vw, vh, calc(...)). */
    private static function sanitize_length($v)
    {
        $v = trim((string) $v);
        if ($v === '') return '';
        if (strlen($v) > 64) $v = substr($v, 0, 64);
        // Permissive: anything sanitize_text_field accepts that looks like a length.
        if (preg_match('/^[0-9a-zA-Z\s\.\,\-\+\*\/\(\)%]+$/', $v)) {
            return $v;
        }
        return '';
    }

    private static function deep_merge(array $base, array $overlay)
    {
        foreach ($overlay as $k => $v) {
            if (is_array($v) && isset($base[$k]) && is_array($base[$k])) {
                $base[$k] = self::deep_merge($base[$k], $v);
            } else {
                $base[$k] = $v;
            }
        }
        return $base;
    }
}
