<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class WalletController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/wallet/balance', [
            'methods'             => 'GET',
            'callback'            => [$this, 'balance'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/wallet/transactions', [
            'methods'             => 'GET',
            'callback'            => [$this, 'transactions'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/wallet/redemption-info', [
            'methods'             => 'GET',
            'callback'            => [$this, 'redemption_info'],
            'permission_callback' => '__return_true',
        ]);

        // My Account rewards tab + the web join (WR9, contract section 4).
        register_rest_route(self::NAMESPACE, '/wallet/loyalty-provider', [
            'methods'             => 'GET',
            'callback'            => [$this, 'loyalty_provider'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/wallet/loyalty-join', [
            'methods'             => 'POST',
            'callback'            => [$this, 'loyalty_join'],
            'permission_callback' => '__return_true',
        ]);

        // Account linking (design v2, BD-4915): one route each, nonce-checked as the join is.
        // The bridge token names the shopper; nothing here forwards a customer id or an address.
        register_rest_route(self::NAMESPACE, '/wallet/loyalty-link/start', [
            'methods'             => 'POST',
            'callback'            => [$this, 'loyalty_link_start'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/wallet/loyalty-link/verify', [
            'methods'             => 'POST',
            'callback'            => [$this, 'loyalty_link_verify'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/wallet/loyalty-link/move', [
            'methods'             => 'POST',
            'callback'            => [$this, 'loyalty_link_move'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/wallet/loyalty-link/resend', [
            'methods'             => 'POST',
            'callback'            => [$this, 'loyalty_link_resend'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/wallet/loyalty-unlink', [
            'methods'             => 'POST',
            'callback'            => [$this, 'loyalty_unlink'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function balance(WP_REST_Request $request)
    {
        return $this->proxy_get('wallet/balance');
    }

    public function transactions(WP_REST_Request $request)
    {
        return $this->proxy_get('wallet/transactions', [
            'page'     => absint($request->get_param('page') ?: 1),
            'per_page' => min(100, max(1, absint($request->get_param('per_page') ?: 20))),
        ]);
    }

    public function redemption_info(WP_REST_Request $request)
    {
        return $this->proxy_get('wallet/redemptionInfo', [
            'subtotal' => floatval($request->get_param('subtotal') ?: 0),
        ]);
    }

    public function loyalty_provider(WP_REST_Request $request)
    {
        return $this->proxy_get('wallet/loyaltyProvider');
    }

    public function loyalty_join(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $p = $request->get_json_params();
        // L8: JSON params are never slashed (no wp_unslash), and a non-string reads as empty.
        $str = static function ($v) { return is_string($v) ? $v : ''; };
        // Consent flags go through exactly as ticked (E3); nothing is defaulted on, and only a JSON true
        // is a tick (R10-B L4: the string "false" is no consent, as the server reads it).
        // No confirm_existing: the web has no link road (CONTRACT 4, SRV-G).
        return $this->proxy_post('wallet/loyaltyJoin', [
            'join'                  => ($p['join'] ?? null) === true,
            'email'                 => ($p['email'] ?? null) === true,
            'sms'                   => ($p['sms'] ?? null) === true,
            'phone'                 => sanitize_text_field($str($p['phone'] ?? null)),
            'consent_version'       => sanitize_text_field($str($p['consent_version'] ?? null)),
            'email_consent_version' => sanitize_text_field($str($p['email_consent_version'] ?? null)),
            'sms_consent_version'   => sanitize_text_field($str($p['sms_consent_version'] ?? null)),
        ]);
    }

    /** A JSON string param, sanitized; anything else reads as empty (L8: JSON is never slashed). */
    private static function json_str(array $p, string $key): string
    {
        $v = $p[$key] ?? null;
        return is_string($v) ? sanitize_text_field($v) : '';
    }

    /** The challenge id: a JSON string or integer, else empty. */
    private static function json_link_id(array $p): string
    {
        $v = $p['link_id'] ?? null;
        if (is_int($v)) return (string) $v;
        return is_string($v) ? sanitize_text_field($v) : '';
    }

    /** {program, phone}: phone '' = the number the account holds (as the join posts it). */
    public function loyalty_link_start(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $p = $request->get_json_params();
        $p = is_array($p) ? $p : [];
        return $this->proxy_post('wallet/loyaltyLinkStart', [
            'program' => self::json_str($p, 'program'),
            'phone'   => self::json_str($p, 'phone'),
        ]);
    }

    /** {link_id, code}: the code is digits only, at most 6 of them. */
    public function loyalty_link_verify(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $p = $request->get_json_params();
        $p = is_array($p) ? $p : [];
        $code = preg_replace('/\D+/', '', self::json_str($p, 'code'));
        return $this->proxy_post('wallet/loyaltyLinkVerify', [
            'link_id' => self::json_link_id($p),
            'code'    => substr((string) $code, 0, 6),
        ]);
    }

    public function loyalty_link_move(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $p = $request->get_json_params();
        $p = is_array($p) ? $p : [];
        return $this->proxy_post('wallet/loyaltyLinkMove', [
            'link_id' => self::json_link_id($p),
        ]);
    }

    public function loyalty_link_resend(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $p = $request->get_json_params();
        $p = is_array($p) ? $p : [];
        return $this->proxy_post('wallet/loyaltyLinkResend', [
            'link_id' => self::json_link_id($p),
        ]);
    }

    public function loyalty_unlink(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $p = $request->get_json_params();
        $p = is_array($p) ? $p : [];
        return $this->proxy_post('wallet/loyaltyUnlink', [
            'program' => self::json_str($p, 'program'),
        ]);
    }
}
