<?php

namespace Bottle360\Bridge\Routing;

use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * Routes sub-paths under the store base path to the SPA page
 * so Vue Router can handle client-side routing.
 */
final class AppRoute
{
    // Bumped to 4 to force a rewrite flush after the homepage-mount support
    // was removed, the old rule set may still contain the SPA_SEGMENTS
    // root pattern from installs that ran an earlier version.
    private const REWRITE_VERSION = 4;
    private const VERSION_OPTION  = 'b360_rewrite_version';

    /** Whether the visitor was signed in when the app page rendered (template_redirect). */
    private $authedAtRender = false;

    public function register(): void
    {
        // Inject our rule at the top of every compiled rule set. Using the
        // filter (vs. add_rewrite_rule) guarantees the rule survives every
        // flush, including flushes triggered by WP Engine or other plugins
        // at unpredictable times.
        add_filter('rewrite_rules_array', [$this, 'injectSpaRule']);
        add_action('init', [$this, 'maybeFlush'], 2);
        add_filter('document_title_parts', [$this, 'setTitle']);
        // Keep WP's canonical redirect from bouncing SPA subpaths back to the
        // app page's permalink, while still letting it fix the host (www vs
        // bare), otherwise the bundle is CORS-blocked on the wrong origin.
        add_filter('redirect_canonical', [$this, 'preventCanonicalRedirect'], 10, 2);
        // `page` is a reserved public query var in WP (the <!--nextpage-->
        // post paging). The SPA listing puts ?page=N in the URL, and since WP
        // 5.5 handle_404() turns a found page with ?page=N but no nextpage
        // marker into a 404, so a refresh of /store/?page=2 rendered the
        // theme's 404 template. Tell core the app page is never that case.
        add_filter('pre_handle_404', [$this, 'preemptPagedContent404'], 10, 2);
        // WP core hard-redirects /login, /admin, /dashboard to wp-login.php.
        // Unhook that so /login can reach our SPA when the store owns that slug.
        add_action('template_redirect', [$this, 'unhookAdminLoginRedirect'], 1);
        // The SPA page (and every sub-path: /store/checkout, /store/account…)
        // renders per-visitor state; stamp it uncacheable at the origin so no
        // page cache in front can share one visitor's page with the next.
        add_action('template_redirect', [$this, 'nocacheAppPage'], 0);
        // WP Rocket 3.19+ refuses to cache or optimize a page whose URL is not
        // the queried page's permalink. Every store sub-route resolves to the
        // app page, so /store/wine/... never cached. Vouch for catalog routes.
        add_filter('rocket_disable_url_validation', [$this, 'allowRocketOnAppRoutes']);
    }

    /**
     * Let WP Rocket cache and optimize the public catalog sub-routes for
     * anonymous visitors.
     *
     * Its URL validation compares the request to get_permalink() of the queried
     * page and, on a mismatch, skips both the cache file and the optimizations.
     * Our rewrite maps every sub-route to the app page on purpose, so the
     * check is a false positive for them. We vouch only for the catalog route
     * shapes (isCacheableStoreRoute): checkout, account, sign-in and any
     * unknown path keep the validation, so they stay uncached and unoptimized
     * as before, and a scanner hitting /store/<junk> cannot fill the cache.
     *
     * What keeps a member's page out of the cache is WP Rocket's rejected
     * cookie (wordpress_logged_in_.+ matches our wordpress_logged_in_b360
     * marker); it ignores Cache-Control when writing. As a second guard we
     * also refuse when the visitor was signed in when the page rendered or is
     * now (a session can expire mid-request after the nav already rendered).
     *
     * @param mixed $disabled
     * @return bool
     */
    public function allowRocketOnAppRoutes($disabled): bool
    {
        if ($disabled) return true;
        if (!$this->isAppPage()) return false;
        if ($this->authedAtRender || \Bottle360\Bridge\Api\BridgeSession::isAuthenticated()) return false;

        $sub = self::requestSubPath(
            (string) ($_SERVER['REQUEST_URI'] ?? ''),
            (string) (parse_url(home_url('/'), PHP_URL_PATH) ?: ''),
            Options::get_app_base_path()
        );
        return $sub !== null && self::isCacheableStoreRoute($sub);
    }

    /**
     * The request path below the store base ('' for the landing page), or null
     * when the request is not under it. Mirrors MetaTags::subPath().
     */
    public static function requestSubPath(string $requestUri, string $homePath, string $basePath): ?string
    {
        $uri      = (string) (parse_url($requestUri, PHP_URL_PATH) ?: '');
        $homePath = rtrim($homePath, '/');
        $basePath = rtrim($basePath, '/');
        if ($homePath !== '' && strpos($uri . '/', $homePath . '/') === 0) {
            $uri = substr($uri, strlen($homePath));
        }
        $uri = rtrim($uri, '/');
        if ($uri !== $basePath && strpos($uri, $basePath . '/') !== 0) return null;
        return trim(substr($uri, strlen($basePath)), '/');
    }

    /**
     * Public catalog routes whose HTML is the same for every anonymous visitor:
     * wine/<slug>/<vintageId>, product|bundle|collection/<slug>, clubs[/<slug>].
     * Mirrors the SPA router (shared/router/index.ts).
     */
    public static function isCacheableStoreRoute(string $sub): bool
    {
        return (bool) preg_match(
            '#^(?:wine/[^/]+/[1-9][0-9]*|(?:product|bundle|collection)/[^/]+|clubs(?:/[^/]+)?)$#',
            $sub
        );
    }

    /**
     * Build the SPA rewrite pattern + target. Returns [pattern, target] or
     * null when the plugin isn't ready (no app page).
     *
     * The SPA always lives under a dedicated sub-path (see
     * Options::get_app_base_path()), one rewrite maps every request under
     * that prefix to the app page, and Vue Router takes it from there.
     */
    private function buildRule(): ?array
    {
        $page_id = (int) get_option('b360_app_page_id', 0);
        if (!$page_id || get_post_status($page_id) !== 'publish') return null;

        $basePath = trim(Options::get_app_base_path(), '/');
        if ($basePath === '') return null;

        $rx = preg_quote($basePath, '/');
        return ['^' . $rx . '/(.+)/?$', 'index.php?page_id=' . $page_id];
    }

    public function injectSpaRule(array $rules): array
    {
        $rule = $this->buildRule();
        if ($rule === null) return $rules;
        [$pattern, $target] = $rule;
        // Prepend so our rule wins over WP's catch-all page rule.
        return [$pattern => $target] + $rules;
    }

    /**
     * Invalidate the compiled rewrite_rules option when our inputs change
     * (plugin version bump, app page id, or its URL path). WP will regenerate
     * the rules on the next request and our filter will contribute our rule.
     *
     * Deleting the option outright is more reliable on managed hosts (WPE,
     * Kinsta) than calling flush_rewrite_rules(), that function defers to
     * wp_loaded and sometimes its results don't propagate through their
     * object cache or nginx config refresh.
     */
    public function maybeFlush(): void
    {
        if ($this->buildRule() === null) return;

        $page_id = (int) get_option('b360_app_page_id', 0);
        $basePath = Options::get_app_base_path();
        $stamp = self::REWRITE_VERSION . ':' . $page_id . ':' . $basePath;

        if (get_option(self::VERSION_OPTION) === $stamp) return;

        delete_option('rewrite_rules');
        update_option(self::VERSION_OPTION, $stamp, true);
    }

    /**
     * WP core's `wp_redirect_admin_locations()` intercepts requests to
     * `/login`, `/admin`, `/dashboard`, `/wp-login`, `/wp-admin` and sends
     * them to wp-login.php. When the SPA owns a `/login` sub-path (e.g.
     * `/store/login`), suppress that behavior so the SPA can render its
     * own login view.
     */
    public function unhookAdminLoginRedirect(): void
    {
        $path = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
        if ($path === '') return;

        $basePath = trim(Options::get_app_base_path(), '/');
        if ($basePath === '') return;

        if ($path === $basePath || strpos($path, $basePath . '/') === 0) {
            remove_action('template_redirect', 'wp_redirect_admin_locations', 1000);
        }
    }

    /**
     * When WP has resolved the request to the app page, suppress canonical
     * redirects that would change the PATH, so sub-paths like /store/checkout/
     * stay put for the SPA to handle instead of bouncing to the page slug.
     *
     * A canonical redirect that only fixes the HOST (www vs bare) must still
     * happen (BD-4771). If it is suppressed, the page renders on the wrong
     * origin and loads the storefront bundle from plugins_url() on the home
     * host as a module script. Module scripts are fetched in CORS mode, the
     * asset carries no Access-Control-Allow-Origin, the browser blocks it and
     * the app never mounts ("Loading..." forever). In that case redirect to
     * the same path on the canonical host, see canonicalHostRedirect().
     *
     * @param string|false $redirect_url
     * @param string       $requested_url
     * @return string|false
     */
    public function preventCanonicalRedirect($redirect_url, $requested_url)
    {
        $page_id = (int) get_option('b360_app_page_id', 0);
        if (!$page_id) return $redirect_url;
        if (get_queried_object_id() !== $page_id) return $redirect_url;
        if (!is_string($redirect_url) || $redirect_url === '' || !is_string($requested_url)) return false;

        $target = self::canonicalHostRedirect($requested_url, $redirect_url);
        return $target ?? false;
    }

    /**
     * Pure decision for the app page's canonical redirect. No WordPress
     * dependencies, so wordpress/tests/canonical-host-redirect.php can run it
     * standalone.
     *
     * Returns null when the redirect must be suppressed: the requested
     * host:port already matches the one WP proposes, so the only thing WP
     * would change is the path or a trailing slash, which is the SPA sub-path
     * case. Otherwise returns the URL to redirect to, on WP's host:port, with
     * the requested scheme, path and query kept:
     *
     *  - host comes from $redirectUrl. WP core already applied its policy
     *    there (it only swaps www <-> bare, never an unrelated alias host, and
     *    forces the port of home_url()), so this inherits that policy and is
     *    no worse than core's own canonical redirect on any other page. On the
     *    hop after ours the host matches, so the helper returns null: the only
     *    fixed point is "no redirect".
     *  - scheme is never changed. Core never redirects on scheme in
     *    redirect_canonical() either; doing so here would loop behind a TLS
     *    terminator that does not surface the protocol to PHP (is_ssl() false)
     *    whenever WP proposes a same-host path change (the SPA's ?page=N
     *    listing URLs do that). A genuine http request also gets an http
     *    plugins_url(), so page and bundle share an origin and there is no
     *    CORS problem to fix on that axis.
     *  - path is the requested path. When $redirectUrl carries the same path
     *    modulo a trailing slash (percent-octet case ignored), WP's
     *    trailing-slash preference is kept. When WP stripped the sub-path
     *    (page permalink), it is put back. Other core normalisations (trailing
     *    punctuation, double slashes) are not reproduced; the next hop is on
     *    the right host and stays put.
     *  - query is the requested query. Args core would add itself (feed
     *    paged, name) are dropped; those branches do not apply to the app
     *    page.
     *  - a home URL with a path prefix (WP in a subdirectory) needs no special
     *    handling because only host:port is compared.
     *
     * @param string $requestedUrl Full URL of the current request.
     * @param string $redirectUrl  Canonical URL WP core proposes.
     * @return string|null Redirect target, or null to suppress the redirect.
     */
    public static function canonicalHostRedirect(string $requestedUrl, string $redirectUrl): ?string
    {
        $req = parse_url($requestedUrl);
        $to  = parse_url($redirectUrl);
        if (!is_array($req) || !is_array($to) || empty($req['host']) || empty($to['host'])) return null;

        $reqHost = strtolower($req['host']) . (isset($req['port']) ? ':' . $req['port'] : '');
        $toHost  = strtolower($to['host']) . (isset($to['port']) ? ':' . $to['port'] : '');
        if ($reqHost === $toHost) return null;

        $scheme  = strtolower((string) ($req['scheme'] ?? 'http'));
        $reqPath = (string) ($req['path'] ?? '/');
        $toPath  = (string) ($to['path'] ?? '');
        $path    = (self::foldPath($toPath) === self::foldPath($reqPath)) ? $toPath : $reqPath;
        if ($path === '') $path = '/';

        $url = $scheme . '://' . $to['host'] . (isset($to['port']) ? ':' . $to['port'] : '') . $path;
        if (isset($req['query']) && $req['query'] !== '') $url .= '?' . $req['query'];
        return $url;
    }

    /**
     * Comparison key for two URL paths: trailing slash ignored, percent-encoded
     * octets case-folded (core lowercases them in the requested URL only after
     * it has built its proposal).
     */
    private static function foldPath(string $path): string
    {
        $folded = preg_replace_callback('/%[0-9A-Fa-f]{2}/', static function (array $m): string {
            return strtolower($m[0]);
        }, $path);
        return rtrim((string) $folded, '/');
    }

    /**
     * Keep WP::handle_404() from 404ing the app page over the SPA's ?page=N
     * (BD-5067). Thin WordPress wrapper around shouldPreemptPagedContent404().
     *
     * A query some other plugin already marked 404 (for example a
     * $wp_query->set_404() in pre_get_posts while the queried object was
     * already memoized) still has non-empty posts and a matching id, and
     * preempting it would render the theme's 404 template with HTTP 200, so
     * it is passed through: we only ever skip core's paged-content check, we
     * never un-404.
     *
     * @param mixed $preempt  false unless an earlier filter already decided.
     * @param mixed $wp_query The WP_Query core passes along.
     * @return mixed
     */
    public function preemptPagedContent404($preempt, $wp_query)
    {
        if (!is_object($wp_query) || !method_exists($wp_query, 'get_queried_object_id') || !property_exists($wp_query, 'posts')) {
            return $preempt;
        }
        if (!empty($wp_query->is_404)) return $preempt;
        $page_id = (int) get_option('b360_app_page_id', 0);
        return self::shouldPreemptPagedContent404(
            $preempt,
            $page_id,
            (int) $wp_query->get_queried_object_id(),
            !empty($wp_query->posts)
        );
    }

    /**
     * Pure decision for the `pre_handle_404` filter on the app page. No
     * WordPress dependencies, so wordpress/tests/store-page-query-404.php can
     * run it standalone.
     *
     * `page` is a reserved public query var: core reads it as the
     * <!--nextpage--> post-paging index. The store listing paginates with
     * ?page=N, so a direct load, refresh, bookmark or shared link of
     * /store/?page=2 reaches WP::handle_404() with query_vars['page'] set.
     * Since WP 5.5 that method, for a singular query whose posts were found,
     * sets $content_found = false when the post's content carries no
     * <!--nextpage--> marker, and the request ends in $wp_query->set_404()
     * plus status_header(404): the theme's 404 template renders instead of
     * the [b360_app] shortcode. Client-side pagination never hits the server,
     * which is why it only shows on a cold load.
     *
     * Returning true from `pre_handle_404` makes handle_404() return before
     * any of its checks, so core never sets the 404 for that request and the
     * default 200 stands. That is safe here because it only happens when the
     * queried object IS the configured app page AND the query found posts:
     * the page exists and was resolved, so the only thing left for core to
     * 404 on is the paged-content check, which the SPA owns. No genuine
     * 404 is masked (a missing or unpublished page has no posts and falls
     * through to core), and no other page is touched (a different queried id
     * returns $preempt unchanged).
     *
     * @param mixed $preempt   The filter's current value. Anything but false
     *                         means another plugin already decided; pass it on.
     * @param int   $appPageId The configured app page id (0 when unset).
     * @param int   $queriedId The queried object id of the request.
     * @param bool  $hasPosts  Whether the query found posts.
     * @return mixed true to skip core's handler, otherwise $preempt.
     */
    public static function shouldPreemptPagedContent404($preempt, int $appPageId, int $queriedId, bool $hasPosts)
    {
        if ($preempt !== false) return $preempt;
        if ($appPageId > 0 && $queriedId === $appPageId && $hasPosts) return true;
        return $preempt;
    }

    /**
     * Cache-Control: no-store (+ Pragma/Expires) on the app page, for a
     * LOGGED-IN visitor only. The app page HTML is identical for every anonymous
     * visitor (everything per-user is fetched as JSON), so it stays page-
     * cacheable for them; a logged-in visitor already carries the standard-
     * named marker cookie that makes page caches bypass, and this header is the
     * belt to that braces. Runs at template_redirect priority 0, before the
     * theme emits a byte, so the headers actually go out.
     */
    public function nocacheAppPage(): void
    {
        if (!$this->isAppPage()) return;
        $this->authedAtRender = \Bottle360\Bridge\Api\BridgeSession::isAuthenticated();
        if (!$this->authedAtRender) return;
        nocache_headers();
        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
            header('X-Accel-Expires: 0');
        }
    }

    /**
     * Check if the current request is for the B360 app page.
     */
    private function isAppPage(): bool
    {
        $page_id = (int) get_option('b360_app_page_id', 0);
        if (!$page_id) return false;

        return is_page($page_id);
    }

    public function setTitle(array $title): array
    {
        if (!$this->isAppPage()) {
            return $title;
        }

        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
        $basePath = Options::get_app_base_path();
        // Anchored prefix strip (str_replace would also hit mid-URL matches).
        $path = strpos($uri, $basePath) === 0 ? substr($uri, strlen($basePath)) : $uri;
        $segment = explode('/', trim((string) $path, '/'))[0] ?? '';

        $title['title'] = SpaRoutes::titleFor($segment);
        return $title;
    }
}
