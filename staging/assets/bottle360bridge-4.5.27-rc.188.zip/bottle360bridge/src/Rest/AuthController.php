<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Api\BridgeApiClient;
use Bottle360\Bridge\Api\BridgeSession;
use Bottle360\Bridge\Settings\Options;
use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class AuthController extends RestBase
{
    /** Sign-in options answer (BD-5253), remembered per site and per backend. */
    private const SIGNIN_OPTIONS_TRANSIENT = 'b360_signin_options_';
    private const SIGNIN_OPTIONS_TTL = 600; // 10 min: a winery switching the email on or off shows within that.

    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/auth/login', [
            'methods'             => 'POST',
            'callback'            => [$this, 'login'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/register', [
            'methods'             => 'POST',
            'callback'            => [$this, 'do_register'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/logout', [
            'methods'             => 'POST',
            'callback'            => [$this, 'logout'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/profile', [
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'get_profile'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods'             => 'POST',
                'callback'            => [$this, 'update_profile'],
                'permission_callback' => '__return_true',
            ],
        ]);

        register_rest_route(self::NAMESPACE, '/auth/change-password', [
            'methods'             => 'POST',
            'callback'            => [$this, 'change_password'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/forgot-password', [
            'methods'             => 'POST',
            'callback'            => [$this, 'forgot_password'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/reset-password', [
            'methods'             => 'POST',
            'callback'            => [$this, 'reset_password'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/request-claim', [
            'methods'             => 'POST',
            'callback'            => [$this, 'request_claim'],
            'permission_callback' => '__return_true',
        ]);

        // BD-5253: sign in with an emailed code or link.
        register_rest_route(self::NAMESPACE, '/auth/sign-in-options', [
            'methods'             => 'GET',
            'callback'            => [$this, 'sign_in_options'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/request-login-code', [
            'methods'             => 'POST',
            'callback'            => [$this, 'request_login_code'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/verify-login-code', [
            'methods'             => 'POST',
            'callback'            => [$this, 'verify_login_code'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/resend-login-link', [
            'methods'             => 'POST',
            'callback'            => [$this, 'resend_login_link'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function login(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $form = $params['form'] ?? $params;

        $username = sanitize_text_field(wp_unslash($form['UserLogin[username]'] ?? $form['username'] ?? ''));
        $password = $form['UserLogin[password]'] ?? $form['password'] ?? '';

        if ($username === '' || $password === '') {
            return $this->error('Username and password are required.', 422);
        }

        $client = BridgeApiClient::instance();
        $result = $client->post('auth/login', [
            'username' => $username,
            'password' => $password,
        ], $this->withRecaptcha($request));

        if ($result['ok'] && isset($result['data']['token'])) {
            BridgeSession::setToken(
                $result['data']['token'],
                $result['data']['expires_at'] ?? ''
            );
            BridgeSession::setAuthenticated(true);

            return $this->success([
                'message' => 'Login successful',
                'user'    => $result['data']['user'] ?? [],
            ]);
        }

        return $this->proxy_error($result, 'Login failed', 401);
    }

    public function do_register(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $form = $params['form'] ?? $params;

        $client = BridgeApiClient::instance();
        $result = $client->post('auth/register', [
            'email'      => sanitize_email(wp_unslash($form['CustomerRegistrationForm[email]'] ?? $form['email'] ?? '')),
            'password'   => $form['CustomerRegistrationForm[password]'] ?? $form['password'] ?? '',
            'first_name' => sanitize_text_field(wp_unslash($form['Profile[firstname]'] ?? $form['firstname'] ?? $form['first_name'] ?? '')),
            'last_name'  => sanitize_text_field(wp_unslash($form['Profile[lastname]'] ?? $form['lastname'] ?? $form['last_name'] ?? '')),
            'phone'      => sanitize_text_field(wp_unslash($form['phone'] ?? '')),
            'dob'        => sanitize_text_field(wp_unslash($form['Profile[birthdate]'] ?? $form['dob'] ?? '')),
            'timezone'   => sanitize_text_field(wp_unslash($form['CustomerRegistrationForm[timezone]'] ?? $form['timezone'] ?? '')),
            'company'    => sanitize_text_field(wp_unslash($form['company'] ?? '')),
            'marketing_opt_in' => !empty($form['marketing_opt_in']) ? 1 : 0,
        ], $this->withRecaptcha($request));

        if ($result['ok'] && isset($result['data']['token'])) {
            BridgeSession::setToken(
                $result['data']['token'],
                $result['data']['expires_at'] ?? ''
            );
            BridgeSession::setAuthenticated(true);

            return $this->success([
                'message' => 'Registration successful',
                'user'    => $result['data']['user'] ?? [],
            ]);
        }

        return $this->proxy_error($result, 'Registration failed', 422);
    }

    public function logout(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        BridgeApiClient::instance()->post('auth/logout');

        BridgeSession::setAuthenticated(false);
        BridgeSession::clearToken();

        return $this->success(['message' => 'Logged out']);
    }

    public function get_profile(WP_REST_Request $request)
    {
        $client = BridgeApiClient::instance();
        $result = $client->get('auth/profile');

        if ($result['ok']) {
            return $this->success(['user' => $result['data']]);
        }

        return $this->proxy_error($result, 'Not authenticated', 401);
    }

    public function update_profile(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $body = [];

        if (isset($params['email'])) {
            $body['email'] = sanitize_email(wp_unslash($params['email']));
        }
        foreach (['first_name', 'last_name', 'company', 'dob'] as $f) {
            if (isset($params[$f])) {
                $body[$f] = sanitize_text_field(wp_unslash($params[$f]));
            }
        }

        $client = BridgeApiClient::instance();
        $result = $client->post('auth/updateProfile', $body);

        if ($result['ok']) {
            return $this->success(['user' => $result['data']]);
        }

        return $this->proxy_error($result, 'Failed to update profile', 500);
    }

    public function change_password(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $currentPassword = wp_unslash($params['current_password'] ?? '');
        $newPassword = wp_unslash($params['new_password'] ?? '');

        if ($currentPassword === '' || $newPassword === '') {
            return $this->error('Current and new password are required', 422);
        }

        $client = BridgeApiClient::instance();
        $result = $client->post('auth/changePassword', [
            'current_password' => $currentPassword,
            'new_password'     => $newPassword,
        ]);

        if ($result['ok']) {
            return $this->success(['message' => 'Password changed successfully']);
        }

        return $this->proxy_error($result, 'Failed to change password', 500);
    }

    public function forgot_password(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $email = sanitize_email(wp_unslash($params['email'] ?? ''));

        if ($email === '') {
            return $this->error('Email is required', 422);
        }

        $return_url = home_url(Options::get_app_base_path() . '/recovery/reset');
        $result = BridgeApiClient::instance()->post('auth/forgotPassword', [
            'email'      => $email,
            'return_url' => $return_url,
        ], $this->withRecaptcha($request));

        if (!$result['ok']) {
            return $this->proxy_error($result, 'Failed to send recovery email.', 500);
        }

        return $this->success(['message' => 'If that email exists, a recovery link has been sent.']);
    }

    /**
     * Confirmation-page "create an account" offer after a passwordless guest
     * order. Mirrors forgot_password: same nonce gate, same reCAPTCHA
     * forwarding, same return_url (the claim link lands on the SPA's recovery
     * page to set a password). The core always answers { email_sent: true } and
     * only actually sends for a passwordless bridge-guest shell, so the reply
     * never reveals whether an email has an account or order history.
     */
    public function request_claim(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $email = sanitize_email(wp_unslash($params['email'] ?? ''));

        if ($email === '') {
            return $this->error('Email is required', 422);
        }

        $return_url = home_url(Options::get_app_base_path() . '/recovery/reset');
        $result = BridgeApiClient::instance()->post('auth/requestClaim', [
            'email'      => $email,
            'return_url' => $return_url,
        ], $this->withRecaptcha($request));

        if (!$result['ok']) {
            return $this->proxy_error($result, 'Failed to send the account link.', 500);
        }

        return $this->success(['email_sent' => true]);
    }

    /**
     * Which sign-in methods this store offers (BD-5253). Today one flag,
     * `signin_code`: true when the winery's sign-in code email is switched on.
     *
     * This runs on every sign-in page view and dialog open, so the answer is
     * kept in a transient. A core from before the route answers 404: that is
     * "off", answered here and kept out of the API Error Log, which would
     * otherwise take an option write per view. Only a definite answer is
     * remembered (a 200, or that 404). A transport failure or a 5xx is passed
     * on as the error it is and asked again next time.
     */
    public function sign_in_options(WP_REST_Request $request)
    {
        $key = self::SIGNIN_OPTIONS_TRANSIENT . md5(Options::get_base_url());
        $cached = get_transient($key);
        if (is_array($cached) && array_key_exists('signin_code', $cached)) {
            return $this->success(['signin_code' => $cached['signin_code'] === true]);
        }

        // link_url tells core where this store's sign-in link page is, so
        // club and campaign emails sent from the admin can link members here.
        $result = BridgeApiClient::instance()->get(
            'auth/signInOptions',
            ['link_url' => home_url(Options::get_app_base_path() . '/signin/link')],
            ['quiet_statuses' => [404]]
        );

        if ($result['ok']) {
            $answer = ['signin_code' => is_array($result['data'] ?? null) && ($result['data']['signin_code'] ?? null) === true];
        } elseif ((int) ($result['status'] ?? 0) === 404) {
            $answer = ['signin_code' => false];
        } else {
            return $this->proxy_error($result, 'Request failed', 500);
        }

        set_transient($key, $answer, self::SIGNIN_OPTIONS_TTL);

        return $this->success($answer);
    }

    /**
     * Email a sign-in code and link (BD-5253). Mirrors forgot_password: same
     * nonce gate and reCAPTCHA forwarding, and a return_url on this store.
     * Here it is the SPA page the emailed link opens (/signin/link); core
     * appends the token to it. Core answers { sent: true } whether or not the
     * address has an account.
     *
     * Exactly email, return_url and next go upstream. `next` is the store
     * route to land on after the link signs the member in; anything that is
     * not a plain in-store path is dropped here (core checks it again).
     */
    public function request_login_code(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $email = sanitize_email(self::string_param($params, 'email'));

        if ($email === '') {
            return $this->error('Enter a valid email address.', 422, 'MISSING_EMAIL');
        }

        $body = [
            'email'      => $email,
            'return_url' => home_url(Options::get_app_base_path() . '/signin/link'),
        ];
        $next = self::string_param($params, 'next');
        if (self::is_store_route($next)) {
            $body['next'] = $next;
        }

        $result = BridgeApiClient::instance()->post('auth/requestLoginCode', $body, $this->withRecaptcha($request));

        if (!$result['ok']) {
            return $this->proxy_error($result, 'We could not send a sign-in code. Please try again.', 500);
        }

        return $this->success(['sent' => true]);
    }

    /**
     * The emailed link no longer works (BD-5253): core emails a fresh code and
     * link to the account the old link was sent for, landing on the same
     * route. Answers { sent: bool }. Same nonce gate as the other code routes.
     *
     * Exactly token and return_url go upstream. A token that is not 64 hex
     * never leaves this server.
     */
    public function resend_login_link(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $token = strtolower(self::string_param($params, 'token'));
        if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
            return $this->success(['sent' => false]);
        }

        $result = BridgeApiClient::instance()->post('auth/resendLoginLink', [
            'token'      => $token,
            'return_url' => home_url(Options::get_app_base_path() . '/signin/link'),
        ], $this->withRecaptcha($request));

        if (!$result['ok']) {
            return $this->proxy_error($result, 'We could not send a new link. Please try again.', 500);
        }

        return $this->success(['sent' => is_array($result['data'] ?? null) && ($result['data']['sent'] ?? null) === true]);
    }

    /**
     * Trade a sign-in code (email + code) or an emailed link's token for a
     * signed-in session (BD-5253). On success this is the login handler: the
     * bridge token goes into the session cookie, never to the browser, the
     * session is marked signed in and any checkout-shell state ends. `next`
     * rides back when core stored one with the code.
     *
     * Exactly token, or email and code, go upstream. A token wins when both
     * are sent.
     */
    public function verify_login_code(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $token = sanitize_text_field(self::string_param($params, 'token'));
        $email = sanitize_email(self::string_param($params, 'email'));
        $code  = (string) preg_replace('/\D+/', '', self::string_param($params, 'code'));

        if ($token !== '' && $code !== '') {
            // The code from the fresh email a dead link's page asked for; the
            // old token tells core whose code it is (the page has no email).
            $body = ['token' => $token, 'code' => $code];
        } elseif ($token !== '') {
            $body = ['token' => $token];
        } elseif ($email !== '' && $code !== '') {
            $body = ['email' => $email, 'code' => $code];
        } else {
            return $this->error('That code is not valid or has expired. Request a new one.', 400, 'INVALID_LOGIN_CODE');
        }

        $result = BridgeApiClient::instance()->post('auth/verifyLoginCode', $body, $this->withRecaptcha($request));

        if ($result['ok'] && isset($result['data']['token'])) {
            BridgeSession::setToken(
                $result['data']['token'],
                $result['data']['expires_at'] ?? ''
            );
            BridgeSession::setAuthenticated(true);

            $data = [
                'message' => 'Login successful',
                'user'    => $result['data']['user'] ?? [],
            ];
            $next = $result['data']['next'] ?? '';
            $next = is_string($next) ? trim($next) : '';
            if (self::is_store_route($next)) {
                $data['next'] = $next;
            }

            return $this->success($data);
        }

        return $this->proxy_error($result, 'That code is not valid or has expired. Request a new one.', 400);
    }

    /**
     * A JSON body value as a trimmed string; '' when absent or not a string.
     * Not unslashed: a decoded JSON body was never slashed, and stripping
     * backslashes would turn `/\evil.example` into a route that passes.
     */
    private static function string_param($params, string $key): string
    {
        if (!is_array($params) || !isset($params[$key]) || !is_string($params[$key])) {
            return '';
        }
        return trim($params[$key]);
    }

    /** A route inside the store: one leading slash, no second slash or backslash after it, no control characters. */
    private static function is_store_route(string $route): bool
    {
        return preg_match('#^/(?![/\\\\])[^\x00-\x1f\x7f]*\z#', $route) === 1 && strlen($route) <= 255;
    }

    public function reset_password(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params       = $request->get_json_params();
        $email        = sanitize_email(wp_unslash($params['email'] ?? ''));
        $activkey     = sanitize_text_field(wp_unslash($params['activkey'] ?? ''));
        $new_password = $params['new_password'] ?? '';

        if ($email === '' || $activkey === '' || $new_password === '') {
            return $this->error('Email, activation key, and new password are required.', 422);
        }

        $result = BridgeApiClient::instance()->post('auth/resetPassword', [
            'email'        => $email,
            'activkey'     => $activkey,
            'new_password' => $new_password,
        ], $this->withRecaptcha($request));

        if ($result['ok']) {
            if (!empty($result['data']['token'])) {
                BridgeSession::setToken(
                    $result['data']['token'],
                    $result['data']['expires_at'] ?? ''
                );
                BridgeSession::setAuthenticated(true);
            }

            return $this->success([
                'password_reset' => true,
                'user'           => $result['data']['user'] ?? null,
            ]);
        }

        return $this->proxy_error($result, 'Failed to reset password', 500);
    }
}
