<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class ClubController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/clubs', [
            'methods'             => 'GET',
            'callback'            => [$this, 'list_clubs'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/join', [
            'methods'             => 'POST',
            'callback'            => [$this, 'join_club'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/memberships', [
            'methods'             => 'GET',
            'callback'            => [$this, 'list_memberships'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/cancel-reasons', [
            'methods'             => 'GET',
            'callback'            => [$this, 'cancel_reasons'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/upcoming-shipments', [
            'methods'             => 'GET',
            'callback'            => [$this, 'upcoming_shipments'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/pickup-locations', [
            'methods'             => 'GET',
            'callback'            => [$this, 'pickup_locations'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/memberships/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'membership_detail'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/memberships/(?P<id>\d+)/pause', [
            'methods'             => 'POST',
            'callback'            => [$this, 'pause_membership'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/memberships/(?P<id>\d+)/resume', [
            'methods'             => 'POST',
            'callback'            => [$this, 'resume_membership'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/memberships/(?P<id>\d+)/cancel', [
            'methods'             => 'POST',
            'callback'            => [$this, 'cancel_membership'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/memberships/(?P<id>\d+)/edit', [
            'methods'             => 'POST',
            'callback'            => [$this, 'edit_membership'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/memberships/(?P<id>\d+)/shipment-history', [
            'methods'             => 'GET',
            'callback'            => [$this, 'shipment_history'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/memberships/(?P<id>\d+)/billing-history', [
            'methods'             => 'GET',
            'callback'            => [$this, 'billing_history'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/shipments/(?P<csu_id>\d+)/customization', [
            'methods'             => 'GET',
            'callback'            => [$this, 'shipment_customization'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/shipments/(?P<csu_id>\d+)/customization/items', [
            'methods'             => 'POST',
            'callback'            => [$this, 'shipment_customization_item'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/shipments/(?P<csu_id>\d+)/customization/note', [
            'methods'             => 'POST',
            'callback'            => [$this, 'shipment_customization_note'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/shipments/(?P<csu_id>\d+)/customization/addons', [
            'methods'             => 'GET',
            'callback'            => [$this, 'shipment_customization_addons'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/shipments/(?P<csu_id>\d+)/customization/submit', [
            'methods'             => 'POST',
            'callback'            => [$this, 'shipment_customization_submit'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/clubs/(?P<id_or_slug>[a-zA-Z0-9_-]+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'club_detail'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function list_clubs(WP_REST_Request $request)
    {
        return $this->proxy_get('club/list', [], ['cache' => 300]);
    }

    public function club_detail(WP_REST_Request $request)
    {
        $idOrSlug = $request->get_param('id_or_slug');

        if (ctype_digit($idOrSlug)) {
            $params = ['club_id' => (int) $idOrSlug];
        } else {
            $params = ['seo_url' => sanitize_title($idOrSlug)];
        }

        return $this->proxy_get('club/detail', $params, ['cache' => 300]);
    }

    public function join_club(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $clubId = (int) ($params['club_id'] ?? 0);
        $optionId = (int) ($params['option_id'] ?? 0);

        if ($clubId <= 0 || $optionId <= 0) {
            return $this->error('club_id and option_id are required', 400);
        }

        $body = ['club_id' => $clubId, 'option_id' => $optionId];

        if (isset($params['address_id'])) {
            $body['address_id'] = (int) $params['address_id'];
        }
        if (isset($params['shipping_address_id'])) {
            // Explicit "Ship to" choice from the join card. The Yii side reads
            // shipping_address_id first; without this it silently fell back to
            // the member's primary address.
            $body['shipping_address_id'] = absint($params['shipping_address_id']);
        }
        if (isset($params['shipment_type'])) {
            $type = sanitize_text_field(wp_unslash($params['shipment_type']));
            if (in_array($type, ['delivery', 'pickup'], true)) {
                $body['shipment_type'] = $type;
            }
        }
        if (isset($params['pickup_location_id'])) {
            $body['pickup_location_id'] = absint($params['pickup_location_id']);
        }
        if (isset($params['note'])) {
            $body['note'] = sanitize_textarea_field(wp_unslash($params['note']));
        }
        // Contact fields for a member with no saved address: club/join mints an
        // address row from the join payload and requires email/phone/dob for it
        // (issue #27). Same field set AddressController forwards on create.
        // Forward only when non-empty so we never send blank strings.
        $contactFields = ['email', 'phone', 'dob', 'first_name', 'last_name'];
        foreach ($contactFields as $f) {
            if (isset($params[$f])) {
                $value = sanitize_text_field(wp_unslash($params[$f]));
                if ($value !== '') {
                    $body[$f] = $value;
                }
            }
        }
        if (isset($params['billing_id'])) {
            $body['billing_id'] = sanitize_text_field(wp_unslash($params['billing_id']));
        }
        if (isset($params['payment_token'])) {
            $body['payment_token'] = sanitize_text_field(wp_unslash($params['payment_token']));
        }

        return $this->proxy_post('club/join', $body, $this->withRecaptcha($request));
    }

    public function list_memberships(WP_REST_Request $request)
    {
        return $this->proxy_get('club/memberships');
    }

    public function membership_detail(WP_REST_Request $request)
    {
        $id = absint($request->get_param('id'));
        return $this->proxy_get('club/membershipDetail', ['membership_id' => $id]);
    }

    public function pause_membership(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $id = absint($request->get_param('id'));
        return $this->proxy_post('club/pause', ['membership_id' => $id]);
    }

    public function resume_membership(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $id = absint($request->get_param('id'));
        return $this->proxy_post('club/resume', ['membership_id' => $id]);
    }

    public function cancel_membership(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $id = absint($request->get_param('id'));
        $params = $request->get_json_params();
        $cancelReasonId = absint($params['cancel_reason_id'] ?? 0);

        return $this->proxy_post('club/cancel', [
            'membership_id'    => $id,
            'cancel_reason_id' => $cancelReasonId,
        ]);
    }

    public function edit_membership(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $id = absint($request->get_param('id'));
        $params = $request->get_json_params();

        $body = ['membership_id' => $id];

        if (isset($params['billing_address_id'])) {
            $body['billing_address_id'] = absint($params['billing_address_id']);
        }
        if (isset($params['shipping_address_id'])) {
            $body['shipping_address_id'] = absint($params['shipping_address_id']);
        }
        if (isset($params['shipment_type'])) {
            $type = sanitize_text_field($params['shipment_type']);
            if (in_array($type, ['delivery', 'pickup'], true)) {
                $body['shipment_type'] = $type;
            }
        }
        if (isset($params['pickup_location_id'])) {
            $body['pickup_location_id'] = absint($params['pickup_location_id']);
        }
        if (isset($params['billing_id'])) {
            $body['billing_id'] = sanitize_text_field(wp_unslash($params['billing_id']));
        }

        return $this->proxy_post('club/edit', $body);
    }

    public function cancel_reasons(WP_REST_Request $request)
    {
        return $this->proxy_get('club/cancelReasons', [], ['cache' => 3600]);
    }

    public function upcoming_shipments(WP_REST_Request $request)
    {
        return $this->proxy_get('club/upcomingShipments', [
            'page'     => absint($request->get_param('page') ?: 1),
            'per_page' => min(100, max(1, absint($request->get_param('per_page') ?: 20))),
        ]);
    }

    public function shipment_history(\WP_REST_Request $request)
    {
        $id = absint($request->get_param('id'));
        return $this->proxy_get('club/shipmentHistory', [
            'membership_id' => $id,
            'page'          => absint($request->get_param('page') ?: 1),
            'per_page'      => min(100, max(1, absint($request->get_param('per_page') ?: 20))),
        ]);
    }

    public function billing_history(\WP_REST_Request $request)
    {
        $id = absint($request->get_param('id'));
        return $this->proxy_get('club/billingHistory', [
            'membership_id' => $id,
            'page'          => absint($request->get_param('page') ?: 1),
            'per_page'      => min(100, max(1, absint($request->get_param('per_page') ?: 20))),
        ]);
    }

    public function pickup_locations(WP_REST_Request $request)
    {
        return $this->proxy_get('club/pickupLocations', [], ['cache' => 3600]);
    }

    public function shipment_customization(WP_REST_Request $request)
    {
        $csuId = absint($request->get_param('csu_id'));
        return $this->proxy_get('club/shipmentCustomization', [
            'shipment_user_id' => $csuId,
        ]);
    }

    public function shipment_customization_item(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $csuId = absint($request->get_param('csu_id'));
        $params = $request->get_json_params();

        $action = sanitize_text_field(wp_unslash($params['action'] ?? ''));
        if (!in_array($action, ['set_qty', 'remove', 'add'], true)) {
            return $this->error('action must be set_qty, remove, or add', 400, 'INVALID_ACTION');
        }

        $body = [
            'shipment_user_id' => $csuId,
            'action'           => $action,
            'sku'              => sanitize_text_field(wp_unslash($params['sku'] ?? '')),
        ];
        if (isset($params['quantity'])) {
            $body['quantity'] = (int) $params['quantity'];
        }

        return $this->proxy_post('club/shipmentCustomizationItem', $body);
    }

    public function shipment_customization_note(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $csuId = absint($request->get_param('csu_id'));
        $params = $request->get_json_params();

        return $this->proxy_post('club/shipmentCustomizationNote', [
            'shipment_user_id' => $csuId,
            'note'             => sanitize_textarea_field(wp_unslash($params['note'] ?? '')),
        ]);
    }

    public function shipment_customization_addons(WP_REST_Request $request)
    {
        $csuId = absint($request->get_param('csu_id'));
        return $this->proxy_get('club/shipmentCustomizationAddons', [
            'shipment_user_id' => $csuId,
        ]);
    }

    public function shipment_customization_submit(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $csuId = absint($request->get_param('csu_id'));
        $params = $request->get_json_params();

        $body = ['shipment_user_id' => $csuId];

        if (isset($params['billing_address_id'])) {
            $body['billing_address_id'] = absint($params['billing_address_id']);
        }
        if (isset($params['shipping_address_id'])) {
            $body['shipping_address_id'] = absint($params['shipping_address_id']);
        }
        if (isset($params['shipment_type'])) {
            $type = sanitize_text_field(wp_unslash($params['shipment_type']));
            if (in_array($type, ['delivery', 'pickup'], true)) {
                $body['shipment_type'] = $type;
            }
        }
        if (isset($params['pickup_location_id'])) {
            $body['pickup_location_id'] = absint($params['pickup_location_id']);
        }
        if (isset($params['billing_id'])) {
            $body['billing_id'] = sanitize_text_field(wp_unslash($params['billing_id']));
        }
        if (isset($params['payment_token'])) {
            $body['payment_token'] = sanitize_text_field(wp_unslash($params['payment_token']));
        }
        if (isset($params['requested_ship_date'])) {
            $rsd = sanitize_text_field(wp_unslash($params['requested_ship_date']));
            // Y-m-d, or empty string to clear. Anything else is dropped here;
            // the Yii service format-validates again.
            if ($rsd === '' || preg_match('/^\d{4}-\d{2}-\d{2}$/', $rsd)) {
                $body['requested_ship_date'] = $rsd;
            }
        }
        if (isset($params['apply_to_future'])) {
            // Strict identity — a malformed client sending the string "false"
            // must not silently propagate fulfillment to all future shipments.
            $body['apply_to_future'] = $params['apply_to_future'] === true;
        }

        return $this->proxy_post('club/shipmentCustomizationSubmit', $body);
    }
}
