<?php

namespace Bottle360\Bridge\Seo;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Api\BridgeApiClient;
use Bottle360\Bridge\Routing\SpaRoutes;

if (!defined('ABSPATH')) exit;

/**
 * Outputs SEO meta tags (description, Open Graph, Twitter Card, canonical)
 * for the B360 app page on initial page load.
 *
 * For product and club detail pages the Bridge API is called (with transient
 * caching) so crawlers see real titles, descriptions, and images in the HTML
 * head — even though the Vue SPA hasn't mounted yet.
 */
final class MetaTags
{
    /** @var array|null Cached meta for the current request (computed once). */
    private ?array $meta = null;

    public function register(): void
    {
        add_action('wp_head', [$this, 'render'], 1);
        add_filter('get_canonical_url', [$this, 'filterCanonical'], 10, 2);
        add_filter('document_title_parts', [$this, 'filterTitle'], 20);
    }

    /**
     * Override the <title> tag for dynamic pages (products, clubs, collections).
     *
     * Runs at priority 20 so it overrides AppRoute::setTitle (priority 10).
     */
    public function filterTitle(array $title): array
    {
        if (!$this->isAppPage()) return $title;

        $meta = $this->resolveMeta();
        if (!empty($meta['title'])) {
            $title['title'] = $meta['title'];
        }

        return $title;
    }

    public function render(): void
    {
        if (!$this->isAppPage()) return;

        $meta = $this->resolveMeta();
        if (empty($meta)) return;

        $siteName = get_bloginfo('name');

        if (!empty($meta['description'])) {
            echo '<meta name="description" content="' . esc_attr($meta['description']) . '" />' . "\n";
        }

        // Open Graph
        echo '<meta property="og:site_name" content="' . esc_attr($siteName) . '" />' . "\n";
        echo '<meta property="og:type" content="' . esc_attr($meta['og_type'] ?? 'website') . '" />' . "\n";

        if (!empty($meta['title'])) {
            echo '<meta property="og:title" content="' . esc_attr($meta['title']) . '" />' . "\n";
        }
        if (!empty($meta['description'])) {
            echo '<meta property="og:description" content="' . esc_attr($meta['description']) . '" />' . "\n";
        }
        if (!empty($meta['image'])) {
            echo '<meta property="og:image" content="' . esc_url($meta['image']) . '" />' . "\n";
        }
        if (!empty($meta['canonical'])) {
            echo '<meta property="og:url" content="' . esc_url($meta['canonical']) . '" />' . "\n";
        }

        // Twitter Card
        $cardType = !empty($meta['image']) ? 'summary_large_image' : 'summary';
        echo '<meta name="twitter:card" content="' . esc_attr($cardType) . '" />' . "\n";
        if (!empty($meta['title'])) {
            echo '<meta name="twitter:title" content="' . esc_attr($meta['title']) . '" />' . "\n";
        }
        if (!empty($meta['description'])) {
            echo '<meta name="twitter:description" content="' . esc_attr($meta['description']) . '" />' . "\n";
        }
        if (!empty($meta['image'])) {
            echo '<meta name="twitter:image" content="' . esc_url($meta['image']) . '" />' . "\n";
        }
    }

    /**
     * Fix WP's canonical URL for SPA sub-routes.
     *
     * Without this, every sub-route (e.g. /store/clubs/) gets a canonical
     * pointing back to the base page (/store/).
     *
     * @param string   $canonical
     * @param \WP_Post $post
     */
    public function filterCanonical(string $canonical, $post): string
    {
        $page_id = (int) get_option('b360_app_page_id', 0);
        if ($page_id <= 0 || (int) $post->ID !== $page_id) return $canonical;

        return $this->buildCanonical();
    }

    // ------------------------------------------------------------------
    // Internal
    // ------------------------------------------------------------------

    private function isAppPage(): bool
    {
        $page_id = (int) get_option('b360_app_page_id', 0);
        return $page_id > 0 && is_page($page_id);
    }

    /** Compute or return cached meta for the current request. */
    private function resolveMeta(): array
    {
        if ($this->meta !== null) return $this->meta;
        $this->meta = $this->buildMeta($this->parseRoute());
        return $this->meta;
    }

    /**
     * Strip the SPA base path off the current REQUEST_URI, returning the
     * trimmed sub-path (e.g. "clubs/test-club"). Uses an anchored prefix
     * strip — str_replace would also hit mid-URL matches of $basePath.
     */
    private function subPath(): string
    {
        $basePath = Options::get_app_base_path();
        $uri      = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
        $path     = strpos($uri, $basePath) === 0 ? substr($uri, strlen($basePath)) : $uri;
        return trim((string) $path, '/');
    }

    private function parseRoute(): array
    {
        $path     = $this->subPath();
        $segments = array_values(array_filter(explode('/', $path)));

        return [
            'type'      => $segments[0] ?? '',
            'segments'  => $segments,
            'full_path' => $path,
        ];
    }

    private function buildCanonical(): string
    {
        $basePath = Options::get_app_base_path();
        $path     = $this->subPath();
        $full     = $path !== '' ? $basePath . '/' . $path : $basePath;
        return rtrim(home_url($full), '/') . '/';
    }

    private function buildMeta(array $route): array
    {
        $type     = $route['type'];
        $segments = $route['segments'];
        $canonical = $this->buildCanonical();

        // ---- Static pages ----
        // Titles live in SpaRoutes (shared with AppRoute::setTitle and the
        // Vue router). Descriptions are meta-tag-specific, declared here.
        $descriptions = [
            ''         => __('Browse our wine selection.', 'b360-bridge'),
            'checkout' => __('Complete your purchase.', 'b360-bridge'),
            'login'    => __('Sign in to your account.', 'b360-bridge'),
            'register' => __('Create a new account.', 'b360-bridge'),
            'account'  => __('Manage your account.', 'b360-bridge'),
            'recovery' => __('Reset your password.', 'b360-bridge'),
        ];

        if (isset($descriptions[$type])) {
            return [
                'title'       => SpaRoutes::titleFor($type),
                'description' => $descriptions[$type],
                'canonical'   => $canonical,
            ];
        }

        // ---- Dynamic pages ----
        switch ($type) {
            case 'wine':
            case 'product':
            case 'bundle':
                return $this->productMeta($segments, $canonical);

            case 'collection':
                $slug = $segments[1] ?? '';
                $name = ucwords(str_replace('-', ' ', $slug)) ?: 'Shop';
                return [
                    'title'       => $name,
                    'description' => 'Browse our ' . $name . ' collection.',
                    'canonical'   => $canonical,
                ];

            case 'clubs':
                if (isset($segments[1])) {
                    return $this->clubMeta($segments[1], $canonical);
                }
                return [
                    'title'       => SpaRoutes::titleFor('clubs'),
                    'description' => __('Explore our wine club memberships.', 'b360-bridge'),
                    'canonical'   => $canonical,
                ];

            default:
                return ['canonical' => $canonical];
        }
    }

    private function productMeta(array $segments, string $canonical): array
    {
        $slug = $segments[1] ?? '';
        if ($slug === '') return ['canonical' => $canonical];

        $params = ['slug' => $slug];
        if (isset($segments[2])) {
            $params['vintage'] = $segments[2];
        }

        $client = BridgeApiClient::instance();
        $res    = $client->get('catalog/product', $params, ['cache' => 0]);

        if (!$res['ok'] || empty($res['data'])) {
            return ['canonical' => $canonical];
        }

        $p       = $res['data'];
        $title   = $p['display_name'] ?? $p['name'] ?? '';
        $vintage = $p['vintage'] ?? '';
        // Append vintage only if it's meaningful and not already in the display name
        if ($vintage !== '' && $vintage !== 'NV' && strpos($title, $vintage) === false) {
            $title .= ' ' . $vintage;
        }

        $description = $p['teaser'] ?? '';
        if ($description === '' && !empty($p['description'])) {
            $description = wp_trim_words(wp_strip_all_tags($p['description']), 30, '…');
        }

        $image = '';
        if (!empty($p['images'])) {
            $image = $p['images'][0]['url'] ?? '';
            if ($image !== '' && strpos($image, 'http') !== 0) {
                // Bridge API returns absolute URLs; this branch is defensive.
                // Without a configured public host we'd emit a relative path
                // in og:image / schema, which breaks social shares — drop it.
                $host = Options::get_public_url();
                $image = $host !== '' ? $host . $image : '';
            }
        }

        return [
            'title'       => $title,
            'description' => $description,
            'image'       => $image,
            'og_type'     => 'product',
            'canonical'   => $canonical,
        ];
    }

    private function clubMeta(string $slug, string $canonical): array
    {
        $client = BridgeApiClient::instance();
        $res    = $client->get('club/detail', ['seo_url' => $slug], ['cache' => 300]);

        if (!$res['ok'] || empty($res['data'])) {
            return ['canonical' => $canonical];
        }

        $c           = $res['data'];
        $title       = $c['name'] ?? '';
        $description = $c['meta_description'] ?? $c['teaser'] ?? '';
        if ($description === '' && !empty($c['description'])) {
            $description = wp_trim_words(wp_strip_all_tags($c['description']), 30, '…');
        }

        return [
            'title'       => $title,
            'description' => $description,
            'canonical'   => $canonical,
        ];
    }
}
