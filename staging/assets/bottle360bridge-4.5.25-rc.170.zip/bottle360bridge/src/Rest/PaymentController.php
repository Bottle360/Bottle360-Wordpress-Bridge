<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class PaymentController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/payment/nmi-key', [
            'methods'             => 'GET',
            'callback'            => [$this, 'nmi_key'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/payment/saved-cards', [
            'methods'             => 'GET',
            'callback'            => [$this, 'saved_cards'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/payment/add-card', [
            'methods'             => 'POST',
            'callback'            => [$this, 'add_card'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/payment/delete-card', [
            'methods'             => 'POST',
            'callback'            => [$this, 'delete_card'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/payment/update-card', [
            'methods'             => 'POST',
            'callback'            => [$this, 'update_card'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function nmi_key(WP_REST_Request $request)
    {
        return $this->proxy_get('payment/nmiKey', [], ['cache' => 3600]);
    }

    public function saved_cards(WP_REST_Request $request)
    {
        return $this->proxy_get('payment/savedCards');
    }

    public function add_card(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $body = $request->get_json_params();
        return $this->proxy_post('payment/addCard', [
            'payment_token'      => sanitize_text_field($body['payment_token'] ?? ''),
            'billing_address_id' => absint($body['billing_address_id'] ?? 0),
            // BD-5009: also point every club membership at the new card.
            'use_for_clubs'      => rest_sanitize_boolean($body['use_for_clubs'] ?? false),
        ], $this->withRecaptcha($request));
    }

    public function delete_card(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $body = $request->get_json_params();
        return $this->proxy_post('payment/deleteCard', [
            'billing_id' => sanitize_text_field($body['billing_id'] ?? ''),
        ]);
    }

    /**
     * BD-5206: replace the card behind an existing saved entry (new number or
     * expiry) under the SAME billing_id, so the memberships billing it keep
     * working. Core answers with the refreshed card and, when the new number
     * matched another saved card, the id it folded into this one
     * (merged_billing_id). The body is rebuilt from named params exactly as
     * add_card does: nothing else passes through.
     */
    public function update_card(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $body = $request->get_json_params();
        return $this->proxy_post('payment/updateCard', [
            'billing_id'         => sanitize_text_field($body['billing_id'] ?? ''),
            'payment_token'      => sanitize_text_field($body['payment_token'] ?? ''),
            'billing_address_id' => absint($body['billing_address_id'] ?? 0),
        ], $this->withRecaptcha($request));
    }
}
