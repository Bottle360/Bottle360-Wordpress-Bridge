<?php

namespace Bottle360\Bridge;

if (!defined('ABSPATH')) exit;

final class Plugin
{
    /** @var self|null */
    private static $instance = null;

    /** @var bool */
    private $booted = false;

    public static function instance(): self
    {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    /**
     * Boot the plugin. Safe to call multiple times.
     */
    public function boot(): void
    {
        if ($this->booted) return;
        $this->booted = true;

        // ----- Admin (menu + settings) -----
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Admin\\Menu', 'register');

        // SettingsPage has separate methods in your codebase
        if (class_exists('Bottle360\\Bridge\\Admin\\SettingsPage')) {
            $sp = new \Bottle360\Bridge\Admin\SettingsPage();
            if (method_exists($sp, 'register_settings')) {
                // Register settings on admin_init
                add_action('admin_init', [$sp, 'settings']); // keep original method if you call it directly
                $sp->register_settings();
            }
            if (method_exists($sp, 'add_menu')) {
                // Add to Settings → Bottle360 Bridge (also fine to use your Admin\Menu)
                add_action('admin_menu', [$sp, 'add_menu']);
            }
        }

        // ----- Frontend assets -----
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Frontend\\Assets', 'register');

        // ----- Routing (rewrite rules + direct handler) -----
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Routing\\Rewrite', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Routing\\DirectHandler', 'register');

        // ----- Shortcodes (actual classes present in your src/Shortcodes) -----
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Shortcodes\\ProductsShortcode', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Shortcodes\\CartShortcode', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Shortcodes\\CartPageShortcode', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Shortcodes\\ProfileShortcode', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Shortcodes\\MyAccountShortcode', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Shortcodes\\LoginShortcode', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Shortcodes\\RegisterShortcode', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Shortcodes\\ClubShortcode', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Shortcodes\\CategoriesShortcode', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Shortcodes\\ProductCardShortcode', 'register');

        // ----- AJAX endpoints / proxies (matching your src/Ajax) -----
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\AuthView', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\AuthProxy', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\GetCsrf', 'register');

        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\LoadListing', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\LoadProductDetail', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\LoadProductCard', 'register');

        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\LoadCart', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\LoadMiniCart', 'register');

        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\AddToCart', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\GetCart', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\RemoveItem', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\UpdateQty', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\CheckoutRedirect', 'register');

        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\LoadClubs', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\LoadClubDetail', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\ClubJoinRedirect', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\LoadCategories', 'register');
        
        // $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\GetSKey', 'register');
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Http\\OutRedirect', 'register');



        $this->maybeInstanceRegister('Bottle360\\Bridge\\Ajax\\GetNonce', 'register');

        // If you add new classes later, just append more lines with maybeInstanceRegister(...)

        // Near the other service registrations in Plugin::boot()
        $this->maybeInstanceRegister('Bottle360\\Bridge\\Services\\YiiSession', 'register');

        $this->maybeInstanceRegister('Bottle360\\Bridge\\Updates\\Updater', 'init');
    }

    /**
     * Helper: instantiate $class and call $method if both exist.
     */
    private function maybeInstanceRegister(string $class, string $method): void
    {
        if (!class_exists($class)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[Bottle360Bridge] Skipping ' . $class . ' (class not found).');
            }
            return;
        }

        try {
            $obj = new $class();
        } catch (\Throwable $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[Bottle360Bridge] Failed to instantiate ' . $class . ': ' . $e->getMessage());
            }
            return;
        }

        if (!method_exists($obj, $method)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[Bottle360Bridge] ' . $class . ' has no method ' . $method . '().');
            }
            return;
        }

        try {
            $obj->{$method}();
        } catch (\Throwable $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[Bottle360Bridge] ' . $class . '::' . $method . '() threw: ' . $e->getMessage());
            }
        }
    }
}
