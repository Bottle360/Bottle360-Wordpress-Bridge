<?php
/**
 * Plugin Name: Bottle360 Bridge
 * Description: Display Bottle360 products and clubs with AJAX and pretty URLs.
 * Version: 1.5.5
 * Author: Bottle360
 * Text Domain: b360-bridge
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * Update URI: https://github.com/Bottle360/Bottle360-Wordpress-Bridge
 */
if (!defined('ABSPATH')) exit;

define('B360_BRIDGE_FILE', __FILE__);
define('B360_BRIDGE_DIR',  plugin_dir_path(__FILE__));
define('B360_BRIDGE_URL',  plugins_url('', __FILE__));
define('B360_BRIDGE_VER',  '1.4.8');

/** Load Composer autoloader if present */
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require __DIR__ . '/vendor/autoload.php';
} else {
    // Optional: warn if someone installs a source ZIP without vendor/
    add_action('admin_notices', static function () {
        if (!current_user_can('manage_options')) return;
        echo '<div class="notice notice-error"><p><strong>Bottle360 Bridge:</strong> Missing <code>vendor/autoload.php</code>. '
           . 'Install the official release ZIP or run <code>composer install --no-dev</code>.</p></div>';
    });
}

spl_autoload_register(static function ($class) {
    $prefix = 'Bottle360\\Bridge\\';
    $len = strlen($prefix);
    if (strncmp($class, $prefix, $len) !== 0) return;
    $relative = substr($class, $len);
    $file = B360_BRIDGE_DIR . 'src/' . str_replace('\\', '/', $relative) . '.php';
    if (file_exists($file)) require $file;
});

add_action('plugins_loaded', static function () {
    (new \Bottle360\Bridge\Plugin())->boot();
});

register_activation_hook(__FILE__, ['\Bottle360\Bridge\Lifecycle\Activator', 'activate']);
register_deactivation_hook(__FILE__, ['\Bottle360\Bridge\Lifecycle\Activator', 'deactivate']);
