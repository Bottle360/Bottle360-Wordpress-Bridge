<?php
namespace Bottle360\Bridge\Updates;

if (!defined('ABSPATH')) exit;

/**
 * PUC in JSON (self-hosted metadata) mode.
 * Metadata is published to: https://bottle360.github.io/Bottle360-Wordpress-Bridge/metadata.json
 */
final class Updater
{
    public static function init(): void
    {
        if (!\is_admin()) return;

        // PUC must be available via Composer autoload (required in b360-bridge.php)
        $hasV5 = \class_exists('\YahnisElsts\PluginUpdateChecker\v5\PucFactory');
        $hasV4 = \class_exists('\YahnisElsts\PluginUpdateChecker\v4\PucFactory');
        if (!$hasV5 && !$hasV4) return;

        $factory = $hasV5
            ? '\YahnisElsts\PluginUpdateChecker\v5\PucFactory'
            : '\YahnisElsts\PluginUpdateChecker\v4\PucFactory';

        // Self-hosted metadata URL (overrideable if ever needed).
        $metadataUrl = \apply_filters(
            'b360/updates/metadata_url',
            'https://bottle360.github.io/Bottle360-Wordpress-Bridge/metadata.json'
        );

        $pluginMain = \dirname(__DIR__, 2) . '/b360-bridge.php'; // boot file
        $pluginSlug = 'bottle360bridge';                          // folder/slug

        /** @var \YahnisElsts\PluginUpdateChecker\v5p0\Plugin\UpdateChecker
         *  |\YahnisElsts\PluginUpdateChecker\v4\Plugin\UpdateChecker $checker
         */
        $checker = $factory::buildUpdateChecker($metadataUrl, $pluginMain, $pluginSlug);

        // “Check for updates” quick link on the Plugins screen.
        \add_filter('plugin_action_links_' . \plugin_basename($pluginMain), static function (array $links) {
            $links[] = \sprintf(
                '<a href="%s">%s</a>',
                \esc_url(\add_query_arg(['force-check' => 1], \self_admin_url('update-core.php'))),
                \esc_html__('Check for updates', 'b360-bridge')
            );
            return $links;
        });

        // Optional one-off force check: /wp-admin/?b360_puc_check=1
        \add_action('admin_init', static function () use ($checker) {
            if (!\current_user_can('manage_options')) return;
            if (isset($_GET['b360_puc_check'])) {
                if (\method_exists($checker, 'setCacheDuration')) $checker->setCacheDuration(0);
                $checker->checkForUpdates();
            }
        });
    }
}
