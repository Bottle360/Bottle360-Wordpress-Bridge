<?php

namespace Bottle360\Bridge\Shortcodes;

if (!defined('ABSPATH')) exit;

/**
 * [b360_product_card] / [b360-product-card]
 *
 * SKU can be supplied either:
 *  - [b360_product_card sku="Maragas2017Malbec"]
 *  - /promo/?sku=Maragas2017Malbec   (with [b360_product_card] on the page)
 */
final class ProductCardShortcode
{
    public function register(): void
    {
        add_shortcode('b360_product_card', [$this, 'render']);
        add_shortcode('b360-product-card', [$this, 'render']);
    }

    public function render($atts = []): string
    {
        $atts = shortcode_atts([
            'sku'        => '',      // shortcode attribute
            'param'      => 'sku',   // GET param name fallback (default sku)
            'class'      => '',
            'store_url'  => '',      // optional override to force products page URL
            'empty'      => 'hide',  // hide|message
            'empty_text' => __('Missing product SKU.', 'b360-bridge'),
        ], $atts, 'b360_product_card');

        wp_enqueue_style('b360-bridge');
        wp_enqueue_script('b360-bridge');
        wp_enqueue_script('b360-product-card');

        // Resolve SKU: shortcode sku wins, else GET[param]
        $sku = '';
        if (!empty($atts['sku']) && is_string($atts['sku'])) {
            $sku = (string) $atts['sku'];
        } else {
            $param = sanitize_key((string) $atts['param']);
            if ($param === '') $param = 'sku';
            if (isset($_GET[$param])) {
                $sku = (string) wp_unslash($_GET[$param]);
            }
        }
        $sku = trim(sanitize_text_field($sku));

        if ($sku === '') {
            if ((string) $atts['empty'] === 'message') {
                return '<div class="b360-product-card-container b360-product-card--empty">' . esc_html((string) $atts['empty_text']) . '</div>';
            }
            return '';
        }

        // IMPORTANT: This must be the REAL products page URL (same base used by rewrite rules)
        $storeUrl = trim((string) $atts['store_url']) !== ''
            ? esc_url_raw((string) $atts['store_url'])
            : $this->findProductsPageUrl();

        if ($storeUrl === '') $storeUrl = trailingslashit(home_url('/'));
        $storeUrl = trailingslashit($storeUrl);

        $id = 'b360-product-card-' . wp_generate_password(6, false);

        $classes = [
            'b360-product-card-container',
            'b360-bridge-container', // styling reuse only
            sanitize_html_class((string) $atts['class']),
        ];
        $classes = array_filter($classes, 'strlen');

        ob_start(); ?>
<div id="<?php echo esc_attr($id); ?>"
     class="<?php echo esc_attr(implode(' ', $classes)); ?>"
     data-b360-sku="<?php echo esc_attr($sku); ?>"
     data-store-url="<?php echo esc_attr($storeUrl); ?>">
  <div class="b360-loading" aria-live="polite"><?php echo esc_html__('Loading…', 'b360-bridge'); ?></div>
</div>
<?php
        return (string) ob_get_clean();
    }

    /**
     * Match DirectHandler::findProductsPageId():
     *  1) pinned option b360_products_page_id
     *  2) first page containing [b360_products] / [b360-products]
     *
     * DO NOT use "b360-bridge-container" detection here, because product-card pages
     * also contain that class and would be falsely detected as the Products page.
     */
    private function findProductsPageUrl(): string
    {
        $pinned = (int) get_option('b360_products_page_id', 0);
        if ($pinned) {
            $p = get_post($pinned);
            if ($p && $p->post_type === 'page' && $p->post_status === 'publish') {
                $u = get_permalink($p);
                if ($u) return trailingslashit($u);
            }
        }

        $pages = get_posts([
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
        ]);

        foreach ($pages as $p) {
            $c = (string) $p->post_content;
            if (has_shortcode($c, 'b360_products') || has_shortcode($c, 'b360-products')) {
                $u = get_permalink($p);
                if ($u) return trailingslashit($u);
            }
        }

        return '';
    }
}
