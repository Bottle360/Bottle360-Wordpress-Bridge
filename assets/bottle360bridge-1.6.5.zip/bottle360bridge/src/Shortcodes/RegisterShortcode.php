<?php

namespace Bottle360\Bridge\Shortcodes;

use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class RegisterShortcode
{
    public function register(): void
    {
        add_shortcode('b360-register', [$this, 'render']);
        add_shortcode('b360_register', [$this, 'render']); // alias
    }

    public function render($atts = []): string
    {
        $atts = shortcode_atts([
            'class'            => '',
            'account_url'      => home_url('/b360-my-account'),
            'redirect_if_auth' => 'yes',
        ], $atts, 'b360-register');

        $accountUrl = (string) $atts['account_url'];

        $this->ensure_assets($accountUrl);

        $id = 'b360-auth-' . wp_generate_password(6, false);

        ob_start(); ?>
        <div id="<?php echo esc_attr($id); ?>"
            class="b360-auth-root <?php echo esc_attr((string) $atts['class']); ?>"
            data-view="register"
            data-account-url="<?php echo esc_url($accountUrl); ?>"
            data-redirect-if-auth="<?php echo esc_attr((string) $atts['redirect_if_auth']); ?>">
            <div class="b360-auth-loading">Loading…</div>
            <div class="b360-auth-error" hidden></div>
            <div class="b360-auth-body" hidden></div>
        </div>
<?php
        return (string) ob_get_clean();
    }

    private function ensure_assets(string $accountUrl): void
    {
        $plugin_file = defined('B360_BRIDGE_FILE') ? B360_BRIDGE_FILE : __FILE__;
        $root        = plugin_dir_path($plugin_file);

        // CSS
        $css_abs = $root . 'assets/css/b360-bridge.css';
        if (file_exists($css_abs) && !wp_style_is('b360-bridge', 'registered')) {
            wp_register_style(
                'b360-bridge',
                plugins_url('assets/css/b360-bridge.css', $plugin_file),
                [],
                (string) (filemtime($css_abs) ?: time())
            );
        }
        if (wp_style_is('b360-bridge', 'registered')) {
            wp_enqueue_style('b360-bridge');
        }

        // JS
        $js_abs = $root . 'assets/js/b360-login-view.js';
        if (file_exists($js_abs) && !wp_script_is('b360-login-view', 'registered')) {
            wp_register_script(
                'b360-login-view',
                plugins_url('assets/js/b360-login-view.js', $plugin_file),
                [],
                (string) (filemtime($js_abs) ?: time()),
                true
            );
        }

        if (wp_script_is('b360-login-view', 'registered')) {
            wp_localize_script('b360-login-view', 'B360Bridge', [
                'ajax_url'  => admin_url('admin-ajax.php'),
                'ajaxUrl'   => admin_url('admin-ajax.php'),
                'nonce'     => Nonce::value(),
                'cartNonce' => Nonce::value(),
                'accountUrl' => $accountUrl,
            ]);
            wp_enqueue_script('b360-login-view');
        }

        $this->ensure_footer_fallback($accountUrl);
    }

    private function ensure_footer_fallback(string $accountUrl): void
    {
        if (did_action('wp_footer')) return;

        add_action('wp_footer', function () use ($accountUrl) {
            if (wp_script_is('b360-login-view', 'done')) return;

            $plugin_file = defined('B360_BRIDGE_FILE') ? B360_BRIDGE_FILE : __FILE__;
            $src         = plugins_url('assets/js/b360-login-view.js', $plugin_file);

            $cfg = [
                'ajax_url' => admin_url('admin-ajax.php'),
                'ajaxUrl'  => admin_url('admin-ajax.php'),
                'nonce'     => Nonce::value(),
                'cartNonce' => Nonce::value(),
                'accountUrl' => $accountUrl,
            ];

            echo '<script>window.B360Bridge=' . wp_json_encode($cfg) . ';</script>';
            echo '<script src="' . esc_url($src) . '" defer></script>';
        }, 99);
    }
}
