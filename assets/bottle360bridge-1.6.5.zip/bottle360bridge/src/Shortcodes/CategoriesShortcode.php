<?php

namespace Bottle360\Bridge\Shortcodes;

if (!defined('ABSPATH')) exit;

/**
 * [b360_categories] / [b360-categories]
 * Renders a responsive category menu that stays on one line (wraps) or stacks on narrow containers.
 * Parent -> local store page; Children -> local store page with ?category=<slug>
 */
final class CategoriesShortcode
{
    public function register(): void
    {
        add_shortcode('b360_categories', [$this, 'render']);
        add_shortcode('b360-categories', [$this, 'render']);
    }

    public function render($atts = []): string
    {
        $atts = shortcode_atts([
            'class'      => '',
            'store_url'  => '',
            'stack'      => 'auto', // 'auto' | 'yes' | 'no'
            'aria_label' => __('Product categories', 'b360-bridge'),
        ], $atts, 'b360_categories');

        wp_enqueue_script('b360-categories');

        $storeUrl = trim((string)$atts['store_url']) !== ''
            ? esc_url_raw($atts['store_url'])
            : $this->findProductsPageUrl();

        if ($storeUrl === '') $storeUrl = trailingslashit(home_url('/'));

        $id = 'b360-catmenu-' . wp_generate_password(6, false);

        $classes = ['b360-catmenu', sanitize_html_class((string)$atts['class'])];
        $classes = array_filter($classes, 'strlen');

        $stackAttr = strtolower((string)$atts['stack']);
        $stack     = in_array($stackAttr, ['yes', 'no', 'auto'], true) ? $stackAttr : 'auto';

        ob_start(); ?>
        <nav id="<?php echo esc_attr($id); ?>"
            class="<?php echo esc_attr(implode(' ', $classes)); ?>"
            role="navigation"
            aria-label="<?php echo esc_attr($atts['aria_label']); ?>"
            data-store-url="<?php echo esc_attr(trailingslashit($storeUrl)); ?>"
            data-stack="<?php echo esc_attr($stack); ?>">
            <ul class="b360-catmenu__list" aria-live="polite"></ul>
        </nav>
<?php
        return (string) ob_get_clean();
    }

    private function findProductsPageUrl(): string
    {
        $pinned = (int) get_option('b360_products_page_id', 0);
        if ($pinned) {
            $p = get_post($pinned);
            if ($p && $p->post_type === 'page' && $p->post_status === 'publish') {
                $u = get_permalink($p);
                if ($u) return trailingslashit($u);
            }
        }

        $pages = get_posts([
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ]);

        // foreach ($pages as $pid) {
        //     $c = (string) get_post_field('post_content', $pid);
        //     if (has_shortcode($c, 'b360_products') || has_shortcode($c, 'b360-products') ||
        //         strpos($c, 'b360-bridge-container') !== false) {
        //         $u = get_permalink($pid);
        //         if ($u) return trailingslashit($u);
        //     }
        // }

        foreach ($pages as $pid) {
            $c = (string) get_post_field('post_content', $pid);

            // Skip product-card landing pages (they also contain b360-bridge-container)
            if (has_shortcode($c, 'b360_product_card') || has_shortcode($c, 'b360-product-card')) {
                continue;
            }

            if (
                has_shortcode($c, 'b360_products') || has_shortcode($c, 'b360-products') ||
                strpos($c, 'b360-bridge-container') !== false
            ) {
                $u = get_permalink($pid);
                if ($u) return trailingslashit($u);
            }
        }


        return trailingslashit(home_url('/'));
    }
}
