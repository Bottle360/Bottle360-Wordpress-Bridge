<?php
namespace Bottle360\Bridge\Shortcodes;

use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

/**
 * [b360-recovery] / [b360_recovery]
 *
 * Displays Bottle360 password recovery form and handles reset via WP AJAX proxy.
 *
 * Usage:
 *  - Create a WP page and add: [b360-recovery]
 *  - Point login shortcode at it:
 *      [b360-login forgot_password_url="/password-recovery"]
 */
final class RecoveryShortcode
{
    public function register(): void
    {
        add_shortcode('b360-recovery', [$this, 'render']);
        add_shortcode('b360_recovery', [$this, 'render']);
    }

    public function render($atts = []): string
    {
        $atts = shortcode_atts([
            'class' => '',
            'debug' => 'no',
        ], $atts, 'b360-recovery');

        $this->ensure_assets();
        $this->ensure_footer_fallback();

        $id = 'b360-recovery-' . wp_generate_password(6, false);

        ob_start(); ?>
          <div id="<?php echo esc_attr($id); ?>"
               class="b360-recovery-root <?php echo esc_attr((string) $atts['class']); ?>"
               data-debug="<?php echo esc_attr((string) $atts['debug']); ?>">
            <div class="b360-auth-loading">Loading…</div>
          </div>
        <?php
        return (string) ob_get_clean();
    }

    private function ensure_assets(): void
    {
        $plugin_file = defined('B360_BRIDGE_FILE') ? B360_BRIDGE_FILE : __FILE__;
        $root        = plugin_dir_path($plugin_file);

        // CSS (reuse existing bridge stylesheet)
        $css_abs = $root . 'assets/css/b360-bridge.css';
        if (file_exists($css_abs) && !wp_style_is('b360-bridge', 'registered')) {
            wp_register_style(
                'b360-bridge',
                plugins_url('assets/css/b360-bridge.css', $plugin_file),
                [],
                (string) (filemtime($css_abs) ?: time())
            );
        }
        if (wp_style_is('b360-bridge', 'registered')) {
            wp_enqueue_style('b360-bridge');
        }

        // JS
        $js_abs = $root . 'assets/js/b360-recovery-view.js';
        if (file_exists($js_abs) && !wp_script_is('b360-recovery-view', 'registered')) {
            wp_register_script(
                'b360-recovery-view',
                plugins_url('assets/js/b360-recovery-view.js', $plugin_file),
                [],
                (string) (filemtime($js_abs) ?: time()),
                true
            );
        }

        if (wp_script_is('b360-recovery-view', 'registered')) {
            wp_localize_script('b360-recovery-view', 'B360Recovery', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce'   => Nonce::value(),
            ]);
            wp_enqueue_script('b360-recovery-view');
        }
    }

    private function ensure_footer_fallback(): void
    {
        add_action('wp_footer', function () {
            global $wp_scripts;
            $printed = is_object($wp_scripts) && !empty($wp_scripts->done) && in_array('b360-recovery-view', (array) $wp_scripts->done, true);
            if ($printed) return;

            $plugin_file = defined('B360_BRIDGE_FILE') ? B360_BRIDGE_FILE : __FILE__;
            $js_url      = plugins_url('assets/js/b360-recovery-view.js', $plugin_file);

            $cfg = [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce'   => Nonce::value(),
            ];

            echo '<script>window.B360Recovery=' . wp_json_encode($cfg) . ';</script>' . "\n";
            echo '<script src="' . esc_url($js_url) . '" defer></script>' . "\n";
        }, 9999);
    }
}
