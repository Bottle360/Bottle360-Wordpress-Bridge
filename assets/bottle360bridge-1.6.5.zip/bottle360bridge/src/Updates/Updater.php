<?php
namespace Bottle360\Bridge\Updates;

if (!defined('ABSPATH')) exit;

/**
 * Self-hosted JSON updater using PUC.
 * Metadata is published to: https://bottle360.github.io/Bottle360-Wordpress-Bridge/metadata.json
 */
final class Updater
{
    public static function init(): void
    {
        if (!is_admin()) return;

        // Ensure the PUC factory class exists (loaded via composer autoload in b360-bridge.php)
        $hasV5 = class_exists('\YahnisElsts\PluginUpdateChecker\v5\PucFactory');
        $hasV4 = class_exists('\YahnisElsts\PluginUpdateChecker\v4\PucFactory');
        if (!$hasV5 && !$hasV4) return;

        $factory = $hasV5
            ? '\YahnisElsts\PluginUpdateChecker\v5\PucFactory'
            : '\YahnisElsts\PluginUpdateChecker\v4\PucFactory';

        // JSON metadata URL (public GitHub Pages)
        $metadataUrl = apply_filters(
            'b360/updates/metadata_url',
            'https://bottle360.github.io/Bottle360-Wordpress-Bridge/metadata.json'
        );

        $pluginMain = dirname(__DIR__, 2) . '/b360-bridge.php';

        /**
         * IMPORTANT: Omit the 3rd $slug param so PUC uses plugin_basename($pluginMain)
         * This avoids any slug/folder mismatch issues.
         *
         * @var \YahnisElsts\PluginUpdateChecker\v5p0\Plugin\UpdateChecker
         *   |\YahnisElsts\PluginUpdateChecker\v4\Plugin\UpdateChecker
         */
        $checker = $factory::buildUpdateChecker($metadataUrl, $pluginMain);

        // “Check for updates” quick link.
        add_filter('plugin_action_links_' . plugin_basename($pluginMain), static function (array $links) {
            $links[] = sprintf(
                '<a href="%s">%s</a>',
                esc_url(add_query_arg(['force-check' => 1], self_admin_url('update-core.php'))),
                esc_html__('Check for updates', 'b360-bridge')
            );
            return $links;
        });

        // ---- Diagnostics (visit /wp-admin/?b360_puc_check=1 once) -----------------
        add_action('admin_init', static function () use ($checker, $metadataUrl, $pluginMain) {
            if (!current_user_can('manage_options')) return;

            // Force a fresh check now.
            if (isset($_GET['b360_puc_check'])) {
                if (method_exists($checker, 'setCacheDuration')) $checker->setCacheDuration(0);
                $update = $checker->checkForUpdates();
                self::dump('PUC forced check', [
                    'plugin_basename' => plugin_basename($pluginMain),
                    'file_exists'     => file_exists($pluginMain),
                    'metadata_url'    => $metadataUrl,
                    'result'          => $update,
                ]);
            }

            // Fetch and show parsed metadata (does HTTP reach the JSON?)
            if (isset($_GET['b360_puc_info'])) {
                $info = $checker->requestInfo();
                self::dump('PUC requestInfo()', [
                    'plugin_basename' => plugin_basename($pluginMain),
                    'metadata_url'    => $metadataUrl,
                    'info'            => $info,
                ]);
            }
        });
        // ---------------------------------------------------------------------------
    }

    private static function dump(string $title, $data): void
    {
        wp_die(
            '<h1>' . esc_html($title) . '</h1><pre style="white-space:pre-wrap">' .
            esc_html(print_r($data, true)) .
            '</pre><p><a href="' . esc_url(admin_url('plugins.php')) . '">&larr; Back to Plugins</a></p>'
        );
    }
}
