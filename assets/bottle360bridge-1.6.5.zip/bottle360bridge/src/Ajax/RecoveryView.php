<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class RecoveryView
{
    public function register(): void
    {
        add_action('wp_ajax_b360_recovery_view',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_recovery_view', [$this, 'handle']);
    }

    public function handle(): void
    {
        // Accept JSON or form
        $ctype  = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson = stripos((string) $ctype, 'application/json') !== false;

        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        if (!is_array($payload)) $payload = [];

        Nonce::assertAjax($payload, 'nonce');

        $query       = (string) ($payload['query'] ?? ''); // "?key=..." from the WP page
        $pageUrl     = (string) ($payload['page_url'] ?? '');
        $recoveryUrl = (string) ($payload['recovery_url'] ?? $pageUrl);

        $base = rtrim((string) Options::get_base_host(), '/');
        $url  = $base . '/b360-user/recovery' . $this->normalizeQuery($query);

        $headers = YiiSession::withYiiCookie([
            'Accept'     => 'text/html, */*;q=0.1',
            'User-Agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Bottle360Bridge/1.0',
            'Referer'    => $pageUrl !== '' ? $pageUrl : home_url('/'),
        ]);

        $res = wp_remote_get($url, [
            'timeout'     => 20,
            'headers'     => $headers,
            'redirection' => 5,
        ]);

        if (is_wp_error($res)) {
            $this->send_error($res->get_error_message(), 502);
        }

        YiiSession::persistFromResponse($res);

        $code = (int) wp_remote_retrieve_response_code($res);
        $html = (string) wp_remote_retrieve_body($res);

        if ($html !== '' && $recoveryUrl !== '') {
            $html = $this->inject_recovery_url_field($html, $recoveryUrl);
        }

        if ($code >= 200 && $code < 300 && $html !== '') {
            $this->send_success(['html' => $html], 200);
        }

        $this->send_error('Upstream returned an unexpected response.', $code ?: 500, ['html' => $html]);
    }

    private function normalizeQuery(string $query): string
    {
        $query = trim($query);
        if ($query === '') return '';
        // Only allow leading "?" style query; if it is a full URL, ignore.
        if (preg_match('~^https?://~i', $query)) return '';
        return ($query[0] === '?') ? $query : ('?' . ltrim($query, '?'));
    }

    private function inject_recovery_url_field(string $html, string $recoveryUrl): string
    {
        // If already present, do nothing
        if (stripos($html, 'name="recovery_url"') !== false) {
            return $html;
        }

        $field = '<input type="hidden" name="recovery_url" value="' . esc_attr($recoveryUrl) . '">';

        // Inject right after opening <form ...> tag(s)
        $out = preg_replace('~(<form\b[^>]*>)~i', '$1\n' . $field, $html, -1, $count);
        if (is_string($out) && $count > 0) {
            return $out;
        }

        return $html;
    }

    private function send_success(array $data, int $status = 200): void
    {
        status_header($status);
        header('Content-Type: application/json; charset=utf-8');
        echo wp_json_encode(array_merge(['success' => 'true'], $data));
        wp_die();
    }

    private function send_error(string $message, int $status = 500, array $extra = []): void
    {
        status_header($status);
        header('Content-Type: application/json; charset=utf-8');
        echo wp_json_encode(array_merge(['success' => 'false', 'message' => $message], $extra));
        wp_die();
    }
}
