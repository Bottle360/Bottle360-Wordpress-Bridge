<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class RecoveryProxy
{
    public function register(): void
    {
        add_action('wp_ajax_b360_recovery_proxy',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_recovery_proxy', [$this, 'handle']);
    }

    public function handle(): void
    {
        $ctype  = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson = stripos((string) $ctype, 'application/json') !== false;

        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : ($_POST + $_GET);

        if (!is_array($payload)) $payload = [];

        Nonce::assertAjax($payload, 'nonce');

        $form        = (isset($payload['form']) && is_array($payload['form'])) ? $payload['form'] : [];
        $query       = (string) ($payload['query'] ?? '');
        $pageUrl     = (string) ($payload['page_url'] ?? '');
        $recoveryUrl = (string) ($payload['recovery_url'] ?? $pageUrl);

        // Guarantee hidden field is present for Bottle360 email link generation
        if ($recoveryUrl !== '' && empty($form['recovery_url'])) {
            $form['recovery_url'] = $recoveryUrl;
        }

        $base = rtrim((string) Options::get_base_host(), '/');
        $url  = $base . '/b360-user/recovery' . $this->normalizeQuery($query);

        $headers = YiiSession::withYiiCookie([
            'Accept'           => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Content-Type'     => 'application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent'       => $_SERVER['HTTP_USER_AGENT'] ?? 'Bottle360Bridge/1.0',
            'X-Requested-With' => 'XMLHttpRequest',
            'Referer'          => $pageUrl !== '' ? $pageUrl : home_url('/'),
        ]);

        $res = wp_remote_post($url, [
            'timeout'     => 25,
            'headers'     => $headers,
            'body'        => $form,
            'redirection' => 0,
        ]);

        if (is_wp_error($res)) {
            $this->send(['success' => 'false', 'message' => $res->get_error_message()], 502);
        }

        YiiSession::persistFromResponse($res);

        $code = (int) wp_remote_retrieve_response_code($res);
        $body = (string) wp_remote_retrieve_body($res);

        // Try to parse JSON responses from upstream (some installs return JSON)
        $json = json_decode($body, true);
        if (is_array($json)) {
            $ok = (
                ($json['success'] ?? null) === true ||
                ($json['success'] ?? '') === 'true' ||
                ($json['status']  ?? '') === 'ok'
            );

            $this->send([
                'success' => $ok ? 'true' : 'false',
                'data'    => $json,
                'message' => (string) ($json['message'] ?? ($ok ? 'OK' : 'Failed')),
                'status'  => $code,
            ], $ok ? 200 : ($code ?: 400));
        }

        // Otherwise treat as HTML (common Yii form behavior)
        if ($body !== '' && $recoveryUrl !== '') {
            $body = $this->inject_recovery_url_field($body, $recoveryUrl);
        }

        $ok = ($code >= 200 && $code < 300);
        $this->send([
            'success' => $ok ? 'true' : 'false',
            'html'    => $body,
            'status'  => $code,
        ], $ok ? 200 : ($code ?: 400));
    }

    private function normalizeQuery(string $query): string
    {
        $query = trim($query);
        if ($query === '') return '';
        if (preg_match('~^https?://~i', $query)) return '';
        return ($query[0] === '?') ? $query : ('?' . ltrim($query, '?'));
    }

    private function inject_recovery_url_field(string $html, string $recoveryUrl): string
    {
        if (stripos($html, 'name="recovery_url"') !== false) {
            return $html;
        }

        $field = '<input type="hidden" name="recovery_url" value="' . esc_attr($recoveryUrl) . '">';

        $out = preg_replace('~(<form\b[^>]*>)~i', '$1\n' . $field, $html, -1, $count);
        if (is_string($out) && $count > 0) {
            return $out;
        }

        return $html;
    }

    private function send(array $payload, int $status = 200): void
    {
        status_header($status);
        header('Content-Type: application/json; charset=utf-8');
        echo wp_json_encode($payload);
        wp_die();
    }
}
