<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Http\Client;
use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class LoadProductCard
{
    public function register(): void
    {
        add_action('wp_ajax_b360_load_product_card',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_load_product_card', [$this, 'handle']);
    }

    public function handle(): void
    {
        $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson  = stripos((string) $ctype, 'application/json') !== false;
        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        Nonce::assertAjax($payload, 'nonce');

        $sku = isset($payload['sku']) ? (string) $payload['sku'] : '';
        $sku = trim(sanitize_text_field($sku));
        if ($sku === '') {
            wp_send_json_error(['message' => 'Missing sku'], 400);
        }

        $base = rtrim((string) Options::get_base_host(), '/');

        $candidates = [
            $base . '/b360-product/?sku=' . rawurlencode($sku),
            $base . '/b360-product?sku=' . rawurlencode($sku),
            $base . '/b360-product/' . rawurlencode($sku),
        ];

        $headers = YiiSession::withYiiCookie([]);
        $client  = new Client();

        $last = null;
        foreach ($candidates as $remote) {
            $res  = $client->get($remote, ['headers' => $headers]);
            $last = $res;

            if (!empty($res['ok'])) {
                $html = (string) ($res['body'] ?? '');
                $html = $this->rewrite_detail_links_to_products_root($html);
                wp_send_json_success(['html' => $html]);
            }
        }

        wp_send_json_error([
            'message' => $last['error'] ?? 'Failed to load product',
            'status'  => $last['status'] ?? 500,
        ], $last['status'] ?? 500);
    }

    /**
     * Ensure the card links navigate to the same direct URLs supported by rewrite rules:
     *   /<products-root>/wine/<slug>/<vintage>
     *   /<products-root>/product/<slug>
     *   /<products-root>/bundle/<slug>
     */
    private function rewrite_detail_links_to_products_root(string $html): string
    {
        $prodRootUrl = $this->findProductsPageUrl();
        $prodRoot    = untrailingslashit($prodRootUrl);

        // If products page is front page, its permalink is typically home_url('/')
        // so untrailingslashit(home_url('/')) yields site root.
        if ($prodRoot === '') {
            $prodRoot = untrailingslashit(home_url('/'));
        }

        $remoteHost = preg_quote(parse_url(
            untrailingslashit((string) Options::get_base_host()),
            PHP_URL_HOST
        ) ?: '', '#');

        $patterns = [
            // absolute remote → local root
            '#https?://' . $remoteHost . '/(?:b360-)?product/([^"\'/]+)#i',
            '#https?://' . $remoteHost . '/(?:b360-)?bundle/([^"\'/]+)#i',
            '#https?://' . $remoteHost . '/(?:b360-)?wine/([^"\'/]+)/([^"\'/]+)#i',

            // relative remote → local root
            '#(?<![A-Za-z0-9_-])/(?:b360-)?product/([^"\'/]+)#i',
            '#(?<![A-Za-z0-9_-])/(?:b360-)?bundle/([^"\'/]+)#i',
            '#(?<![A-Za-z0-9_-])/(?:b360-)?wine/([^"\'/]+)/([^"\'/]+)#i',
        ];

        $replacements = [
            $prodRoot . '/product/$1',
            $prodRoot . '/bundle/$1',
            $prodRoot . '/wine/$1/$2',

            $prodRoot . '/product/$1',
            $prodRoot . '/bundle/$1',
            $prodRoot . '/wine/$1/$2',
        ];

        $out = preg_replace($patterns, $replacements, $html);
        return is_string($out) ? $out : $html;
    }

    private function findProductsPageUrl(): string
    {
        $pinned = (int) get_option('b360_products_page_id', 0);
        if ($pinned) {
            $p = get_post($pinned);
            if ($p && $p->post_type === 'page' && $p->post_status === 'publish') {
                $u = get_permalink($p);
                if ($u) return trailingslashit($u);
            }
        }

        $pages = get_posts([
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
        ]);

        foreach ($pages as $p) {
            $c = (string) $p->post_content;
            if (has_shortcode($c, 'b360_products') || has_shortcode($c, 'b360-products')) {
                $u = get_permalink($p);
                if ($u) return trailingslashit($u);
            }
        }

        return '';
    }
}
