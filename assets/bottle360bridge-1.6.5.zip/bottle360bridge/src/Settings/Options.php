<?php

namespace Bottle360\Bridge\Settings;

final class Options
{
    public const OPT_TENANT        = 'b360_bridge_tenant';
    public const OPT_TLD           = 'b360_bridge_tld';
    public const OPT_DISABLE_CACHE = 'b360_bridge_disable_cache';
    public const OPT_DEBUG         = 'b360_bridge_debug';

    /**
     * Page mapping used for pretty permalinks / direct handlers.
     * These are intentionally separate from the admin settings group name.
     */
    public const OPT_PRODUCTS_PAGE_ID = 'b360_products_page_id';
    public const OPT_CLUB_PAGE_ID     = 'b360_club_page_id';


    /** Allowed public TLDs */
    private const ALLOWED_TLDS = ['com', 'net', 'dev'];

    public static function get_tenant(): string
    {
        return trim((string) get_option(self::OPT_TENANT, ''));
    }

    public static function get_tld(): string
    {
        $tld = strtolower(trim((string) get_option(self::OPT_TLD, 'dev')));
        return in_array($tld, self::ALLOWED_TLDS, true) ? $tld : 'dev';
    }

    public static function is_cache_disabled(): bool
    {
        return (bool) get_option(self::OPT_DISABLE_CACHE, false);
    }

    public static function is_debug_enabled(): bool
    {
        return (bool) get_option(self::OPT_DEBUG, false);
    }

    public static function get_products_page_id(): int
    {
        return (int) get_option(self::OPT_PRODUCTS_PAGE_ID, 0);
    }

    public static function get_club_page_id(): int
    {
        return (int) get_option(self::OPT_CLUB_PAGE_ID, 0);
    }


    /**
     * Tenant-aware + TLD-aware upstream base host.
     * Examples:
     *  - https://acme.bottlethreesixty.dev
     *  - https://acme.bottlethreesixty.com
     *  - https://demo.bottlethreesixty.net (fallback when tenant is empty)
     */
    public static function get_base_host(): string
    {
        $tenant = self::get_tenant();
        $tld    = self::get_tld();
        $sub    = $tenant !== '' ? $tenant : 'demo';
        return 'https://' . $sub . '.bottlethreesixty.' . $tld;
    }
}
