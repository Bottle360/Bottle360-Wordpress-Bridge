(function ($) {
  'use strict';

  function cfg() {
    return window.B360Bridge || window.B360 || {};
  }

  function sanitizeHtml(html) {
    try {
      var tmp = document.createElement('div');
      tmp.innerHTML = html || '';
      var scripts = tmp.querySelectorAll('script, noscript');
      for (var i = 0; i < scripts.length; i++) {
        scripts[i].parentNode.removeChild(scripts[i]);
      }
      return tmp.innerHTML;
    } catch (e) {
      return html || '';
    }
  }

  function normalizePath(p) {
    return (p || '').toString().replace(/\/+$/, '');
  }

  // Parse /product/<slug>, /bundle/<slug>, /wine/<slug>/<vintage>
  function parseDetailFromHref(href) {
    if (!href) return null;
    var h = href.toString().split('#')[0].split('?')[0];

    var m = h.match(/\/(?:b360-)?(product|bundle)\/([^\/]+)\/?$/i);
    if (m) return { type: m[1].toLowerCase(), slug: m[2], vintage: '' };

    m = h.match(/\/(?:b360-)?wine\/([^\/]+)\/([^\/]+)\/?$/i);
    if (m) return { type: 'wine', slug: m[1], vintage: m[2] };

    return null;
  }

  // IMPORTANT: base is PRODUCTS ROOT (products page permalink), NOT current page
  function buildDetailUrl(productsRoot, type, slug, vintage) {
    var base = normalizePath(productsRoot);
    if (!base) base = normalizePath(window.location.origin);

    var path = '/' + type + '/' + slug;
    if (type === 'wine' && vintage) path += '/' + vintage;

    var url = (base + path).replace(/\/+/g, '/');
    return url.endsWith('/') ? url : url + '/';
  }

  function getProductsRoot($wrap) {
    // This comes from PHP shortcode and MUST point to Products page permalink
    var storeUrl = ($wrap.data('storeUrl') || '').toString();
    if (!storeUrl) return window.location.origin;
    // storeUrl can be absolute; we want its pathname root, but keeping it as-is works for navigation
    return storeUrl;
  }

  function extractDetailHrefFromCard($wrap) {
    // Your upstream markup provides data-detail-url="/wine/slug/vintage"
    var d = $wrap.find('.product-image-plp[data-detail-url]').attr('data-detail-url');
    if (d) return d;

    var a = $wrap.find('a[href]').first().attr('href');
    if (a) return a;

    return '';
  }

  function normalizeCardLinks($wrap) {
    var rel = extractDetailHrefFromCard($wrap);
    var info = parseDetailFromHref(rel);
    if (!info) return;

    var prodRoot = getProductsRoot($wrap);
    var detailUrl = buildDetailUrl(prodRoot, info.type, info.slug, info.vintage);

    // Rewrite anchors so "open in new tab" goes to correct direct URL
    $wrap.find('a[href]').each(function () {
      var href = ($(this).attr('href') || '').toString();
      if (/\/(wine|product|bundle)\//i.test(href)) {
        $(this).attr('href', detailUrl);
      }
    });

    // Keep data-detail-url consistent
    $wrap.find('.product-image-plp[data-detail-url]').attr('data-detail-url', detailUrl);
  }

  function loadCard($wrap) {
    var C = cfg();
    var ajaxUrl = C.ajaxUrl || C.ajax_url || window.ajaxurl;
    var nonce = C.nonce || C.cartNonce || '';
    var sku = ($wrap.data('b360Sku') || $wrap.data('sku') || '').toString().trim();

    if (!ajaxUrl || !nonce || !sku) return;

    $wrap.attr('aria-busy', 'true');

    $.post(ajaxUrl, {
      action: 'b360_load_product_card',
      nonce: nonce,
      sku: sku
    }).done(function (res) {
      if (res && res.success) {
        $wrap.html(sanitizeHtml((res.data && res.data.html) || ''));
        normalizeCardLinks($wrap);
      } else {
        var msg = (res && res.data && res.data.message) ? res.data.message : 'Unable to load product.';
        $wrap.html('<div class="b360-error">' + msg + '</div>');
      }
    }).fail(function (xhr) {
      $wrap.html('<div class="b360-error">HTTP ' + (xhr && xhr.status ? xhr.status : '') + '</div>');
    }).always(function () {
      $wrap.removeAttr('aria-busy');
    });
  }

  function openDetail($wrap, info) {
    var prodRoot = getProductsRoot($wrap);
    var detailUrl = buildDetailUrl(prodRoot, info.type, info.slug, info.vintage);

    // If Products UI exists on the page, behave like listing (inline + URL push)
    if ($('#b360-detail').length && window.B360 && typeof window.B360.loadDetail === 'function') {
      try {
        if (window.history && window.history.pushState) {
          window.history.pushState(
            { view: 'detail', type: info.type, slug: info.slug, vintage: info.vintage },
            '',
            detailUrl
          );
        }
      } catch (err) {}

      $('#b360-results').hide().empty();
      window.B360.loadDetail(info.type, info.slug, info.vintage);
      return;
    }

    // Otherwise navigate to direct URL (rewrite rules will serve product detail)
    window.location.href = detailUrl;
  }

  $(function () {
    $('.b360-product-card-container').each(function () {
      loadCard($(this));
    });
  });

  // Whole card click
  $(document)
    .off('click.b360ProductCardCard', '.b360-product-card-container .product-card')
    .on('click.b360ProductCardCard', '.b360-product-card-container .product-card', function (e) {
      if ($(e.target).closest('form.shoppincart_form').length) return;
      if ($(e.target).closest('a').length) return;
      if ($(e.target).is('input,button,select,textarea,label')) return;

      var $wrap = $(this).closest('.b360-product-card-container');
      var rel = extractDetailHrefFromCard($wrap);
      var info = parseDetailFromHref(rel);
      if (!info) return;

      e.preventDefault();
      openDetail($wrap, info);
      return false;
    });

  // Link click inside card
  $(document)
    .off('click.b360ProductCardLinks', '.b360-product-card-container a[href]')
    .on('click.b360ProductCardLinks', '.b360-product-card-container a[href]', function (e) {
      if ($(e.target).closest('form.shoppincart_form').length) return;

      var $wrap = $(this).closest('.b360-product-card-container');
      var href = ($(this).attr('href') || '').toString();
      var info = parseDetailFromHref(href);
      if (!info) return;

      e.preventDefault();
      openDetail($wrap, info);
      return false;
    });

})(jQuery);
