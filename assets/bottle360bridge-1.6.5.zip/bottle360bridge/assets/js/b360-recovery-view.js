(function () {
  'use strict';

  var CFG = window.B360Recovery || window.B360Bridge || window.B360 || {};
  var AJAX_URL = CFG.ajaxUrl || CFG.ajax_url || window.ajaxurl || '/wp-admin/admin-ajax.php';
  var NONCE = CFG.nonce || CFG.cartNonce || '';

  function qsa(root, sel) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function qs(root, sel) { return (root || document).querySelector(sel); }

  function setNonce(n) {
    NONCE = n || '';
    if (window.B360Recovery) window.B360Recovery.nonce = NONCE;
    if (window.B360Bridge) { window.B360Bridge.nonce = NONCE; window.B360Bridge.cartNonce = NONCE; }
    if (window.B360) { window.B360.nonce = NONCE; window.B360.cartNonce = NONCE; }
  }

  function shouldRefreshNonce(status, json) {
    if (status === 403) return true;
    var msg = (json && (json.message || json.error || json.msg)) || '';
    return /nonce/i.test(String(msg));
  }

  function refreshNonce() {
    return fetch(AJAX_URL + '?action=b360_get_nonce', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        var n = (j && (j.nonce || (j.data && j.data.nonce))) || '';
        if (j && (j.success === true || j.success === 'true') && n) {
          setNonce(n);
          return n;
        }
        return '';
      })
      .catch(function () { return ''; });
  }

  function pageUrlForEmail() {
    try {
      var href = String(window.location.href || '');
      href = href.split('#')[0];
      href = href.split('?')[0];
      return href;
    } catch (_) {
      return '';
    }
  }

  function currentQuery() {
    try { return String(window.location.search || ''); } catch (_) { return ''; }
  }

  function ensureRecoveryUrlHiddenFields(root, recoveryUrl) {
    qsa(root, 'form').forEach(function (form) {
      var existing = form.querySelector('input[name="recovery_url"]');
      if (existing) { existing.value = recoveryUrl; return; }
      var input = document.createElement('input');
      input.type = 'hidden';
      input.name = 'recovery_url';
      input.value = recoveryUrl;
      form.appendChild(input);
    });
  }

  function setHTML(el, html) { if (el) el.innerHTML = html; }

  function fetchView(root, triedRefresh) {
    if (!root) return;

    root.classList.add('is-loading');
    setHTML(root, '<div class="b360-auth-loading">Loading…</div>');

    var recoveryUrl = pageUrlForEmail();
    var q = currentQuery();

    var fd = new FormData();
    fd.append('action', 'b360_recovery_view');
    fd.append('nonce', NONCE);
    fd.append('query', q);
    fd.append('page_url', window.location.href);
    fd.append('recovery_url', recoveryUrl);

    return fetch(AJAX_URL, { method: 'POST', credentials: 'same-origin', body: fd })
      .then(function (r) {
        var status = r.status;
        return r.text().then(function (txt) {
          var json; try { json = JSON.parse(txt); } catch (_) {}
          return { status: status, json: json, raw: txt };
        });
      })
      .then(function (res) {
        if (shouldRefreshNonce(res.status, res.json) && !triedRefresh) {
          return refreshNonce().then(function (n) {
            if (n) return fetchView(root, true);
            setHTML(root, '<div class="b360-auth-error">Invalid nonce. Please reload the page.</div>');
          });
        }

        var json = res.json || {};
        var html = json.html || (json.data && json.data.html) || '';
        if (!json || json.success !== 'true' || !html) {
          setHTML(root, '<div class="b360-auth-error">Error loading recovery form.</div>');
          return;
        }

        setHTML(root, html);
        ensureRecoveryUrlHiddenFields(root, recoveryUrl);
        wireForms(root);
      })
      .catch(function () {
        setHTML(root, '<div class="b360-auth-error">Network error occurred.</div>');
      })
      .finally(function () {
        root.classList.remove('is-loading');
      });
  }

  function serializeForm(form) {
    var out = {};
    qsa(form, 'input, select, textarea').forEach(function (el) {
      if (!el.name) return;
      var type = (el.type || '').toLowerCase();
      if ((type === 'checkbox' || type === 'radio') && !el.checked) return;
      out[el.name] = el.value;
    });
    return out;
  }

  function submitOnce(form, payload) {
    return fetch(AJAX_URL + '?action=b360_recovery_proxy', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).then(function (r) {
      var status = r.status;
      return r.text().then(function (txt) {
        var json; try { json = JSON.parse(txt); } catch (_) {}
        return { status: status, json: json, raw: txt };
      });
    });
  }

  function wireForms(root) {
    qsa(root, 'form').forEach(function (form) {
      if (form.getAttribute('data-b360-bound')) return;
      form.setAttribute('data-b360-bound', '1');

      form.addEventListener('submit', function (e) {
        e.preventDefault();

        var recoveryUrl = pageUrlForEmail();
        var q = currentQuery();
        var data = serializeForm(form);
        if (!data.recovery_url) data.recovery_url = recoveryUrl;

        var payload = {
          nonce: NONCE,
          query: q,
          page_url: window.location.href,
          recovery_url: recoveryUrl,
          form: data
        };

        submitOnce(form, payload)
          .then(function (res) {
            if (shouldRefreshNonce(res.status, res.json)) {
              return refreshNonce().then(function (n) {
                if (!n) return res;
                payload.nonce = NONCE;
                return submitOnce(form, payload);
              });
            }
            return res;
          })
          .then(function (res) {
            var json = res.json || {};
            var html = (json && (json.html || (json.data && json.data.html))) || '';
            if (html) {
              setHTML(root, String(html));
              ensureRecoveryUrlHiddenFields(root, recoveryUrl);
              wireForms(root);
              return;
            }
            if (res.raw && /<\s*form\b/i.test(res.raw)) {
              setHTML(root, String(res.raw));
              ensureRecoveryUrlHiddenFields(root, recoveryUrl);
              wireForms(root);
              return;
            }
          })
          .catch(function () {});
      });
    });
  }

  function mount(ctx) {
    var scope = ctx || document;
    var roots = qsa(scope, '.b360-recovery-root:not([data-b360-mounted])');
    if (!roots.length) return false;

    roots.forEach(function (root) {
      root.setAttribute('data-b360-mounted', '1');
      fetchView(root, false);
    });

    return true;
  }

  mount(document);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { mount(document); });
  } else {
    setTimeout(function () { mount(document); }, 0);
  }

  (function retryForABit(attempts, delay) {
    var count = 0;
    var t = setInterval(function () {
      if (mount(document)) { clearInterval(t); return; }
      count++;
      if (count >= attempts) clearInterval(t);
    }, delay);
  })(20, 250);

  try {
    var mo = new MutationObserver(function (muts) {
      for (var i = 0; i < muts.length; i++) {
        var m = muts[i];
        if (!m.addedNodes || !m.addedNodes.length) continue;
        for (var j = 0; j < m.addedNodes.length; j++) {
          var node = m.addedNodes[j];
          if (node.nodeType !== 1) continue;
          if (node.matches && node.matches('.b360-recovery-root')) {
            mount(node.parentNode || document);
          } else if (node.querySelector) {
            if (node.querySelector('.b360-recovery-root')) mount(node);
          }
        }
      }
    });
    mo.observe(document.documentElement || document.body, { childList: true, subtree: true });
  } catch (_) {}
})();
