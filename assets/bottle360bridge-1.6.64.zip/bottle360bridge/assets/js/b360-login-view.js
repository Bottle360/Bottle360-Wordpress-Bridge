(function () {
  'use strict';

  // =============================
  // Config from localized JS
  // =============================
  var L0 = window.B360Bridge || window.B360 || {};
  var AJAX_URL = L0.ajax_url || L0.ajaxUrl || window.ajaxurl || '/wp-admin/admin-ajax.php';
  var ONE_NONCE = L0.nonce || L0.cartNonce || ''; // single source; we still map to both vars below

  // Back-compat aliases you already use:
  var VIEW_NONCE = ONE_NONCE;   // for b360_auth_view (HTML fetch)
  var CART_NONCE = ONE_NONCE;   // for b360_auth_proxy (submit)

  // When we refresh nonce, update globals too so other files see it:
  function setGlobalNonce(n) {
    VIEW_NONCE = CART_NONCE = ONE_NONCE = n || '';
    if (window.B360Bridge) {
      B360Bridge.nonce = n; B360Bridge.cartNonce = n;
    }
    if (window.B360) {
      B360.nonce = n; B360.cartNonce = n;
    }
  }

  // ===== Small utils =====
  function fire(evt, detail) { try { document.dispatchEvent(new CustomEvent(evt, { detail: detail })); } catch (_) { } }
  function qs(root, sel) { return root.querySelector(sel); }
  function qsa(root, sel) { return Array.prototype.slice.call(root.querySelectorAll(sel)); }
  function setHTML(el, html) { if (el) el.innerHTML = html; }
  // applyForgotPasswordLink(root);

  function setText(el, txt) { if (el) el.textContent = txt; }
  function log(root, msg, data) {
    if (!root || (root.getAttribute('data-debug') || '').toLowerCase() !== 'yes') return;
    if (data !== undefined) console.log('[b360-login-view]', msg, data);
    else console.log('[b360-login-view]', msg);
  }

  function setMsg(scopeEl, text, ok) {
    var box = scopeEl && (qs(scopeEl, '.b360-auth-msg') || qs(scopeEl, '[data-b360-auth-msg]'));
    if (!box) return;
    setText(box, text || '');
    if (ok == null) return;
    box.style.color = ok ? 'inherit' : '#b91c1c';
  }

  function serializeForm(form) {
    var out = {};
    if (!form) return out;
    qsa(form, 'input, select, textarea').forEach(function (el) {
      if (!el.name) return;
      var type = (el.type || '').toLowerCase();
      if ((type === 'checkbox' || type === 'radio') && !el.checked) return;
      var val = el.value;
      if (out[el.name] !== undefined) {
        if (!Array.isArray(out[el.name])) out[el.name] = [out[el.name]];
        out[el.name].push(val);
      } else {
        out[el.name] = val;
      }
    });
    return out;
  }

  // ========= Nonce helpers =========
  function shouldRefreshNonce(status, json) {
    if (status === 403) return true;
    var msg = (json && (json.message || json.error || json.msg)) || '';
    return /nonce/i.test(String(msg));
  }

  // Returns Promise<string> resolving to fresh nonce (or '' on failure)
  function refreshNonce() {
    return fetch(AJAX_URL + '?action=b360_get_nonce', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        var n = (j && (j.nonce || (j.data && j.data.nonce))) || '';
        if (j && (j.success === true || j.success === 'true') && n) {
          setGlobalNonce(n);
          return n;
        }
        return '';
      })
      .catch(function () { return ''; });
  }

  // ===== Auth guard (redirect login/register to account if already authed) =====
  function hasStoredUser() {
    try {
      var raw = localStorage.getItem('b360_user');
      if (!raw) return false;
      var s = JSON.parse(raw);
      var fname = s && (s.firstName || (s.user && (s.user.firstname || s.user.firstName || s.user.given_name || s.user.name)));
      return !!fname;
    } catch (_) { return false; }
  }
  function accountUrlFor(root) {
    return (
      (root && root.getAttribute && root.getAttribute('data-account-url')) ||
      (window.B360Bridge && B360Bridge.accountUrl) ||
      '/my-account'
    );
  }

  // ===== View fetch & form wiring (with nonce refresh-once) =====
  function fetchView(view, root, _triedRefresh) {
    if (!root) return;
    log(root, 'fetchView start: ' + view);

    root.classList.add('is-loading');
    setHTML(root, '<div class="b360-auth-loading">Loading…</div>');

    var fd = new FormData();
    fd.append('action', 'b360_auth_view');
    fd.append('nonce', VIEW_NONCE);
    fd.append('view', view);

    fire('b360:auth:init', { root: root, view: view });
    fire('b360:' + view + ':init', { root: root });

    return fetch(AJAX_URL, { method: 'POST', credentials: 'same-origin', body: fd })
      .then(function (r) {
        var status = r.status;
        return r.text().then(function (txt) {
          var json; try { json = JSON.parse(txt); } catch (_) { }
          return { status: status, json: json, raw: txt };
        });
      })
      .then(function (res) {
        var status = res.status, json = res.json || {};
        log(root, 'view response', res);

        if (shouldRefreshNonce(status, json) && !_triedRefresh) {
          // Refresh nonce once and retry
          return refreshNonce().then(function (n) {
            if (n) return fetchView(view, root, true);
            // refresh failed
            setHTML(root, '<div class="b360-auth-error">Invalid nonce. Please reload the page.</div>');
          });
        }

        if (!json || !json.success || !json.html && !(json.data && json.data.html)) {
          setHTML(root, '<div class="b360-auth-error">Error loading view.</div>');
          fire('b360:' + view + ':error', { root: root, reason: 'invalid_response', json: json });
          return;
        }

        var html = json.html || (json.data && json.data.html) || '';
        setHTML(root, html);
        wireForms(root); // robust binder below
        fire('b360:auth:mounted', { root: root, view: view, html: true });
      })
      .catch(function (err) {
        setHTML(root, '<div class="b360-auth-error">Network error occurred.</div>');
        fire('b360:' + view + ':error', { root: root, error: err, stage: 'fetchView' });
        log(root, 'fetchView error', err);
      })
      .finally(function () {
        root.classList.remove('is-loading');
      });
  }

  function successHandler(form, view) {
    return function (res) {
      var status = res.status;
      var data = res.json || {};
      log(form, 'submit response', res);

      var successValue = data && data.success;
      var isSuccess = (successValue === true || successValue === 'true');

      if (status >= 200 && status < 300 && isSuccess) {
        var user = data.user || {};
        var first = user.firstname || user.firstName || user.given_name || user.name || data.firstName || '';

        // Save to LS so profile menu flips on next page
        if (window.b360Auth) {
          if (typeof window.b360Auth.setUserObject === 'function') {
            window.b360Auth.setUserObject({ user: user, firstName: first });
          } else if (typeof window.b360Auth.setUser === 'function') {
            window.b360Auth.setUser({ firstName: first, user: user });
          } else {
            try {
              localStorage.setItem('b360_user', JSON.stringify({ firstName: first, user: user }));
              document.dispatchEvent(new CustomEvent('b360:userChanged', { detail: { firstName: first, user: user } }));
            } catch (_) { }
          }
        } else {
          try {
            localStorage.setItem('b360_user', JSON.stringify({ firstName: first, user: user }));
            document.dispatchEvent(new CustomEvent('b360:userChanged', { detail: { firstName: first, user: user } }));
          } catch (_) { }
        }

        // Fire success events
        try {
          document.dispatchEvent(new CustomEvent('b360:' + view + ':success', {
            detail: { form: form, user: user, firstName: first, raw: data }
          }));
          document.dispatchEvent(new CustomEvent('b360:auth:success', {
            detail: { type: view, user: user, firstName: first, raw: data }
          }));
        } catch (_) { }

        // Redirect to My Account
        setMsg(form, 'Success. Redirecting…', true);
        var root = form.closest('.b360-auth-root');
        var target = accountUrlFor(root);
        setTimeout(function () { window.location.replace(target); }, 10);
        return;
      }

      var msg = (data && (data.message || data.error)) || ('Request failed (' + (status || 500) + ')');
      setMsg(form, msg, false);
      fire('b360:' + view + ':error', { form: form, status: status, response: data, message: msg, stage: 'submit' });
    };
  }

  function submitOnce(form, path, view) {
    var payload = {
      nonce: CART_NONCE,
      method: 'POST',
      path: path,           // '/b360-login' or '/b360-register'
      form: serializeForm(form)
    };

    setMsg(form, 'Please wait…', true);
    fire('b360:' + view + ':submit', { form: form, payload: payload });
    log(form, 'submit payload', payload);

    return fetch(AJAX_URL + '?action=b360_auth_proxy', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(function (r) {
        var status = r.status;
        return r.text().then(function (txt) {
          var json; try { json = JSON.parse(txt); } catch (_) { }
          return { status: status, json: json, raw: txt };
        });
      });
  }

  function submitHandler(form, path, view) {
    return function (e) {
      e.preventDefault();

      submitOnce(form, path, view)
        .then(function (res) {
          if (shouldRefreshNonce(res.status, res.json)) {
            // refresh once & retry
            return refreshNonce().then(function (n) {
              if (!n) return res; // fall through to normal handler (will show error)
              return submitOnce(form, path, view);
            });
          }
          return res;
        })
        .then(successHandler(form, view))
        .catch(function (err) {
          setMsg(form, 'Network error. Please try again.', false);
          fire('b360:' + view + ':error', { form: form, error: err, stage: 'submit_catch' });
          log(form, 'submit catch', err);
        });
    };
  }

  // ===== Forgot password link rewrite =====
  // Bottle360 upstream markup contains a "Forgot password" row but we want it to land on a WP page.
  // URL is supplied via LoginShortcode attribute: forgot_password_url
  function applyForgotPasswordLink(root) {
    if (!root || !root.querySelector) return;

    var url = '';
    try {
      url = (root.getAttribute('data-forgot-url') || '').trim();
      if (!url && window.B360Bridge && B360Bridge.forgotPasswordUrl) {
        url = String(B360Bridge.forgotPasswordUrl || '').trim();
      }
    } catch (_) { }

    var row = root.querySelector('.forgot-password') || root.querySelector('.form-group.forgot-password');
    if (!row) return;

    // If caller didn’t provide a URL, hide the row to avoid sending users to the upstream domain.
    if (!url) {
      row.style.display = 'none';
      return;
    }

    // Unhide just in case upstream included inline style.
    row.style.display = '';

    var a = row.querySelector('a');
    if (!a) return;
    a.setAttribute('href', url);
  }


  // --- Robust form detection ---
  function detectFormType(form) {
    var action = (form.getAttribute('action') || '').toLowerCase();

    // Primary detection by action path
    if (action.indexOf('register') !== -1) return { type: 'register', path: '/b360-register' };
    if (action.indexOf('login') !== -1) return { type: 'login', path: '/b360-login' };

    // Heuristics by input names (upstream changes safe)
    var hasLoginUser = form.querySelector('input[name="UserLogin[username]"], input[name="username"]');
    var hasLoginPass = form.querySelector('input[name="UserLogin[password]"], input[name="password"]');
    if (hasLoginUser && hasLoginPass) {
      return { type: 'login', path: '/b360-login' };
    }

    // Register-ish: has email + password + (firstname|first_name)
    var hasEmail = form.querySelector('input[name="email"], input[type="email"], input[name*="[email]"]');
    var hasPwd = form.querySelector('input[name="password"], input[name*="[password]"]');
    var hasFirst = form.querySelector('input[name="firstname"], input[name="first_name"], input[name*="[firstname]"], input[name*="[first_name]"]');
    if (hasEmail && hasPwd && hasFirst) {
      return { type: 'register', path: '/b360-register' };
    }

    // Unknown
    return null;
  }

  function wireForms(root) {
    if (!root) return;

    // Bind any forms under the mounted view
    var forms = qsa(root, 'form');
    var bound = 0;

    forms.forEach(function (form) {
      var meta = detectFormType(form);
      if (!meta) return;

      if (meta.type === 'login') {
        form.addEventListener('submit', submitHandler(form, meta.path, 'login'));
        bound++;
        log(root, 'login form bound (heuristic)', { action: form.getAttribute('action') || '', path: meta.path });
      } else if (meta.type === 'register') {
        form.addEventListener('submit', submitHandler(form, meta.path, 'register'));
        bound++;
        log(root, 'register form bound (heuristic)', { action: form.getAttribute('action') || '', path: meta.path });
      }
    });

    // Fallbacks (legacy selectors) in case nothing was bound
    if (!bound) {
      var loginForm =
        qs(root, 'form[action*="/b360-login"]') ||
        qs(root, 'form[data-b360-login-form]');
      if (loginForm) {
        loginForm.addEventListener('submit', submitHandler(loginForm, '/b360-login', 'login'));
        bound++;
        log(root, 'login form bound (legacy selector)');
      }

      var registerForm =
        qs(root, 'form[action*="/b360-register"]') ||
        qs(root, 'form[data-b360-register-form]');
      if (registerForm) {
        registerForm.addEventListener('submit', submitHandler(registerForm, '/b360-register', 'register'));
        bound++;
        log(root, 'register form bound (legacy selector)');
      }
    }

    if (!bound) {
      log(root, 'no auth forms detected in injected HTML');
    }

    // Inline switcher (optional)
    root.addEventListener('click', function (e) {
      var t = e.target.closest('[data-b360-switch-view]');
      if (!t) return;
      e.preventDefault();
      var v = (t.getAttribute('data-b360-switch-view') || '').toLowerCase();
      if (v !== 'login' && v !== 'register') v = 'login';
      fetchView(v, root);
    });
  }

  // ===== Robust mounting =====
  function mountAuthRoots(ctx) {
    var scope = ctx || document;
    var roots = qsa(scope, '.b360-auth-root:not([data-b360-bound])');
    if (!roots.length) return false;

    roots.forEach(function (root) {
      root.setAttribute('data-b360-bound', '1'); // prevent double init
      var view = (root.getAttribute('data-view') || 'login').toLowerCase();
      if (view !== 'login' && view !== 'register') view = 'login';

      var wantsRedirect = (root.getAttribute('data-redirect-if-auth') || 'yes') === 'yes';
      if (wantsRedirect && hasStoredUser()) {
        log(root, 'redirecting to account (already authed)');
        window.location.replace(accountUrlFor(root));
        return;
      }

      fetchView(view, root);
    });

    return true;
  }

  // Immediate attempt
  mountAuthRoots(document);

  // Try again on DOM ready and window load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { mountAuthRoots(document); });
  } else {
    setTimeout(function () { mountAuthRoots(document); }, 0);
  }
  window.addEventListener('load', function () { mountAuthRoots(document); });

  // Gentle retry loop (handles builders)
  (function retryForABit(attempts, delay) {
    var count = 0;
    var t = setInterval(function () {
      if (mountAuthRoots(document)) { clearInterval(t); return; }
      count++;
      if (count >= attempts) clearInterval(t);
    }, delay);
  })(20, 250);

  // MutationObserver for dynamically inserted markup
  try {
    var mo = new MutationObserver(function (muts) {
      for (var i = 0; i < muts.length; i++) {
        var m = muts[i];
        if (!m.addedNodes || !m.addedNodes.length) continue;
        for (var j = 0; j < m.addedNodes.length; j++) {
          var node = m.addedNodes[j];
          if (node.nodeType !== 1) continue;
          if (node.matches && node.matches('.b360-auth-root')) {
            mountAuthRoots(node.parentNode || document);
          } else if (node.querySelector) {
            if (node.querySelector('.b360-auth-root')) mountAuthRoots(node);
          }
        }
      }
    });
    mo.observe(document.documentElement || document.body, { childList: true, subtree: true });
  } catch (_) { }
})();
