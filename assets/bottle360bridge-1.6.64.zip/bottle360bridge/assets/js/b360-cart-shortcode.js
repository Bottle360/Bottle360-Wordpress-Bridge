(function ($) {
  'use strict';

  var $toggle, $modal, $close, $backdrop, $body, $dialog, $continue;
  var loading = false;

  // ---- Config / fallbacks ---------------------------------------------------
  // var AJAX_URL = (window.B360Bridge && window.B360Bridge.ajaxUrl) || window.ajaxurl || '/wp-admin/admin-ajax.php';
  // var NONCE    = (window.B360Bridge && (window.B360Bridge.cartNonce || window.B360Bridge.nonce || window.B360Bridge.ajaxNonce)) || '';

  var AJAX_URL = (window.B360Bridge && window.B360Bridge.ajaxUrl) ||
    (window.B360CartShortcode && window.B360CartShortcode.ajaxUrl) ||
    window.ajaxurl || "/wp-admin/admin-ajax.php";
  var NONCE = (window.B360Bridge && (window.B360Bridge.cartNonce || window.B360Bridge.nonce || window.B360Bridge.ajaxNonce)) ||
    (window.B360CartShortcode && (window.B360CartShortcode.nonce || window.B360CartShortcode.ajaxNonce)) ||
    "";

  var B360_CART_QTY_KEY = 'b360.cartQty';

  // ---- Styles for reliable show/hide of the buttons -------------------------
  function ensureInlineStyle() {
    if (document.getElementById('b360-cart-inline-style')) return;
    var css = [
      '#b360-cart-sc-buttons.b360-hidden, .b360-cart-sc-buttons.b360-hidden{display:none !important;}',
      '.b360-cart-sc-spinner{min-height:64px;min-width:64px;display:flex;align-items:center;justify-content:center;}'
    ].join('\n');
    var style = document.createElement('style');
    style.id = 'b360-cart-inline-style';
    style.type = 'text/css';
    style.appendChild(document.createTextNode(css));
    document.head.appendChild(style);
  }

  function getButtonsWrapper() { return $('#b360-cart-sc-buttons, .b360-cart-sc-buttons').first(); }
  function hideButtons() { var $b = getButtonsWrapper(); if ($b.length) $b.addClass('b360-hidden').attr('hidden', true).css('display', 'none'); }
  function showButtons() { var $b = getButtonsWrapper(); if ($b.length) $b.removeClass('b360-hidden').removeAttr('hidden').css('display', ''); }

  // ---- Badge helpers --------------------------------------------------------
  function getSavedCartQty() {
    var v = window.localStorage ? localStorage.getItem(B360_CART_QTY_KEY) : null;
    var n = parseInt(v || '0', 10);
    return isNaN(n) ? 0 : Math.max(0, n);
  }
  function saveCartQty(qty) {
    try { if (window.localStorage) localStorage.setItem(B360_CART_QTY_KEY, String(Math.max(0, parseInt(qty || 0, 10)))); } catch (e) { }
  }
  function updateCartBadge(qty) {
    qty = Math.max(0, parseInt(qty || 0, 10));
    var $badge = $('#b360-cart-sc-count');
    if ($badge.length) $badge.text(qty);
  }

  // ---- Sanitize & loaders ---------------------------------------------------
  function sanitizeHtml(html) {
    var tpl = document.createElement('template');
    tpl.innerHTML = html || '';
    tpl.content.querySelectorAll('script, noscript').forEach(function (n) { n.remove(); });
    tpl.content.querySelectorAll('*').forEach(function (el) {
      Array.from(el.attributes).forEach(function (attr) { if (/^on/i.test(attr.name)) el.removeAttribute(attr.name); });
    });
    return tpl.innerHTML;
  }
  function showLoader() {
    if (!$body || !$body.length) return;
    $body.addClass('b360-cart-sc-loading').attr('aria-busy', 'true')
      .html('<div class="b360-cart-sc-spinner" role="status" aria-live="polite" aria-label="Loading cart…"></div>');
  }
  function clearLoader() { if ($body && $body.length) $body.removeClass('b360-cart-sc-loading').removeAttr('aria-busy'); }

  // ---- Qty extraction (robust across upstream markup) -----------------------
  // We used to rely on table-cell text, but upstream markup often uses <input>
  // for quantity, which makes `.text()` return empty and the badge stay at 0.
  // Strategy order:
  //  1) [data-cart-count] attribute (if upstream provides it)
  //  2) common count elements (.cart-items-count, #cart-count, etc.)
  //  3) sum qty inputs/selects inside the popup
  //  4) sum Qty/Quantity column in table.cart-container-popup (text or input)
  //  5) count line items as a last resort
  function getQtyColumnIndex($root) {
    var idx = -1;
    $root.find('#shopping-cart-popup-content table.cart-container-popup thead th').each(function (i) {
      var t = (($(this).text && $(this).text()) || '').trim();
      if (/(^|\b)(qty|quantity)(\b|$)/i.test(t)) idx = i;
    });
    return idx; // -1 if not found
  }

  function readQtyFromCell($cell) {
    if (!$cell || !$cell.length) return 0;

    // Prefer inputs/selects if present
    var $inp = $cell.find('input:not([type="hidden"])[type="number"], input:not([type="hidden"])[name*="qty"], input:not([type="hidden"])[name*="quantity"], input:not([type="hidden"]).qty, select[name*="qty"], select[name*="quantity"]').first();
    if ($inp.length) {
      var v = $inp.val();
      var n = parseInt((v || '').toString().replace(/[^\d-]/g, ''), 10);
      if (!isNaN(n) && n > 0) return n;
      // some markups store value only in attribute
      var av = $inp.attr('value');
      n = parseInt((av || '').toString().replace(/[^\d-]/g, ''), 10);
      if (!isNaN(n) && n > 0) return n;
    }

    // Fall back to text content
    var txt = ($cell.text ? $cell.text() : '') + '';
    var n2 = parseInt(txt.replace(/[^\d-]/g, ''), 10);
    return (!isNaN(n2) && n2 > 0) ? n2 : 0;
  }

  function extractQtyFromTable($root) {
    var sum = 0, idx = getQtyColumnIndex($root);
    var $rows = $root.find('#shopping-cart-popup-content table.cart-container-popup tbody tr');
    $rows.each(function () {
      var $row = $(this);
      var $cells = $row.children('td');
      var n = 0;

      if (idx >= 0 && $cells.eq(idx).length) {
        n = readQtyFromCell($cells.eq(idx));
      }

      if (!n) {
        // Try any qty input inside the row
        var $rowInp = $row.find('input:not([type="hidden"])[type="number"][name*="qty"], input:not([type="hidden"])[name*="qty"], input:not([type="hidden"])[name*="quantity"], input:not([type="hidden"]).qty, select[name*="qty"], select[name*="quantity"]').first();
        if ($rowInp.length) {
          var v = $rowInp.val();
          if (v === undefined || v === null || v === '') v = $rowInp.attr('value');
          var nn = parseInt((v || '').toString().replace(/[^\d-]/g, ''), 10);
          if (!isNaN(nn) && nn > 0) n = nn;
        }
      }

      if (!n && $cells.eq(1).length) {
        // Common fallback: 2nd cell
        n = readQtyFromCell($cells.eq(1));
      }

      if (!isNaN(n) && n > 0) sum += n;
    });
    return sum;
  }

  function extractQtyFromInputs($root) {
    var sum = 0;
    $root.find(
      '#shopping-cart-popup-content input:not([type="hidden"])[name*="qty"],\
       #shopping-cart-popup-content input:not([type="hidden"])[name*="quantity"],\
       #shopping-cart-popup-content input:not([type="hidden"]).qty,\
       #shopping-cart-popup-content input:not([type="hidden"])[type="number"],\
       #shopping-cart-popup-content select[name*="qty"],\
       #shopping-cart-popup-content select[name*="quantity"]'
    ).each(function () {
      var $el = $(this);
      var v = $el.val();
      if (v === undefined || v === null || v === '') v = $el.attr('value');
      var n = parseInt((v || '').toString().replace(/[^\d-]/g, ''), 10);
      if (!isNaN(n) && n > 0) sum += n;
    });
    return sum;
  }

  function extractQtyFromLineItems($root) {
    var sum = 0;
    var $items = $root.find('#shopping-cart-popup-content .cart-item, #shopping-cart-popup-content .b360-cart-item, #shopping-cart-popup-content .basket-item, #shopping-cart-popup-content .mini-cart-item, #shopping-cart-popup-content [data-cart-item]');

    $items.each(function () {
      var $item = $(this);
      var n = 0;

      var $explicit = $item.find('.quantity-value, [data-quantity], [data-qty], .qty-value, .product-qty, .cart-item-qty').first();
      if ($explicit.length) {
        var explicitVal = $explicit.attr('data-quantity') || $explicit.attr('data-qty') || ($explicit.text ? $explicit.text() : '') || $explicit.attr('value') || '';
        n = parseInt(String(explicitVal).replace(/[^\d-]/g, ''), 10);
        if (isNaN(n) || n < 0) n = 0;
      }

      if (!n) {
        var $inp = $item.find('input:not([type="hidden"])[name*="qty"], input:not([type="hidden"])[name*="quantity"], input:not([type="hidden"]).qty, input:not([type="hidden"])[type="number"], select[name*="qty"], select[name*="quantity"]').first();
        if ($inp.length) {
          var inputVal = $inp.val();
          if (inputVal === undefined || inputVal === null || inputVal === '') inputVal = $inp.attr('value');
          n = parseInt(String(inputVal || '').replace(/[^\d-]/g, ''), 10);
          if (isNaN(n) || n < 0) n = 0;
        }
      }

      if (!n) {
        var qtyText = [
          $item.find('.qty-container-wrapper').first().text(),
          $item.find('.qty-container').first().text(),
          $item.find('.quantity-wrapper').first().text(),
          $item.find('.product-details').first().text(),
          $item.text()
        ].join(' ');
        var match = qtyText.match(/(?:^|\b)(?:qty|quantity)\s*[:\-]?\s*(\d+)/i);
        if (match) {
          n = parseInt(match[1], 10);
          if (isNaN(n) || n < 0) n = 0;
        }
      }

      if (n > 0) sum += n;
    });

    return sum;
  }

  function extractTotalQty($root) {
    // 1) data-cart-count
    var $dc = $root.find('[data-cart-count]').first();
    if ($dc.length) {
      var dv = parseInt(($dc.attr('data-cart-count') || '').toString().replace(/[^\d-]/g, ''), 10);
      if (!isNaN(dv) && dv >= 0) return dv;
    }

    // 2) common count elements
    var $countEl = $root.find('.cart-items-count, .cart-count, #cart-count, .b360-badge-count').first();
    if ($countEl.length) {
      var cv = parseInt((($countEl.text && $countEl.text()) || '').toString().replace(/[^\d-]/g, ''), 10);
      if (!isNaN(cv) && cv >= 0) return cv;
    }

    // 3) inputs/selects sum
    var fromInputs = extractQtyFromInputs($root);
    if (fromInputs > 0) return fromInputs;

    // 4) line-item parsing (non-table modal markup)
    var fromLineItems = extractQtyFromLineItems($root);
    if (fromLineItems > 0) return fromLineItems;

    // 5) table parsing
    var fromTable = extractQtyFromTable($root);
    if (fromTable > 0) return fromTable;

    // 6) fallback: count line items / rows
    var items = $root.find('.cart-item, .b360-cart-item, .basket-item, .mini-cart-item, [data-cart-item], #shopping-cart-popup-content table.cart-container-popup tbody tr').length;
    return items > 0 ? items : 0;
  }

  // Empty detection tailored to your popup
  function isExplicitEmpty($root) {
    var txt = $root.find('#shopping-cart-popup-content').text().trim();
    return /shopping\s+cart\s+is\s+empty/i.test(txt);
  }
  function computeEmpty($root) {
    if (isExplicitEmpty($root)) return true;

    // Any obvious items?
    var $items = $root.find('#shopping-cart-popup-content .cart-item, #shopping-cart-popup-content .b360-cart-item, #shopping-cart-popup-content .basket-item, #shopping-cart-popup-content .mini-cart-item, #shopping-cart-popup-content [data-cart-item]');
    if ($items.length > 0) return false;

    // Table rows (common upstream)
    var $rows = $root.find('#shopping-cart-popup-content table.cart-container-popup tbody tr');
    if ($rows.length > 0) return false;

    // Qty inputs (common when markup is not a table)
    var $qtyInputs = $root.find('#shopping-cart-popup-content input:not([type="hidden"])[name*="qty"], #shopping-cart-popup-content input:not([type="hidden"])[name*="quantity"], #shopping-cart-popup-content input:not([type="hidden"]).qty, #shopping-cart-popup-content select[name*="qty"], #shopping-cart-popup-content select[name*="quantity"]');
    if ($qtyInputs.length > 0) return false;

    // Soft hints
    var txt = $root.find('#shopping-cart-popup-content').text();
    if (/\bsubtotal\b|\btotal\b|(?:\$|€|£|AED|SAR|PKR)\s*\d/i.test(txt)) return false;

    return true;
  }

  // ---- Checkout redirect (same as Cart page) --------------------------------
  function handleCheckout(ev) {
    if (ev && ev.preventDefault) ev.preventDefault();
    var $btn = $(ev && ev.currentTarget ? ev.currentTarget : null);
    if ($btn && $btn.length) { if ($btn.data('busy')) return; $btn.data('busy', true).attr('aria-busy', 'true'); }

    $.post(AJAX_URL, { action: 'b360_checkout_redirect', nonce: NONCE, _ajax_nonce: NONCE })
      .done(function (resp) {
        try {
          var redirectUrl = (resp && resp.data && resp.data.redirect_url) || (resp && resp.redirect_url);
          if (resp && resp.success === false) { throw new Error((resp.data && (resp.data.message || resp.data.body)) || 'Unable to start checkout.'); }
          if (redirectUrl) { window.location.href = redirectUrl; return; }
          throw new Error('Unable to start checkout.');
        } catch (e) { alert(e && e.message ? e.message : 'Unable to start checkout.'); }
      })
      .fail(function () { alert('Unable to start checkout. Please try again.'); })
      .always(function () { if ($btn && $btn.length) { $btn.data('busy', false).removeAttr('aria-busy'); } });
  }

  // Delegated binding (works for injected markup)
  $(document)
    .off('click.b360CheckoutMini')
    .on('click.b360CheckoutMini',
      '#b360-cart-sc-buttons .b360-checkout-btn a, #b360-cart-sc-body a[data-b360-checkout], #b360-cart-sc-body a[href*="checkout"]',
      handleCheckout
    );

  // ---- Load & render mini cart (and update badge) ---------------------------
  function fetchCart() {
    if (loading) return;
    loading = true;
    hideButtons();
    showLoader();

    $.post(AJAX_URL, { action: 'b360_load_minicart', nonce: NONCE, _ajax_nonce: NONCE })
      .done(function (res) {
        var payload = '';
        if (res && res.success) {
          payload = (res.data && (res.data.html || res.data.body || res.data)) || '';
          var clean = sanitizeHtml(payload);
          $body.html(clean || '<div id="shopping-cart-popup"><div id="shopping-cart-popup-content">Shopping cart is empty!</div><div id="shopping-cart-popup-footer"></div></div>');
        } else {
          var msg = (res && res.data && (res.data.message || res.data.body)) || 'Error';
          $body.html('<div class="b360-cart-sc-error">' + msg + '</div>');
        }

        // Compute qty first; if qty > 0, it is not empty even if markup is unusual.
        var qty = extractTotalQty($body);
        var empty = computeEmpty($body) && qty === 0;

        if (!empty) { showButtons(); } else { hideButtons(); }

        saveCartQty(qty);
        updateCartBadge(qty);

        // Hook for others
        $(document).trigger('b360:miniCart:loaded', { empty: empty, qty: qty });
      })
      .fail(function (xhr) {
        $body.html('<div class="b360-cart-sc-error">HTTP ' + (xhr && xhr.status ? xhr.status : '') + '</div>');
        hideButtons();
      })
      .always(function () {
        loading = false;
        clearLoader();
      });
  }

  // Background refresh (does not touch modal DOM) → recompute qty & badge
  function refreshBadgeFromServer() {
    return $.post(AJAX_URL, { action: 'b360_load_minicart', nonce: NONCE, _ajax_nonce: NONCE })
      .done(function (res) {
        if (!(res && res.success)) return;
        var html = sanitizeHtml((res.data && (res.data.html || res.data.body || res.data)) || '');
        var $tmp = $('<div/>').html(html);
        var qty = extractTotalQty($tmp);
        var empty = computeEmpty($tmp) && qty === 0;
        saveCartQty(qty);
        updateCartBadge(qty);
        $(document).trigger('b360:miniCart:badgeRefreshed', { qty: qty, empty: empty });
      });
  }

  // ---- Modal open/close -----------------------------------------------------
  function openModal() {
    if (!$modal || !$modal.length) return;
    $modal.removeAttr('hidden');
    $('body').addClass('b360-cart-sc-open');
    if ($toggle && $toggle.length) $toggle.attr('aria-expanded', 'true');
    fetchCart(); // always refresh on open
  }
  function closeModal() {
    if (!$modal || !$modal.length) return;
    $modal.attr('hidden', true);
    $('body').removeClass('b360-cart-sc-open');
    if ($toggle && $toggle.length) $toggle.attr('aria-expanded', 'false');
  }

  // ---- Public helpers -------------------------------------------------------
  window.B360CartIcon = {
    setCount: function (n) { n = Math.max(0, parseInt(n || 0, 10)); saveCartQty(n); updateCartBadge(n); },
    getCount: function () { return getSavedCartQty(); },
    open: openModal,
    close: closeModal,
    refreshBadge: refreshBadgeFromServer
  };

  // ---- Add-to-cart listeners ------------------------------------------------
  // 1) Optimistic increment when user clicks known "add to cart" triggers
  $(document).on('click.b360AddToCartOptimistic',
    '[data-b360-add-to-cart], .b360-add-to-cart, form[action*="add-to-cart"] button[type="submit"], button[name="add-to-cart"], a[href*="add-to-cart"]',
    function () {
      var $btn = $(this);
      var qty = 1;

      // Try to read a nearby qty input
      var $form = $btn.closest('form');
      var $qtyInput = $form.find('input[name="quantity"], input[name="qty"], input[data-qty], .qty').first();
      if ($qtyInput.length) {
        var v = parseInt(($qtyInput.val() || '').toString().replace(/[^\d-]/g, ''), 10);
        if (!isNaN(v) && v > 0) qty = v;
      }

      var current = getSavedCartQty();
      var optimistic = current + qty;
      saveCartQty(optimistic);
      updateCartBadge(optimistic);
    }
  );

  // 2) Verify after AJAX completes for add-to-cart actions (server truth)
  $(document).on('ajaxComplete.b360AddToCartVerify', function (e, xhr, settings) {
    var s = settings || {};
    var dataStr = typeof s.data === "string" ? s.data : "";
    var urlStr = (s.url || "") + "";

    // If the request used FormData, inspect it too (jQuery will not stringify it).
    var fdAction = "";
    try {
      if (s.data && typeof FormData !== "undefined" && s.data instanceof FormData) {
        fdAction = s.data.get("action") || "";
      }
    } catch (err) { }

    var looksLikeAdd = (fdAction === "b360_add_to_cart") ||
      /(?:^|&)action=b360_add_to_cart(?:&|$)/.test(dataStr) ||
      /add[_-]?to[_-]?cart|addtocart/i.test(dataStr) ||
      /add[_-]?to[_-]?cart|addtocart/i.test(urlStr);
    if (looksLikeAdd) {
      // Recompute from server in background (no modal flicker)
      refreshBadgeFromServer();
    }
  });

  // ---- Init -----------------------------------------------------------------
  $(function () {
    ensureInlineStyle();

    $toggle = $('#b360-cart-sc-toggle');
    $modal = $('#b360-cart-sc-modal');
    $close = $('#b360-cart-sc-close');
    $backdrop = $('.b360-cart-sc-backdrop');
    $body = $('#b360-cart-sc-body');
    // $body     = $(document.body);
    $dialog = $modal.find('.b360-cart-sc-dialog'); // inner modal box
    $continue = $('.b360-cart-sc-continue');

    // Seed badge from localStorage immediately
    updateCartBadge(getSavedCartQty());

    // Buttons hidden until we know state
    hideButtons();

    if ($toggle.length) $toggle.on('click', function (e) { e.preventDefault(); openModal(); });
    if ($close.length) $close.on('click', function (e) { e.preventDefault(); closeModal(); });
    if ($continue.length) $continue.on('click', function (e) { e.preventDefault(); closeModal(); });
    if ($backdrop.length) $backdrop.on('click', function () { closeModal(); });
    $(document).on('keydown', function (e) { if (e.key === 'Escape') closeModal(); });

    // Close when clicking anywhere outside the modal dialog
    $(document).on('click', function (e) {
      if (!$modal || !$modal.length) return;
      if ($modal.is('[hidden]')) return; // modal not open

      var $target = $(e.target);

      // Ignore clicks on the toggle (to avoid instant re-close after open)
      if ($toggle && $toggle.length &&
        ($target.is($toggle) || $toggle.has(e.target).length)) {
        return;
      }

      // Ignore clicks inside the dialog
      if ($dialog && $dialog.length &&
        ($target.is($dialog) || $dialog.has(e.target).length)) {
        return;
      }

      // Anything else closes the modal
      closeModal();
    });


    // Optional: first paint accuracy from server (no UI change)
    refreshBadgeFromServer();
  });

})(jQuery);
