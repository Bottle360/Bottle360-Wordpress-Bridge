/*!
 * Bottle360 Bridge – b360-bridge.js (FULL DROP-IN)
 * - Single pagination click handler (prevents double AJAX)
 * - Page 1 rewrites to pretty ROOT (no /page/1, no /b360-store)
 * - Category-aware pagination: /…/b360-category/<slug>/page/N only when category is active
 * - Product detail links always use products ROOT (/product/<slug>, /bundle/<slug>, /wine/<slug>/<vintage>)
 * - Listing AJAX de-duped (older in-flight requests are aborted)
 * - Preserves your cart / mini-cart / checkout paths
 */
(function ($) {
  "use strict";

  // =========================
  // Helpers: URL parsing/building
  // =========================

  function normalizePath(path) {
    return (path || '').replace(/\/+$/, '');
  }

  // Extract /page/N (defaults to 1)
  function pageFromPath(pathname) {
    var path = normalizePath(pathname || '/');
    var m = path.match(/\/page\/(\d+)(?:\/|$)/i);
    return m ? Math.max(1, parseInt(m[1], 10)) : 1;
  }

  // Remove trailing /page/N from a URL to get the page root (current path)
  function pageRootFromUrl(urlLike) {
    try {
      var a = document.createElement('a');
      a.href = urlLike || window.location.href;
      var root = normalizePath(a.pathname).replace(/\/page\/\d+$/i, '');
      if (root === '') root = '/';
      return root;
    } catch (e) {
      return '/';
    }
  }

  // Products root (prefix before /b360-category/...; no /page/N)
  function productsRootFromUrl(urlLike) {
    try {
      var a = document.createElement('a');
      a.href = urlLike || window.location.href;
      var p = normalizePath(a.pathname).replace(/\/page\/\d+$/i, '');
      var m = p.match(/^(.*)\/(?:b360-category|collection)(?:\/.*)?$/i);
      var root = m ? (m[1] || '/') : (p || '/');
      return root || '/';
    } catch (e) {
      return '/';
    }
  }

  // ---------------------------------
  // Products root resolution
  // ---------------------------------

  function listingWrap() {
    var $w = $('#b360-results');
    if (!$w.length) $w = $('.b360-results').first();
    return $w;
  }

  function storeUrlFromDom() {
    try {
      var $w = listingWrap();
      if (!$w.length) return '';
      var v = ($w.data('storeUrl') || $w.attr('data-store-url') || '').toString();
      return v || '';
    } catch (e) {
      return '';
    }
  }

  function pathFromUrl(urlLike) {
    try {
      var a = document.createElement('a');
      a.href = urlLike || '';
      return a.pathname || '/';
    } catch (e) {
      return '/';
    }
  }

  function productsRootFromStoreUrl(storeUrl) {
    var p = normalizePath(pathFromUrl(storeUrl));
    if (!p) p = '/';
    return p;
  }

  // Resolve products root for building detail/pager URLs.
  // Priority: data-store-url (shortcode) → B360Route.storeBase → current URL fallback
  function resolveProductsRoot() {
    var storeUrl = storeUrlFromDom();
    if (storeUrl) return productsRootFromStoreUrl(storeUrl);

    // On real store routes DirectHandler localizes B360Route.storeBase (.../b360-category)
    if (window.B360Route && B360Route.storeBase) {
      var sp = normalizePath(pathFromUrl(B360Route.storeBase));
      // strip /collection suffix if present
      sp = sp.replace(/\/(?:b360-category|collection)\/?$/i, '');
      if (!sp) sp = '/';
      return sp;
    }

    return productsRootFromUrl(window.location.href);
  }

  function resolveActiveCategorySlug() {
    // 1) data-b360-category on the listing wrapper (shortcode embed)
    try {
      var $w = listingWrap();
      if ($w && $w.length) {
        var c = $w.data('b360Category') || $w.attr('data-b360-category');
        if (c) return c.toString();
      }
    } catch (e) { }

    // 2) store route localization
    if (window.B360Route && B360Route.category) {
      return (B360Route.category || '').toString();
    }

    // 3) URL fallback
    return currentCategorySlug();
  }


  // Recognize detail URLs: /{type}/{slug}[/{vintage}]  (NO /b360/)
  function isDetailPath(pathname) {
    var path = normalizePath(pathname);
    return /\/(wine|product|bundle)\/[^/]+(?:\/[^/]+)?\/?$/i.test(path);
  }

  // Parse detail info from detail URL (NO /b360/)
  function parseDetailFromPath(pathname) {
    var path = normalizePath(pathname);
    var m = path.match(/\/(wine|product|bundle)\/([^/]+)(?:\/([^/]+))?\/?$/i);
    if (!m) return { type: '', slug: '', vintage: '' };
    return {
      type: m[1].toLowerCase(),
      slug: decodeURIComponent(m[2]),
      vintage: m[3] ? decodeURIComponent(m[3]) : ''
    };
  }

  // Build detail URL off the **products root** (no pagination, NO /b360/)
  function buildDetailUrl(productsRoot, type, slug, vintage) {
    var base = productsRoot || '/';
    var parts = [base, type, slug];
    if (type === 'wine' && vintage) parts.push(vintage);
    var url = parts.join('/').replace(/\/+/g, '/');
    return url.endsWith('/') ? url : url + '/';
  }

  // Category slug (if current URL has /b360-category/<slug>)
  function currentCategorySlug() {
    var m = (window.location.pathname || '').match(/\/(?:b360-category|collection)\/([^/]+)/i);
    return (m && m[1]) ? decodeURIComponent(m[1]) : '';
  }

  // Pretty pager URL builder (category-aware). Page 1 → root (no /page/1)
  function prettyPagerUrl(n) {
    var root = resolveProductsRoot();
    var base = (window.location.origin || '') + (root === '/' ? '' : root);
    base = base.replace(/\/+$/, '') || (window.location.origin || '');

    var cat = resolveActiveCategorySlug();
    if (cat) return base + '/collection/' + encodeURIComponent(cat) + (n > 1 ? '/page/' + n : '');
    return base + (n > 1 ? '/page/' + n : '');
  }


  // =========================
  // Sanitizer for remote detail HTML
  // =========================
  function sanitizeHtml(html) {
    var tpl = document.createElement('template');
    tpl.innerHTML = html || '';
    tpl.content.querySelectorAll('script, noscript').forEach(function (n) { n.remove(); });
    tpl.content.querySelectorAll('*').forEach(function (el) {
      Array.from(el.attributes).forEach(function (attr) {
        if (/^on/i.test(attr.name)) el.removeAttribute(attr.name);
      });
    });
    return tpl.innerHTML;
  }

  // ====================================================================
  // Quantity normalization & validation (ADD-ONLY, non-destructive)
  // ====================================================================
  function b360QtyRules($input) {
    var min = parseFloat($input.attr('data-min') || $input.attr('min'));
    var maxS = ($input.attr('data-max') != null) ? $input.attr('data-max') : $input.attr('max');
    var step = parseFloat($input.attr('data-step') || $input.attr('step'));

    if (!isFinite(min) || min <= 0) min = 1;
    if (!isFinite(step) || step <= 0) step = 1;

    var max = parseFloat(maxS);
    if (!isFinite(max) || max <= 0) max = null; // 0/empty => no upper bound

    return { min: min, max: max, step: step };
  }
  function b360QtySetNumber($input, rules) {
    // NEW: never touch hidden fields
    var t = ($input.attr('type') || '').toLowerCase();
    if (t === 'hidden') return;

    try { $input.attr('type', 'number'); } catch (e) { }
    $input.attr('min', String(rules.min));
    $input.attr('step', String(rules.step));
    if (rules.max != null) $input.attr('max', String(rules.max));
    else $input.removeAttr('max');
    $input.attr('inputmode', 'numeric').removeAttr('pattern');
  }
  function b360QtyShowErr($input, msg) {
    var $group = $input.closest('.qty-button-group, .form-group, form');
    var $err = $group.find('.b360-qty-error');
    if (!$err.length) {
      $err = $('<div class="b360-error b360-qty-error" role="alert" aria-live="polite"></div>').appendTo($group);
    }
    $err.text(msg).show();
    $input.addClass('b360-qty-invalid').attr('aria-invalid', 'true');
  }
  function b360QtyClearErr($input) {
    var $group = $input.closest('.qty-button-group, .form-group, form');
    $group.find('.b360-qty-error').hide().text('');
    $input.removeClass('b360-qty-invalid').removeAttr('aria-invalid');
  }
  function b360QtyValidate($input, showError) {
    if (!$input || !$input.length) return { ok: true };
    var rules = b360QtyRules($input);
    var raw = ($input.val() || '').toString().trim();
    var val = parseFloat(raw);

    if (!raw.length || isNaN(val)) {
      if (showError) b360QtyShowErr($input, 'Please enter a number.');
      return { ok: false };
    }
    if (val < rules.min) {
      if (showError) b360QtyShowErr($input, 'Minimum quantity is ' + rules.min + '.');
      return { ok: false };
    }
    if (rules.max != null && val > rules.max) {
      if (showError) b360QtyShowErr($input, 'Maximum quantity is ' + rules.max + '.');
      return { ok: false };
    }
    // step check: val must be min + N*step
    var n = (val - rules.min) / rules.step;
    if (Math.abs(Math.round(n) - n) > 1e-9) {
      if (showError) b360QtyShowErr($input, 'Quantity must be in increments of ' + rules.step + (rules.min ? (' starting at ' + rules.min) : '') + '.');
      return { ok: false };
    }
    b360QtyClearErr($input);
    return { ok: true, value: val };
  }
  function b360EnhanceQty($scope) {
    var $root = ($scope && $scope.length) ? $scope : $(document);
    $root.find('form.shoppincart_form input[name="qty[]"]:not([type="hidden"])').each(function () {
      var $q = $(this);
      var rules = b360QtyRules($q);
      b360QtySetNumber($q, rules);
      b360QtyValidate($q, false);
    });
  }
  // live normalization/validation
  $(document)
    .off('input.b360qty change.b360qty', 'form.shoppincart_form input[name="qty[]"]:not([type="hidden"])')
    .on('input.b360qty change.b360qty', 'form.shoppincart_form input[name="qty[]"]:not([type="hidden"])', function () {
      var $q = $(this);
      b360QtySetNumber($q, b360QtyRules($q));
      b360QtyValidate($q, false);
    });
  // block form submit if invalid (covers Enter key submissions etc.)
  $(document)
    .off('submit.b360qty', 'form.shoppincart_form')
    .on('submit.b360qty', 'form.shoppincart_form', function (e) {
      var $form = $(this);
      var $qty = $form.find('input[name="qty[]"]:not([type="hidden"])').first();
      b360EnhanceQty($form);
      var ok = b360QtyValidate($qty, true).ok;
      if (!ok) { e.preventDefault(); e.stopImmediatePropagation(); return false; }
      return true;
    });

  // =========================
  // AJAX loaders
  // =========================

  var currentListingXhr = null; // de-dupe tracker

  function loadListing(opts) {
    var o = $.extend({ type: 'product', page: 1 }, opts || {});

    // Try #b360-results first, then any .b360-results (just in case)
    var $wrap = $('#b360-results');
    if (!$wrap.length) {
      $wrap = $('.b360-results').first();
    }
    if (!$wrap.length) return;

    // overlay on the results container
    $wrap.addClass('b360-loading-overlay').attr('aria-busy', 'true');

    // spinner node (removed after request)
    var $spin = $('<div class="b360-spinner" aria-hidden="true"></div>');
    $wrap.append($spin);

    var payload = {
      action: 'b360_load_listing',
      nonce: B360Bridge.nonce,
      type: o.type,
      page: o.page,
      page_url: window.location.href
    };

    // ----------------------------
    // Resolve category (multi-source)
    // ----------------------------
    var cat = '';

    // 1) Explicit override from opts.category
    if (typeof o.category === 'string' && o.category.length) {
      cat = o.category;
    }

    // 2) data-b360-category on the results wrapper
    if (!cat) {
      // jQuery data() mapping: data-b360-category → .data('b360Category')
      var dataApi = $wrap.data('b360Category');
      var dataAttr = $wrap.attr('data-b360-category');
      if (dataApi) {
        cat = dataApi.toString();
      } else if (dataAttr) {
        cat = dataAttr.toString();
      }
    }

    // 3) B360Route.category (set by PHP on real /b360-category/<slug> routes)
    if (!cat && window.B360Route && B360Route.category) {
      cat = (B360Route.category || '').toString();
    }

    // 4) Optional global from shortcode (if we ever add it)
    if (!cat && window.B360 && window.B360.selectedCategory) {
      cat = (window.B360.selectedCategory || '').toString();
    }

    // 5) Fallback: derive from current URL /b360-category/<slug>
    if (!cat) {
      try {
        var path = (window.location.pathname || '').replace(/\/+$/, '');
        var m = path.match(/\/(?:b360-category|collection)\/([^/]+)/i);
        if (m && m[1]) {
          cat = decodeURIComponent(m[1]);
        }
      } catch (e) { }
    }

    if (cat) {
      payload.category = cat;
    }

    // DEBUG: see what we're sending
    if (window.console && console.log) {
      console.log('[b360] loadListing resolved category =', cat, 'payload =', payload);
    }

    // ----------------------------
    // AJAX request (unchanged)
    // ----------------------------

    // De-dupe: cancel any in-flight listing request
    if (currentListingXhr && currentListingXhr.readyState !== 4) {
      try { currentListingXhr.abort(); } catch (e) { }
    }

    currentListingXhr = $.post(B360Bridge.ajaxUrl, payload)
      .done(function (res) {
        if (res && res.success) {
          $wrap.html(res.data.html || '<div class="b360-empty">No items</div>');
          // ENHANCE QTY FIELDS after listing render
          b360EnhanceQty($wrap);
          if (window.B360NormalizePager) window.B360NormalizePager($wrap);
        } else {
          $wrap.html('<div class="b360-error">' + (res && res.data && res.data.message ? res.data.message : 'Error') + '</div>');
        }
      })
      .fail(function (xhr) {
        $wrap.html('<div class="b360-error">HTTP ' + (xhr && xhr.status ? xhr.status : '') + '</div>');
      })
      .always(function () {
        // remove overlay/spinner
        $wrap.removeClass('b360-loading-overlay').removeAttr('aria-busy');
        $spin.remove();
        currentListingXhr = null;
      });
  }



  function loadDetail(type, slug, vintage) {
    var $detail = $('#b360-detail');
    if (!$detail.length) return;
    $detail.html('<div class="b360-loading">Loading…</div>');
    $.post(B360Bridge.ajaxUrl, {
      action: 'b360_load_product_detail',
      nonce: B360Bridge.nonce,
      type: type,
      slug: slug,
      vintage: vintage || ''
    }).done(function (res) {
      if (res && res.success) {
        var clean = sanitizeHtml(res.data.html || '<div class="b360-empty">No content</div>');
        $detail.html(clean);
        // ENHANCE QTY FIELDS after detail render
        b360EnhanceQty($detail);
      } else {
        $detail.html('<div class="b360-error">' + (res && res.data && res.data.message ? res.data.message : 'Error') + '</div>');
      }
    }).fail(function (xhr) {
      $detail.html('<div class="b360-error">HTTP ' + (xhr && xhr.status ? xhr.status : '') + '</div>');
    });
  }

  // =========================
  // View transitions
  // =========================

  function showList(page) {
    $('#b360-detail').empty();                 // clear detail
    $('#b360-results').show();                 // show listing
    loadListing({ page: page || 1 });
  }

  function showDetailAndHideList(type, slug, vintage) {
    $('#b360-results').hide().empty();         // hide/remove listing
    loadDetail(type, slug, vintage);
  }

  // =========================
  // Event wiring
  // =========================

  // Pagination (list view) — SINGLE handler (prevents double AJAX)
  $(document)
    .off('click.b360Pager', '#b360-results .pager .pagination a, #b360-results .pagination a')
    .on('click.b360Pager', '#b360-results .pager .pagination a, #b360-results .pagination a', function (e) {
      var href = $(this).attr('href');
      if (!href) return;
      e.preventDefault();

      // derive page from /page/N or ?page=N; /b360-store links mean page 1
      var nextPage = 1;
      var mp = href.match(/\/page\/(\d+)(?:\/|$)/i);
      var mq = href.match(/[?&]page=(\d+)/i);
      if (mp) nextPage = parseInt(mp[1], 10) || 1;
      else if (mq) nextPage = parseInt(mq[1], 10) || 1;
      else if (/\/b360-store(?:\/|$)/i.test(href)) nextPage = 1;

      // page 1 → pretty root (no /page/1, no /b360-store)
      var target = prettyPagerUrl(nextPage);

      history.pushState({ view: 'list', page: nextPage }, '', target);

      // scroll to listing (so loader is visible)
      var container = document.querySelector('.b360-bridge-container') || document.querySelector('#b360-results');
      if (container && container.scrollIntoView) {
        container.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }

      // load
      loadListing({ page: nextPage });
    });

  // Product click → detail (strip pagination from URL; base on **products root**)
  $(document).on('click', '#b360-results a, #b360-results button[data-b360-slug]', function (e) {
    var $t = $(this);
    var type = ($t.data('b360-type') || '').toString();
    var slug = ($t.data('b360-slug') || '').toString();
    var vintage = ($t.data('b360-vintage') || '').toString();
    var href = $t.attr('href');

    var currentPage = pageFromPath(location.pathname);
    var prodRoot = resolveProductsRoot(); // ALWAYS build off Products page root (never current page)

    // If data-* absent, parse from href if it matches our detail shape
    if (!slug && href) {
      var info = parseDetailFromPath(href);
      if (info.slug && info.type) {
        type = info.type; slug = info.slug; vintage = info.vintage;
      }
    }
    if (!slug || !type) return; // not our link; let it behave normally

    e.preventDefault();

    var urlToPush = buildDetailUrl(prodRoot, type, slug, vintage); // no /b360/
    // Push detail state; keep where we came from in history (so Back returns to it)
    if (window.history && window.history.pushState) {
      window.history.pushState(
        { view: 'detail', type: type, slug: slug, vintage: vintage, fromPage: currentPage },
        '',
        urlToPush
      );
    }
    showDetailAndHideList(type, slug, vintage);
  });

  // Back/forward handling
  window.addEventListener('popstate', function () {
    var path = location.pathname;

    if (isDetailPath(path)) {
      // Deep-linking or navigating into detail state
      var info = parseDetailFromPath(path);
      showDetailAndHideList(info.type, info.slug, info.vintage);
      return;
    }

    // Any non-detail path is listing (maybe /page/N)
    var page = pageFromPath(path);
    showList(page);
  });

  // =========================
  // Initial boot
  // =========================
  $(function () {
    // if (!$('.b360-bridge-container').length) return;

    // Only boot listing/detail router when Products UI exists.
    // Product-card embed also uses .b360-bridge-container for styling, but must NOT boot the router.
    if (!$('#b360-results').length && !$('#b360-detail').length && !$('.b360-results').length) return;


    var path = location.pathname;

    if (isDetailPath(path)) {
      // Direct load on detail URL: hide list and load detail
      var info = parseDetailFromPath(path);
      // Replace initial state so Back returns to referrer if any (optional)
      if (window.history && window.history.replaceState) {
        window.history.replaceState({ view: 'detail', type: info.type, slug: info.slug, vintage: info.vintage }, '', location.href);
      }
      showDetailAndHideList(info.type, info.slug, info.vintage);
    } else {
      // Listing route
      var initialPage = pageFromPath(path);
      if (window.history && window.history.replaceState) {
        window.history.replaceState({ view: 'list', page: initialPage }, '', location.href);
      }
      showList(initialPage);
    }
  });

  // Expose minimal API if needed elsewhere
  window.B360 = window.B360 || {};
  window.B360.loadListing = loadListing;
  window.B360.loadDetail = loadDetail;

  // =========================
  // Add to Cart (AJAX → WP)
  // =========================

  // Helper: open modal and inject HTML safely
  function openCartModalWithHtml(cartHtml) {
    var $modal = $('#b360-cart-sc-modal');
    var $body = $('#b360-cart-sc-body');

    if (!$modal.length || !$body.length) {
      // Fallback: if the modal isn't on this page, try mini-cart loader if present
      if (typeof loadMiniCart === 'function') { try { loadMiniCart(); } catch (e) { } }
      else if (typeof window.B360LoadMiniCart === 'function') { try { window.B360LoadMiniCart(); } catch (e) { } }
      return;
    }

    var clean = (typeof sanitizeHtml === 'function') ? sanitizeHtml(cartHtml || '') : (cartHtml || '');
    $body.html(clean || '<div class="b360-cart-sc-empty">Your cart is empty.</div>');

    // open the modal
    $modal.removeAttr('hidden');
    $('body').addClass('b360-cart-sc-open');
    $('#b360-cart-sc-toggle').attr('aria-expanded', 'true');
  }

  // Try to update any badge count from the returned HTML (best effort)
  function updateCartBadgeFromHtml(cartHtml) {
    var $badge = $('#b360-cart-sc-count');
    if (!$badge.length) return;

    var count = 0;
    try {
      var temp = document.createElement('div');
      temp.innerHTML = cartHtml || '';

      var dc = temp.querySelector('[data-cart-count]');
      if (dc && dc.getAttribute('data-cart-count')) {
        count = parseInt(dc.getAttribute('data-cart-count'), 10) || 0;
      }

      if (!count) {
        var el = temp.querySelector('.b360-badge-count, .cart-count, #cart-count, .cart-items-count');
        if (el) count = parseInt((el.textContent || '').trim().replace(/[^\d-]/g, ''), 10) || 0;
      }

      if (!count) {
        var lineItems = temp.querySelectorAll('.cart-item, .b360-cart-item, .basket-item, .mini-cart-item, [data-cart-item]');
        if (lineItems && lineItems.length) {
          lineItems.forEach(function (item) {
            var n = 0;

            var explicit = item.querySelector('.quantity-value, [data-quantity], [data-qty], .qty-value, .product-qty, .cart-item-qty');
            if (explicit) {
              var explicitVal = explicit.getAttribute('data-quantity') || explicit.getAttribute('data-qty') || explicit.textContent || explicit.getAttribute('value') || '';
              n = parseInt(String(explicitVal).replace(/[^\d-]/g, ''), 10) || 0;
            }

            if (!n) {
              var qtyInput = item.querySelector('input:not([type="hidden"])[name*="qty"], input:not([type="hidden"])[name*="quantity"], input:not([type="hidden"]).qty, input:not([type="hidden"])[type="number"], select[name*="qty"], select[name*="quantity"]');
              if (qtyInput) {
                var qtyInputVal = qtyInput.value || qtyInput.getAttribute('value') || '';
                n = parseInt(String(qtyInputVal).replace(/[^\d-]/g, ''), 10) || 0;
              }
            }

            if (!n) {
              var text = [
                ((item.querySelector('.qty-container-wrapper') || {}).textContent || ''),
                ((item.querySelector('.qty-container') || {}).textContent || ''),
                ((item.querySelector('.quantity-wrapper') || {}).textContent || ''),
                ((item.querySelector('.product-details') || {}).textContent || ''),
                item.textContent || ''
              ].join(' ');
              var match = text.match(/(?:^|\b)(?:qty|quantity)\s*[:\-]?\s*(\d+)/i);
              if (match) n = parseInt(match[1], 10) || 0;
            }

            if (n > 0) count += n;
          });
        }
      }

      if (!count) {
        var items = temp.querySelectorAll('.cart-item, .b360-cart-item, .basket-item, .mini-cart-item, [data-cart-item]');
        count = items ? items.length : 0;
      }
    } catch (e) { }

    $badge.text(Math.max(0, count));
  }

  // Global JSONP callback (kept for compatibility if needed)
  window.addCart = function (response) {
    if (response && response.cart) {
      openCartModalWithHtml(response.cart);
      updateCartBadgeFromHtml(response.cart);
    }
    $('#b360-detail form.shoppincart_form .btn.btn-primary[disabled]').each(function () {
      var $b = $(this);
      var t = $b.data('orig-text') || 'Add to Cart';
      $b.data('busy', false).prop('disabled', false).text(t);
    });
  };

  function getCookie(name) {
    const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    return match ? match[2] : null;
  }

  // Delegated handler so it continues to work on dynamically-injected detail HTML
  jQuery(document).on('click', 'form.shoppincart_form .btn.btn-primary', function (e) {
    e.preventDefault();

    var $btn = jQuery(this);
    var $form = $btn.closest('form.shoppincart_form');

    if ($btn.data('busy')) return;

    // ======== QTY VALIDATION GUARD (ADD-ONLY) ========
    var $qty = $form.find('input[name="qty[]"]:not([type="hidden"])').first();
    b360EnhanceQty($form); // ensure number attrs applied
    var valid = b360QtyValidate($qty, true).ok;
    if (!valid) {
      try { $qty[0].focus({ preventScroll: false }); } catch (err) { $qty.focus(); }
      return false; // do not mark busy; do not proceed
    }
    // ================================================

    var orig = $btn.data('orig-text') || $btn.text();
    $btn.data('orig-text', orig);
    $btn.data('busy', true).prop('disabled', true).text('Adding…');

    // Build FormData so array fields like price[], qty[] stay intact
    var formData = new FormData($form[0]);
    formData.append('action', 'b360_add_to_cart');
    formData.append('nonce', B360Bridge.cartNonce);
    formData.append('ajaxmode', 'thirdparty');
    formData.append('_cb', Date.now());

    // Attach Yii cookie if available
    var yiiSession = getCookie('PHPSESSID'); // adjust if Yii uses a different cookie name
    if (yiiSession) {
      formData.append('yii_cookie', yiiSession);
    }

    jQuery.ajax({
      url: B360Bridge.ajaxUrl,
      type: 'POST',
      dataType: 'json',
      processData: false,
      contentType: false,
      data: formData,
      success: function (res) {
        console.log(res);
        if (res.success && res.data.cart) {
          openCartModalWithHtml(res.data.cart);
        } else {
          alert(res.error || 'Could not add to cart.');
        }
      },
      error: function (req, status, err) {
        // console.log(status,err);
        // Fallback open (lets server render a fresh cart in modal on next open)
        $("#b360-cart-sc-toggle").trigger('click');
      },
      complete: function () {
        $btn.data('busy', false).prop('disabled', false).text(orig);
      }
    });

    return false;
  });

  // ===== CSRF cookie utils & ensure =====
  function b360GetCookie(name) {
    var m = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/([$?*|{}\]\\^])/g, '\\$1') + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : '';
  }
  function b360SetCookie(name, value, ttlSeconds) {
    var parts = [name + '=' + encodeURIComponent(value), 'path=/', 'samesite=Lax'];
    if (ttlSeconds) parts.push('max-age=' + Math.max(1, ttlSeconds | 0));
    if (location.protocol === 'https:') parts.push('secure');
    document.cookie = parts.join('; ');
  }
  function ensureCsrf() {
    return new Promise(function (resolve, reject) {
      var name = b360GetCookie('b360_csrf_name');
      var val = b360GetCookie('b360_csrf');
      var exp = parseInt(b360GetCookie('b360_csrf_exp') || '0', 10);
      var nowS = Math.floor(Date.now() / 1000);
      if (name && val && exp && (exp - nowS) > 30) {
        resolve({ name: name, value: val, ttl: exp - nowS });
        return;
      }
      $.post(B360Bridge.ajaxUrl, {
        action: 'b360_get_csrf',
        _ajax_nonce: (B360Bridge.cartNonce || B360Bridge.nonce)
      }).done(function (res) {
        if (res && res.success && res.data && res.data.value) {
          b360SetCookie('b360_csrf_name', res.data.name, res.data.ttl);
          b360SetCookie('b360_csrf', res.data.value, res.data.ttl);
          b360SetCookie('b360_csrf_exp', (Math.floor(Date.now() / 1000) + (res.data.ttl | 0)).toString(), res.data.ttl);
          resolve({ name: res.data.name, value: res.data.value, ttl: res.data.ttl });
        } else {
          reject(res && res.data ? res.data : { message: 'Bad CSRF response' });
        }
      }).fail(function (xhr) {
        reject({ message: 'CSRF fetch failed', status: xhr && xhr.status });
      });
    });
  }
  $(function () { ensureCsrf().catch(function () { }); });
  window.B360 = window.B360 || {};
  window.B360.ensureCsrf = ensureCsrf;

})(jQuery);

jQuery(function ($) {
  var CHECKOUT_SEL = [
    '#b360-shopping-cart-content .cart-order-summary a.btn[href*="checkout"]',
    '#b360-shopping-cart-content a[href*="/orders/checkout"]',
    '#b360-shopping-cart-content a[href*="/store/checkout"]'
  ].join(', ');

  function getNonce() {
    var L = window.B360Bridge || window.B360 || {};
    return L.nonce || L.cartNonce || '';
  }

  // Prefer shared helper if present
  function callCheckoutRedirect() {
    if (typeof window.b360Ajax === 'function') {
      return window.b360Ajax('b360_checkout_redirect', {}); // Promise
    }
    var ajax = (window.B360Bridge && (B360Bridge.ajax_url || B360Bridge.ajaxUrl)) || window.ajaxurl || '/wp-admin/admin-ajax.php';
    return jQuery.post(ajax, { action: 'b360_checkout_redirect', nonce: getNonce() });
  }

  // One delegated handler that works for initial HTML and any later DOM updates
  $(document)
    .off('click.b360Checkout', CHECKOUT_SEL)
    .on('click.b360Checkout', CHECKOUT_SEL, function (e) {
      // Let users open in new tab/window
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.which === 2) return;

      e.preventDefault();

      var $btn = $(this);
      var prev = $btn.text();
      $btn.prop('disabled', true).addClass('is-loading');

      function restore() {
        $btn.prop('disabled', false).removeClass('is-loading').text(prev);
      }

      callCheckoutRedirect()
        .then(function (res) {
          var url =
            (res && res.redirect_url) ||
            (res && res.url) ||
            (res && res.data && (res.data.redirect_url || res.data.url));

          if (url) {
            window.location.assign(url);
          } else {
            var msg = (res && res.data && res.data.message) || 'Unable to load checkout.';
            alert(msg);
            restore();
          }
        })
        .catch(function () {
          alert('Checkout failed.');
          restore();
        });
    });
});

jQuery(function ($) {
  var modalSel = (window.B360Bridge && B360Bridge.cartModalSel) ? B360Bridge.cartModalSel : '#b360-cart-modal';
  var headerTriggerSel = '#b360-open-cart, .b360-open-cart, [data-b360-open-cart]';
  var cartContentSel = '#b360-cart_internal_contents';

  function showModal() {
    var $m = $(modalSel);
    if (!$m.length) return;
    if (typeof $m.modal === 'function') $m.modal('show'); else $m.addClass('is-open');
  }

  function loadMiniCart() {
    var $c = $(cartContentSel);
    if (!$c.length) return;
    $.post(B360Bridge.ajaxUrl, { action: 'b360_load_minicart', nonce: B360Bridge.cartNonce })
      .done(function (r) {
        if (r && r.success && r.data && r.data.html) {
          $c.html(r.data.html);
          $(document).trigger('b360:cart:loaded');
        } else {
          $c.html('<div class="alert alert-danger">Unable to load cart.</div>');
        }
      });
  }
  // Optional: expose for first IIFE fallback
  window.B360LoadMiniCart = loadMiniCart;

  $(document).off('click.b360OpenCart', headerTriggerSel)
    .on('click.b360OpenCart', headerTriggerSel, function (e) {
      e.preventDefault();
      showModal();
    });

  $(document).off('shown.bs.modal.b360Cart', modalSel)
    .on('shown.bs.modal.b360Cart', modalSel, function () {
      loadMiniCart();
    });

  $(document).on('ajaxComplete', function (e, xhr, settings) {
    var data = settings && settings.data ? settings.data.toString() : '';
    if (/(^|&)action=b360_add_to_cart(&|$)/.test(data) && xhr && xhr.status === 200) {
      console.log('in ajax complete if');
      showModal();
    }
  });

  $(document).on('b360:refresh-cart', function () {
    loadMiniCart();
  });
});

/* === B360 pager normalizer (category-aware, rewrite-only) === */
(function ($) {
  "use strict";

  // Products base = prefix before /b360-category (no /page/N)
  function productsBase() {
    var path = (window.location.pathname || '')
      .replace(/\/+$/, '')
      .replace(/\/page\/\d+$/i, '');
    var m = path.match(/^(.*)\/(?:b360-category|collection)(?:\/.*)?$/i);
    var prefix = m ? (m[1] || '') : path;
    return (window.location.origin || '') + (prefix || '/');
  }

  function routeCat() {
    if (window.B360Route && B360Route.category) return B360Route.category;
    var m = (window.location.pathname || '').match(/\/(?:b360-category|collection)\/([^/]+)/i);
    return (m && m[1]) ? decodeURIComponent(m[1]) : '';
  }

  function prettyUrlWithCat(pageNum, catOverride) {
    var base = productsBase().replace(/\/+$/, '');
    var cat = (typeof catOverride === 'string' && catOverride) ? catOverride : routeCat();
    var url = base + (cat ? '/collection/' + encodeURIComponent(cat) : '');
    if (pageNum && pageNum > 1) url += '/page/' + pageNum;
    return url;
  }

  // Rewrite hrefs inside a scope (no click binding here)
  function fixPagerAnchors($scope) {
    $scope.find('a').each(function () {
      var href = this.getAttribute('href') || '';

      // upstream forms or leftovers: capture slug if present so we keep category on page 1 too
      var mStoreQ = href.match(/\/b360-store\/?([^?\/#]+)?[^#]*?[?&]page=(\d+)/i); // /b360-store/<slug>?page=N
      var mStoreP = href.match(/\/b360-store\/?([^?\/#]+)?\/page\/(\d+)(?:\/|$)/i); // /b360-store/<slug>/page/N
      var mStoreBare = href.match(/\/b360-store(?:\/([^?\/#]+))?\/?(?:[#?]|$)/i);      // /b360-store[/<slug>]  (NO page)
      var mBareQ = href.match(/[?&]page=(\d+)/i);                                  // ?page=N
      var mPageP = href.match(/\/page\/(\d+)(?:\/|$)/i);                           // /page/N

      var catFromHref = null;
      var n = 1;
      if (mStoreQ) { catFromHref = mStoreQ[1] ? decodeURIComponent(mStoreQ[1]) : null; n = parseInt(mStoreQ[2], 10) || 1; }
      else if (mStoreP) { catFromHref = mStoreP[1] ? decodeURIComponent(mStoreP[1]) : null; n = parseInt(mStoreP[2], 10) || 1; }
      else if (mBareQ) { n = parseInt(mBareQ[1], 10) || 1; }
      else if (mPageP) { n = parseInt(mPageP[1], 10) || 1; }

      var shouldRewrite = !!mStoreQ || !!mStoreP || !!mBareQ || !!mPageP || !!mStoreBare;

      if (shouldRewrite) {
        // naked /b360-store (or /b360-store/<slug>) → page 1 at pretty base
        if (mStoreBare && !mStoreQ && !mStoreP && !mBareQ && !mPageP) n = 1;
        var newHref = prettyUrlWithCat(n, catFromHref);
        this.setAttribute('href', newHref);
        this.setAttribute('data-page', String(n));
      }
    });
  }

  // After each listing AJAX, normalize anchors
  $(document).ajaxSuccess(function (_evt, _xhr, options) {
    var isListingCall = false;

    if (typeof options.data === 'string') {
      isListingCall = /(^|&)action=b360_load_listing(&|$)/.test(options.data);
    } else if (options.data && typeof options.data === 'object') {
      isListingCall = options.data.action === 'b360_load_listing';
    }

    if (isListingCall) {
      var $wrap = $('#b360-results, .b360-listing, #b360-listing, .b360-bridge-container').first();
      if ($wrap.length) fixPagerAnchors($wrap);
    }
  });

  // Expose manual hook
  window.B360NormalizePager = fixPagerAnchors;

})(jQuery);
/* === /B360 pager normalizer === */
