<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Http\Client;
use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class LoadListing
{
    public function register(): void
    {
        add_action('wp_ajax_b360_load_listing',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_load_listing', [$this, 'handle']);
    }

    public function handle(): void
    {
        try {
            $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
            $isJson  = stripos((string) $ctype, 'application/json') !== false;
            $payload = $isJson ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: []) : $_POST;

            Nonce::assertAjax($payload, 'nonce');

            $page = isset($_REQUEST['page']) ? max(1, (int) $_REQUEST['page']) : $this->current_page_num();

            // category: request > parsed from url (/b360-category/<slug>)
            $category = '';
            if (!empty($_REQUEST['category'])) {
                $category = sanitize_title(wp_unslash($_REQUEST['category']));
            } else {
                $category = $this->detect_category_from_url($this->current_page_url());
            }

            // upstream path still /b360-store[/<category>]
            $base   = rtrim((string) Options::get_base_host(), '/');
            $path   = '/b360-store' . ($category !== '' ? '/' . rawurlencode($category) : '');
            $remote = $base . $path . ($page > 1 ? ('?page=' . $page) : '');

            // cookies
            $headers = [];
            if (
                class_exists('\\Bottle360\\Bridge\\Services\\YiiSession') &&
                method_exists('\\Bottle360\\Bridge\\Services\\YiiSession', 'cookieHeader')
            ) {
                try {
                    $cookie = \Bottle360\Bridge\Services\YiiSession::cookieHeader();
                    if ($cookie) $headers['Cookie'] = $cookie;
                } catch (\Throwable $e) {
                }
            }
            if (isset($_SESSION) && !empty($_SESSION['yii_session_cookie'])) {
                $headers['Cookie'] = (string) $_SESSION['yii_session_cookie'];
            }

            $res = $this->http_get($remote, $headers);
            if (!$res['ok']) {
                wp_send_json_error(['message' => $res['error'] ?? 'Failed to load products', 'status' => (int)$res['status']], (int)$res['status']);
            }

            $pageUrl = $this->current_page_url();
            $html    = $this->rewrite_links_to_local((string) $res['body'], $pageUrl);

            wp_send_json_success([
                'html'        => $html,
                'yii_session' => isset($_SESSION['yii_session_cookie']) ? (string) $_SESSION['yii_session_cookie'] : '',
            ]);
        } catch (\Throwable $e) {
            wp_send_json_error(['message' => 'Unhandled error', 'error' => $e->getMessage()], 500);
        }
    }

    private function current_page_num(): int
    {
        $q = get_query_var('paged');
        $n = (int) ($q ?: 1);
        return max(1, $n);
    }

    private function current_page_url(): string
    {
        $ref = wp_get_referer();
        if ($ref) return untrailingslashit($ref);
        $permalink = get_permalink();
        if ($permalink) return untrailingslashit($permalink);
        return untrailingslashit(home_url(add_query_arg([])));
    }

    private function detect_category_from_url(string $url): string
    {
        $path = (string) parse_url($url, PHP_URL_PATH);
        $path = rtrim($path, '/');
        if ($path === '') return '';
        if (preg_match('#/(?:b360-category|collection)/([^/]+)(?:/|$)#i', $path, $m)) {
            return sanitize_title(rawurldecode($m[1]));
        }
        return '';
    }

    // ---- HTTP normalizer ----
    private function http_get(string $url, array $headers): array
    {
        try {
            if (class_exists(Client::class) && is_callable([Client::class, 'get'])) {
                $resp = Client::get($url, [], $headers);
                $norm = $this->normalize_wp_response($resp);
                if ($norm['ok'] || $norm['status']) return $norm;
            }
        } catch (\Throwable $e) {
        }
        try {
            if (class_exists(Client::class)) {
                $client = new Client();
                if (method_exists($client, 'get')) {
                    $resp = $client->get($url, ['headers' => $headers]);
                    $norm = $this->normalize_wp_response($resp);
                    if ($norm['ok'] || $norm['status']) return $norm;
                }
            }
        } catch (\Throwable $e) {
        }
        $resp = wp_remote_get($url, ['headers' => $headers, 'timeout' => 20]);
        return $this->normalize_wp_response($resp);
    }

    private function normalize_wp_response($resp): array
    {
        if (is_wp_error($resp)) {
            return ['ok' => false, 'status' => 500, 'body' => '', 'error' => $resp->get_error_message()];
        }
        if (is_array($resp) && isset($resp['response'])) {
            $status = isset($resp['response']['code']) ? (int) $resp['response']['code'] : 200;
            $body   = isset($resp['body']) ? (string) $resp['body'] : '';
            return ['ok' => ($status >= 200 && $status < 300), 'status' => $status, 'body' => $body, 'error' => null];
        }
        try {
            $status = (int) ($resp['status'] ?? 200);
            $body   = (string) ($resp['body'] ?? '');
            return ['ok' => ($status >= 200 && $status < 300), 'status' => $status, 'body' => $body, 'error' => null];
        } catch (\Throwable $e) {
            return ['ok' => false, 'status' => 500, 'body' => '', 'error' => 'Unknown response format'];
        }
    }

    /**
     * DETAIL  → {productsRoot}/{type}/{slug}[/{vintage}]  (always based on products root)
     * PAGING  →
     *   - if category active: {productsRoot}/b360-category/{slug}[/page/N]
     *   - else:               {productsRoot}[/page/N]
     * Always returns string.
     */
    private function rewrite_links_to_local(string $html, string $pageBaseUrl): string
    {
        // Detect active category from current URL (if any)
        $path = (string) parse_url($pageBaseUrl, PHP_URL_PATH);
        $activeCat = '';
        if ($path && preg_match('#/(?:b360-category|collection)/([^/]+)#i', rtrim($path, '/'), $m)) {
            $activeCat = sanitize_title(rawurldecode($m[1]));
        }

        // Build productsRoot and categoryBase
        $prod_id  = (int) get_option('b360_products_page_id', 0);
        $is_front = ($prod_id && (get_option('show_on_front') === 'page') && ((int) get_option('page_on_front') === $prod_id));

        $productsRoot = $is_front
            ? rtrim(home_url('/'), '/')
            : rtrim(get_permalink($prod_id), '/');

        $categoryBase = $is_front
            ? rtrim(home_url('/collection'), '/')
            : $productsRoot . '/collection';
        // Choose root for pagination (category-aware) and for detail (always productsRoot)
        $rootForPaging = function (?string $cat) use ($productsRoot, $categoryBase): string {
            if ($cat && $cat !== '') return rtrim($categoryBase, '/') . '/' . rawurlencode($cat);
            return rtrim($productsRoot, '/');
        };
        $rootForDetail = function () use ($productsRoot): string {
            return rtrim($productsRoot, '/'); // NEVER include /b360-category here
        };

        // Remote host for absolute matches
        $remoteHost = preg_quote(parse_url(untrailingslashit((string) \Bottle360\Bridge\Settings\Options::get_base_host()), PHP_URL_HOST) ?: '', '#');

        // ===== DETAIL LINKS (always productsRoot) =====
        $patterns = [
            // upstream wine with vintage
            '#https?://' . $remoteHost . '/(?:b360-)?wine/([^"\'/]+)/([^"\'/]+)#i',
            '#(?<![A-Za-z0-9_-])/(?:b360-)?wine/([^"\'/]+)/([^"\'/]+)#i',
            // upstream product
            '#https?://' . $remoteHost . '/(?:b360-)?product/([^"\'/]+)#i',
            '#(?<![A-Za-z0-9_-])/(?:b360-)?product/([^"\'/]+)#i',
            // upstream bundle
            '#https?://' . $remoteHost . '/(?:b360-)?bundle/([^"\'/]+)#i',
            '#(?<![A-Za-z0-9_-])/(?:b360-)?bundle/([^"\'/]+)#i',
        ];
        $html = preg_replace_callback($patterns, function ($m) use ($rootForDetail) {
            $root = user_trailingslashit($rootForDetail());
            if (stripos($m[0], 'wine/') !== false && isset($m[2])) {
                return esc_url($root . 'wine/' . rawurlencode($m[1]) . '/' . rawurlencode($m[2]));
            }
            if (stripos($m[0], 'product/') !== false) {
                return esc_url($root . 'product/' . rawurlencode($m[1]));
            }
            return esc_url($root . 'bundle/' . rawurlencode($m[1]));
        }, $html) ?? $html;

        // ===== PAGINATION (category-aware) =====
        // /b360-store[/<cat>]?page=N
        $html = preg_replace_callback(
            '#(?:https?://' . $remoteHost . ')?/b360-store(?:/([^"\'/?#]+))?(?:\?[^"\'#]*?\bpage=(\d+)[^"\'#]*)?#i',
            function ($m) use ($rootForPaging, $activeCat) {
                $cat  = $activeCat ?: (isset($m[1]) ? sanitize_title($m[1]) : '');
                $root = user_trailingslashit($rootForPaging($cat));
                $n    = isset($m[2]) ? max(1, (int) $m[2]) : 1;
                return esc_url(($n > 1) ? ($root . 'page/' . $n) : $root);
            },
            $html
        ) ?? $html;

        // /b360-store[/<cat>]/page/N
        $html = preg_replace_callback(
            '#(?:https?://' . $remoteHost . ')?/b360-store(?:/([^"\'/?#]+))?/page/(\d+)(?:/|$)#i',
            function ($m) use ($rootForPaging, $activeCat) {
                $cat  = $activeCat ?: (isset($m[1]) ? sanitize_title($m[1]) : '');
                $root = user_trailingslashit($rootForPaging($cat));
                $n    = max(1, (int) $m[2]);
                return esc_url(($n > 1) ? ($root . 'page/' . $n) : $root);
            },
            $html
        ) ?? $html;

        // bare "?page=N"
        $html = preg_replace_callback(
            '#([\'"])\?[^\'"]*?\bpage=(\d+)[^\'"]*?\1#i',
            function ($m) use ($rootForPaging, $activeCat) {
                $root = user_trailingslashit($rootForPaging($activeCat));
                $n    = max(1, (int) $m[2]);
                $url  = ($n > 1) ? ($root . 'page/' . $n) : $root;
                return $m[1] . esc_url($url) . $m[1];
            },
            $html
        ) ?? $html;

        // naked /b360-store[/<cat>] → page 1
        $html = preg_replace_callback(
            '#(?:https?://' . $remoteHost . ')?/b360-store(?:/([^"\'/?#]+))?/?(?![A-Za-z0-9_\-])#i',
            function ($m) use ($rootForPaging, $activeCat) {
                $cat  = $activeCat ?: (isset($m[1]) ? sanitize_title($m[1]) : '');
                $root = user_trailingslashit($rootForPaging($cat));
                return esc_url($root);
            },
            $html
        ) ?? $html;

        return (string) $html;
    }
}
