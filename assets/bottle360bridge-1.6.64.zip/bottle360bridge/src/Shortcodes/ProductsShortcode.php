<?php

namespace Bottle360\Bridge\Shortcodes;

if (!defined('ABSPATH')) exit;

final class ProductsShortcode
{
    public function register(): void
    {
        // Main products listing
        add_shortcode('b360_products', [$this, 'render']);

        // NEW: per-category variants
        // Usage: [b360_category slug="reds"] or [b360_category category="reds"]
        add_shortcode('b360_category', [$this, 'renderCategory']);
        add_shortcode('b360-category', [$this, 'renderCategory']); // optional dashed alias
    }

    /**
     * Main products listing shortcode.
     *
     * [b360_products]
     * [b360_products category="reds"]  // also works now
     */
    public function render($atts = [], $content = null): string
    {
        wp_enqueue_style('b360-bridge');
        wp_enqueue_script('b360-bridge');

        $atts = shortcode_atts([
            'title'     => __('Bottle360 Products', 'b360-bridge'),
            'category'  => '', // optional slug (used by [b360_category] and [b360_products category="…"])
            'store_url' => '', // optional override to force products page URL
        ], $atts, 'b360_products');


        // Normalize the category slug
        // $category = sanitize_title((string) $atts['category']);
        $category = $atts['category'];

        // IMPORTANT: This must be the REAL products page URL (same base used by rewrite rules)
        $storeUrl = trim((string) $atts['store_url']) !== ''
            ? esc_url_raw((string) $atts['store_url'])
            : $this->findProductsPageUrl();

        if ($storeUrl === '') $storeUrl = trailingslashit(home_url('/'));
        $storeUrl = trailingslashit($storeUrl);


        ob_start();
?>
        <div class="b360-bridge-container">
            <?php
            // Debug helper (kept commented):
            // $yii_cookie = $_SESSION['yii_session_cookie'] ?? null;
            // if (!empty($yii_cookie)) {
            //     echo $cookieString = $yii_cookie['name'] . '=' . $yii_cookie['value'];
            // } else {
            //     echo "No Yii cookie found in session.";
            // }
            ?>
            <div
                id="b360-results"
                class="b360-results"
                data-store-url="<?php echo esc_attr($storeUrl); ?>"
                <?php if ($category !== '') : ?>
                data-b360-category="<?php echo esc_attr($category); ?>"
                <?php endif; ?>></div>
            <div id="b360-detail" class="b360-detail" aria-live="polite"></div>
        </div>
<?php
        return (string) ob_get_clean();
    }

    /**
     * Per-category wrapper:
     *
     * [b360_category category="reds"]
     * [b360-category category="reds"]           // alias
     */
    public function renderCategory($atts = [], $content = null): string
    {
        $atts = shortcode_atts([
            // 'slug'     => '',
            'category' => '',
            'title'    => '',
        ], $atts, 'b360_category');

        // Delegate back to the main renderer (which handles enqueue + markup)
        return $this->render($atts, $content);
    }

    /**
     * Detect the Products/Store page URL.
     * Priority:
     *  1) pinned option b360_products_page_id
     *  2) first page containing [b360_products] / [b360-products]
     */
    private function findProductsPageUrl(): string
    {
        $pinned = (int) get_option('b360_products_page_id', 0);
        if ($pinned) {
            $p = get_post($pinned);
            if ($p && $p->post_type === 'page' && $p->post_status === 'publish') {
                $u = get_permalink($p);
                if ($u) return trailingslashit($u);
            }
        }

        $pages = get_posts([
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
        ]);

        foreach ($pages as $p) {
            $c = (string) $p->post_content;
            if (has_shortcode($c, 'b360_products') || has_shortcode($c, 'b360-products')) {
                $u = get_permalink($p->ID);
                if ($u) return trailingslashit($u);
            }
        }

        return '';
    }
}
