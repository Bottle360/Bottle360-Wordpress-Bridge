<?php

namespace Bottle360\Bridge\Rewrite;

if (!defined('ABSPATH')) exit;

final class Rewrite
{
    const QV_IS_STORE      = 'b360_is_store';
    const QV_CATEGORY      = 'b360_category';
    const QV_B360PATH      = 'b360_path';
    const QV_CLUB_DETAIL   = 'b360_club_detail';
    const QV_CLUB_ADDRESS  = 'b360_club_address';
    const QV_CLUB_JOIN     = 'b360_club_join';
    const QV_CLUB_CONFIRM  = 'b360_club_confirmation';

    public static function init(): void
    {
        add_action('init',       [__CLASS__, 'add_rules']);
        add_filter('query_vars', [__CLASS__, 'add_vars']);
    }

    public static function add_vars(array $vars): array
    {
        foreach ([self::QV_IS_STORE, self::QV_CATEGORY, self::QV_B360PATH, self::QV_CLUB_DETAIL, self::QV_CLUB_ADDRESS, self::QV_CLUB_JOIN, self::QV_CLUB_CONFIRM] as $v) {
            if (!in_array($v, $vars, true)) $vars[] = $v;
        }
        return $vars;
    }

    public static function add_rules(): void
    {
        $prod_id   = self::findProductsPageId();
        $prod_path = $prod_id ? self::relativePathForPost($prod_id) : '';
        $is_front  = $prod_id && (get_option('show_on_front') === 'page') && ((int) get_option('page_on_front') === (int) $prod_id);

        // ---- Back-compat: legacy product detail passthrough (/b360/...) ----
        if ($prod_path !== '') {
            $rx = preg_quote(trim($prod_path, '/'), '/');
            add_rewrite_rule('^' . $rx . '/b360/(.+)/?$', 'index.php?pagename=' . $rx . '&' . self::QV_B360PATH . '=$matches[1]', 'top');
            add_rewrite_rule('^' . $rx . '/page/([0-9]+)/?$', 'index.php?pagename=' . $rx . '&paged=$matches[1]', 'top');
        }

        // ---- Clubs (unchanged) ----
        $club_id   = self::findClubsPageId();
        $club_path = $club_id ? self::relativePathForPost($club_id) : '';
        if ($club_path !== '') {
            $rx = preg_quote(trim($club_path, '/'), '/');
            add_rewrite_rule('^' . $rx . '/b360-club/([^/]+)/?$',             'index.php?pagename=' . $rx . '&' . self::QV_CLUB_DETAIL  . '=$matches[1]', 'top');
            add_rewrite_rule('^' . $rx . '/b360-club/([^/]+)/join/?$',        'index.php?pagename=' . $rx . '&' . self::QV_CLUB_JOIN    . '=$matches[1]', 'top');
            add_rewrite_rule('^' . $rx . '/b360-club/([^/]+)/address/?$',     'index.php?pagename=' . $rx . '&' . self::QV_CLUB_ADDRESS . '=$matches[1]', 'top');
            add_rewrite_rule('^' . $rx . '/b360-club/([^/]+)/confirmation/?$', 'index.php?pagename=' . $rx . '&' . self::QV_CLUB_CONFIRM . '=$matches[1]', 'top');
        }

        // ---- NEW: Pretty product detail routes on the products page (or root if front page) ----
        if ($prod_id) {
            if ($is_front) {
                // /product/<slug>
                add_rewrite_rule('^product/([^/]+)/?$', 'index.php?' . self::QV_B360PATH . '=product/$matches[1]', 'top');
                // /bundle/<slug>
                add_rewrite_rule('^bundle/([^/]+)/?$',  'index.php?' . self::QV_B360PATH . '=bundle/$matches[1]',  'top');
                // /wine/<slug>/<vintage>
                add_rewrite_rule('^wine/([^/]+)/([^/]+)/?$', 'index.php?' . self::QV_B360PATH . '=wine/$matches[1]/$matches[2]', 'top');
            } else {
                $rx = preg_quote(trim($prod_path, '/'), '/');
                add_rewrite_rule('^' . $rx . '/product/([^/]+)/?$', 'index.php?pagename=' . $rx . '&' . self::QV_B360PATH . '=product/$matches[1]', 'top');
                add_rewrite_rule('^' . $rx . '/bundle/([^/]+)/?$',  'index.php?pagename=' . $rx . '&' . self::QV_B360PATH . '=bundle/$matches[1]',  'top');
                add_rewrite_rule('^' . $rx . '/wine/([^/]+)/([^/]+)/?$', 'index.php?pagename=' . $rx . '&' . self::QV_B360PATH . '=wine/$matches[1]/$matches[2]', 'top');
            }
        }

        // ---- Category listing routes (collection base; legacy b360-category kept) ----
        if ($prod_id) {
            if ($is_front) {
                // Canonical: /collection/<slug>[/page/N]
                add_rewrite_rule('^collection/([^/]+)/?$', 'index.php?' . self::QV_IS_STORE . '=1&' . self::QV_CATEGORY . '=$matches[1]', 'top');
                add_rewrite_rule('^collection/([^/]+)/page/([0-9]+)/?$', 'index.php?' . self::QV_IS_STORE . '=1&' . self::QV_CATEGORY . '=$matches[1]&paged=$matches[2]', 'top');
                add_rewrite_rule('^collection/?$', 'index.php?' . self::QV_IS_STORE . '=1', 'top');

                // Legacy (kept for backward compatibility): /b360-category/<slug>[/page/N]
                add_rewrite_rule('^b360-category/([^/]+)/?$', 'index.php?' . self::QV_IS_STORE . '=1&' . self::QV_CATEGORY . '=$matches[1]', 'top');
                add_rewrite_rule('^b360-category/([^/]+)/page/([0-9]+)/?$', 'index.php?' . self::QV_IS_STORE . '=1&' . self::QV_CATEGORY . '=$matches[1]&paged=$matches[2]', 'top');
                add_rewrite_rule('^b360-category/?$', 'index.php?' . self::QV_IS_STORE . '=1', 'top');
            } else {
                $rx = preg_quote(trim($prod_path, '/'), '/');

                // Canonical: /<products-page>/collection/<slug>[/page/N]
                add_rewrite_rule('^' . $rx . '/collection/([^/]+)/?$', 'index.php?pagename=' . $rx . '&' . self::QV_IS_STORE . '=1&' . self::QV_CATEGORY . '=$matches[1]', 'top');
                add_rewrite_rule('^' . $rx . '/collection/([^/]+)/page/([0-9]+)/?$', 'index.php?pagename=' . $rx . '&' . self::QV_IS_STORE . '=1&' . self::QV_CATEGORY . '=$matches[1]&paged=$matches[2]', 'top');
                add_rewrite_rule('^' . $rx . '/collection/?$', 'index.php?pagename=' . $rx . '&' . self::QV_IS_STORE . '=1', 'top');

                // Legacy: /<products-page>/b360-category/<slug>[/page/N]
                add_rewrite_rule('^' . $rx . '/b360-category/([^/]+)/?$', 'index.php?pagename=' . $rx . '&' . self::QV_IS_STORE . '=1&' . self::QV_CATEGORY . '=$matches[1]', 'top');
                add_rewrite_rule('^' . $rx . '/b360-category/([^/]+)/page/([0-9]+)/?$', 'index.php?pagename=' . $rx . '&' . self::QV_IS_STORE . '=1&' . self::QV_CATEGORY . '=$matches[1]&paged=$matches[2]', 'top');
                add_rewrite_rule('^' . $rx . '/b360-category/?$', 'index.php?pagename=' . $rx . '&' . self::QV_IS_STORE . '=1', 'top');
            }
        }
    }

    // -------- helpers --------
    private static function relativePathForPost(int $post_id): string
    {
        $url = get_permalink($post_id);
        if (!$url) return '';
        $home = trailingslashit(home_url('/'));
        $path = str_replace($home, '', trailingslashit($url));
        return trim($path, '/');
    }

    private static function findProductsPageId(): int
    {
        $pinned = (int) get_option('b360_products_page_id', 0);
        if ($pinned) {
            $p = get_post($pinned);
            if ($p && $p->post_type === 'page' && $p->post_status === 'publish') return (int) $p->ID;
        }
        $pages = get_posts(['post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => -1]);
        foreach ($pages as $p) {
            $c = (string) $p->post_content;
            if (has_shortcode($c, 'b360_products') || has_shortcode($c, 'b360-products')) return (int) $p->ID;
        }
        return 0;
    }

    private static function findClubsPageId(): int
    {
        $pinned = (int) get_option('b360_club_page_id', 0);
        if ($pinned) {
            $p = get_post($pinned);
            if ($p && $p->post_type === 'page' && $p->post_status === 'publish') return (int) $p->ID;
        }
        $pages = get_posts(['post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => -1]);
        foreach ($pages as $p) {
            $c = (string) $p->post_content;
            if (has_shortcode($c, 'b360_club') || has_shortcode($c, 'b360-club')) return (int) $p->ID;
        }
        return 0;
    }
}
Rewrite::init();
