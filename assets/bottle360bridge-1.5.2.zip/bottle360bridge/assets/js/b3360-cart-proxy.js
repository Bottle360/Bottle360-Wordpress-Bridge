/* assets/js/b3360-cart-proxy.js */
(function ($) {
  'use strict';

  var ROOTS = '#b360-results, #b360-detail';

  var FORM_SELECTOR =
      'form.shoppincart_form,' +
      'form[action*="/store/cart/create"],' +
      'form[action*="/thirdpartywidget/default/create"]';

  var BUY_NOW_SELECTOR =
      ROOTS + ' .product_variation #addCartButton,' +
      ROOTS + ' .product_variation .btn-add-cart,' +
      ROOTS + ' .btn.btn-primary[data-add-to-cart],' +
      ROOTS + ' form.shoppincart_form [type="submit"],' +
      ROOTS + ' .add-to-cart';

  function getDbgFlag() {
    return /(?:\?|&)b360dbg=1(?:&|$)/.test(location.search) ? 1 : 0;
  }

  function getCookie(name) {
    var m = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/([$?*|{}\]\\^])/g, '\\$1') + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : '';
  }
  function setCookie(name, value, ttlSeconds) {
    var parts = [name + '=' + encodeURIComponent(value), 'path=/', 'samesite=Lax'];
    if (ttlSeconds) parts.push('max-age=' + Math.max(1, ttlSeconds|0));
    if (location.protocol === 'https:') parts.push('secure');
    document.cookie = parts.join('; ');
  }

  function ensureCsrfLocal() {
    if (window.B360 && typeof window.B360.ensureCsrf === 'function') {
      return window.B360.ensureCsrf();
    }
    return new Promise(function (resolve, reject) {
      $.post(B360Bridge.ajaxUrl, {
        action: 'b360_get_csrf',
        _ajax_nonce: (B360Bridge.cartNonce || B360Bridge.nonce)
      })
      .done(function (res) {
        if (res && res.success && res.data && res.data.value) {
          setCookie('b360_csrf_name', res.data.name, res.data.ttl);
          setCookie('b360_csrf',      res.data.value, res.data.ttl);
          setCookie('b360_csrf_exp', (Math.floor(Date.now()/1000) + (res.data.ttl|0)).toString(), res.data.ttl);
          resolve({ name: res.data.name, value: res.data.value, ttl: res.data.ttl });
        } else {
          reject(res && res.data ? res.data : { message: 'Bad CSRF response' });
        }
      })
      .fail(function (xhr) { reject({ message: 'CSRF fetch failed', status: xhr && xhr.status }); });
    });
  }

  function serializeForm($form) {
    var data = {};
    $form.serializeArray().forEach(function (p) {
      if (data[p.name] !== undefined) {
        if (!Array.isArray(data[p.name])) data[p.name] = [data[p.name]];
        data[p.name].push(p.value);
      } else {
        data[p.name] = p.value;
      }
    });
    return data;
  }

  function postViaProxy(fields) {
    return $.post(B360Bridge.ajaxUrl, {
      action: 'b360_proxy_form',
      _ajax_nonce: (B360Bridge.cartNonce || B360Bridge.nonce),
      page_url: window.location.href,        // helps set Referer
      debug: getDbgFlag(),
      fields: fields
    });
  }

  function openModal() {
    var $modal = $('#b360-cart-sc-modal');
    if (!$modal.length) return;
    $modal.removeAttr('hidden');
    $('body').addClass('b360-cart-sc-open');
    $('#b360-cart-sc-toggle').attr('aria-expanded', 'true');
  }

  function handleSubmit(e) {
    e.preventDefault();
    e.stopImmediatePropagation();

    var $form = $(this);
    var $btn  = $form.find('[type="submit"]').first();
    var prev  = $btn.html();

    if ($btn.prop('disabled')) return;
    $btn.prop('disabled', true).attr('aria-busy', 'true').html('Adding…');

    var fields = serializeForm($form);

    ensureCsrfLocal()
      .then(function (tok) {
        if (tok && tok.name && tok.value) {
          fields[tok.name] = tok.value; // token field in body
        }
        return postViaProxy(fields);
      })
      .done(function (res) {
        if (!res || !res.success) {
          alert((res && res.data && res.data.message) ? res.data.message : 'Could not add to cart.');
          if (res && res.data && res.data.debug) console.log('[B360 add-to-cart debug]', res.data.debug);
          return;
        }
        if (res.data && res.data.debug) console.log('[B360 add-to-cart debug]', res.data.debug);

        if (typeof window.B360RefreshCart === 'function') window.B360RefreshCart();
        openModal();
      })
      .fail(function (xhr) {
        alert('Add to cart failed' + (xhr && xhr.status ? ' (HTTP ' + xhr.status + ')' : '.'));
      })
      .always(function () {
        $btn.prop('disabled', false).removeAttr('aria-busy').html(prev);
      });
  }

  function handleClick(e) {
    var $form = $(this).closest('form');
    if ($form.length) {
      e.preventDefault();
      e.stopImmediatePropagation();
      $form.trigger('submit');
    }
  }

  $(document).on('submit', ROOTS + ' ' + FORM_SELECTOR, handleSubmit);
  $(document).on('click',  BUY_NOW_SELECTOR,             handleClick);

  $(document).on('b360:openCart', function () {
    if (typeof window.B360RefreshCart === 'function') window.B360RefreshCart();
    openModal();
  });

})(jQuery);
