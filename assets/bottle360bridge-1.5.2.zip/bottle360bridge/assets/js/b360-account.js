(function () {
  'use strict';

  // Config
  var G          = window.B360Account || {};
  var AJAX_URL   = G.ajaxUrl   || (window.B360Bridge && B360Bridge.ajaxUrl) || window.ajaxurl || '/wp-admin/admin-ajax.php';
  var CART_NONCE = G.cartNonce || (window.B360Bridge && B360Bridge.cartNonce) || '';
  var DEFAULT_LOGIN = G.loginUrl || '/login';

  // Utils
  function qsa(root, sel){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
  function qs(root, sel){ return (root||document).querySelector(sel); }
  function setText(el, txt){ if (el) el.textContent = txt == null ? '' : String(txt); }
  function show(el){ if (el) el.hidden = false; }
  function hide(el){ if (el) el.hidden = true; }
  function debug(root, msg, data){
    var d = (root && (root.getAttribute('data-debug')||'').toLowerCase()==='yes');
    if (!d) return;
    if (data!==undefined) console.log('[b360-account]', msg, data); else console.log('[b360-account]', msg);
  }

  function getStoredUser(){
    try {
      var raw = localStorage.getItem('b360_user');
      return raw ? JSON.parse(raw) : null;
    } catch(_){ return null; }
  }

  function resolveLoginUrl(root){
    return (root && root.getAttribute('data-login-url')) || DEFAULT_LOGIN;
  }

  function redirectToLogin(root){
    window.location.replace(resolveLoginUrl(root));
  }

  function renderProfile(root, user){
    var body = qs(root, '.b360-account-body');
    var load = qs(root, '.b360-account-loading');
    var err  = qs(root, '.b360-account-error');

    hide(load); hide(err); show(body);

    setText(qs(root, '[data-b360-field="firstname"]'), user.firstname || user.firstName || '');
    setText(qs(root, '[data-b360-field="lastname"]'),  user.lastname  || user.lastName  || '');
    setText(qs(root, '[data-b360-field="username"]'),  user.username  || '');
    setText(qs(root, '[data-b360-field="email"]'),     user.email     || '');
    setText(qs(root, '[data-b360-field="user_id"]'),   user.user_id   || user.id || '');

    // Ensure logout link works even without account JS (handled by b360-profile.js)
    root.addEventListener('click', function(e){
      var a = e.target.closest('[data-action="logout"]');
      if (!a) return;
      e.preventDefault();
      if (window.b360Auth && typeof window.b360Auth.logout === 'function') {
        window.b360Auth.logout();
      } else {
        try { localStorage.removeItem('b360_user'); } catch(_){}
        location.reload();
      }
    });
  }

  function showError(root, message){
    var body = qs(root, '.b360-account-body');
    var load = qs(root, '.b360-account-loading');
    var err  = qs(root, '.b360-account-error');
    hide(load); hide(body); show(err);
    err.textContent = message || 'Something went wrong.';
  }

  function fetchProfile(root){
    var load = qs(root, '.b360-account-loading');
    var body = qs(root, '.b360-account-body');
    var err  = qs(root, '.b360-account-error');

    show(load); hide(body); hide(err);

    var payload = { nonce: CART_NONCE, method: 'GET', path: '/b360-user/profile' };
    debug(root, 'profile payload', payload);

    return fetch(AJAX_URL + '?action=b360_auth_proxy', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    .then(function(r){
      var status = r.status;
      return r.text().then(function(txt){
        var json; try{ json = JSON.parse(txt); }catch(_){}
        return {status: status, json: json, raw: txt};
      });
    })
    .then(function(res){
      debug(root, 'profile response', res);

      if (res.status === 401 || res.status === 403) {
        redirectToLogin(root); return;
      }

      var data = res.json || {};
      // Common patterns: {success:true, user:{...}} OR {user:{...}} OR pure user object
      var user = (data.user || data.profile || data.data || (data.success ? data.user : null) || data);
      if (!user || typeof user !== 'object') {
        // If API returned "success:false" with message — show message; otherwise redirect
        var msg = (data && (data.message || data.error)) || 'Unable to load profile.';
        showError(root, msg);
        return;
      }

      // Persist/refresh local copy
      try {
        var s = getStoredUser() || {};
        var first = user.firstname || user.firstName || s.firstName || '';
        localStorage.setItem('b360_user', JSON.stringify({ firstName: first, user: user }));
        document.dispatchEvent(new CustomEvent('b360:userChanged', { detail: { firstName: first, user: user } }));
      } catch(_){}

      renderProfile(root, user);
    })
    .catch(function(err){
      debug(root, 'profile fetch error', err);
      showError(root, 'Network error. Please try again.');
    });
  }

  function mountRoots(ctx){
    var scope = ctx || document;
    var roots = qsa(scope, '.b360-account-root:not([data-b360-bound])');
    if (!roots.length) return false;

    roots.forEach(function(root){
      root.setAttribute('data-b360-bound', '1');

      // Guard: require local storage user
      var s = getStoredUser();
      if (!s || !(s.firstName || (s.user && (s.user.firstname || s.user.firstName)))) {
        debug(root, 'no LS user -> redirect to login');
        redirectToLogin(root);
        return;
      }

      fetchProfile(root);
    });

    return true;
  }

  // Try to mount in all scenarios (DOM ready, load, retry, observer)
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function(){ mountRoots(document); });
  } else {
    mountRoots(document);
  }
  window.addEventListener('load', function(){ mountRoots(document); });

  (function retry(attempts, delay){
    var n = 0, t = setInterval(function(){
      if (mountRoots(document)) { clearInterval(t); return; }
      if (++n >= attempts) clearInterval(t);
    }, delay);
  })(20, 250);

  try {
    var mo = new MutationObserver(function(muts){
      for (var i=0;i<muts.length;i++){
        var m = muts[i];
        if (!m.addedNodes || !m.addedNodes.length) continue;
        for (var j=0;j<m.addedNodes.length;j++){
          var node = m.addedNodes[j];
          if (node.nodeType !== 1) continue;
          if (node.matches && node.matches('.b360-account-root')) mountRoots(node.parentNode || document);
          else if (node.querySelector && node.querySelector('.b360-account-root')) mountRoots(node);
        }
      }
    });
    mo.observe(document.documentElement || document.body, { childList: true, subtree: true });
  } catch(_){}
})();
