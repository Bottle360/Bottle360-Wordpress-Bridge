(function ($) {
  "use strict";

  // ---- small helpers ----
  function getAjaxUrl() {
    if (window.B360Bridge && B360Bridge.ajaxUrl) return B360Bridge.ajaxUrl;
    return '/wp-admin/admin-ajax.php';
  }
  function getNonceField() {
    return (window.B360Bridge && B360Bridge.nonce_field) ? B360Bridge.nonce_field : 'nonce';
  }
  function getNonceValue() {
    return (window.B360Bridge && B360Bridge.nonce) ? B360Bridge.nonce : '';
  }

  // Base for pretty category URLs:
  //  - if products page is homepage → https://site/b360-category
  //  - else → https://site/<products-page>/b360-category
  function derivePrettyBase($root) {
    // Prefer server-localized base (set by DirectHandler)
    if (window.B360Route && B360Route.storeBase) {
      return B360Route.storeBase.replace(/\/+$/, '');
    }

    // Fallback to shortcode-provided products page URL, then append /b360-category
    var storeUrl = ($root && $root.attr('data-store-url'))
      ? String($root.attr('data-store-url'))
      : (window.location.origin || '') + '/';
    storeUrl = storeUrl.replace(/\/+$/, '');

    return storeUrl + '/b360-category';
  }

  function activeCategoryFromEnv() {
    // 1) Localized category (best)
    if (window.B360Route && typeof B360Route.category === 'string' && B360Route.category.length) {
      return B360Route.category;
    }
    if (window.B360Bridge && B360Bridge.route && typeof B360Bridge.route.category === 'string' && B360Bridge.route.category.length) {
      return B360Bridge.route.category;
    }
    // 2) Parse from path: /b360-category/<slug>[/page/N]
    try {
      var path = (window.location.pathname || '').replace(/\/+$/, '');
      var m = path.match(/\/b360-category\/([^/]+)/i);
      return (m && m[1]) ? decodeURIComponent(m[1]) : '';
    } catch (e) {
      return '';
    }
  }

  function buildItem(label, href, isActive) {
    var a = $('<a>', { 'class': 'b360-catmenu__link', href: href, text: label });
    if (isActive) a.addClass('is-active');
    return $('<li>', { 'class': 'b360-catmenu__item' }).append(a);
  }

  function prettyCategoryUrl($root, slug) {
    var base = derivePrettyBase($root).replace(/\/+$/, '');
    return base + '/' + encodeURIComponent(slug);
  }

  // ---- main init ----
  function init($root) {
    if ($root.data('b360CatInit')) return;
    $root.data('b360CatInit', true);

    // list container
    var $list = $root.find('.b360-catmenu__list');
    if (!$list.length) {
      $list = $('<ul class="b360-catmenu__list" aria-live="polite"></ul>');
      $root.append($list);
    }

    // parent/store link (NOT the pretty route)
    var storeUrl = ($root.data('storeUrl') || '/').toString();
    if (!/\/$/.test(storeUrl)) storeUrl += '/';

    // layout option
    var stack = ($root.data('stack') || 'auto').toString().toLowerCase();
    if (stack === 'yes') $root.addClass('b360-catmenu--stacked');
    if (stack === 'no')  $root.removeClass('b360-catmenu--stacked');

    var activeSlug = activeCategoryFromEnv();

    // loading state
    $list.html('<li class="b360-catmenu__item b360-catmenu__item--loading">Loading…</li>');

    // payload (same action & nonce style you used)
    var payload = { action: 'b360_load_categories' };
    payload[getNonceField()] = getNonceValue();

    $.post(getAjaxUrl(), payload)
      .done(function (res) {
        $list.empty();

        if (!res || !res.success || !res.data || !res.data.categories) {
          $list.append('<li class="b360-catmenu__item b360-catmenu__item--empty">No categories</li>');
          return;
        }

        var data = res.data.categories;

        // Parent → local store root page (not pretty)
        if (data.parent && data.parent.text) {
          $list.append(
            $('<li>', { 'class': 'b360-catmenu__item b360-catmenu__item--parent' })
              .append($('<a>', { 'class': 'b360-catmenu__link is-parent', href: storeUrl, text: data.parent.text }))
          );
        }

        // Children → pretty permalink /…/b360-category/<slug>
        (data.children || []).forEach(function (c) {
          var slug  = (c && c.slug) ? String(c.slug) : '';
          var label = (c && c.text) ? String(c.text) : slug;
          if (!slug) return;

          var url = prettyCategoryUrl($root, slug);
          var isActive = !!(activeSlug && slug.toLowerCase() === activeSlug.toLowerCase());
          $list.append(buildItem(label, url, isActive));
        });

        if (!$list.children().length) {
          $list.append('<li class="b360-catmenu__item b360-catmenu__item--empty">No categories</li>');
        }
      })
      .fail(function (xhr) {
        $list.html('<li class="b360-catmenu__item b360-catmenu__item--error">Error ' + (xhr && xhr.status ? xhr.status : '') + '</li>');
      });
  }

  // auto-init
  $(function () {
    $('.b360-catmenu').each(function () { init($(this)); });
  });

})(jQuery);
