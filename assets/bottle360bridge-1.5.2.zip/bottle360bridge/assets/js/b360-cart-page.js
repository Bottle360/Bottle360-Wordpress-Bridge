/* assets/js/b360-cart-page.js */
;(function () {
  'use strict';

  // -------- jQuery bootstrap (noConflict-safe) --------
  function withJQuery(fn) {
    var jq = window.jQuery;
    if (typeof jq === 'function') return fn(jq);
    document.addEventListener('DOMContentLoaded', function () {
      if (typeof window.jQuery === 'function') fn(window.jQuery);
      else console.error('[b360-cart-page] jQuery not found; aborting.');
    });
  }

  withJQuery(function ($) {

    // ---------- config / nonce helpers ----------
    function L() { return window.B360Bridge || window.B360 || {}; }
    function ajaxURL() { return L().ajax_url || L().ajaxUrl || window.ajaxurl || '/wp-admin/admin-ajax.php'; }
    function getNonce() { return L().nonce || L().cartNonce || ''; }
    function setNonce(n) {
      if (window.B360Bridge) { B360Bridge.nonce = n; B360Bridge.cartNonce = n; }
      if (window.B360)       { B360.nonce = n;       B360.cartNonce = n; }
    }
    function refreshNonce() {
      var body = new URLSearchParams({ action: 'b360_get_nonce' }).toString();
      return fetch(ajaxURL(), {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: body
      })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        var n = (j && (j.nonce || (j.data && j.data.nonce))) || '';
        if ((j && (j.success === true || j.success === 'true')) && n) {
          setNonce(n);
          return n;
        }
        throw new Error('nonce refresh failed');
      });
    }
    function looksNonceError(res) {
      if (!res) return false;
      if (res.status === 403) return true;
      var j = res.json || res;
      var msg = j && (j.message || j.error || (j.data && j.data.message) || '');
      return /nonce/i.test(String(msg || ''));
    }

    // Universal admin-ajax wrapper: adds nonce and retries once on nonce failure
    function wpAjax(action, data, _retried) {
      var payload = Object.assign({}, data || {}, { action: action, nonce: getNonce() });
      return fetch(ajaxURL(), {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams(payload).toString()
      })
      .then(function (r) {
        var status = r.status;
        return r.text().then(function (txt) {
          var json; try { json = JSON.parse(txt); } catch (_) {}
          return { status: status, json: json || null, raw: txt };
        });
      })
      .then(function (res) {
        if (!_retried && looksNonceError(res)) {
          return refreshNonce().then(function () {
            return wpAjax(action, data, true);
          });
        }
        return res.json || res;
      });
    }

    // ---------- helpers ----------
    function sanitizeHtml(html) {
      var tpl = document.createElement('template');
      tpl.innerHTML = html || '';
      tpl.content.querySelectorAll('script, noscript').forEach(function (n) { n.remove(); });
      tpl.content.querySelectorAll('*').forEach(function (el) {
        Array.from(el.attributes).forEach(function (attr) {
          if (/^on/i.test(attr.name)) el.removeAttribute(attr.name);
        });
      });
      return tpl.innerHTML;
    }

    function parseMoney(txt) {
      return parseFloat(String(txt || '').replace(/[^0-9.]/g, '')) || 0;
    }

    function getItemIdFromInput($input) {
      var classes = String($input.attr('class') || '').split(/\s+/);
      for (var i = 0; i < classes.length; i++) {
        if (classes[i].indexOf('spinned-') === 0) return classes[i].replace(/^spinned-/, '');
      }
      return '';
    }

    // ---------- Cart Qty: number field + min/max/step validation ----------
    function cartQtyRules($input) {
      var min  = parseFloat($input.attr('data-min')  || $input.attr('min'));
      var step = parseFloat($input.attr('data-step') || $input.attr('step'));
      var maxS = ($input.attr('data-max') != null) ? $input.attr('data-max') : $input.attr('max');
      var max  = parseFloat(maxS);
      if (!isFinite(min)  || min  <= 0) min  = 1;
      if (!isFinite(step) || step <= 0) step = 1;
      if (!isFinite(max) || max <= 0) max = null; // 0 or missing = no upper bound
      return { min:min, max:max, step:step };
    }
    function cartQtySetNumber($input, rules) {
      try { $input.attr('type','number'); } catch(e){}
      $input.attr('min',  String(rules.min));
      $input.attr('step', String(rules.step));
      if (rules.max != null) $input.attr('max', String(rules.max)); else $input.removeAttr('max');
      $input.attr('inputmode', 'numeric').removeAttr('pattern');
    }
    function cartQtyErrorShow($input, msg) {
      var $row = $input.closest('.qty-button-group, .form-group, .b360-cart-line, .cart-row, tr, form');
      var $err = $row.find('.b360-qty-error');
      if (!$err.length) {
        $err = $('<div class="b360-error b360-qty-error" role="alert" aria-live="polite"></div>').appendTo($row);
      }
      $err.text(msg).show();
      $input.addClass('b360-qty-invalid').attr('aria-invalid', 'true');
    }
    function cartQtyErrorClear($input) {
      var $row = $input.closest('.qty-button-group, .form-group, .b360-cart-line, .cart-row, tr, form');
      $row.find('.b360-qty-error').hide().text('');
      $input.removeClass('b360-qty-invalid').removeAttr('aria-invalid');
    }
    function cartQtyValidate($input, showError) {
      if (!$input || !$input.length) return { ok:true, value: null };
      var rules = cartQtyRules($input);
      var raw   = ($input.val() || '').toString().trim();
      var val   = parseFloat(raw);
      if (!raw.length || isNaN(val)) {
        if (showError) cartQtyErrorShow($input, 'Please enter a number.');
        return { ok:false };
      }
      if (val < rules.min) {
        if (showError) cartQtyErrorShow($input, 'Minimum quantity is ' + rules.min + '.');
        return { ok:false };
      }
      if (rules.max != null && val > rules.max) {
        if (showError) cartQtyErrorShow($input, 'Maximum quantity is ' + rules.max + '.');
        return { ok:false };
      }
      // Step alignment: must be min + N*step
      var n = (val - rules.min) / rules.step;
      if (Math.abs(Math.round(n) - n) > 1e-9) {
        if (showError) cartQtyErrorShow($input, 'Quantity must be in increments of ' + rules.step + (rules.min ? (' starting at ' + rules.min) : '') + '.');
        return { ok:false };
      }
      cartQtyErrorClear($input);
      // Force integer when step is integer (typical), else keep value
      var stepInt = Math.abs(rules.step - Math.round(rules.step)) < 1e-9;
      var outVal = stepInt ? Math.round(val) : val;
      return { ok:true, value: outVal };
    }
    function enhanceCartQty($scope) {
      var $root = ($scope && $scope.length) ? $scope : $(document);
      $root.find('#b360-carT input[class*="spinned-"], #b360-carT input[name="qty"], #b360-carT input[name="qty[]"], #b360-carT input[name^="qty["], #b360-carT input[name*="quantity"]').each(function(){
        var $q = $(this);
        var rules = cartQtyRules($q);
        cartQtySetNumber($q, rules);
        cartQtyValidate($q, false);
      });
    }

    // Replace the whole normalizeSuccess with this:
    function normalizeSuccess(res) {
      // 1) Plain string "success"
      if (typeof res === 'string') return res.trim().toLowerCase() === 'success';

      if (!res) return false;

      // 2) WordPress JSON: success:true => treat as success regardless of body content
      if (res.success === true) return true;

      // 3) Some handlers return { data: { status: 2xx, body: "<!doctype html>..." } }
      if (res.data) {
        if (typeof res.data.status === 'number' && res.data.status >= 200 && res.data.status < 400) {
          return true;
        }
        if (typeof res.data.body === 'string') {
          if (/<!doctype html>/i.test(res.data.body)) return true;
          if (res.data.body.trim().toLowerCase() === 'success') return true;
        }
      }

      return false;
    }

    function refreshCartContentsAjax(dbg) {
      var $target = $('#b360-carT');
      if (!$target.length) return window.location.reload();
      $target.attr('aria-busy', 'true');

      return wpAjax('b360_load_cart', { debug: dbg ? 1 : 0 })
        .then(function (res) {
          if (res && res.success && res.data && res.data.html) {
            $target.html(sanitizeHtml(res.data.html));
            if (dbg && res.data.debug) console.log('[B360 cart debug]', res.data.debug);
            // Enhance qty fields on refreshed HTML
            enhanceCartQty($target);
          } else {
            var msg = (res && res.data && res.data.message) ? res.data.message : 'Unable to load cart.';
            $target.html('<div class="b360-error">' + msg + '</div>');
          }
        })
        .catch(function (err) {
          $target.html('<div class="b360-error">Network error</div>');
          console.error('[b360-cart-page] load_cart error', err);
        })
        .finally(function () {
          $target.removeAttr('aria-busy');
        });
    }

    // ---------- initial cart hydrate ----------
    $(function () {
      var $target = $('#b360-carT');
      if (!$target.length) return;

      var dbg = /(?:\?|&)b360dbg=1(?:&|$)/.test(location.search);
      $target.attr('aria-busy', 'true').html('<div class="b360-loading">Loading…</div>');

      var ensure = (window.B360 && typeof window.B360.ensureCsrf === 'function')
        ? Promise.resolve().then(function () { return window.B360.ensureCsrf(); }).catch(function () { })
        : Promise.resolve();

      ensure.then(function () { return refreshCartContentsAjax(dbg); })
            .catch(function () { return refreshCartContentsAjax(dbg); });
    });

    // ---------- QTY UPDATE (de-duped binding, silent on success) ----------
    if (!window.__B360_CART_QTY_BOUND__) {
      window.__B360_CART_QTY_BOUND__ = true;

      function handleQtyChange($input) {
        if ($input.data('b360Busy')) return;

        // Normalize and validate first
        cartQtySetNumber($input, cartQtyRules($input));
        var v = cartQtyValidate($input, true);
        if (!v.ok) return;
        var qty = v.value;
        $input.val(qty);

        var itemId = getItemIdFromInput($input);
        if (!itemId) return;

        var price = parseMoney($input.closest('tr').find('.cart-product-price').text());

        var $tot = $('#b360-cart_internal_contents .cart-order-summary .price_total');
        var prev = $tot.text(); $tot.text('…');

        $input.data('b360Busy', true);

        wpAjax('b360_update_qty', { item: itemId, qty: qty, price: price })
          .then(function (res) {
            if (normalizeSuccess(res)) {
              // ✅ silent on success — just refresh cart HTML (will re-enhance qty)
              return refreshCartContentsAjax(false);
            }
            $tot.text(prev);
            alert((res && res.data && (res.data.message || res.data.body)) || 'Update failed.');
          })
          .catch(function (xhr) {
            $tot.text(prev);
            alert('Request failed.');
          })
          .finally(function () {
            $input.data('b360Busy', false);
          });
      }

      $(document)
        .off('change.b360qty', '#b360-carT input[class*="spinned-"]')
        .on('change.b360qty', '#b360-carT input[class*="spinned-"]', function () {
          handleQtyChange($(this));
        });

      // Live feedback as user types (clear/show error without sending AJAX)
      $(document)
        .off('input.b360qty', '#b360-carT input[class*="spinned-"]')
        .on('input.b360qty', '#b360-carT input[class*="spinned-"]', function () {
          var $q = $(this);
          cartQtySetNumber($q, cartQtyRules($q));
          cartQtyValidate($q, false);
        });
    }

    // ---------- REMOVE ITEM (de-duped binding, silent on success) ----------
    if (!window.__B360_CART_REMOVE_BOUND__) {
      window.__B360_CART_REMOVE_BOUND__ = true;

      function getIdFromHref(href) {
        try {
          var a = document.createElement('a');
          a.href = href;
          var qs = a.search || (href.indexOf('?') >= 0 ? href.slice(href.indexOf('?')) : '');
          var params = new URLSearchParams(qs);
          return params.get('id') || '';
        } catch (e) { return ''; }
      }

      $(document)
        .off('click.b360rm', '#b360-carT a[href*="/store/cart/delete"]')
        .on('click.b360rm', '#b360-carT a[href*="/store/cart/delete"]', function (e) {
          e.preventDefault();

          var id = getIdFromHref(this.getAttribute('href') || '');
          if (!id) return;

          var $link = $(this);
          var $target = $('#b360-carT');

          if ($link.data('b360Busy')) return; // prevent double clicks
          $link.data('b360Busy', true);

          $target.attr('aria-busy', 'true');

          wpAjax('b360_remove_item', { item: id })
            .then(function (res) {
              if (normalizeSuccess(res)) {
                // ✅ silent on success — refresh the cart HTML
                return refreshCartContentsAjax(false);
              }
              // error only
              var msg = (res && res.data && (res.data.message || res.data.body)) || 'Remove failed.';
              alert(msg);
            })
            .catch(function () {
              alert('Request failed.');
            })
            .finally(function () {
              $link.data('b360Busy', false);
              $target.removeAttr('aria-busy');
            });
        });
    }
  });
})();
