/*!
 * b360-clubs.js — listing, detail (AJAX + History), and Join Club (AJAX redirect with Yii session)
 * Requires localized globals:
 *   B360Bridge.ajaxUrl      (admin-ajax.php)
 *   B360Bridge.nonce        (central bridge nonce)
 *   B360Bridge.clubsListUrl (permalink of the page with the clubs shortcode)
 */
(function ($) {
  // ======================
  // URL helpers
  // ======================
  function withTrailingSlash(u) { return (u || '').replace(/\/?$/, '/'); }
  function withoutTrailingSlash(u) { return (u || '').replace(/\/+$/, ''); }
  function trimSlashes(u) { return (u || '').replace(/^\/+|\/+$/g, ''); }
  function toAbsolute(u) { try { return new URL(u, window.location.origin).href; } catch (e) { return window.location.origin + '/'; } }
  function toPathname(u) { try { return new URL(u, window.location.origin).pathname.replace(/\/?$/, '/'); } catch (e) { return '/'; } }
  function joinUrl(base /* abs or rel */) {
    var out = withoutTrailingSlash(base || '');
    for (var i = 1; i < arguments.length; i++) {
      var seg = String(arguments[i] == null ? '' : arguments[i]);
      seg = trimSlashes(seg);
      if (seg) out += '/' + seg;
    }
    return out + '/';
  }
  function pageFromPath(path) {
    var m = (path || '').match(/(?:^|\/)page\/(\d+)\/?$/i);
    return m ? Math.max(1, parseInt(m[1], 10)) : 1;
  }
  function sanitizeHref(href) {
    // Fix cases like "/http://site/clubs/page/2/"
    return (href || '').replace(/^\/+(https?:\/\/)/i, '$1');
  }

  // ======================
  // Centralized config
  // ======================
  var L = window.B360Bridge || {};
  function ajaxUrl()  { return L.ajaxUrl  || window.ajaxurl || '/wp-admin/admin-ajax.php'; }
  function nonce()    { return L.nonce    || ''; }
  function clubsBase() { return (L.clubsListUrl ? L.clubsListUrl : '/'); }

  // ======================
  // Resolve the true base (where the clubs shortcode lives)
  // ======================
  var RAW_BASE = clubsBase();
  if (!RAW_BASE) {
    var t = $('#b360-club-app .keys').attr('title');
    if (t) RAW_BASE = t;
  }
  if (!RAW_BASE) {
    var p = window.location.pathname;
    var parts = p.split('/').filter(Boolean);
    if (parts.length >= 2) {
      var last = parts[parts.length - 1];
      if (!/^page$/i.test(last) && !/^join-club/i.test(last) && !/^address$/i.test(last) && !/^join-club-confirmation$/i.test(last)) {
        parts.pop();
      }
      RAW_BASE = '/' + parts.join('/') + '/';
    } else {
      RAW_BASE = '/';
    }
  }

  // Canonical base forms
  var BASE_ABS  = withTrailingSlash(toAbsolute(RAW_BASE)); // e.g. https://site/clubs/
  var BASE_PATH = withTrailingSlash(toPathname(RAW_BASE)); // e.g. /clubs/

  // ======================
  // JOIN CLUB (AJAX → URL → navigate)
  // ======================

  // Call the WP AJAX handler that returns redirect_url and already appends s_key server-side.
  function b360JoinAjax(payload) {
    payload = payload || {};
    payload.action = 'b360_club_join_redirect';
    payload.nonce  = nonce();

    return $.post(ajaxUrl(), payload)
      .then(function (res) {
        // Support either {redirect_url} or {data:{redirect_url}}
        var url = (res && res.redirect_url) ||
                  (res && res.url) ||
                  (res && res.data && (res.data.redirect_url || res.data.url));
        if (!url) {
          var msg = (res && res.data && res.data.message) || 'Join URL not available.';
          return $.Deferred().reject({ message: msg }).promise();
        }
        return url;
      });
  }

  function b360CurrentClubSlug($form) {
    // 1) Prefer form action (works with "/clubs/<slug>" or legacy)
    var action = $form && $form.attr('action') ? $form.attr('action') : '';
    if (action) {
      try {
        var u = new URL(action, window.location.origin);
        var segs = u.pathname.split('/').filter(Boolean);
        if (segs.length) return segs[segs.length - 1];
      } catch (e) {}
    }
    // 2) Fallback relative to the clubs list base
    var base = (function () {
      try { return new URL(clubsBase() || '/', window.location.origin).pathname.replace(/\/?$/, '/'); }
      catch (e) { return '/'; }
    })();
    var path = (window.location.pathname || '/').replace(/\/?$/, '/');
    if (path.indexOf(base) === 0) {
      var rest = path.substring(base.length);
      var parts = rest.split('/').filter(Boolean);
      if (parts.length && !/^page$/i.test(parts[0])) return parts[0];
    }
    return '';
  }

  // Intercept native submit and route through AJAX (no admin-post)
  document.addEventListener('submit', function (ev) {
    var form = ev.target;
    if (!form || form.id !== 'club-form') return;
    ev.preventDefault();
    ev.stopPropagation();

    var $form = jQuery(form);
    var optionId = $form.find('input.club_option_id:checked').val();
    if (!optionId) {
      var $first = $form.find('input.club_option_id').first();
      if ($first.length) $first.focus();
      alert('Please select a club option to continue.');
      return;
    }
    var slug = b360CurrentClubSlug($form);
    if (!slug) {
      alert('Unable to detect club slug. Please try again.');
      return;
    }

    // Send option_id — server will build /b360-club/{slug}/join-club/{optionId}/?s_key=...
    var payload = {
      slug: slug,
      option_id: String(optionId)
    };

    var $btn = $form.find('button[type=submit], input[type=submit]').first();
    var prev = $btn.text();
    if ($btn.length) $btn.prop('disabled', true).text('Please wait…');

    b360JoinAjax(payload)
      .done(function (url) { window.location.assign(url); })
      .fail(function (err) { alert((err && err.message) || 'Join failed.'); })
      .always(function () { if ($btn.length) $btn.prop('disabled', false).text(prev); });
  }, true);

  // Extra safety: if anything calls form.submit() directly
  (function () {
    var NativeSubmit = HTMLFormElement.prototype.submit;
    if (!NativeSubmit) return;
    HTMLFormElement.prototype.submit = function () {
      if (this && this.id === 'club-form') {
        var $form = jQuery(this);
        var optionId = $form.find('input.club_option_id:checked').val();
        if (!optionId) {
          var $first = $form.find('input.club_option_id').first();
          if ($first.length) $first.focus();
          alert('Please select a club option to continue.');
          return;
        }
        var slug = b360CurrentClubSlug($form);
        if (!slug) {
          alert('Unable to detect club slug. Please try again.');
          return;
        }
        var payload = { slug: slug, option_id: String(optionId) };
        b360JoinAjax(payload)
          .done(function (url) { window.location.assign(url); })
          .fail(function (err) { alert((err && err.message) || 'Join failed.'); });
        return; // block native submit
      }
      return NativeSubmit.apply(this, arguments);
    };
  })();

  // Also intercept clicks on submit buttons (covers Enter-key default button)
  // (HARD SCOPED to #club-form only)
  document.addEventListener('click', function (ev) {
    var target = ev.target;
    if (!target) return;

    // Only react if the click happened on the submit control INSIDE #club-form
    var submitBtn = target.closest && target.closest('#club-form button[type="submit"], #club-form input[type="submit"]');
    if (!submitBtn) return;

    var form = submitBtn.form;
    if (!form || form.id !== 'club-form') return;

    ev.preventDefault();
    ev.stopPropagation();

    var $form = jQuery(form);
    var optionId = $form.find('input.club_option_id:checked').val();
    if (!optionId) {
      var $first = $form.find('input.club_option_id').first();
      if ($first.length) $first.focus();
      alert('Please select a club option to continue.');
      return;
    }

    var slug = b360CurrentClubSlug($form);
    if (!slug) {
      alert('Unable to detect club slug. Please try again.');
      return;
    }

    var payload = { slug: slug, option_id: String(optionId) };

    // Optional UX nicety: disable only the clicked submit button
    var $btn = jQuery(submitBtn);
    var prev = $btn.is('input') ? $btn.val() : $btn.text();
    if ($btn.length) {
      if ($btn.is('input')) $btn.prop('disabled', true).val('Please wait…');
      else $btn.prop('disabled', true).text('Please wait…');
    }

    b360JoinAjax(payload)
      .done(function (url) { window.location.assign(url); })
      .fail(function (err) { alert((err && err.message) || 'Join failed.'); })
      .always(function () {
        if ($btn.length) {
          if ($btn.is('input')) $btn.prop('disabled', false).val(prev);
          else $btn.prop('disabled', false).text(prev);
        }
      });
  }, true);


  // ======================
  // AJAX: listing & detail
  // ======================
  function loadClubs(opts) {
    // IMPORTANT: send relative path to backend to avoid "/http://..." concatenations there
    var o = $.extend({ page: 1, page_url: BASE_PATH }, opts || {});
    $('#b360-club-listing').html('<div class="b360-loading">Loading…</div>');

    $.post(ajaxUrl(), {
      action:  'b360_load_clubs',
      nonce:   nonce(),
      page:    o.page,
      page_url: o.page_url   // relative, e.g. "/clubs/"
    })
    .done(function (res) {
      if (res && res.success && res.data && res.data.html) {
        $('#b360-club-listing').html(res.data.html);

        // Normalize any hrefs the backend may have produced like "/http://..."
        $('#b360-club-listing a').each(function () {
          var href = $(this).attr('href');
          if (href && /^\/+https?:\/\//i.test(href)) {
            $(this).attr('href', sanitizeHref(href));
          }
        });

        if (history.replaceState) {
          var newUrlAbs = (o.page && o.page > 1)
            ? joinUrl(BASE_ABS, 'page', String(o.page))
            : BASE_ABS;
          history.replaceState({ view: 'clubs', page: o.page }, '', newUrlAbs);
        }

        $(document).trigger('b360:clubs:updated');
      } else {
        $('#b360-club-listing').html('<p class="b360-error">Failed to load clubs.</p>');
        if (window.console) console.error('Failed to load clubs:', res);
      }
    })
    .fail(function (xhr) {
      $('#b360-club-listing').html('<p class="b360-error">Error loading clubs.</p>');
      if (window.console) console.error('AJAX error while loading clubs:', xhr);
    });
  }

  function loadClubDetail(slug, pushState) {
    if (pushState === undefined) pushState = true;
    slug = trimSlashes(slug);

    $('#b360-club-listing').html('<div class="b360-loading">Loading…</div>');

    $.post(ajaxUrl(), {
      action: 'b360_load_club_detail',
      nonce:  nonce(),
      slug:   slug
    })
    .done(function (res) {
      if (res && res.success && res.data && res.data.html) {
        $('#b360-club-listing').html(res.data.html);

        $('#b360-club-listing a').each(function () {
          var href = $(this).attr('href');
          if (href && /^\/+https?:\/\//i.test(href)) {
            $(this).attr('href', sanitizeHref(href));
          }
        });

        if (pushState && history.pushState) {
          var newUrlAbs = joinUrl(BASE_ABS, slug); // absolute, clean
          history.pushState({ view: 'club-detail', slug: slug }, '', newUrlAbs);
        }

        $(document).trigger('b360:club:detail:loaded');
      } else {
        $('#b360-club-listing').html('<p class="b360-error">Failed to load club detail.</p>');
        if (window.console) console.error('Failed to load club detail:', res);
      }
    })
    .fail(function (xhr) {
      $('#b360-club-listing').html('<p class="b360-error">Error loading club detail.</p>');
      if (window.console) console.error('AJAX error while loading club detail:', xhr);
    });
  }

  // ======================
  // Events (pagination, detail nav)
  // ======================
  $(document).on('click', '#b360-club-listing .pagination a', function (e) {
    e.preventDefault();
    var href = sanitizeHref($(this).attr('href') || '');
    var page = pageFromPath(href);
    loadClubs({ page: page });
  });

  $(document).on('click', "[data-cy='join-club-link'], [data-detail-url]", function (e) {
    e.preventDefault();
    var href = sanitizeHref($(this).attr('href') || $(this).data('detail-url') || '');
    if (!href) return;
    var parts = href.split('?')[0].split('#')[0].split('/').filter(Boolean);
    var slug  = parts.pop();
    if (slug) loadClubDetail(slug, true);
  });

  window.onpopstate = function (ev) {
    var currentPath = withTrailingSlash(window.location.pathname);

    if (ev && ev.state && ev.state.view === 'club-detail' && ev.state.slug) {
      loadClubDetail(ev.state.slug, false);
      return;
    }

    if (currentPath.indexOf(BASE_PATH) === 0) {
      var rest = currentPath.substring(BASE_PATH.length);
      var m = rest.match(/^page\/(\d+)\/?$/i);
      var page = m ? Math.max(1, parseInt(m[1], 10)) : 1;

      var segs = rest.split('/').filter(Boolean);
      if (segs.length && !/^page$/i.test(segs[0])) {
        loadClubDetail(segs[0], false);
      } else {
        loadClubs({ page: page });
      }
      return;
    }

    loadClubs({ page: 1 });
  };

  // ======================
  // Init
  // ======================
  $(function () {
    var $mount = $('#b360-club-listing');
    if (!$mount.length) return;

    var currentPath = withTrailingSlash(window.location.pathname);

    if (currentPath.indexOf(BASE_PATH) === 0) {
      var rest  = currentPath.substring(BASE_PATH.length);
      var segs  = rest.split('/').filter(Boolean);

      if (segs.length >= 1 && !/^page$/i.test(segs[0])) {
        loadClubDetail(segs[0], false);  // direct detail URL
        return;
      }
      loadClubs({ page: pageFromPath(rest) });       // listing or listing page/2
      return;
    }

    // Fallback to listing
    loadClubs({ page: 1 });
  });
})(jQuery);
