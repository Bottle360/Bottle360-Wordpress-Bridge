(function () {
  'use strict';

  // ---- Minimal CustomEvent polyfill (older browsers) ----
  (function () {
    if (typeof window.CustomEvent === 'function') return;
    function CustomEvent(event, params) {
      params = params || { bubbles: false, cancelable: false, detail: null };
      var evt = document.createEvent('CustomEvent');
      evt.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
      return evt;
    }
    CustomEvent.prototype = window.Event.prototype;
    window.CustomEvent = CustomEvent;
  })();

  // ---- Tiny storage helper around the existing lsKey ----
  var LS_KEY = (window.B360PS && B360PS.lsKey) || 'b360_user';
  var storage = {
    get: function () {
      try { return JSON.parse(localStorage.getItem(LS_KEY) || 'null'); }
      catch (_) { return null; }
    },
    set: function (obj) {
      try { localStorage.setItem(LS_KEY, JSON.stringify(obj || {})); } catch (_) {}
      try { document.dispatchEvent(new CustomEvent('b360:userChanged', { detail: obj || null })); } catch (_) {}
    },
    clear: function () {
      try { localStorage.removeItem(LS_KEY); } catch (_) {}
      try { document.dispatchEvent(new CustomEvent('b360:userChanged', { detail: null })); } catch (_) {}
    }
  };

  // ---- Public API for other views (login/register) ----
  window.b360Auth = {
    setUser: function ({ firstName, user } = {}) {
      var payload = {};
      if (user && typeof user === 'object') payload.user = user;
      if (firstName) payload.firstName = firstName;
      if (!payload.firstName) {
        var u = payload.user || {};
        payload.firstName = u.firstname || u.firstName || u.given_name || u.name || 'User';
      }
      storage.set(payload);
    },
    // Back-compat alias used elsewhere in the plugin
    setUserObject: function ({ user, firstName } = {}) {
      window.b360Auth.setUser({ user: user || {}, firstName: firstName });
    },
    getUser: function () { return storage.get(); },
    clearUser: function () { storage.clear(); },

    // ---- Logout: call AuthProxy, clear local user, redirect on success ----
    logout: function (opts) {
      opts = opts || {};
      var DEBUG = !!(window.B360_DEBUG_AUTH || /[?&]b360_debug_auth=1\b/.test(location.search));

      // Localized values (kept consistent with the rest of the plugin)
      var AJAX_URL =
        (window.B360PS && B360PS.ajaxUrl) ||
        (window.B360Bridge && B360Bridge.ajaxUrl) ||
        window.ajaxurl || '/wp-admin/admin-ajax.php';

      var NONCE =
        (window.B360PS && (B360PS.cartNonce || B360PS.nonce)) ||
        (window.B360Bridge && B360Bridge.cartNonce) || '';

      function serverLogout() {
        var payload = { nonce: NONCE, method: 'GET', path: '/b360-user/logout' };
        return fetch(AJAX_URL + '?action=b360_auth_proxy', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      }

      try { document.dispatchEvent(new CustomEvent('b360:logout:init')); } catch (_) {}

      return serverLogout()
        .then(function (r) {
          var status = r.status;
          return r.text().then(function (txt) {
            var json; try { json = JSON.parse(txt); } catch (_) {}
            var ok = json && (
              json.cleared === true ||
              json.success === true ||
              json.success === 'true' ||
              String(json.status || '').toLowerCase() === 'ok'
            );

            if (DEBUG) console.log('[b360] logout → status:', status, 'json:', json);

            if (ok) {
              // delete user object from localStorage
              storage.clear();

              try { document.dispatchEvent(new CustomEvent('b360:logout:done', { detail: { ok: true, response: json } })); } catch (_) {}

              // Resolve redirect target - prefer shortcode-provided login URL
              var redirectTo = (opts && opts.redirect) || '';
              if (!redirectTo) {
                try {
                  var root = document.querySelector('.b360-authmenu');
                  redirectTo = (root && root.dataset && root.dataset.loginUrl) || '';
                  if (!redirectTo && root) {
                    var loginLink = root.querySelector('.b360-authmenu__list--out a[href]');
                    if (loginLink) redirectTo = loginLink.getAttribute('href');
                  }
                } catch (_) {}
              }

              if (!DEBUG) {
                if (redirectTo) window.location.href = redirectTo;
                else window.location.reload();
              } else {
                console.warn('[b360] redirect suppressed (debug). Would go to:', redirectTo || '(reload)');
              }
            } else {
              try { document.dispatchEvent(new CustomEvent('b360:logout:fail', { detail: { ok: false, response: json, status: status } })); } catch (_) {}
              if (DEBUG) console.warn('[b360] logout failed; user state preserved.', json);
            }

            return json || {};
          });
        })
        .catch(function (err) {
          try { document.dispatchEvent(new CustomEvent('b360:logout:error', { detail: err })); } catch (_) {}
          if (DEBUG) console.warn('[b360] logout network error; state preserved.', err);
          return { success: 'false', message: 'Network error' };
        });
    }
  };

  // ---- Auth menu controller (used by [b360_profile]) ----
  function initAuthMenu(root) {
    var listOut = root.querySelector('.b360-authmenu__list--out');
    var listIn  = root.querySelector('.b360-authmenu__list--in');
    var welcomeName = root.querySelector('.b360-authmenu__name');
    var welcomeWrap = root.querySelector('.b360-authmenu__welcome');

    var showWelcome = (root.dataset.showWelcome || 'yes') === 'yes';
    var welcomePref = (root.dataset.welcomePrefix || 'Welcome').trim();

    function showLoggedOut() {
      if (listOut) listOut.style.display = 'inline-flex';
      if (listIn)  listIn.style.display  = 'none';
      if (welcomeWrap) welcomeWrap.style.display = 'none';
    }

    function showLoggedIn(firstName) {
      var name = (firstName || '').trim();
      if (name && welcomeName) welcomeName.textContent = name;
      if (welcomeWrap) {
        welcomeWrap.style.display = showWelcome ? 'inline-flex' : 'none';
        var pref = root.querySelector('.b360-authmenu__welcome-prefix');
        if (pref) pref.textContent = welcomePref;
      }
      if (listOut) listOut.style.display = 'none';
      if (listIn)  listIn.style.display  = 'inline-flex';
    }

    function updateUI() {
      var s = storage.get();
      if (s) {
        var u = s.user || {};
        var first = s.firstName || u.firstname || u.firstName || u.given_name || u.name || '';
        showLoggedIn(first);
      } else {
        showLoggedOut();
      }
    }

    root.addEventListener('click', function (e) {
      var el = e.target.closest('[data-action]');
      if (!el) return;
      var act = el.getAttribute('data-action');
      if (act === 'logout') {
        e.preventDefault();
        var redirect = root.dataset.loginUrl || '';
        window.b360Auth.logout({ redirect: redirect });
      }
    });

    document.addEventListener('b360:userChanged', updateUI);
    updateUI();
  }

  function initAll() {
    try {
      document.querySelectorAll('.b360-authmenu').forEach(initAuthMenu);
    } catch (_) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }
  window.addEventListener('pageshow', initAll);
  document.addEventListener('turbo:load', initAll);
  document.addEventListener('htmx:afterSettle', initAll);
})();
