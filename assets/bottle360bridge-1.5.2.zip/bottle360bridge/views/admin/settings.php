<?php

/**
 * Admin settings view (two-column layout)
 * Path: views/admin/settings.php
 */
defined('ABSPATH') || exit;

use Bottle360\Bridge\Settings\Options;

// Current config preview
$tenant   = Options::get_tenant();
$tld      = Options::get_tld();
$baseHost = Options::get_base_host();

/**
 * Shortcodes (ordered as requested):
 * 1) Products
 * 2) Cart
 * 3) Mini Cart
 * 4) Clubs
 * 5) Profile
 * 6) Login
 * 7) Registration
 * 8) My Account
 *
 * Notes:
 * - Keys are the actual shortcode tags.
 * - "aliases" shows any alternative tags supported by your code.
 */
$shortcodes = [

    // 1) PRODUCTS
    'b360_products' => [
        'title'       => __('Products', 'b360-bridge'),
        'aliases'     => [],
        'description' => __('Renders the Bottle360 products app.', 'b360-bridge'),
        'attributes'  => [
            // From your Products shortcode defaults
            'title' => ['type' => 'string', 'default' => __('Bottle360 Products', 'b360-bridge'), 'notes' => 'Heading text.'],
        ],
        'example' => '[b360_products title="Bottle360 Products"]',
    ],

    // 2) CART (PAGE)
    'b360_cart' => [
        'title'       => __('Cart', 'b360-bridge'),
        'aliases'     => [],
        'description' => __('Full cart page container. Enqueues cart assets and renders the cart app container.', 'b360-bridge'),
        'attributes'  => [],
        'example' => '[b360_cart]',
    ],

    // 3) MINI CART (ICON/WIDGET)
    'b360_cart_icon' => [
        'title'       => __('Mini Cart', 'b360-bridge'),
        'aliases'     => [],
        'description' => __('Compact cart icon/widget with modal or dropdown preview.', 'b360-bridge'),
        'attributes'  => [
            // From your Mini Cart defaults
            'count' => ['type' => 'string|int', 'default' => '0',    'notes' => 'Initial count indicator (visual only).'],
            'label' => ['type' => 'string',     'default' => 'Cart', 'notes' => 'Button/label text.'],
        ],
        'example' => '[b360_cart_icon count="0" label="Cart"]',
    ],

    // 4) CLUBS
    'b360-club' => [
        'title'       => __('Clubs', 'b360-bridge'),
        'aliases'     => [],
        'description' => __('Bottle360 clubs listing/app container.', 'b360-bridge'),
        'attributes'  => [],
        'example' => '[b360-club]',
    ],

    // 5) PROFILE
    'b360-profile' => [
        'title'       => __('Profile', 'b360-bridge'),
        'aliases'     => ['b360_profile'],
        'description' => __('Profile menu/links that react to Bottle360 API login state stored in localStorage.', 'b360-bridge'),
        'attributes'  => [
            'class'          => ['type' => 'string', 'default' => '',                     'notes' => 'Extra CSS class for the nav.'],
            'login_url'      => ['type' => 'URL',    'default' => home_url('/login'),     'notes' => 'Login page URL.'],
            'register_url'   => ['type' => 'URL',    'default' => home_url('/register'),  'notes' => 'Registration page URL.'],
            'account_url'    => ['type' => 'URL',    'default' => home_url('/my-account'), 'notes' => 'Account page URL.'],
            'show_welcome'   => ['type' => 'yes|no', 'default' => 'yes',                  'notes' => 'Show welcome text if API user is present.'],
            'welcome_prefix' => ['type' => 'string', 'default' => 'Welcome',              'notes' => 'Prefix before user name.'],
        ],
        'example' => '[b360-profile login_url="/login" register_url="/register" account_url="/my-account" show_welcome="yes" welcome_prefix="Welcome"]',
    ],

    // 6) LOGIN
    'b360-login' => [
        'title'       => __('Login', 'b360-bridge'),
        'aliases'     => ['b360_login'],
        'description' => __('Bottle360 login form with API session handling.', 'b360-bridge'),
        'attributes'  => [
            'view'             => ['type' => 'string',  'default' => 'login',                     'notes' => 'Internal view selector.'],
            'account_page_url' => ['type' => 'URL',     'default' => home_url('/my-account'),     'notes' => 'Redirect/links target after login.'],
            'redirect_if_auth' => ['type' => 'yes|no',  'default' => 'yes',                        'notes' => 'If already authenticated, redirect to account page.'],
            'class'            => ['type' => 'string',  'default' => '',                           'notes' => 'Extra CSS class.'],
            'debug'            => ['type' => 'yes|no',  'default' => 'no',                         'notes' => 'Enable extra notices/logging.'],
        ],
        'example' => '[b360-login account_page_url="/my-account" redirect_if_auth="yes"]',
    ],

    // 7) REGISTRATION
    'b360-register' => [
        'title'       => __('Registration', 'b360-bridge'),
        'aliases'     => ['b360_register'],
        'description' => __('Bottle360 registration form with API session handling.', 'b360-bridge'),
        'attributes'  => [
            'view'             => ['type' => 'string',  'default' => 'register',                  'notes' => 'Internal view selector.'],
            'account_page_url' => ['type' => 'URL',     'default' => home_url('/my-account'),     'notes' => 'Redirect/links target after registration.'],
            'redirect_if_auth' => ['type' => 'yes|no',  'default' => 'yes',                        'notes' => 'If already authenticated, redirect to account page.'],
            'class'            => ['type' => 'string',  'default' => '',                           'notes' => 'Extra CSS class.'],
            'debug'            => ['type' => 'yes|no',  'default' => 'no',                         'notes' => 'Enable extra notices/logging.'],
        ],
        'example' => '[b360-register account_page_url="/my-account" redirect_if_auth="yes"]',
    ],

    // 8) MY ACCOUNT (Router)
    'my_account' => [
        'title'       => __('My Account', 'b360-bridge'),
        'aliases'     => [],
        'description' => __('Router that links out to tenant pages and gates content based on Bottle360 session.', 'b360-bridge'),
        'attributes'  => [
            'active'         => ['type' => 'string', 'default' => 'profile', 'notes' => 'Active tab/section.'],
            'login_page_url' => ['type' => 'URL',    'default' => '/login',  'notes' => 'Your site’s login page (used for redirects).'],
        ],
        'example' => '[my_account login_page_url="/login"]',
    ],
];

// Allow extension if needed.
$shortcodes = apply_filters('b360_bridge_admin_shortcodes', $shortcodes);

// Utility to render attributes neatly
$render_attr_row = function (array $attrs): string {
    if (!$attrs) {
        return '<p class="description" style="margin:8px 0;">' . esc_html__('No attributes.', 'b360-bridge') . '</p>';
    }
    $out = '<table class="widefat striped" style="margin:8px 0 12px;">';
    $out .= '<thead><tr><th>' . esc_html__('Attribute', 'b360-bridge') . '</th><th>' . esc_html__('Type', 'b360-bridge') . '</th><th>' . esc_html__('Default', 'b360-bridge') . '</th><th>' . esc_html__('Notes', 'b360-bridge') . '</th></tr></thead><tbody>';
    foreach ($attrs as $name => $meta) {
        $out .= '<tr>';
        $out .= '<td><code>' . esc_html($name) . '</code></td>';
        $out .= '<td>' . esc_html($meta['type'] ?? '') . '</td>';
        $out .= '<td><code>' . esc_html(is_string($meta['default'] ?? '') ? (string) $meta['default'] : '') . '</code></td>';
        $out .= '<td>' . esc_html($meta['notes'] ?? '') . '</td>';
        $out .= '</tr>';
    }
    $out .= '</tbody></table>';
    return $out;
};
?>
<div class="wrap b360-bridge-settings">
    <h1><?php echo esc_html__('Bottle360 Bridge', 'b360-bridge'); ?></h1>

    <style>
        .b360-grid {
            display: flex;
            gap: 16px;
            align-items: flex-start;
            width: 100%;
        }

        /* Let columns respect the gap and prevent overflow */
        .b360-col-left,
        .b360-col-right {
            min-width: 0;
        }

        .b360-col-left {
            flex: 0 0 calc(70% - 8px);
            max-width: calc(70% - 8px);
        }

        .b360-col-right {
            flex: 0 0 calc(30% - 8px);
            max-width: calc(30% - 8px);
        }

        /* Make cards fill their column, not the WP default narrow width */
        .b360-bridge-settings .card {
            width: 100% !important;
            max-width: none !important;
            box-sizing: border-box;
            display: block;
        }

        /* Keep the first right-side card sticky only */
        .b360-col-right .card:first-child {
            position: sticky;
            top: 16px;
        }

        .b360-col-right .card:not(:first-child) {
            margin-top: 16px;
            position: static;
        }

        /* Tables/inputs should wrap inside cards */
        .b360-bridge-settings .widefat {
            width: 100%;
            box-sizing: border-box;
            table-layout: auto;
        }

        .b360-bridge-settings .widefat td,
        .b360-bridge-settings .widefat th {
            word-break: break-word;
        }

        .b360-bridge-settings .regular-text.code {
            width: 100%;
            box-sizing: border-box;
        }

        /* Avoid stray horizontal scrollbars */
        .b360-bridge-settings {
            overflow-x: hidden;
        }

        @media (max-width:1100px) {
            .b360-grid {
                flex-direction: column;
            }

            .b360-col-left,
            .b360-col-right {
                flex-basis: 100%;
                max-width: 100%;
            }

            .b360-col-right .card:first-child {
                position: static;
            }
        }
    </style>


    <div class="b360-grid">
        <!-- LEFT: SETTINGS (70%) -->
        <div class="b360-col-left">
            <div class="card" style="padding:16px;">
                <h2><?php echo esc_html__('Settings', 'b360-bridge'); ?></h2>
                <form action="options.php" method="post">
                    <?php
                    // Use the registered Settings API group/sections/fields
                    settings_fields('b360_bridge');
                    do_settings_sections('b360_bridge');
                    submit_button();
                    ?>
                </form>
            </div>
        </div>

        <!-- RIGHT: HOW-TO + SHORTCODES (30%) -->
        <div class="b360-col-right">
            <!-- HOW TO USE -->
            <div class="card" style="padding:16px;">
                <h2><?php echo esc_html__('How to use the plugin', 'b360-bridge'); ?></h2>
                <ol style="margin-left:20px;">
                    <li><?php echo esc_html__('Set your Tenant Subdomain and TLD in the Settings.', 'b360-bridge'); ?></li>
                    <li><?php echo esc_html__('Place any of the shortcodes on pages (see Shortcodes card).', 'b360-bridge'); ?></li>
                    <li><?php echo esc_html__('The plugin exposes the upstream base URL to JS as', 'b360-bridge'); ?> <code>B360Bridge.baseHost</code>.</li>
                </ol>
                <p>
                    <strong><?php echo esc_html__('Current config:', 'b360-bridge'); ?></strong>
                    <?php
                    printf(
                        ' %s: <code>%s</code> — %s: <code>.%s</code> — %s: <code>%s</code>',
                        esc_html__('Tenant', 'b360-bridge'),
                        esc_html($tenant !== '' ? $tenant : 'demo'),
                        esc_html__('TLD', 'b360-bridge'),
                        esc_html($tld),
                        esc_html__('Base Host', 'b360-bridge'),
                        esc_html($baseHost)
                    );
                    ?>
                </p>
            </div>

            <!-- SHORTCODES -->
            <div class="card" style="padding:16px;">
                <h2><?php echo esc_html__('Shortcodes', 'b360-bridge'); ?></h2>

                <?php foreach ($shortcodes as $tag => $def): ?>
                    <div class="b360-shortcode" style="margin-bottom:18px;">
                        <h3 style="margin-bottom:4px;">
                            <code>[<?php echo esc_html($tag); ?>]</code>
                            — <?php echo esc_html($def['title'] ?? ''); ?>
                            <?php if (!empty($def['aliases'])): ?>
                                <small class="description">&nbsp;<?php echo esc_html__('Aliases:', 'b360-bridge'); ?>
                                    <?php foreach ($def['aliases'] as $alias): ?>
                                        <code>[<?php echo esc_html($alias); ?>]</code>
                                    <?php endforeach; ?>
                                </small>
                            <?php endif; ?>
                        </h3>

                        <?php if (!empty($def['description'])): ?>
                            <p class="description" style="margin-top:4px;"><?php echo esc_html($def['description']); ?></p>
                        <?php endif; ?>

                        <?php
                        $attrs = (array)($def['attributes'] ?? []);
                        echo $render_attr_row($attrs);
                        ?>

                        <?php if (!empty($def['example'])): ?>
                            <div class="b360-example">
                                <label style="display:block; font-weight:600; margin-bottom:4px;"><?php echo esc_html__('Example', 'b360-bridge'); ?></label>
                                <div style="display:flex; gap:8px; align-items:center;">
                                    <input type="text" readonly value="<?php echo esc_attr($def['example']); ?>" class="regular-text code b360-copy-input" style="width:100%;" />
                                    <button type="button" class="button b360-copy-btn"><?php echo esc_html__('Copy', 'b360-bridge'); ?></button>
                                </div>
                            </div>
                        <?php endif; ?>
                        <hr />
                    </div>
                <?php endforeach; ?>

                <p class="description">
                    <?php echo esc_html__('You can extend this table via the', 'b360-bridge'); ?>
                    <code>b360_bridge_admin_shortcodes</code>
                    <?php echo esc_html__('filter.', 'b360-bridge'); ?>
                </p>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('click', function(e) {
        if (e.target && e.target.classList.contains('b360-copy-btn')) {
            const input = e.target.closest('.b360-example').querySelector('.b360-copy-input');
            input.select();
            input.setSelectionRange(0, 99999);
            try {
                document.execCommand('copy');
                e.target.textContent = '<?php echo esc_js(__('Copied!', 'b360-bridge')); ?>';
                setTimeout(() => {
                    e.target.textContent = '<?php echo esc_js(__('Copy', 'b360-bridge')); ?>';
                }, 1200);
            } catch (_) {}
        }
    }, false);
</script>