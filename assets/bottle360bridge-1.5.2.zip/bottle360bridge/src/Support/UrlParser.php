<?php
namespace Bottle360\Bridge\Support;

final class UrlParser {
    public static function parse(string $rawPath): ?array {
        $after = trim($rawPath, '/');
        if ($after === '') return null;
        $parts = array_values(array_filter(array_map('urldecode', explode('/', $after)), 'strlen'));

        $map = [
            'w' => 'wine',
            'wine' => 'wine',
            'p' => 'product',
            'product' => 'product',
            'b' => 'bundle',
            'bundle' => 'bundle',
        ];

        $type = '';
        $slug = '';
        $vintage = '';

        $norm = function($t) use ($map) {
            $t = strtolower($t);
            return $map[$t] ?? $t;
        };

        $hasVintageWord = function($p) {
            return is_string($p) && strtolower($p) === 'vintage';
        };

        if (count($parts) === 1) {
            $type = 'product';
            $slug = $parts[0];
        } elseif (count($parts) >= 2) {
            if (isset($map[strtolower($parts[0])])) {
                $type = $norm($parts[0]);
                $slug = $parts[1];
                if (!empty($parts[2]) && $hasVintageWord($parts[2]) && !empty($parts[3])) {
                    $vintage = $parts[3];
                } else {
                    $vintage = $parts[2] ?? '';
                }
            } elseif (isset($map[strtolower($parts[1])])) {
                $slug = $parts[0];
                $type = $norm($parts[1]);
                if (!empty($parts[2]) && $hasVintageWord($parts[2]) && !empty($parts[3])) {
                    $vintage = $parts[3];
                } else {
                    $vintage = $parts[2] ?? '';
                }
            } else {
                $type = $norm($parts[0]);
                $slug = $parts[1];
                $vintage = $parts[2] ?? '';
            }
        } else {
            return null;
        }

        $slug = sanitize_title($slug);
        $vintage = preg_replace('/[^0-9A-Za-z-]/', '', (string)$vintage);

        $type = apply_filters('b360_bridge_resolve_type', $type, $slug);

        return [
            'type' => $type,
            'slug' => $slug,
            'vintage' => $vintage,
        ];
    }
}
