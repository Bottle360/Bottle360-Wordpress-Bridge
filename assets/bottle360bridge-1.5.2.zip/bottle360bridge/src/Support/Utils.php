<?php
namespace Bottle360\Bridge\Support;

if (!defined('ABSPATH')) exit;

/**
 * Persists remote cookies per browser so ProxyForm and LoadCart share session.
 */
final class Utils {
    private const SID_COOKIE = 'b360_sid';

    public static function browser_token(): string {
        if (!empty($_COOKIE[self::SID_COOKIE])) {
            return sanitize_text_field($_COOKIE[self::SID_COOKIE]);
        }
        $token = wp_generate_uuid4();
        setcookie(self::SID_COOKIE, $token, time() + 30 * DAY_IN_SECONDS, COOKIEPATH ?: '/', $_SERVER['HTTP_HOST'], is_ssl(), true);
        $_COOKIE[self::SID_COOKIE] = $token;
        return $token;
    }

    private static function jar_key(): string {
        return 'b360_cookiejar_' . self::browser_token();
    }

    public static function store_cookies_from_response($response): void {
        $cookies = function_exists('wp_remote_retrieve_cookies') ? wp_remote_retrieve_cookies($response) : [];
        if (is_array($cookies) && !empty($cookies)) {
            set_transient(self::jar_key(), $cookies, 7 * DAY_IN_SECONDS);
        }
    }

    public static function cookie_args(): array {
        $cookies = get_transient(self::jar_key());
        return $cookies ? ['cookies' => $cookies] : [];
    }
}
