<?php

namespace Bottle360\Bridge\Shortcodes;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Services\YiiSession;

if (!defined('ABSPATH')) exit;

final class MyAccountShortcode
{
  public function register(): void
  {
    add_shortcode('my_account', [$this, 'render']);
  }

  /** Build local redirector link that resolves s_key on click. */
  private function out_link(string $path): string
  {
    // Normalise to a path-only value to keep redirector strict/safe.
    $path = '/' . ltrim($path, '/');
    $url  = add_query_arg(
      ['action' => 'b360_out', 'to' => $path],
      admin_url('admin-post.php')
    );
    return esc_url($url);
  }

  /** Make a site-absolute URL from a given path or URL (for WP login page). */
  private function build_site_url(string $pathOrUrl): string
  {
    $pathOrUrl = trim($pathOrUrl);
    if ($pathOrUrl === '') {
      return esc_url(home_url('/'));
    }
    if (preg_match('~^https?://~i', $pathOrUrl)) {
      return esc_url($pathOrUrl);
    }
    return esc_url(home_url('/' . ltrim($pathOrUrl, '/')));
  }

  /**
   * (Kept for completeness — not used for links anymore)
   * Get s_key as base64(value of upstream Yii cookie).
   */
  private function get_s_key(): string
  {
    $cookie = YiiSession::cookieHeader(); // e.g., "advanced-frontend=abcdef..."
    if ($cookie === '' || strpos($cookie, '=') === false) return '';
    $val = trim(substr($cookie, strpos($cookie, '=') + 1));
    if ($val === '') return '';
    return base64_encode($val);
  }

  public function render($atts = []): string
  {
    $atts = shortcode_atts([
      'active'         => 'profile',
      'login_page_url' => '/login',
    ], $atts, 'my_account');

    // All tenant links go through the redirector now
    $urls = [
      'store'        => $this->out_link('/store'),
      'loyalty'      => $this->out_link('/user/loyalty'),
      'edit'         => $this->out_link('/user/editprofile'),
      'addresses'    => $this->out_link('/user/addresses'),
      'orders'       => $this->out_link('/user/orders'),
      'cards'        => $this->out_link('/user/credit-card'),
      'clubs'        => $this->out_link('/user/club-list'),
      'shipments'    => $this->out_link('/user/upcoming-shipments'),
      'gifts'        => $this->out_link('/user/gift_certificates'),
      'allocations'  => $this->out_link('/user/allocations'),
      'reservations' => $this->out_link('/user/my-reservations'),
      'changepass'   => $this->out_link('/user/changepassword'),
      'logout'       => $this->out_link('/user/logout'),
    ];

    $same_page  = get_permalink();
    $login_url  = $this->build_site_url((string) $atts['login_page_url']);

    $active = strtolower(sanitize_key($atts['active']));
    $is = function (string $key) use ($active) {
      return $active === $key ? ' class="active"' : '';
    };

    ob_start(); ?>
    <!-- Guard: if localStorage.b360_user is missing/invalid, redirect to WP login page -->
    <script>
      (function() {
        try {
          var raw = localStorage.getItem('b360_user');
          if (!raw) { window.location.replace(<?php echo json_encode($login_url); ?>); return; }
          try { JSON.parse(raw); } catch (e) { window.location.replace(<?php echo json_encode($login_url); ?>); return; }
        } catch (err) { window.location.replace(<?php echo json_encode($login_url); ?>); }
      })();
    </script>

    <div class="container inner-page-contents">
      <div class="row">
        <div class="col-lg-3">
          <div class="user-links">
            <h3>Member Area</h3>
            <p><span data-b360="welcome">Welcome</span></p>
            <ul>
              <li><a class="storelink" href="<?php echo $urls['store']; ?>" target="_blank" rel="noopener noreferrer">Shop Now</a></li>
              <li class="account">
                <a<?php echo $is('profile'); ?> href="<?php echo esc_url($same_page); ?>" target="_blank" rel="noopener noreferrer">My Account</a>
              </li>
              <li class="loyalty"><a href="<?php echo $urls['loyalty']; ?>" target="_blank" rel="noopener noreferrer">DevWallet</a></li>
              <li class="edit"><a href="<?php echo $urls['edit']; ?>" target="_blank" rel="noopener noreferrer">Edit Your Profile</a></li>
              <li class="addressbook"><a href="<?php echo $urls['addresses']; ?>" target="_blank" rel="noopener noreferrer">Addresses</a></li>
              <li class="myorders"><a href="<?php echo $urls['orders']; ?>" target="_blank" rel="noopener noreferrer">Order History</a></li>
              <li class="cardbook"><a href="<?php echo $urls['cards']; ?>" target="_blank" rel="noopener noreferrer">Credit Cards</a></li>
              <li class="clublist"><a href="<?php echo $urls['clubs']; ?>" target="_blank" rel="noopener noreferrer">Club Memberships</a></li>
              <li class="upcoming-shipments"><a href="<?php echo $urls['shipments']; ?>" target="_blank" rel="noopener noreferrer">Upcoming Wine Club Shipments</a></li>
              <li class="gift-certificates"><a href="<?php echo $urls['gifts']; ?>" target="_blank" rel="noopener noreferrer">Gift Certificates/Credits</a></li>
              <li class="allocations"><a href="<?php echo $urls['allocations']; ?>" target="_blank" rel="noopener noreferrer">My Allocations</a></li>
              <li class="reservation"><a href="<?php echo $urls['reservations']; ?>" target="_blank" rel="noopener noreferrer">My Reservations</a></li>
              <li class="changepass"><a href="<?php echo $urls['changepass']; ?>" target="_blank" rel="noopener noreferrer">Change Password</a></li>
              <li class="logout"><a href="<?php echo $urls['logout']; ?>" target="_blank" rel="noopener noreferrer">Logout</a></li>
            </ul>
          </div>
        </div>

        <div class="col-lg-9">
          <div class="user-contents-wrapper container">
            <div class="user-profile">
              <h2 class="mb-4">Your profile</h2>
              <div class="table-div">
                <div class="d-flex border-bottom p-2 flex-wrap">
                  <div class="col-md-4">First Name</div>
                  <div class="col-md-8"><span data-b360="first_name">—</span></div>
                </div>
                <div class="d-flex border-bottom p-2 flex-wrap">
                  <div class="col-md-4">Last Name</div>
                  <div class="col-md-8"><span data-b360="last_name">—</span></div>
                </div>
                <div class="d-flex border-bottom p-2 flex-wrap">
                  <div class="col-md-4">Birthdate</div>
                  <div class="col-md-8"><span data-b360="birthdate">—</span></div>
                </div>
                <div class="d-flex border-bottom p-2 flex-wrap">
                  <div class="col-md-4">Username</div>
                  <div class="col-md-8"><span data-b360="username">—</span></div>
                </div>
                <div class="d-flex border-bottom p-2 flex-wrap">
                  <div class="col-md-4">E-mail</div>
                  <div class="col-md-8"><span data-b360="email">—</span></div>
                </div>
                <div class="d-flex border-bottom p-2 flex-wrap">
                  <div class="col-md-4"></div>
                  <div class="col-md-8">
                    <a href="<?php echo $urls['edit']; ?>" class="btn btn-primary user-edit-btn" target="_blank" rel="noopener noreferrer">Edit Profile</a>
                  </div>
                </div>
              </div>
            </div> <!-- .user-profile -->
          </div> <!-- .user-contents-wrapper -->
        </div>
      </div>
    </div>

    <script>
      (function() {
        // Populate small profile bits from localStorage (unchanged)
        try {
          var raw = localStorage.getItem('b360_user');
          if (!raw) return;
          var root = JSON.parse(raw);
          function get(o,p){return p.split('.').reduce(function(a,k){return (a&&a[k]!==undefined)?a[k]:undefined;},o);}
          function pick(paths){for(var i=0;i<paths.length;i++){var v=get(root,paths[i]);if(v===undefined||v===null)continue;v=String(v).trim();if(v!=='')return v;}return '';}
          function norm(v){if(!v)return'';v=String(v).trim();var m=v.match(/^(\d{4})-(\d{2})-(\d{2})$/);if(m)return m[2]+'/'+m[3]+'/'+m[1];return v;}
          var first=pick(['user.firstname','firstName','first_name','fname']);
          var last =pick(['user.lastname','lastName','last_name','lname']);
          var email=pick(['user.email','email']);
          var usern=pick(['user.username','username','userName','login']);
          var bday =norm(pick(['user.birthdate','birthdate','birth_date','dob']));
          function set(sel,val){var el=document.querySelector(sel); if(el) el.textContent=val||'—';}
          set('[data-b360="first_name"]', first);
          set('[data-b360="last_name"]',  last);
          set('[data-b360="email"]',      email);
          set('[data-b360="username"]',   usern);
          set('[data-b360="birthdate"]',  bday);
          var welcome=document.querySelector('[data-b360="welcome"]');
          if (welcome) welcome.textContent = (first||usern) ? ('Welcome ' + (first||usern)) : 'Welcome';
        } catch(e){}
      })();
    </script>
<?php
    return (string) ob_get_clean();
  }
}
