<?php
namespace Bottle360\Bridge\Shortcodes;

if (!defined('ABSPATH')) exit;

final class LoginShortcode
{
    public function register(): void
    {
        add_shortcode('b360-login',  [$this, 'render']);
        add_shortcode('b360_login',  [$this, 'render']); // alias
    }

    public function render($atts = []): string
    {
        $atts = shortcode_atts([
            'view'              => 'login',
            'account_page_url'  => home_url('/my-account'),
            'redirect_if_auth'  => 'yes', // yes|no
            'class'             => '',
            'debug'             => 'no',
        ], $atts, 'b360-login');

        $this->ensure_assets($atts['account_page_url']);
        $this->ensure_footer_fallback($atts['account_page_url']);

        $id = 'b360-auth-' . wp_generate_password(6, false);

        ob_start(); ?>
          <div id="<?php echo esc_attr($id); ?>"
               class="b360-auth-root <?php echo esc_attr($atts['class']); ?>"
               data-view="<?php echo esc_attr($atts['view']); ?>"
               data-account-url="<?php echo esc_url($atts['account_page_url']); ?>"
               data-redirect-if-auth="<?php echo esc_attr($atts['redirect_if_auth']); ?>"
               data-debug="<?php echo esc_attr($atts['debug']); ?>">
            <div class="b360-auth-loading">Loading…</div>
          </div>
        <?php
        return (string) ob_get_clean();
    }

    /**
     * Register+enqueue the assets the normal WP way and localize config.
     * Also uses filemtime() for cache busting.
     */
    private function ensure_assets(string $accountUrl): void
    {
        $plugin_file = defined('B360_BRIDGE_FILE') ? B360_BRIDGE_FILE : __FILE__;
        $root        = plugin_dir_path($plugin_file);

        // CSS
        $css_abs = $root . 'assets/css/b360-bridge.css';
        if (file_exists($css_abs) && !wp_style_is('b360-bridge', 'registered')) {
            wp_register_style(
                'b360-bridge',
                plugins_url('assets/css/b360-bridge.css', $plugin_file),
                [],
                (string) (filemtime($css_abs) ?: time())
            );
        }
        if (wp_style_is('b360-bridge', 'registered')) {
            wp_enqueue_style('b360-bridge');
        }

        // JS
        $js_abs = $root . 'assets/js/b360-login-view.js';
        if (file_exists($js_abs) && !wp_script_is('b360-login-view', 'registered')) {
            wp_register_script(
                'b360-login-view',
                plugins_url('assets/js/b360-login-view.js', $plugin_file),
                [],
                (string) (filemtime($js_abs) ?: time()),
                true
            );
        }

        // Localize ONLY what the view needs
        if (wp_script_is('b360-login-view', 'registered')) {
            wp_localize_script('b360-login-view', 'B360Bridge', [
                'ajaxUrl'    => admin_url('admin-ajax.php'),
                'nonce'      => wp_create_nonce('b360_bridge_nonce'), // for b360_auth_view
                'cartNonce'  => wp_create_nonce('b360_nonce'),        // for b360_auth_proxy
                'accountUrl' => $accountUrl,
                // 'baseHost' => \Bottle360\Bridge\Settings\Options::get_base_host(), // uncomment if used in JS
            ]);
            wp_enqueue_script('b360-login-view');
        }
    }

    /**
     * Footer fallback: if WP didn’t print the handle, inject it once manually.
     * Avoids double-load by checking $wp_scripts->done.
     */
    private function ensure_footer_fallback(string $accountUrl): void
    {
        add_action('wp_footer', function () use ($accountUrl) {
            // If WP printed scripts normally and our handle is done, bail.
            global $wp_scripts;
            $printed = is_object($wp_scripts) && !empty($wp_scripts->done) && in_array('b360-login-view', (array) $wp_scripts->done, true);
            if ($printed) return;

            $plugin_file = defined('B360_BRIDGE_FILE') ? B360_BRIDGE_FILE : __FILE__;
            $js_url      = plugins_url('assets/js/b360-login-view.js', $plugin_file);

            // Print config + script tag as a last resort
            $cfg = [
                'ajaxUrl'    => admin_url('admin-ajax.php'),
                'nonce'      => wp_create_nonce('b360_bridge_nonce'),
                'cartNonce'  => wp_create_nonce('b360_nonce'),
                'accountUrl' => $accountUrl,
            ];
            echo '<script>window.B360Bridge=' . wp_json_encode($cfg) . ';</script>' . "\n";
            echo '<script src="' . esc_url($js_url) . '" defer></script>' . "\n";
        }, 9999);
    }
}
