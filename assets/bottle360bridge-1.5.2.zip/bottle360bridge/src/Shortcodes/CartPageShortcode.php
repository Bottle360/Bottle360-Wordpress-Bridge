<?php

namespace Bottle360\Bridge\Shortcodes;

final class CartPageShortcode
{
    public function register(): void
    {
        add_shortcode('b360_cart', [$this, 'render']);
    }

    public function render($atts = []): string
    {
        // Enqueue cart-page assets if they’re registered
        if (wp_style_is('b360-cart-page', 'registered')) {
            wp_enqueue_style('b360-cart-page');
        }
        if (wp_script_is('b360-cart-page', 'registered')) {
            wp_enqueue_script('b360-cart-page');
        } elseif (wp_script_is('b360-bridge', 'registered')) {
            // fallback to main bundle if that’s where the loader lives
            wp_enqueue_script('b360-bridge');
        }

        ob_start(); ?>
        <div id="b360-carT" class="b360-cart-page">
            <div id="b360-cart_internal_contents"></div>
        </div>
        <?php
        return ob_get_clean();
    }
}
