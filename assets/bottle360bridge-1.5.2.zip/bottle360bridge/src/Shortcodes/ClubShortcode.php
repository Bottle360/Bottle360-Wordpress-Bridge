<?php

namespace Bottle360\Bridge\Shortcodes;


final class ClubShortcode
{
    public function register()
    {
        add_shortcode('b360-club', [$this, 'render']);
    }


    public function render($atts = [])
    {
        // Attributes for future customization
        $atts = shortcode_atts([
            'per_page' => 12,
        ], $atts, 'b360-club');


        ob_start();
?>
        <div id="b360-club-app" data-per-page="<?php echo esc_attr($atts['per_page']); ?>">
            <div id="b360-club-listing"></div>
            <div id="b360-club-pagination"></div>
        </div>
        <script>
            window.b360ClubAjax = '<?php echo esc_js(admin_url('admin-ajax.php')); ?>';
        </script>
<?php
        // enqueue assets (ensure Assets.php registers this file or enqueue here)
        wp_enqueue_script('b360-club-js');
        // wp_enqueue_style('b360-bridge-css');


        return ob_get_clean();
    }
}
