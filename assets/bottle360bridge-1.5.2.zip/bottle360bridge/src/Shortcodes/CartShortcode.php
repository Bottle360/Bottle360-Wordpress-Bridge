<?php
namespace Bottle360\Bridge\Shortcodes;

if (!defined('ABSPATH')) exit;

final class CartShortcode
{
    public function register(): void
    {
        add_shortcode('b360_cart_icon', [$this, 'render']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue']);
    }

    public function enqueue(): void
    {
        // Base styles/scripts
        wp_enqueue_style('b360-bridge');
        wp_enqueue_script('b360-bridge');

        $bridge_css_path = B360_BRIDGE_DIR . '/assets/css/b360-cart-modal.css';
        $bridge_css_ver = file_exists($bridge_css_path) ? filemtime($bridge_css_path) : B360_BRIDGE_VER;

        // Cart CSS
        wp_enqueue_style(
            'b360-cart-modal',
            B360_BRIDGE_URL . '/assets/css/b360-cart-modal.css',
            [],
            $bridge_css_ver
        );

        // Cart JS
        wp_enqueue_script(
            'b360-cart-shortcode',
            B360_BRIDGE_URL . '/assets/js/b360-cart-shortcode.js',
            ['jquery', 'b360-bridge'], // <-- depend on base so B360CartShortcode can coexist
            B360_BRIDGE_VER,
            true
        );

        // Localize for the modal (legacy action kept)
        wp_localize_script('b360-cart-shortcode', 'B360CartShortcode', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('b360_bridge_nonce'),
        ]);
    }

    public function render($atts = [], $content = ''): string
    {
        $atts = shortcode_atts([
            'count' => '0',
            'label' => 'Cart',
            'cart_url' => '/cart'
        ], $atts, 'b360_cart_icon');

        ob_start(); ?>
        <div class="b360-cart-sc-root">
            <a href="#" class="b360-cart-sc-button" id="b360-cart-sc-toggle" aria-controls="b360-cart-sc-modal" aria-haspopup="dialog" aria-expanded="false">
                <svg class="b360-cart-sc-icon" viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><path d="M7 4h-2l-1 2h2l3.6 7.59-1.35 2.45A1.99 1.99 0 0 0 10 19h9v-2h-8.42c-.14 0-.25-.11-.25-.25l.03-.12L11.1 14h5.45a2 2 0 0 0 1.79-1.11l3.58-6.49A1 1 0 0 0 21 5H8.31l-.94-2Z"/></svg>
                <span class="b360-cart-sc-label"><?php echo esc_html($atts['label']); ?></span>
                <span class="b360-cart-sc-badge" id="b360-cart-sc-count"><?php echo (int) $atts['count']; ?></span>
            </a>

            <!-- Modal -->
            <div class="b360-cart-sc-modal" id="b360-cart-sc-modal" role="dialog" aria-modal="true" aria-labelledby="b360-cart-sc-toggle" hidden>
                <div class="b360-cart-sc-backdrop" data-close="1"></div>
                <div class="b360-cart-sc-dialog" role="document">
                    <button type="button" class="b360-cart-sc-close" id="b360-cart-sc-close" aria-label="Close cart">&times;</button>
                    <div id="b360-cart-sc-body" class="b360-cart-sc-body" aria-live="polite"></div>
                    <div id="b360-cart-sc-buttons" class="b360-cart-sc-buttons" aria-live="polite">
                        <span class="b360-cart-btn"><a href="<?php echo $atts['cart_url'] ?>">Go to Cart</a></span>
                        <span class="b360-checkout-btn"><a href="/checkout">Proceed to Checkout</a></span>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return (string) ob_get_clean();
    }
}
