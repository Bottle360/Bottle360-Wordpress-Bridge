<?php
namespace Bottle360\Bridge\Shortcodes;

if (!defined('ABSPATH')) exit;

final class ProfileShortcode
{
    public function register(): void
    {
        add_shortcode('b360-profile', [$this, 'render']);
        add_shortcode('b360_profile', [$this, 'render']); // alias
    }

    public function render($atts = []): string
    {
        $atts = shortcode_atts([
            'class'           => '',
            'login_url'       => home_url('/login'),
            'register_url'    => home_url('/register'),
            'account_url'     => home_url('/my-account'),
            'show_welcome'    => 'yes',     // yes|no
            'welcome_prefix'  => 'Welcome', // text
        ], $atts, 'b360-profile');

        // enqueue profile assets (script handles localization in Assets.php)
        wp_enqueue_script('b360-profile');

        ob_start(); ?>
        <nav class="b360-authmenu <?php echo esc_attr($atts['class']); ?>"
             data-show-welcome="<?php echo esc_attr($atts['show_welcome']); ?>"
             data-welcome-prefix="<?php echo esc_attr($atts['welcome_prefix']); ?>"
             data-login-url="<?php echo esc_url($atts['login_url']); ?>">
          <!-- Logged OUT -->
          <ul class="b360-authmenu__list b360-authmenu__list--out">
            <li><a class="b360-authmenu__link" href="<?php echo esc_url($atts['login_url']); ?>">Login</a></li>
            <li><a class="b360-authmenu__link" href="<?php echo esc_url($atts['register_url']); ?>">Register</a></li>
          </ul>

          <!-- Logged IN (hidden by default; JS will flip based on localStorage only) -->
          <ul class="b360-authmenu__list b360-authmenu__list--in" style="display:none">
            <li class="b360-authmenu__welcome">
              <span class="b360-authmenu__welcome-prefix"><?php echo esc_html($atts['welcome_prefix']); ?></span>
              <span class="b360-authmenu__name"></span>
            </li>
            <li><a class="b360-authmenu__link" href="<?php echo esc_url($atts['account_url']); ?>">My Account</a></li>
            <li><a class="b360-authmenu__link" href="#" data-action="logout">Logout</a></li>
          </ul>
        </nav>
        <?php
        return (string) ob_get_clean();
    }
}
