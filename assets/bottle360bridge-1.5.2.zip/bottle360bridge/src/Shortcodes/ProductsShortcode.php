<?php

namespace Bottle360\Bridge\Shortcodes;

final class ProductsShortcode
{
    public function register(): void
    {
        add_shortcode('b360_products', [$this, 'render']);
    }

    public function render($atts = [], $content = null): string
    {
        wp_enqueue_style('b360-bridge');
        wp_enqueue_script('b360-bridge');

        $atts = shortcode_atts([
            'title' => __('Bottle360 Products', 'b360-bridge'),
        ], $atts, 'b360_products');

        ob_start();
?>
        <div class="b360-bridge-container">
            <?php
            // $yii_cookie = $_SESSION['yii_session_cookie'] ?? null;

            // if (!empty($yii_cookie)) {
            //     echo $cookieString = $yii_cookie['name'] . '=' . $yii_cookie['value'];
            // } else {
            //     echo "No Yii cookie found in session.";
            // }
            ?>
            <div id="b360-results" class="b360-results"></div>
            <div id="b360-detail" class="b360-detail" aria-live="polite"></div>
        </div>
<?php
        return (string) ob_get_clean();
    }
}
