<?php
namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class CheckoutRedirect
{
    public function register(): void
    {
        add_action('wp_ajax_b360_checkout_redirect',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_checkout_redirect', [$this, 'handle']);
    }

    /** Extract base64-encoded s_key from the Yii session cookie header ("name=value"). */
    private function current_s_key(): string
    {
        $pair = YiiSession::cookieHeader(); // e.g. "yii_session_cookie=abcdef"
        if (!$pair || strpos($pair, '=') === false) return '';
        $val = trim(substr($pair, strpos($pair, '=') + 1));
        return $val !== '' ? base64_encode($val) : '';
    }

    /** Return the first URL that responds with 2xx/3xx; otherwise null. */
    private function first_working_url(array $urls, array $headers): ?string
    {
        foreach ($urls as $u) {
            $r = wp_remote_get($u, ['timeout' => 8, 'redirection' => 2, 'headers' => $headers]);
            if (is_wp_error($r)) continue;
            $code = (int) wp_remote_retrieve_response_code($r);
            if ($code >= 200 && $code < 400) return $u;
        }
        return null;
    }

    public function handle(): void
    {
        // Accept JSON or x-www-form-urlencoded
        $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson  = stripos((string)$ctype, 'application/json') !== false;
        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        // Primary unified nonce
        $ok = Nonce::verifyFrom($payload, 'nonce');

        // Back-compat: accept _ajax_nonce | security | _wpnonce
        if (!$ok) {
            $fb     = (string)($_REQUEST['_ajax_nonce'] ?? $_REQUEST['security'] ?? $_REQUEST['_wpnonce'] ?? '');
            $action = (string)($payload['action'] ?? $_REQUEST['action'] ?? '');
            if ($fb !== '') {
                $ok = ($action && wp_verify_nonce($fb, $action)) || wp_verify_nonce($fb, 'b360_nonce');
            }
        }
        if (!$ok) {
            wp_send_json_error(['message' => 'Invalid nonce'], 403);
        }

        // Must have a Yii session cookie to carry identity to checkout
        $s_key = $this->current_s_key();
        if ($s_key === '') {
            wp_send_json_error(['message' => 'No Yii session found']);
        }

        $base = rtrim((string) Options::get_base_host(), '/');

        // Allow override from client; default to your current path
        $preferredPath = isset($payload['path']) ? (string)$payload['path'] : '/b360-orders/checkout';
        $paths = [
            '/' . ltrim($preferredPath, '/'),
            '/store/checkout',
            '/b360-store/checkout',
        ];

        // Merge query params and inject s_key if not present
        $query = (isset($payload['query']) && is_array($payload['query'])) ? $payload['query'] : [];
        if (!isset($query['s_key'])) {
            $query['s_key'] = $s_key;
        }

        // Build candidate URLs
        $candidates = [];
        foreach ($paths as $p) {
            $u = $base . $p;
            if (!empty($query)) {
                $u .= (strpos($u, '?') === false ? '?' : '&') . http_build_query($query);
            }
            $candidates[] = $u;
        }

        // Preflight (optional but helpful) with the same Yii cookie the browser will send
        $headers = YiiSession::withYiiCookie([
            'Accept'           => 'text/html,application/xhtml+xml',
            'User-Agent'       => 'Bottle360Bridge/1.0 (+WordPress)',
            'X-Requested-With' => 'XMLHttpRequest',
        ]);

        $chosen = $this->first_working_url($candidates, $headers) ?: $candidates[0];

        // Keep your original response shape
        wp_send_json_success(['redirect_url' => esc_url_raw($chosen)], 200);
    }
}
