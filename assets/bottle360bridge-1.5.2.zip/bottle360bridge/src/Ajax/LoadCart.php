<?php
namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Support\Nonce;
use Bottle360\Bridge\Services\YiiSession;

if (!defined('ABSPATH')) exit;

final class LoadCart
{
    public function register(): void
    {
        add_action('wp_ajax_b360_load_cart',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_load_cart', [$this, 'handle']);
    }

    public function handle(): void
    {
        // Accept JSON or x-www-form-urlencoded
        $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson  = stripos((string)$ctype, 'application/json') !== false;
        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        // ✅ Unified nonce (403 JSON if invalid)
        Nonce::assertAjax($payload, 'nonce');

        $base = rtrim((string) Options::get_base_host(), '/');

        // Allow override via payload['path']; else try robust fallbacks
        $preferred  = isset($payload['path']) ? (string)$payload['path'] : '/b360-store/cart';
        $candidates = [
            '/' . ltrim($preferred, '/'),
            '/store/cart',
        ];

        // Always forward the upstream Yii cookie
        $headers = YiiSession::withYiiCookie([
            'Accept'           => 'text/html,application/xhtml+xml',
            'User-Agent'       => 'Bottle360Bridge/1.0 (+WordPress)',
            'X-Requested-With' => 'XMLHttpRequest',
        ]);

        // If there is no Yii cookie at all, tell the caller (prevents confusing “empty cart”)
        if (empty($headers['Cookie'])) {
            wp_send_json_error([
                'message' => 'No Yii session cookie present (user not initialized).',
                'hint'    => 'Log in or hit an endpoint that seeds the Yii session before loading the cart.',
            ], 409);
        }

        $lastRes = null; $lastUrl = null;

        foreach ($candidates as $path) {
            $url  = $base . $path;
            $res  = wp_remote_get($url, [
                'timeout'     => 20,
                'redirection' => 3,
                'headers'     => $headers,
            ]);
            $lastRes = $res; $lastUrl = $url;

            if (is_wp_error($res)) {
                continue;
            }
            $code = (int) wp_remote_retrieve_response_code($res);
            if ($code >= 200 && $code < 300) {
                $body = (string) wp_remote_retrieve_body($res);
                wp_send_json_success([
                    'html'        => $body,
                    'status'      => $code,
                    'url'         => $url,
                    'yii_session' => $headers['Cookie'] ?? '',
                ]);
            }
            // try next candidate on non-2xx
        }

        if (is_wp_error($lastRes)) {
            wp_send_json_error([
                'message' => 'Network error',
                'error'   => $lastRes->get_error_message(),
            ], 500);
        }

        $code = (int) wp_remote_retrieve_response_code($lastRes);
        $body = (string) wp_remote_retrieve_body($lastRes);
        wp_send_json_error([
            'message' => 'Failed to load cart HTML',
            'status'  => $code,
            'body'    => $body,
            'url'     => $lastUrl,
        ], $code ?: 502);
    }
}
