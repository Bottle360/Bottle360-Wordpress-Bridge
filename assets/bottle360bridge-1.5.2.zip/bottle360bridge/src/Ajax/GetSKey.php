<?php
namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class GetSKey
{
    public function register(): void
    {
        add_action('wp_ajax_b360_get_s_key',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_get_s_key', [$this, 'handle']);
    }

    public function handle(): void
    {
        $payload = $_POST + $_GET;
        Nonce::assertAjax($payload, 'nonce');

        $skey = '';
        $pair = YiiSession::cookieHeader(); // e.g. "advanced-frontend=abcdef..."
        if ($pair && strpos($pair, '=') !== false) {
            $val = trim(substr($pair, strpos($pair, '=') + 1));
            if ($val !== '') $skey = base64_encode($val);
        }

        wp_send_json_success(['s_key' => $skey]);
    }
}
