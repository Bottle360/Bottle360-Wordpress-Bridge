<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Support\Utils;

if (!defined('ABSPATH')) exit;

final class GetCsrf
{
    // Static register so you can call GetCsrf::register();
    public static function register(): void
    {
        add_action('wp_ajax_b360_get_csrf',        [self::class, 'handle']);
        add_action('wp_ajax_nopriv_b360_get_csrf', [self::class, 'handle']); // <-- NOT $this
    }

    // Static handler is fine since we don't use $this inside
    public static function handle(): void
    {
        // $nonce = $_POST['_ajax_nonce'] ?? ($_POST['nonce'] ?? '');
        // $valid = wp_verify_nonce($nonce, 'b360_nonce') || wp_verify_nonce($nonce, 'b360_bridge_nonce');
        // if (!$valid) {
        //     wp_send_json_error(['message' => 'Invalid nonce'], 403);
        // }

        // $base = rtrim(Options::get_base_host(), '/'); // e.g. https://demo.bottlethreesixty.dev
        // // Using the endpoint you specified:
        // $url  = $base . '/thirdpartywidget/default/getcsrftoken';

        // $response = wp_remote_get($url, array_merge([
        //     'timeout'     => 20,
        //     'redirection' => 3,
        //     'headers'     => \Bottle360\Bridge\Services\YiiSession::withYiiCookie([
        //         'Accept'     => 'application/json, text/html;q=0.9,*/*;q=0.8',
        //         'User-Agent' => 'Bottle360Bridge/1.0 (+WordPress)',
        //     ]),
        // ], Utils::cookie_args()));

        // if (is_wp_error($response)) {
        //     wp_send_json_error(['message' => 'Network error', 'error' => $response->get_error_message()], 500);
        // }

        // Utils::store_cookies_from_response($response);

        // $body = (string) wp_remote_retrieve_body($response);
        // $name = '';
        // $value = '';

        // // Prefer JSON
        // $json = json_decode($body, true);
        // if (is_array($json)) {
        //     $name  = $json['name']  ?? $json['csrf_name'] ?? 'yii_csrf_wp';
        //     $value = $json['value'] ?? $json['token']     ?? $json['csrf'] ?? '';
        // }

        // // Fallbacks: HTML meta/input
        // if (!$value && preg_match('/<meta[^>]+name=[\'"]yii_csrf_wp[\'"][^>]+content=[\'"]([^\'"]+)[\'"]/i', $body, $m)) {
        //     $name = 'yii_csrf_wp'; $value = $m[1];
        // }
        // if (!$value && preg_match('/<meta[^>]+name=[\'"]csrf-token[\'"][^>]+content=[\'"]([^\'"]+)[\'"]/i', $body, $m)) {
        //     $name = 'csrf-token';  $value = $m[1];
        // }
        // if (!$value && preg_match('/<input[^>]+name=[\'"]yii_csrf_wp[\'"][^>]+value=[\'"]([^\'"]+)[\'"]/i', $body, $m)) {
        //     $name = 'yii_csrf_wp'; $value = $m[1];
        // }

        // // Last resort: look for a CSRF cookie
        // if (!$value) {
        //     $cookies = wp_remote_retrieve_cookies($response);
        //     if (is_array($cookies)) {
        //         foreach ($cookies as $cookie) {
        //             $ckName = method_exists($cookie, 'get_name') ? $cookie->get_name() : ($cookie->name ?? '');
        //             $ckVal  = method_exists($cookie, 'get_value') ? $cookie->get_value() : ($cookie->value ?? '');
        //             if (!$ckName || !$ckVal) continue;
        //             if (strtolower($ckName) === 'yii_csrf_wp' || strtoupper($ckName) === 'YII_CSRF_TOKEN') {
        //                 $name = $ckName; $value = $ckVal; break;
        //             }
        //         }
        //     }
        // }

        // if (!$value) {
        //     wp_send_json_error(['message' => 'CSRF token not found at source', 'url' => $url], 502);
        // }

        // // 2h TTL (overridable via filter if you like)
        // $ttl = (int) apply_filters('b360/csrf_ttl', 2 * HOUR_IN_SECONDS);

        // // Write client-readable cookies
        // $cookieDomain = $_SERVER['HTTP_HOST'] ?? '';
        // $cookiePath   = COOKIEPATH ?: '/';
        // $secure       = is_ssl();
        // $httpOnly     = false;
        // setcookie('b360_csrf_name', $name, time() + $ttl, $cookiePath, $cookieDomain, $secure, $httpOnly);
        // setcookie('b360_csrf',      $value, time() + $ttl, $cookiePath, $cookieDomain, $secure, $httpOnly);
        // setcookie('b360_csrf_exp', (string) (time() + $ttl), time() + $ttl, $cookiePath, $cookieDomain, $secure, $httpOnly);

        // wp_send_json_success([
        //     'name'  => $name,
        //     'value' => $value,
        //     'ttl'   => $ttl,
        //     'url'   => $url,
        // ]);
    }
}
