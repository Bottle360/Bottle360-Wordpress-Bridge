<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class RemoveItem
{
    public function register(): void
    {
        add_action('wp_ajax_b360_remove_item',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_remove_item', [$this, 'handle']);
    }

    public function handle(): void
    {
        // Accept JSON or x-www-form-urlencoded
        $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson  = stripos((string)$ctype, 'application/json') !== false;
        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        // ✅ Unified nonce check (403 JSON on failure)
        Nonce::assertAjax($payload, 'nonce');

        // Inputs
        $item = isset($payload['item']) ? sanitize_text_field($payload['item']) : '';
        if ($item === '') {
            wp_send_json_error(['message' => 'Missing item id'], 400);
        }

        // Upstream URL
        $base = rtrim((string) Options::get_base_host(), '/');
        $url  = $base . '/store/cart/delete?' . http_build_query([
            'id' => $item,
            '_'  => time(),
        ]);

        // Headers: Yii cookie only (no PHPSESSID)
        $args = [
            'timeout' => 20,
            'headers' => YiiSession::withYiiCookie([
                'Accept' => 'application/json, */*;q=0.1',
            ]),
        ];

        // Call upstream
        $res = wp_remote_get($url, $args);
        if (is_wp_error($res)) {
            wp_send_json_error(['message' => $res->get_error_message()], 502);
        }

        $code = (int) wp_remote_retrieve_response_code($res);
        $body = (string) wp_remote_retrieve_body($res);
        $trim = strtolower(trim($body));

        // Yii endpoints often return literal "success"
        if ($trim === 'success') {
            wp_send_json_success('success');
        }

        if ($code >= 200 && $code < 300) {
            wp_send_json_success(['status' => $code, 'body' => $body]);
        }

        wp_send_json_error([
            'message' => 'Remote remove failed',
            'status'  => $code,
            'body'    => $body,
        ], 502);
    }
}
