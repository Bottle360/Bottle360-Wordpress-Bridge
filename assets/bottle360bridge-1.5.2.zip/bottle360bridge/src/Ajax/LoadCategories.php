<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Http\Client;
use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class LoadCategories
{
    public function register(): void
    {
        add_action('wp_ajax_b360_load_categories',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_load_categories', [$this, 'handle']);
    }

    public function handle(): void
    {
        // Mirror LoadListing/LoadProductDetail: build $payload, then assert nonce.
        $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson  = stripos((string)$ctype, 'application/json') !== false;
        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        // ✅ Same verification method as listing/detail
        Nonce::assertAjax($payload, 'nonce');

        $remote = rtrim((string) Options::get_base_host(), '/') . '/b360-categories';

        // Forward Yii session cookie if available (same pattern as other proxies)
        $headers = [];
        if (class_exists('\Bottle360\Bridge\Services\YiiSession') &&
            method_exists('\Bottle360\Bridge\Services\YiiSession', 'cookieHeader')) {
            try {
                $cookie = \Bottle360\Bridge\Services\YiiSession::cookieHeader();
                if ($cookie) $headers['Cookie'] = $cookie;
            } catch (\Throwable $e) {}
        }

        $client = new Client();
        $res    = $client->get($remote, ['headers' => $headers]);

        if (empty($res['ok'])) {
            wp_send_json_error([
                'message' => $res['error'] ?? 'Failed to load categories',
                'status'  => (int) ($res['status'] ?? 500),
            ], (int) ($res['status'] ?? 500));
        }

        $data = $this->extract((string) ($res['body'] ?? ''));
        wp_send_json_success(['categories' => $data], 200);
    }

    /**
     * Return shape:
     * [
     *   'parent'   => ['text' => 'Store', 'href' => '/store'] | null,
     *   'children' => [['text'=>'Red Wines','href'=>'/store/red-wines','slug'=>'red-wines'], ...]
     * ]
     */
    private function extract(string $html): array
    {
        $out = ['parent' => null, 'children' => []];
        if ($html === '') return $out;

        $dom = new \DOMDocument();
        libxml_use_internal_errors(true);
        $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html);
        libxml_clear_errors();

        $xp = new \DOMXPath($dom);

        // Parent: first <li><a> under .category-tree
        // $parentA = $xp->query("//ul[contains(concat(' ', normalize-space(@class), ' '), ' category-tree ')]/li[1]/a")?->item(0);
        $parentList = $xp->query("//ul[contains(concat(' ', normalize-space(@class), ' '), ' category-tree ')]/li[1]/a");
        $parentA    = ($parentList instanceof \DOMNodeList && $parentList->length > 0) ? $parentList->item(0) : null;
        if ($parentA instanceof \DOMElement) {
            $href = $parentA->getAttribute('href');
            $text = trim($parentA->textContent ?? '');
            if ($href !== '') $out['parent'] = ['text' => $text, 'href' => $href];
        }

        // Children: first-level anchors within .child ul’s
        $nodes = $xp->query("//ul[contains(concat(' ', normalize-space(@class), ' '), ' category-tree ')]//ul[contains(concat(' ', normalize-space(@class), ' '), ' child ')]//a");
        $children = [];
        if ($nodes instanceof \DOMNodeList) {
            foreach ($nodes as $node) {
                if (!($node instanceof \DOMElement)) continue;
                $href = $node->getAttribute('href');
                $text = trim($node->textContent ?? '');
                $slug = $this->lastSegment($href);
                if ($slug === '') continue;
                $children[] = ['text' => $text ?: $slug, 'href' => $href, 'slug' => $slug];
            }
        }

        // Dedup by slug
        $seen = [];
        $children = array_values(array_filter($children, function($row) use (&$seen){
            $slug = $row['slug'] ?? '';
            if ($slug === '' || isset($seen[$slug])) return false;
            $seen[$slug] = true;
            return true;
        }));

        $out['children'] = $children;
        return $out;
    }

    private function lastSegment(string $href): string
    {
        $path = (string) parse_url($href, PHP_URL_PATH);
        $path = trim($path, '/');
        if ($path === '') return '';
        $parts = explode('/', $path);
        return sanitize_title(end($parts));
    }
}
