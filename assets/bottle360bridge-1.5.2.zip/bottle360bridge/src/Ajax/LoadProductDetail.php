<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Http\Client;

use Bottle360\Bridge\Support\Nonce;

final class LoadProductDetail
{
    public function register(): void
    {
        add_action('wp_ajax_b360_load_product_detail', [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_load_product_detail', [$this, 'handle']);
    }

    public function handle(): void
    {
        // Accept JSON or form just to read the nonce (doesn't change your existing logic)
        $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson  = stripos((string)$ctype, 'application/json') !== false;
        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        // ✅ unified nonce check (single b360_nonce across the plugin)
        Nonce::assertAjax($payload, 'nonce');


        $type    = isset($_POST['type']) ? sanitize_text_field(wp_unslash($_POST['type'])) : '';
        $slug    = isset($_POST['slug']) ? sanitize_title(wp_unslash($_POST['slug'])) : '';
        $vintage = isset($_POST['vintage']) ? sanitize_text_field(wp_unslash($_POST['vintage'])) : '';

        if (!$type || !$slug) {
            wp_send_json_error(['message' => 'Invalid params'], 400);
        }

        $type = strtolower($type);
        $base = rtrim(Options::get_base_host(), '/');

        if ($type === 'wine' && $vintage) {
            $url = $base . '/b360-wine/' . rawurlencode($slug) . '/' . rawurlencode($vintage);
        } elseif ($type === 'product') {
            $url = $base . '/b360-product/' . rawurlencode($slug);
        } elseif ($type === 'bundle') {
            $url = $base . '/b360-bundle/' . rawurlencode($slug);
        } else {
            wp_send_json_error(['message' => 'Invalid type'], 400);
        }

        $client = new Client();
        $res = $client->get($url);

        if (!$res['ok']) {
            wp_send_json_error(['message' => $res['error'] ?? 'HTTP error', 'status' => $res['status'] ?? 500], $res['status'] ?? 500);
        }

        wp_send_json_success(['html' => $res['body'], 'url' => $url]);
    }
}
