<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Http\Client;
use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Support\Nonce;

final class LoadClubs
{
    public function register(): void
    {
        add_action('wp_ajax_b360_load_clubs', [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_load_clubs', [$this, 'handle']);
    }

    public function handle(): void
    {
        // Accept JSON or x-www-form-urlencoded
        $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson  = stripos((string)$ctype, 'application/json') !== false;
        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        // ✅ unified nonce (403 JSON on failure)
        Nonce::assertAjax($payload, 'nonce');

        // Determine current page for pagination
        $page = isset($payload['page']) ? max(1, (int) $payload['page']) : $this->current_page_num();

        $base   = rtrim(Options::get_base_host(), '/'); // tenant-aware
        $remote = $base . '/b360-club' . ($page > 1 ? '?page=' . $page : '');

        // Forward only the upstream Yii cookie (never PHPSESSID)
        $headers = YiiSession::withYiiCookie([]);

        $client = new Client();
        $res    = $client->get($remote, ['headers' => $headers]);

        if (!$res['ok']) {
            wp_send_json_error([
                'message' => $res['error'] ?? 'Failed to load clubs',
                'status'  => $res['status'] ?? 500
            ], $res['status'] ?? 500);
        }

        $html = (string) ($res['body'] ?? '');
        $html = $this->rewrite_links_to_local($html, $this->current_page_url());

        wp_send_json_success([
            'html'        => $html,
            'yii_session' => $headers['Cookie'] ?? '',
        ]);
    }

    private function current_page_num(): int
    {
        $paged = get_query_var('paged');
        if ($paged) return max(1, (int) $paged);
        if (isset($_GET['paged'])) return max(1, (int) $_GET['paged']);
        return 1;
    }

    private function current_page_url(): string
    {
        $ref = wp_get_referer();
        if ($ref) {
            return untrailingslashit($ref);
        }
        $permalink = get_permalink();
        if ($permalink) {
            return untrailingslashit($permalink);
        }
        return untrailingslashit(home_url(add_query_arg([])));
    }

    /**
     * Rewrites Bottle360 club links to local pretty URLs:
     *   /b360-club/{slug}
     *   /b360-club/{slug}/join-club/{token}
     *   /b360-club/{slug}/join-club-confirmation/{token}
     *   /b360-club/address/{token}/join-club
     * Plus pagination -> /page/N and root mapping.
     */
    private function rewrite_links_to_local(string $html, string $pageBaseUrl): string
    {
        $pageBase = untrailingslashit($pageBaseUrl);
        $pageRoot = preg_replace('#/page/\d+/?$#i', '', $pageBase);
        $pageRoot = untrailingslashit($pageRoot);

        $remoteHost = preg_quote(parse_url(
            untrailingslashit(Options::get_base_host()), PHP_URL_HOST
        ) ?: '', '#');

        // Rewrite detail + join flows
        $patterns = [
            // Club detail
            '#https?://' . $remoteHost . '/b360-club/([^"\'/]+)#i',
            '#(?<![A-Za-z0-9_-])/b360-club/([^"\'/]+)#i',

            // Join club
            '#https?://' . $remoteHost . '/b360-club/([^"\'/]+)/join-club/([^"\'/]+)#i',
            '#(?<![A-Za-z0-9_-])/b360-club/([^"\'/]+)/join-club/([^"\'/]+)#i',

            // Confirmation
            '#https?://' . $remoteHost . '/b360-club/([^"\'/]+)/join-club-confirmation/([^"\'/]+)#i',
            '#(?<![A-Za-z0-9_-])/b360-club/([^"\'/]+)/join-club-confirmation/([^"\'/]+)#i',

            // Address join
            '#https?://' . $remoteHost . '/b360-club/address/([^"\'/]+)/join-club#i',
            '#(?<![A-Za-z0-9_-])/b360-club/address/([^"\'/]+)/join-club#i',
        ];
        $replacements = [
            $pageRoot . '/b360-club/$1',
            $pageRoot . '/b360-club/$1',

            $pageRoot . '/b360-club/$1/join-club/$2',
            $pageRoot . '/b360-club/$1/join-club/$2',

            $pageRoot . '/b360-club/$1/join-club-confirmation/$2',
            $pageRoot . '/b360-club/$1/join-club-confirmation/$2',

            $pageRoot . '/b360-club/address/$1/join-club',
            $pageRoot . '/b360-club/address/$1/join-club',
        ];

        $html = preg_replace($patterns, $replacements, $html);

        // Pagination → /page/N
        $html = preg_replace_callback(
            '#(?:https?://' . $remoteHost . ')?/b360-club\?page=([0-9]+)#i',
            function ($m) use ($pageRoot) {
                $n   = (int) $m[1];
                $url = ($n > 1) ? ($pageRoot . '/page/' . $n) : $pageRoot;
                return esc_url(user_trailingslashit($url));
            },
            $html
        );

        // Root /b360-club → local root
        $html = preg_replace(
            '#(?:https?://' . $remoteHost . ')?/b360-club\b(?!\?)#i',
            esc_url(user_trailingslashit($pageRoot)),
            $html
        );

        return $html;
    }
}
