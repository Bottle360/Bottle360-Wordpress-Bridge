<?php
namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class ClubJoinRedirect
{
    public function register(): void
    {
        add_action('wp_ajax_b360_club_join_redirect',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_club_join_redirect', [$this, 'handle']);
    }

    /** s_key = base64(cookie value) from "name=value" Yii cookie header */
    private function sKey(): string
    {
        $pair = YiiSession::cookieHeader(); // "cookieName=cookieValue"
        if (!$pair || strpos($pair, '=') === false) return '';
        $val = trim(substr($pair, strpos($pair, '=') + 1));
        return $val !== '' ? base64_encode($val) : '';
    }

    /** Choose first URL that answers 2xx/3xx */
    private function firstWorkingUrl(array $urls, array $headers): ?string
    {
        foreach ($urls as $u) {
            $r = wp_remote_get($u, ['timeout'=>8,'redirection'=>2,'headers'=>$headers]);
            if (is_wp_error($r)) continue;
            $code = (int) wp_remote_retrieve_response_code($r);
            if ($code >= 200 && $code < 400) return $u;
        }
        return null;
    }

    public function handle(): void
    {
        // Accept JSON or x-www-form-urlencoded
        $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson  = stripos((string)$ctype, 'application/json') !== false;
        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        // Nonce: centralized (with fallbacks)
        $ok = Nonce::verifyFrom($payload, 'nonce');
        if (!$ok) {
            $fb     = (string)($_REQUEST['_ajax_nonce'] ?? $_REQUEST['security'] ?? $_REQUEST['_wpnonce'] ?? '');
            $action = (string)($payload['action'] ?? $_REQUEST['action'] ?? '');
            if ($fb !== '') {
                $ok = ($action && wp_verify_nonce($fb, $action)) || wp_verify_nonce($fb, 'b360_nonce');
            }
        }
        if (!$ok) wp_send_json_error(['message' => 'Invalid nonce'], 403);

        $base = rtrim((string) Options::get_base_host(), '/');

        // Inputs
        $slug         = isset($payload['slug']) ? (string)$payload['slug'] : '';
        // We accept either option_id or token (alias)
        $optionId     = isset($payload['option_id']) ? (string)$payload['option_id'] : '';
        if (!$optionId && isset($payload['token'])) $optionId = (string)$payload['token'];

        // (Optional) address flow or explicit path override
        $addressToken = isset($payload['address_token']) ? (string)$payload['address_token'] : '';
        $pathOverride = isset($payload['path']) ? (string)$payload['path'] : '';

        // Always try to attach s_key if we have a Yii session
        $sk = $this->sKey();
        $query = [];
        if ($sk !== '') $query['s_key'] = $sk;

        // Build candidate paths with option in the PATH (not query)
        $paths = [];
        if ($pathOverride !== '') {
            $paths[] = '/' . ltrim($pathOverride, '/');
        } elseif ($addressToken !== '') {
            // Address pre-step flow
            $paths[] = '/b360-club/address/' . rawurlencode($addressToken) . '/join-club';
        } elseif ($slug !== '') {
            if ($optionId !== '') {
                // Desired shape: /b360-club/{slug}/join-club/{optionId}/
                $paths[] = '/b360-club/' . rawurlencode($slug) . '/join-club/' . rawurlencode($optionId) . '/';
                // Also try without trailing slash just in case upstream routing prefers it
                $paths[] = '/b360-club/' . rawurlencode($slug) . '/join-club/' . rawurlencode($optionId);
            } else {
                $paths[] = '/b360-club/' . rawurlencode($slug) . '/join-club/';
                $paths[] = '/b360-club/' . rawurlencode($slug) . '/join-club';
            }
        } else {
            // Fallback: club list
            $paths[] = '/user/club-list';
        }

        // Build full candidate URLs and append s_key
        $candidates = [];
        foreach ($paths as $p) {
            $u = $base . $p;
            if (!empty($query)) {
                $u .= (strpos($u, '?') === false ? '?' : '&') . http_build_query($query);
            }
            $candidates[] = $u;
        }

        // Preflight using the same Yii cookie the browser will send
        $headers = YiiSession::withYiiCookie([
            'Accept'           => 'text/html,application/xhtml+xml',
            'User-Agent'       => 'Bottle360Bridge/1.0 (+WordPress)',
            'X-Requested-With' => 'XMLHttpRequest',
        ]);

        $chosen = $this->firstWorkingUrl($candidates, $headers) ?: $candidates[0];

        wp_send_json_success([
            'redirect_url' => esc_url_raw($chosen),
            'url'          => esc_url_raw($chosen),
        ], 200);
    }
}
