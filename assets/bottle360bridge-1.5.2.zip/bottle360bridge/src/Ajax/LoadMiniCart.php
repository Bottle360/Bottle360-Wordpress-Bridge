<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class LoadMiniCart
{
    public function register(): void
    {
        add_action('wp_ajax_b360_load_minicart',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_load_minicart', [$this, 'handle']);
    }

    public function handle(): void
    {
        // Accept JSON or x-www-form-urlencoded
        $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson  = stripos((string)$ctype, 'application/json') !== false;
        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        // ✅ Unified nonce check (403 JSON on failure)
        Nonce::assertAjax($payload, 'nonce');

        $base = rtrim((string) Options::get_base_host(), '/');

        // Allow override via payload['path']; otherwise try robust fallbacks
        $preferred  = isset($payload['path']) ? (string)$payload['path'] : '/store/cart_contents';
        $candidates = [
            '/' . ltrim($preferred, '/'),
            '/b360-store/cart_contents',   // fallback if tenant uses the b360- prefix
        ];

        // Always forward the upstream Yii cookie
        $headers = YiiSession::withYiiCookie([
            'Accept'           => 'text/html,application/xhtml+xml',
            'User-Agent'       => 'Bottle360Bridge/1.0 (+WordPress)',
            'X-Requested-With' => 'XMLHttpRequest',
        ]);

        // Try each candidate until one returns 2xx
        foreach ($candidates as $path) {
            $url = $base . $path;

            $res = wp_remote_get($url, [
                'timeout'     => 20,
                'redirection' => 3,
                'headers'     => $headers,
            ]);

            if (is_wp_error($res)) {
                // network failure → try next candidate
                continue;
            }

            $code = (int) wp_remote_retrieve_response_code($res);
            if ($code >= 200 && $code < 300) {
                $html = (string) wp_remote_retrieve_body($res);
                wp_send_json_success([
                    'html'            => $html,
                    'status'          => $code,
                    'url'             => $url,
                    'request_headers' => $headers,
                    'yii_session'     => $headers['Cookie'] ?? '',
                ]);
            }
            // non-2xx → try next candidate
        }

        wp_send_json_error(['message' => 'Mini cart fetch failed'], 502);
    }
}
