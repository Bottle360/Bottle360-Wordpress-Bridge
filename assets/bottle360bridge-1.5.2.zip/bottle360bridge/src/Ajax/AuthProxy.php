<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class AuthProxy
{
    private const ALLOWED = [
        '/b360-login',
        '/b360-register',
        '/b360-user/profile',
        '/b360-user/logout',
    ];

    // Order matters for picking the upstream Yii cookie value
    private const CANDIDATE_COOKIES = ['advanced-frontend', 'frontend', 'PHPSESSID'];

    public function register(): void
    {
        add_action('wp_ajax_b360_auth_proxy',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_auth_proxy', [$this, 'handle']);
    }

    public function handle(): void
    {
        // -------- payload / nonce ----------
        $ctype  = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson = stripos($ctype, 'application/json') !== false;

        $rawBody = file_get_contents('php://input');
        $payload = [];
        if ($isJson) {
            $tmp = json_decode((string)$rawBody, true);
            if (is_array($tmp)) $payload = $tmp;
        }
        if (!$payload) $payload = $_POST + $_GET;

        Nonce::assertAjax($payload, 'nonce');

        $path = (string)($payload['path'] ?? '');
        if (!in_array($path, self::ALLOWED, true)) {
            $this->send(['success' => 'false', 'message' => 'Unsupported path'], 400);
        }

        $base = rtrim((string) Options::get_base_host(), '/');

        // -------- map form (login/register only; unchanged behavior) ----------
        $form = [];
        if ($path === '/b360-login') {
            if (isset($payload['form']) && is_array($payload['form'])) {
                $form = $payload['form'];
            } else {
                // Pass through common fields; keep your existing naming intact
                $form = [
                    'UserLogin[username]'   => (string)($payload['username'] ?? ''),
                    'UserLogin[password]'   => (string)($payload['password'] ?? ''),
                    'UserLogin[rememberMe]' => (string)($payload['rememberMe'] ?? '0'),
                ];
            }
            $u = (string)($form['UserLogin[username]'] ?? '');
            $p = (string)($form['UserLogin[password]'] ?? '');
            if ($u === '' || $p === '') {
                $this->send(['success' => 'false', 'message' => 'Username and password are required.'], 422);
            }
        } elseif ($path === '/b360-register') {
            $form = (isset($payload['form']) && is_array($payload['form'])) ? $payload['form'] : (array)$payload;
        }

        // =====================================================================
        // LOGOUT: GET + s_key in query (ONLY change requested) — everything else intact
        // =====================================================================
        if ($path === '/b360-user/logout') {
            $logoutUrl = $base . $path;

            // derive s_key from upstream Yii cookie value
            $s_key = '';
            $pair  = YiiSession::cookieHeader(); // e.g., "advanced-frontend=abcdef..."
            if ($pair && strpos($pair, '=') !== false) {
                $val = trim(substr($pair, strpos($pair, '=') + 1));
                if ($val !== '') $s_key = base64_encode($val);
            }
            if ($s_key !== '') {
                $logoutUrl = add_query_arg(['s_key' => $s_key], $logoutUrl);
            }

            // Simple GET (no headers/cookies forwarded)
            $res  = wp_remote_get($logoutUrl, ['timeout' => 20, 'redirection' => 0]);
            $meta = $this->build_server_meta($logoutUrl, 'GET', $res);

            if (is_wp_error($res)) {
                $this->send([
                    'success'         => 'false',
                    'message'         => $meta['message'] ?? 'Logout failed',
                    'cleared'         => false,
                    'reinitialized'   => false,
                    'server_request'  => ['url' => $logoutUrl, 'method' => 'GET'],
                    'server_response' => $meta,
                ], 400);
            }

            $raw  = (string) wp_remote_retrieve_body($res);
            $json = json_decode($raw, true);

            $ok = is_array($json) && (
                (($json['success'] ?? null) === true) ||
                (($json['success'] ?? '') === 'true') ||
                (($json['status']  ?? '') === 'ok')
            );

            if ($ok) {
                // Clear any locally stored upstream Yii cookie & re-init a guest session
                $this->clear_yii_session_cookie_exact();
                $reinit = $this->reinit_guest_session($base);

                $this->send([
                    'success'         => 'true',
                    'message'         => (string)($json['message'] ?? 'Logged out.'),
                    'cleared'         => true,
                    'reinitialized'   => (bool) $reinit,
                    'server_request'  => ['url' => $logoutUrl, 'method' => 'GET'],
                    'server_response' => $meta,
                ], 200);
            }

            // Failure → keep local session intact
            $this->send([
                'success'         => 'false',
                'message'         => (string)($json['message'] ?? 'Logout failed'),
                'cleared'         => false,
                'reinitialized'   => false,
                'server_request'  => ['url' => $logoutUrl, 'method' => 'GET'],
                'server_response' => $meta,
            ], 400);
        }

        // =====================================================================
        // NON-LOGOUT FLOWS (login/register/profile) — left intact
        // =====================================================================
        // You can keep your existing cookie/headers behavior here as before
        $headers = [
            'Accept'     => 'application/json, */*;q=0.1',
            'User-Agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Bottle360Bridge/1.0',
        ];
        [$headers, $cookieJar] = $this->attach_session_cookie($base, $headers);

        $url    = $base . $path;
        $method = ($path === '/b360-user/profile') ? 'GET' : 'POST';

        $args = [
            'timeout'     => 20,
            'headers'     => $headers,
            'cookies'     => $cookieJar,
            'redirection' => 0,
        ];
        if ($method === 'POST') $args['body'] = $form;

        $res = ($method === 'POST') ? wp_remote_post($url, $args) : wp_remote_get($url, $args);
        if (is_wp_error($res)) {
            $this->send(['success' => 'false', 'message' => $res->get_error_message()], 502);
        }

        // Persist cookies for non-logout flows
        $this->store_yii_cookie_from_response($res);

        $code = (int) wp_remote_retrieve_response_code($res);
        $body = (string) wp_remote_retrieve_body($res);
        $json = json_decode($body, true);

        $ok = is_array($json) && (
            ($json['success'] ?? null) === true ||
            ($json['success'] ?? '') === 'true' ||
            ($json['status']  ?? '') === 'ok'
        );

        $this->send([
            'success'         => $ok ? 'true' : 'false',
            'message'         => (string)($json['message'] ?? ($ok ? 'OK' : 'Failed')),
            'user'            => $json['user'] ?? null,
            'server_response' => $this->build_server_meta($url, $method, $res),
        ], $ok ? 200 : 400);
    }

    // ---------------- helpers (unchanged) ----------------

    private function attach_session_cookie(string $base, array $headers): array
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

        $host = parse_url($base, PHP_URL_HOST) ?: '';
        $cookieJar = [];
        $pairs = [];

        foreach (self::CANDIDATE_COOKIES as $name) {
            if (!empty($_SESSION[$name])) {
                $val = (string) $_SESSION[$name];
                $pairs[$name] = $val;
                if (class_exists('\WP_Http_Cookie')) {
                    $cookieJar[] = new \WP_Http_Cookie([
                        'name'   => $name,
                        'value'  => $val,
                        'domain' => $host ?: null,
                        'path'   => '/',
                    ]);
                }
            }
        }

        if ($pairs) {
            $cookieHeader = [];
            foreach ($pairs as $n => $v) $cookieHeader[] = $n . '=' . $v;
            $headers['Cookie'] = implode('; ', $cookieHeader);
        }

        return [$headers, $cookieJar];
    }

    /** Persist any Yii cookie we see in the upstream response into PHP $_SESSION (not browser). */
    private function store_yii_cookie_from_response($response): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        if (is_wp_error($response)) return;

        $headers = wp_remote_retrieve_headers($response);
        $setCookies = [];

        if (is_object($headers) && method_exists($headers, 'getAll')) {
            $all = (array) $headers->getAll();
            foreach ($all as $k => $v) {
                if (strtolower((string)$k) === 'set-cookie') {
                    if (is_array($v)) { $setCookies = array_merge($setCookies, $v); }
                    elseif (is_string($v)) { $setCookies[] = $v; }
                }
            }
        } elseif (is_array($headers)) {
            foreach ($headers as $k => $v) {
                if (strtolower((string)$k) === 'set-cookie') {
                    if (is_array($v)) { $setCookies = array_merge($setCookies, $v); }
                    elseif (is_string($v)) { $setCookies[] = $v; }
                }
            }
        }

        if (!$setCookies) return;

        foreach ($setCookies as $line) {
            $first = explode(';', (string)$line, 2)[0];
            [$name, $value] = array_pad(explode('=', $first, 2), 2, '');
            $name = trim((string)$name);
            $value = trim((string)$value);

            if ($name !== '' && in_array($name, self::CANDIDATE_COOKIES, true)) {
                $_SESSION[$name] = $value;
                if (method_exists(YiiSession::class, 'set')) {
                    YiiSession::set($name, $value);
                }
            }
        }
    }

    /** Build a safe, exact upstream response meta (no Set-Cookie leakage). */
    private function build_server_meta(string $url, string $method, $response): array
    {
        if (is_wp_error($response)) {
            return [
                'url'     => $url,
                'method'  => $method,
                'error'   => true,
                'message' => $response->get_error_message(),
            ];
        }

        $code        = (int) wp_remote_retrieve_response_code($response);
        $headers_obj = wp_remote_retrieve_headers($response);
        $headers_arr = [];

        // Normalize headers to array and strip cookies
        if (is_object($headers_obj) && method_exists($headers_obj, 'getAll')) {
            $headers_arr = (array) $headers_obj->getAll();
        } elseif (is_array($headers_obj)) {
            $headers_arr = $headers_obj;
        }
        foreach (array_keys($headers_arr) as $k) {
            $lk = strtolower((string)$k);
            if ($lk === 'set-cookie' || $lk === 'cookie') unset($headers_arr[$k]);
        }

        $body = (string) wp_remote_retrieve_body($response);

        return [
            'url'         => $url,
            'method'      => $method,
            'status_code' => $code,
            'headers'     => $headers_arr,
            'content_type'=> (string) wp_remote_retrieve_header($response, 'content-type'),
            'body'        => $body,
        ];
    }

    /** Remove any stored Yii cookie from our PHP session */
    private function clear_yii_session_cookie_exact(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        foreach (self::CANDIDATE_COOKIES as $k) {
            if (isset($_SESSION[$k])) unset($_SESSION[$k]);
        }
        foreach (self::CANDIDATE_COOKIES as $k) {
            if (method_exists(YiiSession::class, 'set')) {
                YiiSession::set($k, '');
            }
        }
    }

    /** Start a fresh anonymous upstream session (no cookies); return true if captured a new Yii cookie. */
    private function reinit_guest_session(string $base): bool
    {
        $headers = [
            'Accept'     => 'application/json, */*;q=0.1',
            'User-Agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Bottle360Bridge/1.0',
        ];
        $candidates = [
            rtrim($base, '/') . '/',
            rtrim($base, '/') . '/b360-user/profile',
        ];
        foreach ($candidates as $u) {
            $res = wp_remote_get($u, ['timeout' => 10, 'headers' => $headers, 'redirection' => 0]);
            if (is_wp_error($res)) continue;
            $this->store_yii_cookie_from_response($res);
            if ($this->has_yii_session_cookie()) return true;
        }
        return false;
    }

    private function has_yii_session_cookie(): bool
    {
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        foreach (self::CANDIDATE_COOKIES as $k) {
            if (!empty($_SESSION[$k])) return true;
        }
        return false;
    }

    private function send(array $payload, int $status = 200): void
    {
        status_header($status);
        header('Content-Type: application/json; charset=utf-8');
        echo wp_json_encode($payload);
        wp_die();
    }
}
