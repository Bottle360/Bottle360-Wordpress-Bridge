<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class AddToCart
{
    public function register(): void
    {
        add_action('wp_ajax_b360_add_to_cart',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_add_to_cart', [$this, 'handle']);
    }

    public function handle(): void
    {
        // Build payload (accept JSON or x-www-form-urlencoded)
        $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson  = stripos((string)$ctype, 'application/json') !== false;
        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        // ✅ Unified nonce verification (403 JSON on failure)
        Nonce::assertAjax($payload, 'nonce');

        // Strip admin-ajax noise
        $ignore = ['action', 'nonce', 'ajaxmode', '_cb', 'yii_cookie'];
        $body   = array_diff_key($payload, array_flip($ignore));

        if (empty($body)) {
            wp_send_json_error(['message' => 'Missing POST params'], 400);
        }

        $base = rtrim((string) Options::get_base_host(), '/');

        // allow override via payload['path'], else try robust fallbacks
        $preferred = isset($payload['path']) ? (string)$payload['path'] : '/b360-store/cart/create';
        $candidates = [
            '/' . ltrim($preferred, '/'),
            // '/store/cart/create',
        ];

        $headers = YiiSession::withYiiCookie([
            'Accept' => 'application/json, */*;q=0.1',
        ]);

        $lastErr = null;
        $lasterrCode = null;
        foreach ($candidates as $path) {
            $url  = $base . $path;
            $res  = wp_remote_post($url, [
                'timeout' => 20,
                'body'    => $body,
                'headers' => $headers,
            ]);

            if (is_wp_error($res)) {
                $lastErr = $res->get_error_message();
                // continue;
            }
            $code = (int) wp_remote_retrieve_response_code($res);
            $out  = (string) wp_remote_retrieve_body($res);

            // print_r(wp_remote_retrieve_body($res));
            // wp_die();

            if ($code >= 200 && $code < 300) {
                status_header($code ?: 200);
                header('Content-Type: application/json; charset=utf-8');
                echo $out;
                wp_die();
            }
            // if it’s a 404/redirect/etc, try next candidate
            // $lastErr = "HTTP $code from $path";
            $lastErr = $out;
            $lasterrCode = $code;
        }

        // wp_send_json_error(['message' => $lastErr ?: 'Add to cart failed'], 502);
        // wp_send_json_error(['message' => $lastErr], $lasterrCode);
        // wp_send_json_error( $lastErr, $lasterrCode);
        echo json_encode(array(
            'success' => false,
            'error' => $lastErr,
            'http_response_code' => $lasterrCode
        ));
        wp_die();
    }
}
