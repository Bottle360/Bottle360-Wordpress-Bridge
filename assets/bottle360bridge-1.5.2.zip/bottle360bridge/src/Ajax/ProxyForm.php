<?php
namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Support\Utils;

if (!defined('ABSPATH')) exit;

final class ProxyForm {
    public function register(): void {
        add_action('wp_ajax_b360_proxy_form',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_proxy_form', [$this, 'handle']);
    }

    public function handle(): void {
        $nonce = $_POST['_ajax_nonce'] ?? ($_POST['nonce'] ?? '');
        $valid = wp_verify_nonce($nonce, 'b360_nonce') || wp_verify_nonce($nonce, 'b360_bridge_nonce');
        if (!$valid) {
            wp_send_json_error(['message' => 'Invalid nonce'], 403);
        }

        $sendDebug = current_user_can('manage_options') && !empty($_POST['debug']);

        $base      = rtrim(Options::get_base_host(), '/');     // e.g., https://demo.bottlethreesixty.dev
        $actionUrl = $base . '/store/cart/create';             // align with your form action

        // Gather fields (supports nested 'fields' from JS)
        $fields = [];
        if (isset($_POST['fields']) && is_array($_POST['fields'])) {
            $fields = $_POST['fields'];
        } else {
            $fields = $_POST;
            unset($fields['action'], $fields['_ajax_nonce'], $fields['nonce'], $fields['debug']);
        }

        // Load cookie jar and try to inject CSRF into both header & body
        $cookieArgs = Utils::cookie_args();
        $csrfName   = '';
        $csrfValue  = '';
        if (!empty($cookieArgs['cookies']) && is_array($cookieArgs['cookies'])) {
            foreach ($cookieArgs['cookies'] as $cookie) {
                $name = method_exists($cookie, 'get_name') ? $cookie->get_name() : ($cookie->name ?? '');
                $val  = method_exists($cookie, 'get_value') ? $cookie->get_value() : ($cookie->value ?? '');
                if (!$name || !$val) continue;
                $lower = strtolower($name);
                if ($lower === 'yii_csrf_wp' || $lower === 'yii_csrf_token' || $lower === 'csrf-token' || $lower === 'yii_csrf_token') {
                    $csrfName  = $name;
                    $csrfValue = self::sanitizeToken($val);
                    break;
                }
            }
        }

        if ($csrfName && $csrfValue) {
            // Put token into body with the correct field name
            $fields[$csrfName] = $csrfValue;
        }

        // Build headers (also carry CSRF in headers for Yii)
        $referer = !empty($_POST['page_url']) ? esc_url_raw($_POST['page_url']) : home_url(add_query_arg([], '/'));
        $headers = [
            'Accept'           => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Content-Type'     => 'application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent'       => 'Bottle360Bridge/1.0 (+WordPress)',
            'X-Requested-With' => 'XMLHttpRequest',
            'Referer'          => $referer,
        ];
        // Normalize: forward only the upstream Yii cookie (never PHPSESSID)
        if (class_exists('\Bottle360\Bridge\Services\YiiSession')) {
            try { $__cookie = \Bottle360\Bridge\Services\YiiSession::cookieHeader();
                if ($__cookie) { $headers['Cookie'] = $__cookie; } else { unset($headers['Cookie']); }
            } catch (\Throwable $e) { unset($headers['Cookie']); }
        }

        if ($csrfValue) {
            $headers['X-CSRF-Token']     = $csrfValue;
            $headers['X-Yii-Csrf-Token'] = $csrfValue;
            $headers['X-CSRF-Name']      = $csrfName ?: 'yii_csrf_wp';
        }

        $args = array_merge([
            'method'      => 'POST',
            'timeout'     => 25,
            'redirection' => 3,
            'headers'     => $headers,
            'body'        => $fields,
        ], $cookieArgs);

        $response = wp_remote_request($actionUrl, $args);

        if (is_wp_error($response)) {
            $payload = ['message' => 'Network error', 'error' => $response->get_error_message()];
            if ($sendDebug) $payload['debug'] = self::debugPayload($actionUrl, $args, null, null, $csrfName, $csrfValue);
            wp_send_json_error($payload, 500);
        }

        Utils::store_cookies_from_response($response);

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);

        if ($code < 200 || $code >= 300) {
            $payload = ['message' => 'Remote error from Bottle360', 'status' => $code, 'body' => $body];
            if ($sendDebug) $payload['debug'] = self::debugPayload($actionUrl, $args, $code, $response, $csrfName, $csrfValue);
            wp_send_json_error($payload, $code ?: 502);
        }

        $payload = ['status' => $code, 'body' => $body];
        if ($sendDebug) $payload['debug'] = self::debugPayload($actionUrl, $args, $code, $response, $csrfName, $csrfValue);
        wp_send_json_success($payload);
    }

    private static function sanitizeToken(string $val): string
    {
        $val = trim($val);
        $val = trim($val, "\"'; \t\r\n");
        return $val;
    }

    private static function debugPayload(string $url, array $args, ?int $code, $response, string $csrfName, string $csrfValue): array
    {
        $mask = function (string $s): string {
            if ($s === '') return '';
            $len = strlen($s);
            if ($len <= 10) return str_repeat('•', max(0, $len - 4)) . substr($s, -4);
            return substr($s, 0, 6) . str_repeat('•', $len - 10) . substr($s, -4);
        };

        $sentHeaders = $args['headers'] ?? [];
        foreach ($sentHeaders as $k => $v) {
            $lk = strtolower($k);
            if ($lk === 'x-csrf-token' || $lk === 'x-yii-csrf-token' || $lk === 'authorization' || $lk === 'cookie') {
                $sentHeaders[$k] = $mask((string) $v);
            }
        }

        $sentBody = $args['body'] ?? [];
        if (is_array($sentBody)) {
            foreach ($sentBody as $k => $v) {
                $lk = strtolower($k);
                if ($lk === 'yii_csrf_wp' || $lk === 'yii_csrf_token' || $lk === 'csrf-token' || $lk === 'yii_csrf_token') {
                    $sentBody[$k] = $mask((string) $v);
                }
            }
        }

        $cookieNames = [];
        if (!empty($args['cookies']) && is_array($args['cookies'])) {
            foreach ($args['cookies'] as $cookie) {
                $cookieNames[] = method_exists($cookie, 'get_name') ? $cookie->get_name() : ($cookie->name ?? '');
            }
        }

        $recvCookies = [];
        if ($response && function_exists('wp_remote_retrieve_cookies')) {
            $rc = wp_remote_retrieve_cookies($response);
            if (is_array($rc)) {
                foreach ($rc as $cookie) {
                    $recvCookies[] = method_exists($cookie, 'get_name') ? $cookie->get_name() : ($cookie->name ?? '');
                }
            }
        }

        return [
            'requested_url'    => $url,
            'response_code'    => $code,
            'sent_headers'     => $sentHeaders,
            'sent_body_keys'   => array_keys(is_array($args['body'] ?? null) ? $args['body'] : []),
            'csrf_field_used'  => $csrfName,
            'csrf_field_value' => $mask($csrfValue),
            'cookie_jar_names' => $cookieNames,
            'received_cookies' => $recvCookies,
        ];
    }
}
