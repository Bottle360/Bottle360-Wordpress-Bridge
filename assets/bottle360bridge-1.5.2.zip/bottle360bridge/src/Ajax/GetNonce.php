<?php
namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class GetNonce
{
    public function register(): void
    {
        add_action('wp_ajax_b360_get_nonce',        [$this,'handle']);
        add_action('wp_ajax_nopriv_b360_get_nonce', [$this,'handle']);
    }
    public function handle(): void
    {
        wp_send_json_success(['nonce' => Nonce::value()], 200);
    }
}
