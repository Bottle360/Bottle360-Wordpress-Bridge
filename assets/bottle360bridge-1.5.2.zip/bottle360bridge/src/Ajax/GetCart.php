<?php
namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Settings\Options;


if (!defined('ABSPATH')) exit;

final class GetCart
{
    public function register(): void
    {
        add_action('wp_ajax_b360_get_cart',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_get_cart', [$this, 'handle']);
    }

    public function handle(): void
    {
        if (!session_id()) {
            session_start();
        }

        $cookieHeader = YiiSession::cookieHeader();

        $headers = [];
        // Normalize: forward only the upstream Yii cookie (never PHPSESSID)
        if (class_exists('\Bottle360\Bridge\Services\YiiSession')) {
            try { $__cookie = \Bottle360\Bridge\Services\YiiSession::cookieHeader();
                if ($__cookie) { $headers['Cookie'] = $__cookie; } else { unset($headers['Cookie']); }
            } catch (\Throwable $e) { unset($headers['Cookie']); }
        }

        if ($cookieHeader) {
            $headers['Cookie'] = $cookieHeader;
        }

        $base   = rtrim(Options::get_base_host(), '/'); // tenant-aware
        $url = $base  . '/store/cart_content';
        $res = wp_remote_get($url, [
            'timeout' => 15,
            'headers' => $headers,
        ]);

        if (is_wp_error($res)) {
            wp_send_json_error(['message' => $res->get_error_message()], 500);
        }

        $body = wp_remote_retrieve_body($res);

        header('Content-Type: application/json; charset=utf-8');
        echo $body;
        wp_die();
    }
}
