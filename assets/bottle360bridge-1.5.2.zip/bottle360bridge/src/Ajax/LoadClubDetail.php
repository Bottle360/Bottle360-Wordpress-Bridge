<?php
namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Http\Client;

use Bottle360\Bridge\Support\Nonce;

final class LoadClubDetail {
    public function register(): void {
        add_action('wp_ajax_b360_load_club_detail', [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_load_club_detail', [$this, 'handle']);
    }

    public function handle(): void {
        // Accept JSON or form just for nonce verification (doesn't change your existing logic)
        $ctype   = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson  = stripos((string)$ctype, 'application/json') !== false;
        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        // ✅ unified nonce check (uses the single b360_nonce across the plugin)
        Nonce::assertAjax($payload, 'nonce');

        $slug = isset($_POST['slug']) ? sanitize_title(wp_unslash($_POST['slug'])) : '';

        if (!$slug) {
            wp_send_json_error(['message' => 'Invalid params'], 400);
        }

        $base = rtrim(Options::get_base_host(), '/');
        $url  = $base . '/b360-club/' . rawurlencode($slug);

        $client = new Client();
        $res = $client->get($url);

        if (!$res['ok']) {
            wp_send_json_error([
                'message' => $res['error'] ?? 'HTTP error',
                'status'  => $res['status'] ?? 500
            ], $res['status'] ?? 500);
        }

        wp_send_json_success([
            'html' => $res['body'],
            'url'  => $url
        ]);
    }
}
