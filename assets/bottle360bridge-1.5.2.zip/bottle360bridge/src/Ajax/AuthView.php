<?php

namespace Bottle360\Bridge\Ajax;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Services\YiiSession;

use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class AuthView
{
    public function register(): void
    {
        add_action('wp_ajax_b360_auth_view',        [$this, 'handle']);
        add_action('wp_ajax_nopriv_b360_auth_view', [$this, 'handle']);
    }

    public function handle(): void
    {
        // Accept JSON or form
        $ctype  = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
        $isJson = stripos((string)$ctype, 'application/json') !== false;

        $payload = $isJson
            ? (json_decode(file_get_contents('php://input') ?: '{}', true) ?: [])
            : $_POST;

        if (!is_array($payload)) {
            $payload = [];
        }

        // Strict nonce check (returns 403 JSON if invalid)
        Nonce::assertAjax($payload, 'nonce');

        // View selector
        $view = strtolower((string)($payload['view'] ?? 'login'));
        if (!in_array($view, ['login', 'register'], true)) {
            $this->send_error('Unsupported view', 400);
        }

        // Build upstream URL
        $base = rtrim((string) Options::get_base_host(), '/');
        $path = ($view === 'register') ? '/b360-register' : '/b360-login';
        $url  = $base . $path;

        // Forward ONLY the Yii cookie (never PHPSESSID)
        $headers = YiiSession::withYiiCookie([
            'Accept'     => 'text/html, */*;q=0.1',
            'User-Agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Bottle360Bridge/1.0',
        ]);

        // Fetch HTML
        $res = wp_remote_get($url, [
            'timeout'     => 20,
            'headers'     => $headers,
            'redirection' => 5,
        ]);

        if (is_wp_error($res)) {
            $this->send_error($res->get_error_message(), 502);
        }

        $code = (int) wp_remote_retrieve_response_code($res);
        $html = (string) wp_remote_retrieve_body($res);

        if ($code >= 200 && $code < 300 && $html !== '') {
            $this->send_success(['html' => $html], 200);
        }

        $this->send_error('Upstream returned an unexpected response.', $code ?: 500, ['html' => $html]);
    }

    private function send_success(array $data, int $status = 200): void
    {
        status_header($status);
        header('Content-Type: application/json; charset=utf-8');
        echo wp_json_encode(array_merge(['success' => 'true'], $data));
        wp_die();
    }

    private function send_error(string $message, int $status = 500, array $extra = []): void
    {
        status_header($status);
        header('Content-Type: application/json; charset=utf-8');
        echo wp_json_encode(array_merge(['success' => 'false', 'message' => $message], $extra));
        wp_die();
    }
}
