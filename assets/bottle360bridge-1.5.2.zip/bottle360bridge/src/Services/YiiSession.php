<?php
namespace Bottle360\Bridge\Services;

use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * YiiSession
 *
 * - Creates & maintains an upstream Bottle360/Yii session cookie independently of WordPress.
 * - Seeds a fresh Yii session at early page load (logged-in or logged-out).
 * - Exposes helpers to attach that cookie to all upstream requests.
 * - Can refresh the stored cookie from any upstream WP HTTP response.
 */
final class YiiSession
{
    /** Candidate cookie names we consider an upstream session token. */
    private const CANDIDATES = ['advanced-frontend', 'frontend', 'PHPSESSID'];

    /** Keys we read/write inside PHP $_SESSION. */
    private const SESSION_KEY = 'yii_session_cookie';     // array('name' => ..., 'value' => ...)
    private const SESSION_KEY_BC = 'b360_yii_cookie';     // backward-compat (string "name=value")

    /** Wire early bootstrap on every request. */
    public function register(): void
    {
        add_action('init', [$this, 'bootstrap_session'], 1); // very early
    }

    /**
     * Ensure a Yii session exists in $_SESSION.
     * If missing, fetch a lightweight upstream page to get a Set-Cookie and store it.
     */
    public function bootstrap_session(): void
    {
        self::ensureSession();

        // Already have one → nothing to do.
        if (self::cookieHeader() !== '') {
            return;
        }

        // Try to seed from a lightweight upstream page that reliably sets a session.
        $base = rtrim((string) Options::get_base_host(), '/');
        $url  = $base . '/b360-store';

        $resp = wp_remote_get($url, [
            'timeout'     => 15,
            'redirection' => 5,
            'sslverify'   => false, // keep relaxed as in your backup
        ]);

        if (is_wp_error($resp)) {
            // Don’t hard-fail the page; just skip seeding for now.
            return;
        }

        // Capture any qualifying Set-Cookie from the response.
        self::persistFromResponse($resp);
    }

    /** Start PHP session if needed (we never set/clear browser PHPSESSID here). */
    private static function ensureSession(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            error_log('session started again: ' . session_id());
            @session_start();
        }
    }

    /**
     * Persist an upstream Yii cookie from a WP HTTP response into $_SESSION.
     * Call this after any upstream wp_remote_get/post that might refresh the session.
     */
    public static function persistFromResponse($response): void
    {
        self::ensureSession();

        if (is_wp_error($response)) return;
        if (!function_exists('wp_remote_retrieve_cookies')) return;

        $cookies = wp_remote_retrieve_cookies($response);
        if (!is_array($cookies) || !$cookies) return;

        $want = array_map('strtolower', self::CANDIDATES);

        foreach ($cookies as $c) {
            // WP_Http_Cookie object
            $name  = isset($c->name)  ? (string) $c->name  : '';
            $value = isset($c->value) ? (string) $c->value : '';

            // Fallback parse from header if needed
            if (($name === '' || $value === '') && method_exists($c, 'getHeaderValue')) {
                $h = (string) $c->getHeaderValue(); // "name=value; Path=/; ..."
                if (strpos($h, '=') !== false) {
                    $first = explode(';', $h, 2)[0];
                    [$n, $v] = array_pad(explode('=', $first, 2), 2, '');
                    $name  = $name  ?: trim($n);
                    $value = $value ?: trim($v);
                }
            }

            if ($name === '' || $value === '') continue;
            if (!in_array(strtolower($name), $want, true)) continue;

            // Store only the upstream cookie; DO NOT touch PHPSESSID here.
            self::set($name, $value);
            break; // one is enough
        }
    }

    /** Store/refresh the upstream Yii cookie in $_SESSION. */
    public static function set(string $name, string $value): void
    {
        self::ensureSession();

        $name  = trim($name);
        $value = trim($value);
        if ($name === '' || $value === '') return;

        $_SESSION[self::SESSION_KEY] = ['name' => $name, 'value' => $value];
        // Back-compat: also keep the plain "name=value" string.
        $_SESSION[self::SESSION_KEY_BC] = $name . '=' . $value;
    }

    /**
     * Return "name=value" for the stored Yii cookie, or "" if none.
     * This is what you put into the HTTP "Cookie" header for upstream calls.
     */
    public static function cookieHeader(): string
    {
        self::ensureSession();

        // Preferred array format.
        if (!empty($_SESSION[self::SESSION_KEY]) && is_array($_SESSION[self::SESSION_KEY])) {
            $cookie = $_SESSION[self::SESSION_KEY];
            error_log('in if 1');
            if (!empty($cookie['name']) && !empty($cookie['value'])) {
                error_log('session sending with yii_session_cookie' . print_r($cookie, true));
                return $cookie['name'] . '=' . $cookie['value'];
            }
        }

        // Back-compat fallback string.
        if (!empty($_SESSION[self::SESSION_KEY_BC]) && is_string($_SESSION[self::SESSION_KEY_BC])) {
            error_log('session sent with b360_session_cookie'. print_r($_SESSION[self::SESSION_KEY_BC], true));
            return (string) $_SESSION[self::SESSION_KEY_BC];
        }

        return '';
    }

    /**
     * Convenience: merge headers and inject ONLY the Yii cookie if present.
     * Usage: $headers = YiiSession::withYiiCookie(['Accept' => 'application/json']);
     */
    public static function withYiiCookie(array $headers = []): array
    {
        $cookie = self::cookieHeader();
        if ($cookie !== '') {
            $headers['Cookie'] = $cookie;
        } else {
            unset($headers['Cookie']);
        }
        return $headers;
    }
}
