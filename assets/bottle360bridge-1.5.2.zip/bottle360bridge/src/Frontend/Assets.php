<?php

namespace Bottle360\Bridge\Frontend;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Support\Nonce;

if (!defined('ABSPATH')) exit;

final class Assets
{
    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);
        add_action('wp',                 [$this, 'maybe_enqueue_for_route']);
    }

    public function register_assets(): void
    {
        // Styles
        wp_register_style('b360-bridge', plugins_url('assets/css/b360-bridge.css', B360_BRIDGE_FILE), [], B360_BRIDGE_VER);
        wp_register_style('b360-cart-modal', plugins_url('assets/css/b360-cart-modal.css', B360_BRIDGE_FILE), [], B360_BRIDGE_VER);

        // Core + pages
        wp_register_script('b360-bridge', plugins_url('assets/js/b360-bridge.js', B360_BRIDGE_FILE), ['jquery'], B360_BRIDGE_VER, true);
        wp_register_script('b360-club-js', plugins_url('assets/js/b360-clubs.js', B360_BRIDGE_FILE), ['jquery', 'b360-bridge'], B360_BRIDGE_VER, true);
        wp_register_script('b360-cart-page', plugins_url('assets/js/b360-cart-page.js', B360_BRIDGE_FILE), ['jquery', 'b360-bridge'], B360_BRIDGE_VER, true);
        wp_register_script('b360-login-view', plugins_url('assets/js/b360-login-view.js', B360_BRIDGE_FILE), ['jquery', 'b360-bridge'], B360_BRIDGE_VER, true);
        wp_register_script('b360-profile', plugins_url('assets/js/b360-profile.js', B360_BRIDGE_FILE), ['jquery', 'b360-bridge'], B360_BRIDGE_VER, true);

        // Scripts
        wp_register_script('b360-categories', plugins_url('assets/js/b360-categories.js', B360_BRIDGE_FILE), ['jquery', 'b360-bridge'], B360_BRIDGE_VER, true);

        // Shared config (one nonce for everything)
        $shared = [
            'ajax_url'     => admin_url('admin-ajax.php'),
            'ajaxUrl'      => admin_url('admin-ajax.php'), // back-compat
            'nonce'        => Nonce::value(),
            'cartNonce'    => Nonce::value(),              // back-compat key used in older JS
            'base_host'    => Options::get_base_host(),
            'admin_post'   => admin_url('admin-post.php'),
            'clubsListUrl' => $this->getClubsListUrl(),
        ];

        if (wp_script_is('b360-bridge', 'registered')) {
            wp_localize_script('b360-bridge', 'B360Bridge', $shared);
            wp_localize_script('b360-bridge', 'B360',       $shared);
        }

        if (wp_script_is('b360-profile', 'registered')) {
            wp_localize_script('b360-profile', 'B360PS', [
                'lsKey'     => 'b360_user',
                'ajaxUrl'   => $shared['ajax_url'],
                'nonce'     => $shared['nonce'],
                'cartNonce' => $shared['cartNonce'],
            ]);
        }
    }

    public function maybe_enqueue_for_route(): void
    {
        if (get_query_var('b360_path')) {
            wp_enqueue_style('b360-bridge');
            wp_enqueue_script('b360-bridge');
        }

        if (get_query_var('b360_club_detail') || get_query_var('b360_club_join') || get_query_var('b360_club_confirmation') || get_query_var('b360_club_address')) {
            wp_enqueue_style('b360-bridge');
            wp_enqueue_style('b360-cart-modal');
            wp_enqueue_script('b360-bridge');
            wp_enqueue_script('b360-club-js');
        }

        if (is_singular()) {
            global $post;
            if ($post) {
                $c = (string) $post->post_content;
                if (has_shortcode($c, 'b360-club') || has_shortcode($c, 'b360_club')) {
                    wp_enqueue_style('b360-bridge');
                    wp_enqueue_style('b360-cart-modal');
                    wp_enqueue_script('b360-bridge');
                    wp_enqueue_script('b360-club-js');
                }
            }
        }

        if (function_exists('is_page') && is_page('cart')) {
            wp_enqueue_style('b360-bridge');
            wp_enqueue_style('b360-cart-modal');
            wp_enqueue_script('b360-bridge');
            wp_enqueue_script('b360-cart-page');
        }

        // Login/Register pages normally need this
        if (is_page() || is_singular()) {
            global $post;
            if ($post && is_string($post->post_content)) {
                if (has_shortcode($post->post_content, 'b360-login') || has_shortcode($post->post_content, 'b360_register')) {
                    wp_enqueue_script('b360-login-view');
                }
            }
        }
    }

    private function getClubsListUrl(): string
    {
        $pinned = (int) get_option('b360_club_page_id', 0);
        if ($pinned) {
            $url = get_permalink($pinned);
            if ($url) return trailingslashit($url);
        }

        $posts = get_posts(['post_type' => 'any', 'post_status' => 'publish', 'posts_per_page' => -1]);
        foreach ($posts as $p) {
            $c = (string) ($p->post_content ?? '');
            if (has_shortcode($c, 'b360-club') || has_shortcode($c, 'b360_club')) {
                $url = get_permalink($p->ID);
                if ($url) return trailingslashit($url);
            }
        }

        $prefix = trim((string) get_option('b360_club_base_prefix', ''), '/');
        if ($prefix !== '') return trailingslashit(home_url('/' . $prefix . '/'));

        return trailingslashit(home_url('/'));
    }
}
