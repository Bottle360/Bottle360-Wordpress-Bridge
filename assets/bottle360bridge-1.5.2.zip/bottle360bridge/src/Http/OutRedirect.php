<?php
namespace Bottle360\Bridge\Http;

use Bottle360\Bridge\Services\YiiSession;
use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * Click-time redirector:
 *   /wp-admin/admin-post.php?action=b360_out&to=/user/orders
 *
 * Resolves the CURRENT upstream session cookie → base64 → s_key
 * and appends it to the tenant URL before 302 redirect.
 */
final class OutRedirect
{
    public function register(): void
    {
        add_action('admin_post_b360_out',        [$this, 'handle']); // logged-in
        add_action('admin_post_nopriv_b360_out', [$this, 'handle']); // not logged-in
    }

    public function handle(): void
    {
        // Ensure no caching of the redirect response
        nocache_headers();

        $to = isset($_GET['to']) ? wp_unslash((string) $_GET['to']) : '';
        $to = trim($to);

        // We only allow PATHS (start with "/") to avoid open redirects.
        if ($to === '' || $to[0] !== '/') {
            wp_die('Invalid destination', 400);
        }

        // Build tenant absolute URL
        $base = rtrim((string) Options::get_base_host(), '/');
        if ($base === '' || !preg_match('~^https?://~i', $base)) {
            wp_die('Tenant base host not configured', 500);
        }

        // Compose destination, preserving any query in "to"
        $dest = $base . $to;

        // Get the CURRENT Yii cookie -> base64 -> s_key
        $s_key = '';
        $pair  = YiiSession::cookieHeader(); // e.g. "advanced-frontend=abcdef..."
        if ($pair && strpos($pair, '=') !== false) {
            $val = trim(substr($pair, strpos($pair, '=') + 1));
            if ($val !== '') {
                $s_key = base64_encode($val);
            }
        }

        if ($s_key !== '') {
            // Append or replace s_key on the destination URL
            $dest = add_query_arg(['s_key' => $s_key], $dest);
        }

        // Final 302
        wp_redirect(esc_url_raw($dest), 302);
        exit;
    }
}
