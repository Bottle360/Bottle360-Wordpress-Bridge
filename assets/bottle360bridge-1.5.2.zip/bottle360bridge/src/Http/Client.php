<?php
namespace Bottle360\Bridge\Http;

final class Client {
    /**
     * GET a URL via WordPress HTTP API.
     * Returns ['ok'=>bool, 'status'=>int, 'body'=>string, 'error'=>string?]
     */
    public function get(string $url, array $extraArgs = []): array {
        $args = array_merge([
            'timeout'     => 15,
            'redirection' => 3,
        ], $extraArgs);

        $response = wp_remote_get($url, $args);
        if (is_wp_error($response)) {
            return [
                'ok'    => false,
                'status'=> 0,
                'error' => $response->get_error_message(),
            ];
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);

        if ($code >= 200 && $code < 300) {
            return ['ok' => true, 'status' => $code, 'body' => $body];
        }

        return [
            'ok'     => false,
            'status' => $code,
            'error'  => 'HTTP ' . $code,
            'body'   => $body,
        ];
    }

    public function post(string $url, array $body = [], array $headers = [], array $extraArgs = []): array {
        $args = array_merge([
            'method'      => 'POST',
            'timeout'     => 20,
            'redirection' => 3,
            'body'        => $body,
            'headers'     => $headers,
        ], $extraArgs);

        $response = wp_remote_request($url, $args);
        if (is_wp_error($response)) {
            return [
                'ok'     => false,
                'status' => 0,
                'error'  => $response->get_error_message(),
                'body'   => '',
            ];
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);

        if ($code >= 200 && $code < 300) {
            return ['ok' => true, 'status' => $code, 'body' => $body];
        }

        return [
            'ok'     => false,
            'status' => $code,
            'error'  => 'HTTP ' . $code,
            'body'   => $body,
        ];
    }

}
