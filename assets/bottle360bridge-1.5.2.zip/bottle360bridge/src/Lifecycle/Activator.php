<?php
namespace Bottle360\Bridge\Lifecycle;

final class Activator {
    public static function activate(): void {
        // do_action('init');
        flush_rewrite_rules();
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
    }
}
