<?php
namespace Bottle360\Bridge\Admin;

final class Menu {
    public function register(): void {
        add_action('admin_menu', [$this, 'add_menu']);
        add_filter('plugin_action_links_' . plugin_basename(B360_BRIDGE_FILE), [$this, 'settings_link']);
    }

    public function add_menu(): void {
        add_menu_page(
            __('Bottle360 Bridge', 'b360-bridge'),
            __('Bottle360 Bridge', 'b360-bridge'),
            'manage_options',
            'b360-bridge-settings',
            [$this, 'render'],
            'dashicons-cart',
            60
        );
    }

    public function render(): void {
        require B360_BRIDGE_DIR . 'views/admin/settings.php';
    }

    public function settings_link(array $links): array {
        $url = admin_url('admin.php?page=b360-bridge-settings');
        $links[] = '<a href="' . esc_url($url) . '">' . esc_html__('Settings', 'b360-bridge') . '</a>';
        return $links;
    }
}
