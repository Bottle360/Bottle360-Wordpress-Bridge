<?php
namespace Bottle360\Bridge\Admin;

use Bottle360\Bridge\Settings\Options;

final class SettingsPage {

    /**
     * Attach the settings registration to admin_init.
     * Call this from Plugin->boot()
     */
    public function register_settings(): void {
        \add_action('admin_init', [$this, 'settings']);
    }

    /**
     * Add the options page. Call this from Plugin->boot()
     */
    public function add_menu(): void {
        \add_options_page(
            __('Bottle360 Bridge', 'b360-bridge'),
            __('Bottle360 Bridge', 'b360-bridge'),
            'manage_options',
            'b360_bridge',
            [$this, 'render']
        );
    }

    /**
     * Register settings, sections, fields (Settings API)
     */
    public function settings(): void {
        // --- Register settings
        \register_setting('b360_bridge', Options::OPT_TENANT, [
            'type'              => 'string',
            'sanitize_callback' => [$this, 'sanitize_tenant'],
            'default'           => '',
        ]);

        \register_setting('b360_bridge', Options::OPT_TLD, [
            'type'              => 'string',
            'sanitize_callback' => [$this, 'sanitize_tld'],
            'default'           => 'dev',
        ]);

        \register_setting('b360_bridge', Options::OPT_DISABLE_CACHE, [
            'type'              => 'boolean',
            'sanitize_callback' => [$this, 'sanitize_bool'],
            'default'           => false,
        ]);

        \register_setting('b360_bridge', Options::OPT_DEBUG, [
            'type'              => 'boolean',
            'sanitize_callback' => [$this, 'sanitize_bool'],
            'default'           => false,
        ]);

        // --- Sections
        \add_settings_section(
            'b360_bridge_main',
            __('Bottle360 Tenant', 'b360-bridge'),
            function () {
                echo '<p class="description">' .
                    \esc_html__('Configure your tenant subdomain and environment TLD. These compose the upstream base URL used by the plugin.', 'b360-bridge') .
                '</p>';
            },
            'b360_bridge'
        );

        \add_settings_section(
            'b360_bridge_adv',
            __('Advanced', 'b360-bridge'),
            function () {},
            'b360_bridge'
        );

        // --- Fields (Main)
        \add_settings_field(
            Options::OPT_TENANT,
            __('Tenant Subdomain', 'b360-bridge'),
            [$this, 'field_tenant'],
            'b360_bridge',
            'b360_bridge_main'
        );

        \add_settings_field(
            Options::OPT_TLD,
            __('Bottle360 TLD', 'b360-bridge'),
            [$this, 'field_tld'],
            'b360_bridge',
            'b360_bridge_main'
        );

        // --- Fields (Advanced)
        \add_settings_field(
            Options::OPT_DISABLE_CACHE,
            __('Disable Caching', 'b360-bridge'),
            [$this, 'field_disable_cache'],
            'b360_bridge',
            'b360_bridge_adv'
        );

        \add_settings_field(
            Options::OPT_DEBUG,
            __('Enable Debug Mode', 'b360-bridge'),
            [$this, 'field_debug'],
            'b360_bridge',
            'b360_bridge_adv'
        );
    }

    // ---------------- Renderers ----------------

    public function render(): void {
        if (! \current_user_can('manage_options')) {
            return;
        }

        // Prefer a view file to keep markup separated from logic.
        $view = \dirname(__DIR__, 2) . '/views/admin/settings.php';
        if (\is_readable($view)) {
            // Make Settings API callbacks available inside the view
            $screen_slug = 'b360_bridge';
            include $view;
            return;
        }

        // Fallback (should not be needed if view exists)
        echo '<div class="wrap">';
        echo '<h1>' . \esc_html__('Bottle360 Bridge Settings', 'b360-bridge') . '</h1>';
        echo '<form action="options.php" method="post">';
        \settings_fields('b360_bridge');
        \do_settings_sections('b360_bridge');
        \submit_button();
        echo '</form>';
        echo '</div>';
    }

    public function field_tenant(): void {
        $val = \esc_attr(Options::get_tenant());
        echo '<input type="text" name="' . \esc_attr(Options::OPT_TENANT) . '" value="' . $val . '" class="regular-text" placeholder="your-tenant" />';
        echo '<p class="description">' .
            \esc_html__('Example result: https://your-tenant.bottlethreesixty.{tld}', 'b360-bridge') .
        '</p>';
    }

    public function field_tld(): void {
        $current = Options::get_tld();
        $choices = ['com' => '.com', 'net' => '.net', 'dev' => '.dev'];

        echo '<select name="' . \esc_attr(Options::OPT_TLD) . '">';
        foreach ($choices as $value => $label) {
            printf(
                '<option value="%s"%s>%s</option>',
                \esc_attr($value),
                \selected($current, $value, false),
                \esc_html($label)
            );
        }
        echo '</select>';
        echo '<p class="description">' .
            \esc_html__('Select the environment TLD. Combined with the tenant to form the base URL.', 'b360-bridge') .
        '</p>';
    }

    public function field_disable_cache(): void {
        $checked = Options::is_cache_disabled() ? 'checked' : '';
        echo '<label><input type="checkbox" name="' . \esc_attr(Options::OPT_DISABLE_CACHE) . '" value="1" ' . $checked . ' /> ';
        echo \esc_html__('Bypass transients or local caches where applicable (useful during development).', 'b360-bridge') . '</label>';
    }

    public function field_debug(): void {
        $checked = Options::is_debug_enabled() ? 'checked' : '';
        echo '<label><input type="checkbox" name="' . \esc_attr(Options::OPT_DEBUG) . '" value="1" ' . $checked . ' /> ';
        echo \esc_html__('Enable extra logging/notices for troubleshooting.', 'b360-bridge') . '</label>';
    }

    // ---------------- Sanitizers ----------------

    public function sanitize_tenant($value): string {
        $value = \sanitize_text_field((string) $value);
        $value = \strtolower(\preg_replace('/[^a-z0-9-]/', '', $value));
        return $value;
    }

    public function sanitize_tld($value): string {
        $v = \strtolower(\sanitize_text_field((string) $value));
        return \in_array($v, ['com','net','dev'], true) ? $v : 'dev';
    }

    public function sanitize_bool($value): bool {
        return (bool) $value;
    }
}
