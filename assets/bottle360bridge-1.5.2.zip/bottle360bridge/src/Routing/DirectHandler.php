<?php
namespace Bottle360\Bridge\Rewrite;

if (!defined('ABSPATH')) exit;

/**
 * Serves the Products page for category routes and product detail.
 * Localizes B360Route.storeBase to .../b360-category.
 * Clubs flow remains untouched (plus rescue for pretty club-detail paths).
 */
final class DirectHandler
{
    public static function init(): void {
        add_action('template_redirect',   [__CLASS__, 'bootstrap']);
        add_filter('body_class',          [__CLASS__, 'bodyClass']);
        add_action('wp_enqueue_scripts',  [__CLASS__, 'localizeStoreRoute'], 20);
    }

    public static function bodyClass(array $classes): array {
        if ((int) get_query_var('b360_is_store') === 1) $classes[] = 'b360-store-listing';
        if (get_query_var('b360_path'))                 $classes[] = 'b360-product-detail';
        if (get_query_var('b360_club_detail'))          $classes[] = 'b360-club-detail';
        return $classes;
    }

    public static function bootstrap(): void
    {
        // --- Rescue pretty Club Detail URLs: /<clubs-page>/<club-slug> ---
        // If rewrites didn't set b360_club_detail for pretty paths, swap to the clubs page
        // and mark as a non-404 so the shortcode + JS can load the detail via slug.
        self::rescueClubDetailFromPath();

        // Serve Products page for listing/category/product-detail
        if ((int) get_query_var('b360_is_store') === 1 || get_query_var('b360_path')) {
            $page_id = self::findProductsPageId();
            if ($page_id) self::applyPage($page_id);
        }

        // Serve Clubs page for club routes (unchanged)
        if (get_query_var('b360_club_detail') || get_query_var('b360_club_join') ||
            get_query_var('b360_club_address') || get_query_var('b360_club_confirmation')) {
            $club_id = self::findClubsPageId();
            if ($club_id) self::applyPage($club_id);
        }
    }

    public static function localizeStoreRoute(): void
    {
        if ((int) get_query_var('b360_is_store') !== 1 && !get_query_var('b360_path')) return;

        $category = sanitize_title(get_query_var('b360_category', ''));
        $prod_id  = self::findProductsPageId();
        $is_front = $prod_id && (get_option('show_on_front') === 'page') && ((int) get_option('page_on_front') === (int) $prod_id);

        $base = $is_front
            ? rtrim(home_url('/b360-category'), '/')
            : rtrim(trailingslashit(get_permalink($prod_id)) . 'b360-category', '/');

        $payload = [
            'category'  => $category,
            'storeBase' => $base, // e.g. https://site.com/store/b360-category OR https://site.com/b360-category
        ];

        if (wp_script_is('b360-bridge', 'registered') || wp_script_is('b360-bridge', 'enqueued')) {
            wp_localize_script('b360-bridge', 'B360Route', $payload);
        }
        if (wp_script_is('b360-categories', 'registered') || wp_script_is('b360-categories', 'enqueued')) {
            wp_localize_script('b360-categories', 'B360Route', $payload);
        }
    }

    // -------- helpers --------

    /**
     * If the current request looks like /<clubs-page>/<club-slug> (not /page/N or join subroutes),
     * force WordPress to render the Clubs page and mark it as a non-404, so the
     * shortcode and JS can fetch the detail via the slug from the path.
     */
    private static function rescueClubDetailFromPath(): void
    {
        // Already handled via query vars? nothing to do.
        if (get_query_var('b360_club_detail') || get_query_var('b360_club_join') ||
            get_query_var('b360_club_address') || get_query_var('b360_club_confirmation')) {
            return;
        }

        $clubs_id = self::findClubsPageId();
        if (!$clubs_id) return;

        $base_url  = get_permalink($clubs_id);
        if (!$base_url) return;

        $base_path = '/' . trim((string) parse_url($base_url, PHP_URL_PATH), '/'); // e.g. "/clubs"
        $req_path  = '/' . trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');

        // Exact base → it's the listing, not a detail
        if ($req_path === $base_path) return;

        // Must live under the clubs base
        $prefix = rtrim($base_path, '/') . '/';
        if (strpos($req_path, $prefix) !== 0) return;

        // Remainder after the base (candidate slug or subroute)
        $rest  = trim(substr($req_path, strlen($prefix)), '/');
        if ($rest === '') return;

        $parts = array_values(array_filter(explode('/', $rest), 'strlen'));
        if (empty($parts)) return;

        // Ignore pagination and known special subroutes
        $first = strtolower($parts[0]);
        if ($first === 'page' || $first === 'join-club' || $first === 'join-club-address' || $first === 'join-club-confirmation') {
            return;
        }

        // Looks like a club slug under the clubs page → serve the Clubs page
        self::applyPage($clubs_id);

        // Mark as club detail for downstream logic (e.g., body_class)
        if (function_exists('set_query_var')) {
            set_query_var('b360_club_detail', 1);
        } else {
            global $wp_query;
            if (isset($wp_query) && is_object($wp_query)) {
                $wp_query->set('b360_club_detail', 1);
            }
        }

        // Clear 404 and send 200 OK
        global $wp_query;
        if (isset($wp_query)) {
            $wp_query->is_404 = false;
        }
        status_header(200);
    }

    private static function findProductsPageId(): int {
        $pinned = (int) get_option('b360_products_page_id', 0);
        if ($pinned) {
            $p = get_post($pinned);
            if ($p && $p->post_type === 'page' && $p->post_status === 'publish') return (int) $p->ID;
        }
        $pages = get_posts(['post_type'=>'page','post_status'=>'publish','posts_per_page'=>-1]);
        foreach ($pages as $p) {
            $c = (string) $p->post_content;
            if (has_shortcode($c, 'b360_products') || has_shortcode($c, 'b360-products')) return (int) $p->ID;
        }
        return 0;
    }

    private static function findClubsPageId(): int {
        $pinned = (int) get_option('b360_club_page_id', 0);
        if ($pinned) {
            $p = get_post($pinned);
            if ($p && $p->post_type === 'page' && $p->post_status === 'publish') return (int) $p->ID;
        }
        $pages = get_posts(['post_type'=>'page','post_status'=>'publish','posts_per_page'=>-1]);
        foreach ($pages as $p) {
            $c = (string) $p->post_content;
            if (has_shortcode($c, 'b360_club') || has_shortcode($c, 'b360-club')) return (int) $p->ID;
        }
        return 0;
    }

    private static function applyPage(int $page_id): void
    {
        global $wp_query, $post;

        $page_post = get_post($page_id);
        if (!$page_post) return;

        $wp_query->is_singular   = true;
        $wp_query->is_page       = true;
        $wp_query->is_archive    = false;
        $wp_query->is_home       = false;

        $isFront = (get_option('show_on_front') === 'page') && ((int) get_option('page_on_front') === (int) $page_post->ID);
        $wp_query->is_front_page = $isFront;

        $wp_query->queried_object    = $page_post;
        $wp_query->queried_object_id = $page_post->ID;
        $wp_query->posts             = [$page_post];
        $wp_query->post              = $page_post;

        $post = $page_post;
        setup_postdata($post);
    }
}

DirectHandler::init();
