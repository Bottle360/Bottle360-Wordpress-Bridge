<?php
namespace Bottle360\Bridge\Updates;

if (!defined('ABSPATH')) exit;

final class Updater
{
    public static function init(): void
    {
        if (!is_admin()) return;

        $hasV5 = class_exists('\YahnisElsts\PluginUpdateChecker\v5\PucFactory');
        $hasV4 = class_exists('\YahnisElsts\PluginUpdateChecker\v4\PucFactory');
        if (!$hasV5 && !$hasV4) return;

        $factory = $hasV5
            ? '\YahnisElsts\PluginUpdateChecker\v5\PucFactory'
            : '\YahnisElsts\PluginUpdateChecker\v4\PucFactory';

        // Default public repo (no client config needed)
        $repoUrl = apply_filters(
            'b360/updates/repo_url',
            'https://github.com/Bottle360/Bottle360-Wordpress-Bridge'
        );
        $branch  = apply_filters('b360/updates/branch', 'main');

        $pluginMain = dirname(__DIR__, 2) . '/b360-bridge.php'; // boot file
        $pluginSlug = 'bottle360bridge';                         // folder/slug

        /** @var \YahnisElsts\PluginUpdateChecker\v5p0\Plugin\UpdateChecker $checker */
        $checker = $factory::buildUpdateChecker($repoUrl, $pluginMain, $pluginSlug);

        if (method_exists($checker, 'setBranch')) {
            $checker->setBranch($branch);
        }
        if (method_exists($checker, 'getVcsApi') && $checker->getVcsApi()) {
            // Prefer GitHub Release assets over auto-generated source zips
            $checker->getVcsApi()->enableReleaseAssets();
        }

        add_filter('plugin_action_links_' . plugin_basename($pluginMain), static function (array $links) {
            $links[] = sprintf(
                '<a href="%s">%s</a>',
                esc_url(add_query_arg(['force-check' => 1], self_admin_url('update-core.php'))),
                esc_html__('Check for updates', 'b360-bridge')
            );
            return $links;
        });
    }
}
