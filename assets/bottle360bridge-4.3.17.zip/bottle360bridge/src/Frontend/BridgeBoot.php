<?php

namespace Bottle360\Bridge\Frontend;

use Bottle360\Bridge\Routing\SpaRoutes;
use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Support\Nonce;
use Bottle360\Bridge\Support\ViteAssets;

if (!defined('ABSPATH')) exit;

/**
 * Bootstraps the unified bridge Vue bundle on every front-end page.
 *
 * Responsibilities:
 *   - Emit window.B360Bridge config (REST URL, nonce, base path, route metadata)
 *   - Load the single bridge.ts bundle (renderBridgeTags is idempotent)
 *   - Emit the sidebar cart-drawer placeholder
 *
 * Page-scoped widgets (like the full SPA mount from [b360_app]) live in
 * their own shortcode classes and emit their own [data-b360-widget="..."]
 * placeholder divs — this class only wires up the one-time page bootstrap.
 *
 * Replaces the previous SidebarInjector class, which had a narrower
 * (sidebar-only) scope and tightly coupled the sidebar bundle to its own
 * Vite entry point.
 */
final class BridgeBoot
{
    public function register(): void
    {
        // Priority 5 so the bundle is defined before any late shortcode output.
        add_action('wp_footer', [$this, 'emit'], 5);
    }

    public function emit(): void
    {
        $basePath = Options::get_app_base_path();

        $config = wp_json_encode([
            'restUrl'  => esc_url_raw(rest_url('b360/v1/')),
            'nonce'    => Nonce::value(),
            'basePath' => $basePath,
            // Server-emitted page titles for client-side route transitions.
            // Consumed by frontend/router/index.ts to build titleMap. The
            // nav active-state map used to live here too; BridgeNav.vue now
            // derives active state directly from the route table.
            'routes'   => [
                'titles' => SpaRoutes::titles(),
            ],
        ]);

        echo '<script>window.B360Bridge = ' . $config . ';</script>' . "\n";

        // Sidebar cart-drawer placeholder — teleport target for SidebarApp.vue.
        echo '<div data-b360-widget="sidebar" data-base-path="'
            . esc_attr($basePath) . '"></div>' . "\n";

        echo ViteAssets::renderBridgeTags() . "\n";
    }
}
