<?php

namespace Bottle360\Bridge\Shortcodes;

use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * [b360_app] — emits the placeholder that the unified bridge bundle
 * teleports the full Vue SPA into.
 *
 * The bundle itself is loaded unconditionally by Frontend\BridgeBoot on
 * every front-end page, so this shortcode only needs to mark up the
 * mount point and flag the page so theme CSS can adapt.
 */
final class AppShortcode
{
    public function register(): void
    {
        add_shortcode('b360_app', [$this, 'render']);
    }

    public function render($atts): string
    {
        // Flag the page so theme / plugin CSS can target storefront pages.
        // Guarded with a static so repeated shortcode calls on the same
        // request don't pile up filter callbacks.
        static $flagged = false;
        if (!$flagged) {
            $flagged = true;
            add_filter('body_class', static function (array $classes): array {
                $classes[] = 'b360-app-active';
                $classes[] = 'b360-has-storefront';
                return $classes;
            });
        }

        $basePath = Options::get_app_base_path();

        return
            // Inline CSS to beat WP theme defaults (title, large margins)
            // before the bundle has a chance to mount.
              '<style>'
            .   file_get_contents(__DIR__ . '/app-shortcode.css')
            . '</style>'

            . '<div class="b360-app"'
            . ' data-b360-widget="app"'
            . ' data-base-path="' . esc_attr($basePath) . '"'
            . '>'
            // Pre-mount spinner; Root.vue clears innerHTML before teleport.
            . file_get_contents(__DIR__ . '/app-spinner.html')
            . '</div>';
    }
}
