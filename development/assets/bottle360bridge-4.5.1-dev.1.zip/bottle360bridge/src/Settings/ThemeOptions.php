<?php

namespace Bottle360\Bridge\Settings;

if (!defined('ABSPATH')) exit;

/**
 * V2 Bridge theme options. Stores a full BridgeThemeV2-shaped array
 * under the `b360_theme_v2` WP option. The legacy V1 option key
 * (`b360_theme`) is deleted on activation — see Lifecycle\Activator.
 */
final class ThemeOptions
{
    const OPTION_KEY     = 'b360_theme_v2';
    const SCHEMA_VERSION = 2;

    public static function defaults()
    {
        return [
            'name'    => 'Estate Default',
            'version' => 2,
            'colors'  => [
                'brandPrimary'          => '#1A2438',
                'brandSecondary'        => '#7C5C3C',
                'brandAccent'           => '#8B6F47',
                'brandAccentFade'       => '#C9A876',
                'actionPrimary'         => '#7A1730',
                'actionPrimaryHover'    => '#641226',
                'actionPrimaryText'     => '#FFFFFF',
                'actionSecondary'       => '#FFFFFF',
                'actionSecondaryText'   => '#1A2438',
                'linkText'              => '#1A2438',
                'surfacePage'           => '#FAF8F3',
                'surfaceCard'           => '#FFFFFF',
                'surfaceElevated'       => '#F7F4ED',
                'surfaceMuted'          => '#F3EEE8',
                'surfaceInverse'        => '#1A2438',
                'surfaceDisabled'       => '#F1EFE8',
                'textPrimary'           => '#171717',
                'textSecondary'         => '#4F4A45',
                'textMuted'             => '#6B6660',
                'textSubtle'            => '#8C867E',
                'textOnInverse'         => '#FFFFFF',
                'textOnInverseMuted'    => 'rgba(255,255,255,0.68)',
                'textAccent'            => '#8B6F47',
                'borderSubtle'          => '#EAE5D9',
                'borderStrong'          => '#CFC2B5',
                'borderFocus'           => '#8B6F47',
                'divider'               => '#E9E4DE',
                'selectedSurface'       => '#FFF7F8',
                'selectedBorder'        => '#7A1730',
                'focusRing'             => 'rgba(122, 23, 48, 0.18)',
                'success'               => '#2E7D32',
                'successSoft'           => '#EAF4EC',
                'successText'           => '#FFFFFF',
                'warning'               => '#8A6B0F',
                'warningSoft'           => '#F7EED2',
                'warningText'           => '#FFFFFF',
                'error'                 => '#B03A2E',
                'errorSoft'             => '#F8E7E4',
                'errorText'             => '#FFFFFF',
                'info'                  => '#1A4A7A',
                'infoSoft'              => '#E8F0FA',
                'infoText'              => '#FFFFFF',
                'priceText'             => '#171717',
                'discountText'          => '#2E7D32',
                'surfaceInverseOverlay' => 'rgba(0,0,0,0.18)',
                'borderOnInverse'       => 'rgba(255,255,255,0.14)',
            ],
            'typography' => [
                'fontSans'      => 'inherit',
                'fontSerif'     => 'Georgia, Cambria, "Times New Roman", serif',
                'fontMono'      => 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                'bodyWeight'    => 400,
                'labelWeight'   => 600,
                'headingWeight' => 650,
                'titleWeight'   => 700,
                'headingTransform'     => 'none',
                'headingLetterSpacing' => 'normal',
            ],
            'density' => 'default',
            'radius'  => [
                'xs'      => '4px',
                'sm'      => '6px',
                'control' => '10px',
                'card'    => '14px',
                'panel'   => '18px',
                'pill'    => '999px',
            ],
            'shadow' => [
                'none'    => 'none',
                'sm'      => '0 1px 2px rgba(23, 23, 23, 0.06), 0 6px 16px rgba(23, 23, 23, 0.04)',
                'md'      => '0 2px 6px rgba(23, 23, 23, 0.08), 0 12px 32px rgba(23, 23, 23, 0.06)',
                'lg'      => '0 8px 24px rgba(23, 23, 23, 0.10), 0 20px 56px rgba(23, 23, 23, 0.08)',
                'overlay' => '0 8px 24px -8px rgba(26, 36, 56, 0.18)',
            ],
            'widths' => [
                'form'            => '520px',
                'reading'         => '720px',
                'content'         => '960px',
                'account'         => '1120px',
                'wide'            => '1180px',
                'store'           => '1280px',
                'checkout'        => '1200px',
                'studio'          => '1440px',
                'readableMeasure' => '68ch',
            ],
            'components' => [
                'button' => [
                    'textTransform' => 'none',
                    'letterSpacing' => 'normal',
                ],
                'productCard' => [
                    'actionsLayout' => 'inline',
                    'showTeaser'    => false,
                    'showBuyCase'   => false,
                    'showQty'       => false,
                    'showCasePrice' => false,
                ],
                'surfaces' => [
                    'card'        => ['border' => true,  'shadow' => 'sm'],
                    'elevated'    => ['border' => true,  'shadow' => 'md'],
                    'productCard' => ['border' => false, 'shadow' => 'sm'],
                ],
                'tabs' => [
                    'indicator'          => 'scale-center',
                    'indicatorThickness' => 3,
                    'indicatorColor'     => null,
                    'indicatorRadius'    => 'rounded',
                    'overflow'           => 'scroll',
                ],
                'storeListing' => [
                    'categoryHeader'          => 'page-title',
                    'showCategoryDescription' => true,
                    'lockedCategoryTreatment' => 'inline-banner',
                ],
                'loyalty' => [
                    'showEarnOnCatalog' => false,
                    'showEarnOnDetail'  => false,
                ],
            ],
            'assets' => [
                'checkoutLogoUrl'     => '',
                'checkoutLogoLinkUrl' => '',
            ],
            'motion' => [
                'intensity'          => null,
                'reducedMotion'      => null,
                'routeTransition'    => null,
                'loadingStyle'       => null,
                'celebrationsEnabled' => null,
                'baseDuration'       => null,
            ],
            '_overrides'               => [],
            '_appliedVibeId'           => null,
            '_appliedTypographyPairId' => null,
        ];
    }

    public static function get()
    {
        $stored = get_option(self::OPTION_KEY, []);
        if (!is_array($stored)) $stored = [];
        return self::deep_merge(self::defaults(), $stored);
    }

    public static function save(array $input)
    {
        $sanitized = self::sanitize($input);
        $merged    = self::deep_merge(self::defaults(), $sanitized);
        update_option(self::OPTION_KEY, $merged, false);
        return $merged;
    }

    public static function reset()
    {
        delete_option(self::OPTION_KEY);
        return self::defaults();
    }

    /** Sanitise a partial BridgeThemeV2 payload. Unknown keys are dropped. */
    private static function sanitize(array $input)
    {
        $out = [];

        if (isset($input['name']) && is_string($input['name'])) {
            $out['name'] = sanitize_text_field(substr($input['name'], 0, 80));
        }

        if (isset($input['colors']) && is_array($input['colors'])) {
            $colors = [];
            foreach ($input['colors'] as $k => $v) {
                if (!is_string($v)) continue;
                $clean = self::sanitize_color_value($v);
                if ($clean !== null) $colors[$k] = $clean;
            }
            if (!empty($colors)) $out['colors'] = $colors;
        }

        if (isset($input['typography']) && is_array($input['typography'])) {
            $typo = [];
            $string_keys = ['fontSans', 'fontSerif', 'fontMono'];
            foreach ($string_keys as $k) {
                if (isset($input['typography'][$k]) && is_string($input['typography'][$k])) {
                    $typo[$k] = self::sanitize_font_stack($input['typography'][$k]);
                }
            }
            $int_keys = ['bodyWeight', 'labelWeight', 'headingWeight', 'titleWeight'];
            foreach ($int_keys as $k) {
                if (isset($input['typography'][$k])) {
                    $typo[$k] = max(100, min(900, (int) $input['typography'][$k]));
                }
            }
            // Heading-only display traits — strict enums (readability-bounded).
            $enum_keys = [
                'headingTransform'     => ['none', 'uppercase', 'lowercase', 'capitalize'],
                'headingLetterSpacing' => ['normal', 'tight', 'wide', 'wider', 'widest'],
            ];
            foreach ($enum_keys as $k => $allowed) {
                if (isset($input['typography'][$k]) && in_array($input['typography'][$k], $allowed, true)) {
                    $typo[$k] = $input['typography'][$k];
                }
            }
            if (!empty($typo)) $out['typography'] = $typo;
        }

        if (isset($input['density']) && in_array($input['density'], ['compact', 'default', 'airy'], true)) {
            $out['density'] = $input['density'];
        }

        if (isset($input['radius']) && is_array($input['radius'])) {
            $radius = [];
            foreach (['xs', 'sm', 'control', 'card', 'panel', 'pill'] as $k) {
                if (isset($input['radius'][$k]) && is_string($input['radius'][$k])) {
                    $radius[$k] = self::sanitize_length($input['radius'][$k]);
                }
            }
            if (!empty($radius)) $out['radius'] = $radius;
        }

        if (isset($input['shadow']) && is_array($input['shadow'])) {
            $shadow = [];
            foreach (['none', 'sm', 'md', 'lg', 'overlay'] as $k) {
                if (isset($input['shadow'][$k]) && is_string($input['shadow'][$k])) {
                    $shadow[$k] = sanitize_text_field(substr($input['shadow'][$k], 0, 240));
                }
            }
            if (!empty($shadow)) $out['shadow'] = $shadow;
        }

        if (isset($input['widths']) && is_array($input['widths'])) {
            $widths = [];
            foreach (['form', 'reading', 'content', 'account', 'wide', 'store', 'checkout', 'studio', 'readableMeasure'] as $k) {
                if (isset($input['widths'][$k]) && is_string($input['widths'][$k])) {
                    $widths[$k] = self::sanitize_length($input['widths'][$k]);
                }
            }
            if (!empty($widths)) $out['widths'] = $widths;
        }

        if (isset($input['components']) && is_array($input['components'])) {
            $comp = [];
            if (isset($input['components']['button']) && is_array($input['components']['button'])) {
                $bt = $input['components']['button'];
                $cleanBt = [];
                if (isset($bt['textTransform']) && in_array($bt['textTransform'], ['none', 'uppercase'], true)) {
                    $cleanBt['textTransform'] = $bt['textTransform'];
                }
                if (isset($bt['letterSpacing']) && in_array($bt['letterSpacing'], ['normal', 'wide', 'wider'], true)) {
                    $cleanBt['letterSpacing'] = $bt['letterSpacing'];
                }
                if (!empty($cleanBt)) $comp['button'] = $cleanBt;
            }
            if (isset($input['components']['productCard']) && is_array($input['components']['productCard'])) {
                $pc = $input['components']['productCard'];
                $cleanPc = [];
                if (isset($pc['actionsLayout']) && in_array($pc['actionsLayout'], ['inline', 'hover'], true)) {
                    $cleanPc['actionsLayout'] = $pc['actionsLayout'];
                }
                if (isset($pc['showTeaser']))    $cleanPc['showTeaser']    = (bool) $pc['showTeaser'];
                if (isset($pc['showBuyCase']))   $cleanPc['showBuyCase']   = (bool) $pc['showBuyCase'];
                if (isset($pc['showQty']))       $cleanPc['showQty']       = (bool) $pc['showQty'];
                if (isset($pc['showCasePrice'])) $cleanPc['showCasePrice'] = (bool) $pc['showCasePrice'];
                if (!empty($cleanPc)) $comp['productCard'] = $cleanPc;
            }
            if (isset($input['components']['surfaces']) && is_array($input['components']['surfaces'])) {
                $cleanSurfaces = [];
                foreach (['card', 'elevated', 'productCard'] as $family) {
                    if (!isset($input['components']['surfaces'][$family]) || !is_array($input['components']['surfaces'][$family])) {
                        continue;
                    }
                    $fam   = $input['components']['surfaces'][$family];
                    $clean = [];
                    if (isset($fam['border'])) {
                        $clean['border'] = (bool) $fam['border'];
                    }
                    if (isset($fam['shadow']) && in_array($fam['shadow'], ['none', 'sm', 'md', 'lg'], true)) {
                        $clean['shadow'] = $fam['shadow'];
                    }
                    if (!empty($clean)) $cleanSurfaces[$family] = $clean;
                }
                if (!empty($cleanSurfaces)) $comp['surfaces'] = $cleanSurfaces;
            }
            if (isset($input['components']['tabs']) && is_array($input['components']['tabs'])) {
                $tb = $input['components']['tabs'];
                $cleanTb = [];
                if (isset($tb['indicator']) && in_array($tb['indicator'], ['scale-center', 'slide', 'fade', 'none'], true)) {
                    $cleanTb['indicator'] = $tb['indicator'];
                }
                if (isset($tb['indicatorThickness'])) {
                    $cleanTb['indicatorThickness'] = max(2, min(5, (int) $tb['indicatorThickness']));
                }
                if (array_key_exists('indicatorColor', $tb)) {
                    if ($tb['indicatorColor'] === null || $tb['indicatorColor'] === '') {
                        $cleanTb['indicatorColor'] = null;
                    } elseif (is_string($tb['indicatorColor'])) {
                        $clean = self::sanitize_color_value($tb['indicatorColor']);
                        if ($clean !== null) $cleanTb['indicatorColor'] = $clean;
                    }
                }
                if (isset($tb['indicatorRadius']) && in_array($tb['indicatorRadius'], ['flat', 'rounded', 'capsule'], true)) {
                    $cleanTb['indicatorRadius'] = $tb['indicatorRadius'];
                }
                if (isset($tb['overflow']) && in_array($tb['overflow'], ['scroll', 'wrap'], true)) {
                    $cleanTb['overflow'] = $tb['overflow'];
                }
                if (array_key_exists('animationDuration', $tb)) {
                    if ($tb['animationDuration'] === null || $tb['animationDuration'] === '') {
                        $cleanTb['animationDuration'] = null;
                    } elseif (in_array($tb['animationDuration'], ['150ms', '280ms', '400ms'], true)) {
                        $cleanTb['animationDuration'] = $tb['animationDuration'];
                    }
                }
                if (!empty($cleanTb)) $comp['tabs'] = $cleanTb;
            }
            if (isset($input['components']['storeListing']) && is_array($input['components']['storeListing'])) {
                $sl = $input['components']['storeListing'];
                $cleanSl = [];
                if (isset($sl['categoryHeader']) && in_array($sl['categoryHeader'], ['page-title', 'compact', 'hidden', 'with-lock-banner'], true)) {
                    $cleanSl['categoryHeader'] = $sl['categoryHeader'];
                }
                if (isset($sl['showCategoryDescription'])) {
                    $cleanSl['showCategoryDescription'] = (bool) $sl['showCategoryDescription'];
                }
                if (isset($sl['lockedCategoryTreatment']) && in_array($sl['lockedCategoryTreatment'], ['inline-banner', 'icon-only', 'redirect'], true)) {
                    $cleanSl['lockedCategoryTreatment'] = $sl['lockedCategoryTreatment'];
                }
                if (!empty($cleanSl)) $comp['storeListing'] = $cleanSl;
            }
            if (isset($input['components']['loyalty']) && is_array($input['components']['loyalty'])) {
                $ly = $input['components']['loyalty'];
                $cleanLy = [];
                if (isset($ly['showEarnOnCatalog'])) {
                    $cleanLy['showEarnOnCatalog'] = (bool) $ly['showEarnOnCatalog'];
                }
                if (isset($ly['showEarnOnDetail'])) {
                    $cleanLy['showEarnOnDetail'] = (bool) $ly['showEarnOnDetail'];
                }
                if (!empty($cleanLy)) $comp['loyalty'] = $cleanLy;
            }
            if (!empty($comp)) $out['components'] = $comp;
        }

        if (isset($input['assets']) && is_array($input['assets'])) {
            $assets = [];
            if (isset($input['assets']['checkoutLogoUrl']) && is_string($input['assets']['checkoutLogoUrl'])) {
                $url = esc_url_raw(trim($input['assets']['checkoutLogoUrl']));
                if ($url !== '' || $input['assets']['checkoutLogoUrl'] === '') $assets['checkoutLogoUrl'] = $url;
            }
            if (isset($input['assets']['checkoutLogoLinkUrl']) && is_string($input['assets']['checkoutLogoLinkUrl'])) {
                $url = esc_url_raw(trim($input['assets']['checkoutLogoLinkUrl']));
                if ($url !== '' || $input['assets']['checkoutLogoLinkUrl'] === '') $assets['checkoutLogoLinkUrl'] = $url;
            }
            if (!empty($assets)) $out['assets'] = $assets;
        }

        if (isset($input['motion']) && is_array($input['motion'])) {
            $out['motion'] = self::sanitize_motion($input['motion']);
        }

        if (isset($input['_overrides']) && is_array($input['_overrides'])) {
            $overrides = [];
            foreach ($input['_overrides'] as $key) {
                if (is_string($key) && preg_match('/^[a-zA-Z][a-zA-Z0-9_]{0,40}$/', $key)) {
                    $overrides[] = $key;
                }
            }
            $out['_overrides'] = array_values(array_unique($overrides));
        }

        // Applied vibe / typography pair ids — short kebab-ish identifiers
        // stamped by the frontend when the user clicks a preset card. Either
        // a string up to 64 chars matching [a-z0-9-_], or null.
        if (array_key_exists('_appliedVibeId', $input)) {
            $out['_appliedVibeId'] = self::sanitize_preset_id($input['_appliedVibeId']);
        }
        if (array_key_exists('_appliedTypographyPairId', $input)) {
            $out['_appliedTypographyPairId'] = self::sanitize_preset_id($input['_appliedTypographyPairId']);
        }

        return $out;
    }

    /**
     * Sanitize the motion block. Unknown keys are silently dropped.
     * All fields default to null (omit-when-unset pattern).
     *
     * @param array $m
     * @return array
     */
    private static function sanitize_motion(array $m)
    {
        $out = [];

        if (array_key_exists('intensity', $m)) {
            if ($m['intensity'] === null || $m['intensity'] === '') {
                $out['intensity'] = null;
            } elseif (in_array($m['intensity'], ['calm', 'standard', 'lively'], true)) {
                $out['intensity'] = $m['intensity'];
            }
        }

        if (array_key_exists('reducedMotion', $m)) {
            if ($m['reducedMotion'] === null || $m['reducedMotion'] === '') {
                $out['reducedMotion'] = null;
            } elseif (in_array($m['reducedMotion'], ['respect-system', 'always-on', 'always-off'], true)) {
                $out['reducedMotion'] = $m['reducedMotion'];
            }
        }

        if (array_key_exists('routeTransition', $m)) {
            if ($m['routeTransition'] === null || $m['routeTransition'] === '') {
                $out['routeTransition'] = null;
            } elseif (in_array($m['routeTransition'], ['fade', 'slide', 'crossfade', 'none'], true)) {
                $out['routeTransition'] = $m['routeTransition'];
            }
        }

        if (array_key_exists('loadingStyle', $m)) {
            if ($m['loadingStyle'] === null || $m['loadingStyle'] === '') {
                $out['loadingStyle'] = null;
            } elseif (in_array($m['loadingStyle'], ['skeleton', 'spinner', 'inline-shimmer'], true)) {
                $out['loadingStyle'] = $m['loadingStyle'];
            }
        }

        if (array_key_exists('celebrationsEnabled', $m)) {
            if ($m['celebrationsEnabled'] === null) {
                $out['celebrationsEnabled'] = null;
            } else {
                $out['celebrationsEnabled'] = (bool) $m['celebrationsEnabled'];
            }
        }

        if (array_key_exists('baseDuration', $m)) {
            if ($m['baseDuration'] === null || $m['baseDuration'] === '') {
                $out['baseDuration'] = null;
            } else {
                $val = (int) $m['baseDuration'];
                if ($val >= 160 && $val <= 560) {
                    $out['baseDuration'] = $val;
                }
            }
        }

        return $out;
    }

    /**
     * Accept a kebab-case-ish preset id (a–z, 0–9, -, _) up to 64 chars,
     * or null. Anything else collapses to null.
     *
     * @param mixed $v
     * @return string|null
     */
    private static function sanitize_preset_id($v)
    {
        if ($v === null || $v === '') return null;
        if (!is_string($v)) return null;
        if (strlen($v) > 64) return null;
        if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $v)) return null;
        return $v;
    }

    /** Accept #RGB, #RRGGBB, rgb(...), rgba(...). Returns null when invalid. */
    private static function sanitize_color_value($v)
    {
        $v = trim((string) $v);
        if (preg_match('/^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/', $v)) {
            return $v;
        }
        if (preg_match('/^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(?:,\s*(?:0|1|0?\.\d+)\s*)?\)$/', $v)) {
            return $v;
        }
        return null;
    }

    /** Trim and bound a font stack to 240 chars; strip control characters. */
    private static function sanitize_font_stack($v)
    {
        $v = preg_replace('/[\x00-\x1F\x7F]/', '', (string) $v);
        return sanitize_text_field(substr($v, 0, 240));
    }

    /** Accept CSS length-like values (number+unit, ch, %, vw, vh, calc(...)). */
    private static function sanitize_length($v)
    {
        $v = trim((string) $v);
        if ($v === '') return '';
        if (strlen($v) > 64) $v = substr($v, 0, 64);
        // Permissive: anything sanitize_text_field accepts that looks like a length.
        if (preg_match('/^[0-9a-zA-Z\s\.\,\-\+\*\/\(\)%]+$/', $v)) {
            return $v;
        }
        return '';
    }

    private static function deep_merge(array $base, array $overlay)
    {
        foreach ($overlay as $k => $v) {
            if (is_array($v) && isset($base[$k]) && is_array($base[$k])) {
                $base[$k] = self::deep_merge($base[$k], $v);
            } else {
                $base[$k] = $v;
            }
        }
        return $base;
    }
}
