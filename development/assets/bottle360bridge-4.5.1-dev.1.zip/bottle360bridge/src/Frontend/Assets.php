<?php

namespace Bottle360\Bridge\Frontend;

if (!defined('ABSPATH')) exit;

/**
 * Server-side CSS-var emission for the V2 Bridge theme.
 *
 * Mirrors frontend/theme/cssVars.ts so the storefront paints with the
 * correct tokens before the Vue bundle boots and re-applies them.
 * Variables are scoped to .b360-bridge-root, .v-overlay-container,
 * and .b360-nav — never :root.
 */
final class Assets
{
    /**
     * Intensity preset map — mirrors INTENSITY_PRESETS in motionPresets.ts.
     * fast / base / slow values in ms.
     *
     * @var array
     */
    private static $INTENSITY_PRESETS = array(
        'calm'     => array('fast' => 130, 'base' => 240, 'slow' => 360),
        'standard' => array('fast' => 160, 'base' => 280, 'slow' => 420),
        'lively'   => array('fast' => 190, 'base' => 320, 'slow' => 480),
    );

    public function register()
    {
        add_action('wp_enqueue_scripts', [$this, 'registerStyles']);
        add_action('wp_head', [$this, 'emitThemeVars'], 1);
    }

    public function registerStyles()
    {
        // Navigation shortcode [b360_nav] — tokens now come from emitThemeVars
        // (no separate b360-tokens.css; it was V1-only and has been removed).
        wp_register_style(
            'b360-nav',
            plugins_url('assets/css/b360-nav.css', B360_BRIDGE_FILE),
            [],
            $this->version('assets/css/b360-nav.css')
        );
    }

    private function version($relativePath)
    {
        $path = trailingslashit(B360_BRIDGE_DIR) . ltrim($relativePath, '/');
        if (file_exists($path)) {
            $mtime = filemtime($path);
            if ($mtime !== false) return (string) $mtime;
        }
        return B360_BRIDGE_VER;
    }

    public function emitThemeVars()
    {
        $theme   = \Bottle360\Bridge\Settings\ThemeOptions::get();
        $colors  = isset($theme['colors'])     ? $theme['colors']     : [];
        $typo    = isset($theme['typography']) ? $theme['typography'] : [];
        $radius  = isset($theme['radius'])     ? $theme['radius']     : [];
        $shadow  = isset($theme['shadow'])     ? $theme['shadow']     : [];
        $widths  = isset($theme['widths'])     ? $theme['widths']     : [];
        $tabs    = isset($theme['components']['tabs']) ? $theme['components']['tabs'] : [];
        $button  = isset($theme['components']['button']) ? $theme['components']['button'] : [];
        $surfaces = isset($theme['components']['surfaces']) ? $theme['components']['surfaces'] : [];
        $motion  = isset($theme['motion']) && is_array($theme['motion']) ? $theme['motion'] : [];

        echo '<script>window.B360_THEME = ' . wp_json_encode($theme) . ';</script>' . "\n";
        echo '<style id="b360-theme-vars">.b360-bridge-root, .v-overlay-container, .b360-nav {' . "\n";
        echo self::cssVarLines($colors, $typo, $radius, $shadow, $widths, $tabs, $button, $surfaces);
        echo self::motionVarLines($motion);
        echo "  color: var(--b360-text-primary);\n";
        echo "  background: transparent;\n";
        echo "  font-family: var(--b360-font-sans);\n";
        echo '}' . "\n";
        // Cart-pill FOUC cloak. This rule lives in the SYNCHRONOUS, render-
        // blocking inline head block so it is present before the nav first
        // paints. The server-rendered cart <li> (NavShortcode::renderCartButton)
        // would otherwise flash with browser-default <button> styling on slow
        // loads — because b360-nav.css is enqueued during shortcode render
        // (after wp_head) and therefore prints late (footer), NOT render-
        // blocking in <head>. We hide the whole .b360-nav__item--cart <li>
        // (so its count badge is cloaked too) at opacity:0 from first paint,
        // then b360-nav.css reveals it (opacity:1) exactly when the pill
        // styling lands — co-loaded in the same stylesheet. opacity-only:
        // the <li> keeps its box, so there is NO layout shift; it still
        // participates in the desktop flex row and the mobile two-per-row grid.
        echo '.b360-nav .b360-nav__item--cart {' . "\n";
        echo "  opacity: 0;\n";
        echo "  transition: opacity var(--b360-motion-fast, 160ms) ease;\n";
        // Failsafe reveal: b360-nav.css normally un-cloaks the cart (opacity:1)
        // the moment its styling lands — but that stylesheet is enqueued late
        // (non-blocking) and could fail to load (404 / host CSP / caching
        // plugin). Without a backstop the cart pill — the primary buy CTA —
        // would stay invisible AND unclickable forever. A long-delayed keyframe
        // force-reveals it well after any realistic nav.css load, so the worst
        // case degrades to "unstyled but clickable" (the pre-cloak behaviour),
        // never "hidden". On the happy path nav.css reveals it far sooner and
        // this animation is a no-op (1→1).
        echo "  animation: b360-nav-cart-uncloak var(--b360-motion-fast, 160ms) ease 4s forwards;\n";
        echo '}' . "\n";
        echo '@keyframes b360-nav-cart-uncloak { to { opacity: 1; } }' . "\n";
        echo '</style>' . "\n";
    }

    /**
     * Emit motion CSS vars. Mirrors buildMotionVars() in cssVars.ts.
     *
     * @param array $m Motion block from theme options.
     * @return string
     */
    private static function motionVarLines(array $m)
    {
        if (empty($m)) return '';

        $out = '';

        // Duration vars: baseDuration overrides intensity; standard emits nothing.
        $baseDuration = isset($m['baseDuration']) ? $m['baseDuration'] : null;
        $intensity    = isset($m['intensity'])    ? $m['intensity']    : null;

        if ($baseDuration !== null && is_int($baseDuration)) {
            $fast = (int) round($baseDuration * 0.57);
            $slow = (int) round($baseDuration * 1.5);
            $out .= '  --b360-motion-fast: ' . $fast . "ms;\n";
            $out .= '  --b360-motion-base: ' . $baseDuration . "ms;\n";
            $out .= '  --b360-motion-slow: ' . $slow . "ms;\n";
        } elseif ($intensity !== null && $intensity !== 'standard' && isset(self::$INTENSITY_PRESETS[$intensity])) {
            $preset = self::$INTENSITY_PRESETS[$intensity];
            $out .= '  --b360-motion-fast: ' . $preset['fast'] . "ms;\n";
            $out .= '  --b360-motion-base: ' . $preset['base'] . "ms;\n";
            $out .= '  --b360-motion-slow: ' . $preset['slow'] . "ms;\n";
        }

        // Route transition — only emit when non-default (default is 'fade').
        $routeTransition = isset($m['routeTransition']) ? $m['routeTransition'] : null;
        if ($routeTransition !== null && $routeTransition !== 'fade') {
            $out .= '  --b360-route-transition: ' . self::escVar($routeTransition) . ";\n";
        }

        // Loading style — only emit when non-default (default is 'skeleton').
        $loadingStyle = isset($m['loadingStyle']) ? $m['loadingStyle'] : null;
        if ($loadingStyle !== null && $loadingStyle !== 'skeleton') {
            $out .= '  --b360-loading-style: ' . self::escVar($loadingStyle) . ";\n";
        }

        // Celebrations — only emit when explicitly disabled.
        $celebrationsEnabled = isset($m['celebrationsEnabled']) ? $m['celebrationsEnabled'] : null;
        if ($celebrationsEnabled === false) {
            $out .= "  --b360-celebrations: 0;\n";
        }

        // reducedMotion is a runtime gate — no CSS emission.

        return $out;
    }

    private static function cssVarLines(array $c, array $t, array $r, array $s, array $w, array $tabs, array $button, array $surfaces)
    {
        $tabsRadius = self::tabsIndicatorRadiusCss(isset($tabs['indicatorRadius']) ? $tabs['indicatorRadius'] : 'rounded');
        $tabsColor  = (isset($tabs['indicatorColor']) && $tabs['indicatorColor'])
            ? $tabs['indicatorColor']
            : 'var(--b360-action-primary)';
        $tabsThickness = isset($tabs['indicatorThickness']) ? (int) $tabs['indicatorThickness'] : 3;
        $tabsDuration  = isset($tabs['animationDuration']) ? $tabs['animationDuration'] : null;

        $lines = [
            // Brand
            ['--b360-brand-primary',         self::str($c, 'brandPrimary',    '#1A2438')],
            ['--b360-brand-secondary',       self::str($c, 'brandSecondary',  '#7C5C3C')],
            ['--b360-brand-accent',          self::str($c, 'brandAccent',     '#8B6F47')],
            ['--b360-brand-accent-fade',     self::str($c, 'brandAccentFade', '#C9A876')],
            // Action
            ['--b360-action-primary',        self::str($c, 'actionPrimary',       '#7A1730')],
            ['--b360-action-primary-hover',  self::str($c, 'actionPrimaryHover',  '#641226')],
            ['--b360-action-primary-text',   self::str($c, 'actionPrimaryText',   '#FFFFFF')],
            ['--b360-action-secondary',      self::str($c, 'actionSecondary',     '#FFFFFF')],
            ['--b360-action-secondary-text', self::str($c, 'actionSecondaryText', '#1A2438')],
            // Link
            ['--b360-link-text',             self::str($c, 'linkText', '#1A2438')],
            // Surfaces
            ['--b360-surface-page',          self::str($c, 'surfacePage',     '#FAF8F3')],
            ['--b360-surface-card',          self::str($c, 'surfaceCard',     '#FFFFFF')],
            ['--b360-surface-elevated',      self::str($c, 'surfaceElevated', '#F7F4ED')],
            ['--b360-surface-muted',         self::str($c, 'surfaceMuted',    '#F3EEE8')],
            ['--b360-surface-inverse',       self::str($c, 'surfaceInverse',  '#1A2438')],
            ['--b360-surface-disabled',      self::str($c, 'surfaceDisabled', '#F1EFE8')],
            // Text
            ['--b360-text-primary',          self::str($c, 'textPrimary',        '#171717')],
            ['--b360-text-secondary',        self::str($c, 'textSecondary',      '#4F4A45')],
            ['--b360-text-muted',            self::str($c, 'textMuted',          '#6B6660')],
            ['--b360-text-subtle',           self::str($c, 'textSubtle',         '#8C867E')],
            ['--b360-text-on-inverse',       self::str($c, 'textOnInverse',      '#FFFFFF')],
            ['--b360-text-on-inverse-muted', self::str($c, 'textOnInverseMuted', 'rgba(255,255,255,0.68)')],
            ['--b360-text-accent',           self::str($c, 'textAccent',         '#8B6F47')],
            // Borders
            ['--b360-border-subtle',         self::str($c, 'borderSubtle', '#EAE5D9')],
            ['--b360-border-strong',         self::str($c, 'borderStrong', '#CFC2B5')],
            ['--b360-border-focus',          self::str($c, 'borderFocus',  '#8B6F47')],
            ['--b360-divider',               self::str($c, 'divider',      '#E9E4DE')],
            // Selection / focus
            ['--b360-selected-surface',      self::str($c, 'selectedSurface', '#FFF7F8')],
            ['--b360-selected-border',       self::str($c, 'selectedBorder',  '#7A1730')],
            ['--b360-focus-ring',            self::str($c, 'focusRing',       'rgba(122, 23, 48, 0.18)')],
            // Status
            ['--b360-success',               self::str($c, 'success',     '#2E7D32')],
            ['--b360-success-soft',          self::str($c, 'successSoft', '#EAF4EC')],
            ['--b360-success-text',          self::str($c, 'successText', '#FFFFFF')],
            ['--b360-warning',               self::str($c, 'warning',     '#8A6B0F')],
            ['--b360-warning-soft',          self::str($c, 'warningSoft', '#F7EED2')],
            ['--b360-warning-text',          self::str($c, 'warningText', '#FFFFFF')],
            ['--b360-error',                 self::str($c, 'error',       '#B03A2E')],
            ['--b360-error-soft',            self::str($c, 'errorSoft',   '#F8E7E4')],
            ['--b360-error-text',            self::str($c, 'errorText',   '#FFFFFF')],
            ['--b360-info',                  self::str($c, 'info',        '#1A4A7A')],
            ['--b360-info-soft',             self::str($c, 'infoSoft',    '#E8F0FA')],
            ['--b360-info-text',             self::str($c, 'infoText',    '#FFFFFF')],
            // Inverse-surface tints
            ['--b360-surface-inverse-overlay', self::str($c, 'surfaceInverseOverlay', 'rgba(0,0,0,0.18)')],
            ['--b360-border-on-inverse',       self::str($c, 'borderOnInverse',       'rgba(255,255,255,0.14)')],
            // Price
            ['--b360-price-text',            self::str($c, 'priceText',    '#171717')],
            ['--b360-discount-text',         self::str($c, 'discountText', '#2E7D32')],
            // Typography
            ['--b360-font-sans',             self::fontStr($t, 'fontSans',  'ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif')],
            ['--b360-font-serif',            self::fontStr($t, 'fontSerif', 'Georgia, serif')],
            ['--b360-font-mono',             self::fontStr($t, 'fontMono',  'ui-monospace, monospace')],
            ['--b360-body-weight',           (string) (isset($t['bodyWeight'])    ? (int) $t['bodyWeight']    : 400)],
            ['--b360-label-weight',          (string) (isset($t['labelWeight'])   ? (int) $t['labelWeight']   : 600)],
            ['--b360-heading-weight',        (string) (isset($t['headingWeight']) ? (int) $t['headingWeight'] : 650)],
            ['--b360-title-weight',          (string) (isset($t['titleWeight'])   ? (int) $t['titleWeight']   : 700)],
            ['--b360-heading-transform',     self::headingTransform($t)],
            ['--b360-heading-tracking',      self::headingTracking($t)],
            // Radii
            ['--b360-radius-xs',             self::str($r, 'xs',      '4px')],
            ['--b360-radius-sm',             self::str($r, 'sm',      '6px')],
            ['--b360-radius-control',        self::str($r, 'control', '10px')],
            ['--b360-radius-card',           self::str($r, 'card',    '14px')],
            ['--b360-radius-panel',          self::str($r, 'panel',   '18px')],
            ['--b360-radius-pill',           self::str($r, 'pill',    '999px')],
            // Shadows
            ['--b360-shadow-none',           self::str($s, 'none',    'none')],
            ['--b360-shadow-sm',             self::str($s, 'sm',      '0 1px 2px rgba(0,0,0,0.06)')],
            ['--b360-shadow-md',             self::str($s, 'md',      '0 2px 6px rgba(0,0,0,0.08)')],
            ['--b360-shadow-lg',             self::str($s, 'lg',      '0 8px 24px rgba(0,0,0,0.10)')],
            ['--b360-shadow-overlay',        self::str($s, 'overlay', '0 8px 24px rgba(0,0,0,0.18)')],
            // Widths
            ['--b360-width-form',            self::str($w, 'form',     '520px')],
            ['--b360-width-reading',         self::str($w, 'reading',  '720px')],
            ['--b360-width-content',         self::str($w, 'content',  '960px')],
            ['--b360-width-account',         self::str($w, 'account',  '1120px')],
            ['--b360-width-wide',            self::str($w, 'wide',     '1180px')],
            ['--b360-width-store',           self::str($w, 'store',    '1280px')],
            ['--b360-width-checkout',        self::str($w, 'checkout', '1200px')],
            ['--b360-width-studio',          self::str($w, 'studio',   '1440px')],
            ['--b360-readable-measure',      self::str($w, 'readableMeasure', '68ch')],
            // Buttons (component character — casing + tracking)
            ['--b360-btn-transform', self::buttonTransform($button)],
            ['--b360-btn-tracking',  self::buttonTracking($button)],
            // Surfaces (border + shadow per family — mirrors buildSurfaceVars in cssVars.ts;
            // defaults: card border+sm, elevated border+md, productCard borderless+sm)
            ['--b360-surface-card-border',               self::surfaceBorder($surfaces, 'card',        true)],
            ['--b360-surface-card-shadow',               self::surfaceShadow($surfaces, 'card',        'sm')],
            ['--b360-surface-elevated-border',           self::surfaceBorder($surfaces, 'elevated',    true)],
            ['--b360-surface-elevated-shadow',           self::surfaceShadow($surfaces, 'elevated',    'md')],
            ['--b360-surface-product-card-border',       self::surfaceBorder($surfaces, 'productCard', false)],
            ['--b360-surface-product-card-shadow',       self::surfaceShadow($surfaces, 'productCard', 'sm')],
            ['--b360-surface-product-card-shadow-hover', self::surfaceShadowHover($surfaces, 'productCard', 'sm')],
            // Tabs (component customisation)
            ['--b360-tabs-indicator-thickness', $tabsThickness . 'px'],
            ['--b360-tabs-indicator-color',     $tabsColor],
            ['--b360-tabs-indicator-radius',    $tabsRadius],
            // Nav cart pill — aliased so the styling studio can theme the
            // cart slot independently of the global action-primary color.
            ['--b360-nav-cart-bg',         'var(--b360-action-primary)'],
            ['--b360-nav-cart-bg-hover',   'var(--b360-action-primary-hover)'],
            ['--b360-nav-cart-fg',         'var(--b360-action-primary-text)'],
            ['--b360-nav-cart-divider',    'rgba(255,255,255,0.32)'],
            // Legacy V1 aliases — kept so unmigrated stylesheets keep working.
            ['--b360-color-primary',         self::str($c, 'actionPrimary',       '#7A1730')],
            ['--b360-color-primary-hover',   self::str($c, 'actionPrimaryHover',  '#641226')],
            ['--b360-color-secondary',       self::str($c, 'brandSecondary',      '#7C5C3C')],
            ['--b360-color-accent',          self::str($c, 'brandAccent',         '#8B6F47')],
            ['--b360-color-surface',         self::str($c, 'surfaceCard',         '#FFFFFF')],
            ['--b360-color-bg',              self::str($c, 'surfacePage',         '#FAF8F3')],
            ['--b360-color-error',           self::str($c, 'error',               '#B03A2E')],
            ['--b360-color-warning',         self::str($c, 'warning',             '#8A6B0F')],
            ['--b360-color-success',         self::str($c, 'success',             '#2E7D32')],
            ['--b360-color-text',            self::str($c, 'textPrimary',         '#171717')],
            ['--b360-color-text-muted',      self::str($c, 'textMuted',           '#6B6660')],
            ['--b360-color-surface-hover',   self::str($c, 'surfaceMuted',        '#F3EEE8')],
            ['--b360-radius-btn',            self::str($r, 'control',             '10px')],
            ['--b360-radius-input',          self::str($r, 'sm',                  '6px')],
            ['--b360-font-body',             self::fontStr($t, 'fontSans',            'ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif')],
            ['--b360-font-heading',          self::fontStr($t, 'fontSerif',           'Georgia, serif')],
        ];

        if ($tabsDuration !== null) {
            $lines[] = ['--b360-motion-tab-slider', $tabsDuration];
        }

        $out = '';
        foreach ($lines as $row) {
            $out .= '  ' . $row[0] . ': ' . self::escVar($row[1]) . ";\n";
        }
        return $out;
    }

    /** Surface border CSS for a family — mirrors surfaceBorderCss() in cssVars.ts. */
    private static function surfaceBorder(array $surfaces, $family, $defaultBorder)
    {
        $border = isset($surfaces[$family]['border']) ? (bool) $surfaces[$family]['border'] : $defaultBorder;
        return $border ? '1px solid var(--b360-border-subtle)' : 'none';
    }

    /** Surface shadow CSS for a family — mirrors surfaceShadowCss() in cssVars.ts. */
    private static function surfaceShadow(array $surfaces, $family, $defaultLevel)
    {
        $level = isset($surfaces[$family]['shadow']) ? $surfaces[$family]['shadow'] : $defaultLevel;
        if (!in_array($level, ['none', 'sm', 'md', 'lg'], true)) $level = $defaultLevel;
        return 'var(--b360-shadow-' . $level . ')';
    }

    /** Product-card hover elevation — flat stays flat, else bump one step.
     *  Mirrors SURFACE_SHADOW_BUMP in cssVars.ts. */
    private static function surfaceShadowHover(array $surfaces, $family, $defaultLevel)
    {
        $level = isset($surfaces[$family]['shadow']) ? $surfaces[$family]['shadow'] : $defaultLevel;
        $bump  = ['none' => 'none', 'sm' => 'md', 'md' => 'lg', 'lg' => 'lg'];
        $hover = isset($bump[$level]) ? $bump[$level] : 'md';
        return 'var(--b360-shadow-' . $hover . ')';
    }

    private static function tabsIndicatorRadiusCss($mode)
    {
        if ($mode === 'flat')    return '0';
        if ($mode === 'capsule') return '999px';
        return '4px 4px 0 0';
    }

    private static function str(array $src, $key, $fallback)
    {
        return (isset($src[$key]) && is_string($src[$key]) && $src[$key] !== '')
            ? $src[$key]
            : $fallback;
    }

    /**
     * Font-family resolver. Like str(), but a value of inherit/initial/unset/
     * revert/empty resolves to the concrete fallback instead of passing through.
     *
     * Why: under a hostile host theme, emitting `font-family: inherit` makes the
     * storefront (and every teleported v-dialog / v-overlay, which live as direct
     * children of the host <body>) pick up the host's body font — e.g. a winery
     * site's "EB Garamond" bleeding into our UI. That defeats the CSS armor. A
     * real configured font stack (set via the Styling Studio) still passes
     * through unchanged; only the "inherit the host" sentinels are coerced.
     *
     * To restore host-font inheritance, swap these call sites back to str().
     */
    private static function fontStr(array $src, $key, $fallback)
    {
        $v = (isset($src[$key]) && is_string($src[$key])) ? trim($src[$key]) : '';
        $lower = strtolower($v);
        if ($v === '' || in_array($lower, ['inherit', 'initial', 'unset', 'revert', 'revert-layer'], true)) {
            return $fallback;
        }
        return $v;
    }

    /** Heading text-transform keyword. MIRRORS cssVars.ts headingTransformCss(). */
    private static function headingTransform(array $t)
    {
        $allowed = ['none', 'uppercase', 'lowercase', 'capitalize'];
        $v = isset($t['headingTransform']) && is_string($t['headingTransform']) ? $t['headingTransform'] : 'none';
        return in_array($v, $allowed, true) ? $v : 'none';
    }

    /** Named heading letter-spacing step → em (additive). MIRRORS cssVars.ts HEADING_TRACKING_EM. */
    private static function headingTracking(array $t)
    {
        $map = ['normal' => '0em', 'tight' => '-0.02em', 'wide' => '0.04em', 'wider' => '0.08em', 'widest' => '0.14em'];
        $key = isset($t['headingLetterSpacing']) && is_string($t['headingLetterSpacing']) ? $t['headingLetterSpacing'] : 'normal';
        return isset($map[$key]) ? $map[$key] : '0em';
    }

    /** Button label text-transform keyword. MIRRORS cssVars.ts buttonTransformCss(). */
    private static function buttonTransform(array $b)
    {
        $v = isset($b['textTransform']) && is_string($b['textTransform']) ? $b['textTransform'] : 'none';
        return in_array($v, ['none', 'uppercase'], true) ? $v : 'none';
    }

    /** Named button letter-spacing step → em. MIRRORS cssVars.ts BUTTON_TRACKING_EM. */
    private static function buttonTracking(array $b)
    {
        $map = ['normal' => '0em', 'wide' => '0.04em', 'wider' => '0.08em'];
        $key = isset($b['letterSpacing']) && is_string($b['letterSpacing']) ? $b['letterSpacing'] : 'normal';
        return isset($map[$key]) ? $map[$key] : '0em';
    }

    /** CSS-context escape: forbid `<` `>` to keep us safe from breaking out
     *  of the <style> block. Numbers/hex/rgb()/font-stacks all pass through. */
    private static function escVar($v)
    {
        return str_replace(['<', '>'], '', (string) $v);
    }
}
