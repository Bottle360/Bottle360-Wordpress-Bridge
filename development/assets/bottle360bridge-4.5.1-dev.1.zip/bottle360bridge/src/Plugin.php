<?php

namespace Bottle360\Bridge;

if (!defined('ABSPATH')) exit;

final class Plugin
{
    private static ?self $instance = null;
    private bool $booted = false;

    public static function instance(): self
    {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public function boot(): void
    {
        if ($this->booted) return;
        $this->booted = true;

        // Self-heal the app-page option for installs that never ran activation
        // (migrated from staging, deployed via git, restored from backup, etc.).
        // Runs before rewrite rules register, no-op when the option is set.
        add_action('init', [\Bottle360\Bridge\Lifecycle\Activator::class, 'maybeHeal'], 1);

        // --- Admin Styling Studio (fullscreen theme editor) ---
        $this->register('Admin\\StudioPage');

        // --- Admin settings ---
        if (class_exists('Bottle360\\Bridge\\Admin\\SettingsPage')) {
            $sp = new \Bottle360\Bridge\Admin\SettingsPage();
            $sp->register_settings();
            add_action('admin_menu', [$sp, 'add_menu']);

            // "Settings" link on the Plugins list row
            add_filter('plugin_action_links_bottle360bridge/b360-bridge.php', function ($links) {
                $url = admin_url('options-general.php?page=b360_bridge');
                array_unshift($links, '<a href="' . esc_url($url) . '">' . esc_html__('Settings', 'b360-bridge') . '</a>');
                return $links;
            });

            // add note about rewrite requirements needed to have the plugin actually work
            add_action('admin_notices', function () {
                if (!get_option('permalink_structure')) {
                    echo '<div class="notice notice-error"><p>';
                    echo '<strong>Bottle360 Bridge:</strong> Pretty permalinks are required. ';
                    echo 'Go to <a href="' . esc_url(admin_url('options-permalink.php')) . '">Settings &rarr; Permalinks</a> ';
                    echo 'and select any structure other than &ldquo;Plain.&rdquo;';
                    echo '</p></div>';
                }

                $conflict_slug = get_transient('b360_page_conflict');
                if ($conflict_slug) {
                    delete_transient('b360_page_conflict');
                    echo '<div class="notice notice-warning is-dismissible"><p>';
                    echo '<strong>Bottle360 Bridge:</strong> A page with slug &ldquo;' . esc_html($conflict_slug) . '&rdquo; ';
                    echo 'already exists but does not contain the <code>[b360_app]</code> shortcode. ';
                    echo 'Please add <code>[b360_app]</code> to that page, or change the store base path in settings.';
                    echo '</p></div>';
                }

                if (get_transient('b360_app_page_is_homepage')) {
                    echo '<div class="notice notice-error"><p>';
                    echo '<strong>Bottle360 Bridge:</strong> The storefront page is configured as the site homepage ';
                    echo '(<em>Settings &rarr; Reading</em>). This is not supported — the SPA must live at a ';
                    echo 'dedicated sub-path so storefront URLs can be distinguished from regular WordPress pages. ';
                    echo 'Please change <em>Your homepage displays</em> to a different page, or to &ldquo;Your latest posts.&rdquo;';
                    echo '</p></div>';
                }
            });
        }

        // --- Frontend CSS registration ---
        $this->register('Frontend\\Assets');

        // --- Bridge bundle bootstrap (every frontend page: loads the Vue
        //     bundle, emits window.B360Bridge config, injects the sidebar
        //     cart-drawer placeholder)
        $this->register('Frontend\\BridgeBoot');

        // --- SPA shortcode + sub-path routing ---
        $this->register('Shortcodes\\AppShortcode');   // [b360_app] — Vue SPA mount point
        $this->register('Routing\\AppRoute');

        // --- SEO meta tags (description, OG, Twitter Card, canonical) ---
        $this->register('Seo\\MetaTags');

        // --- Bridge API session ---
        $this->register('Api\\BridgeSession');

        // --- Widget shortcodes (embeddable in any page) ---
        $this->register('Shortcodes\\ProductCardShortcode');  // [b360_product_card] — embed a product anywhere
        $this->register('Shortcodes\\NavShortcode');          // [b360_nav] — store navigation bar
        $this->register('Shortcodes\\ClubsShortcode');        // [b360_clubs] — embeddable clubs list
        $this->register('Shortcodes\\CollectionsShortcode'); // [b360_collections] — embeddable collections/categories grid
        $this->register('Shortcodes\\FormShortcode');         // [b360_form] — generic admin-defined form

        // --- REST API controllers (replacing AJAX handlers) ---
        $this->register('Rest\\BootstrapController');
        $this->register('Rest\\NonceController');
        $this->register('Rest\\CatalogController');
        $this->register('Rest\\CartController');
        $this->register('Rest\\AuthController');
        $this->register('Rest\\CheckoutController');
        $this->register('Rest\\PaymentController');
        $this->register('Rest\\ClubController');
        $this->register('Rest\\OrderController');
        $this->register('Rest\\AddressController');
        $this->register('Rest\\FormController');
        $this->register('Rest\\WalletController');
        $this->register('Rest\\ThemeController');

        // --- Plugin updater ---
        $this->register('Updates\\Updater', 'init');
    }

    private function register(string $shortClass, string $method = 'register'): void
    {
        $class = 'Bottle360\\Bridge\\' . $shortClass;
        if (!class_exists($class)) return;

        try {
            $obj = new $class();
            if (method_exists($obj, $method)) {
                $obj->{$method}();
            }
        } catch (\Throwable $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[B360Bridge] ' . $class . '::' . $method . '() error: ' . $e->getMessage());
            }
        }
    }
}
