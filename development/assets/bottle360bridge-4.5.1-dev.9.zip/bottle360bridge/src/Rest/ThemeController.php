<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Settings\ThemeOptions;
use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class ThemeController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/theme', [
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'get_theme'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods'             => 'PUT',
                'callback'            => [$this, 'save_theme'],
                'permission_callback' => [$this, 'require_manage_options'],
            ],
        ]);

        register_rest_route(self::NAMESPACE, '/theme/reset', [
            'methods'             => 'POST',
            'callback'            => [$this, 'reset_theme'],
            'permission_callback' => [$this, 'require_manage_options'],
        ]);
    }

    public function require_manage_options(): bool
    {
        return current_user_can('manage_options');
    }

    public function get_theme(WP_REST_Request $request)
    {
        return $this->success(ThemeOptions::get());
    }

    public function save_theme(WP_REST_Request $request)
    {
        $params = $request->get_json_params();
        if (!is_array($params)) {
            return $this->error('Request body must be a JSON object', 400, 'b360_invalid_body');
        }
        $saved = ThemeOptions::save($params);
        return $this->success($saved);
    }

    public function reset_theme(WP_REST_Request $request)
    {
        $defaults = ThemeOptions::reset();
        return $this->success($defaults);
    }
}
