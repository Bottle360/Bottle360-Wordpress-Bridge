<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class WalletController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/wallet/balance', [
            'methods'             => 'GET',
            'callback'            => [$this, 'balance'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/wallet/transactions', [
            'methods'             => 'GET',
            'callback'            => [$this, 'transactions'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/wallet/redemption-info', [
            'methods'             => 'GET',
            'callback'            => [$this, 'redemption_info'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function balance(WP_REST_Request $request)
    {
        return $this->proxy_get('wallet/balance');
    }

    public function transactions(WP_REST_Request $request)
    {
        return $this->proxy_get('wallet/transactions', [
            'page'     => absint($request->get_param('page') ?: 1),
            'per_page' => min(100, max(1, absint($request->get_param('per_page') ?: 20))),
        ]);
    }

    public function redemption_info(WP_REST_Request $request)
    {
        return $this->proxy_get('wallet/redemptionInfo', [
            'subtotal' => floatval($request->get_param('subtotal') ?: 0),
        ]);
    }
}
