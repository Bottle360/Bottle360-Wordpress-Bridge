<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class OrderController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/orders', [
            'methods'             => 'GET',
            'callback'            => [$this, 'list_orders'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/orders/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'order_detail'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/orders/(?P<id>\d+)/recreate', [
            'methods'             => 'POST',
            'callback'            => [$this, 'recreate_order'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function list_orders(WP_REST_Request $request)
    {
        $params = [
            'page'     => max(1, (int) ($request->get_param('page') ?? 1)),
            'per_page' => min(100, max(1, (int) ($request->get_param('per_page') ?? 20))),
        ];

        return $this->proxy_get('order/history', $params);
    }

    public function order_detail(WP_REST_Request $request)
    {
        $orderId = absint($request->get_param('id'));

        if ($orderId <= 0) {
            return $this->error('order_id is required', 400);
        }

        return $this->proxy_get('order/detail', ['order_id' => $orderId]);
    }

    public function recreate_order(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $orderId = absint($request->get_param('id'));
        if ($orderId <= 0) {
            return $this->error('order_id is required', 400);
        }

        return $this->proxy_post('order/recreate', ['order_id' => $orderId]);
    }
}
