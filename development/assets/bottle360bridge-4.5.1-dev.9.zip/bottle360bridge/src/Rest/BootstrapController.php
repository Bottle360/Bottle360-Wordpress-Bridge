<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

/**
 * Public bootstrap endpoint — returns non-sensitive runtime config the Vue
 * frontend needs before it can talk to the bridge (most notably the
 * reCAPTCHA v3 site key + enabled flag).
 *
 * Separate from initSession: the frontend doesn't need a fresh token to
 * render UI, and /bootstrap is cached via transient so every page load
 * doesn't cost a bridge roundtrip.
 *
 * No nonce required — the response contains only public info, and we want
 * it reachable on the very first page load before a nonce is available.
 */
final class BootstrapController extends RestBase
{
    private const TRANSIENT_KEY = 'b360_bootstrap_config';
    private const TRANSIENT_TTL = 300; // 5 min — short enough that toggling
                                        // recaptcha in the admin propagates
                                        // quickly without requiring a flush.

    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/bootstrap', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_bootstrap'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function get_bootstrap(WP_REST_Request $request)
    {
        $cached = get_transient(self::TRANSIENT_KEY);
        if (is_array($cached)) {
            return $this->success($cached);
        }

        $result = \Bottle360\Bridge\Api\BridgeApiClient::instance()->get('default/config');
        if (!$result['ok']) {
            // Fail-open on the boot endpoint: the frontend can't block itself
            // from loading because we couldn't reach the admin. Return a
            // safe "recaptcha disabled" shape so callers fall through without
            // attaching tokens (the bridge will still enforce server-side
            // when keys exist; the frontend just won't pre-mint tokens).
            // wallet_enabled defaults TRUE here too: an unreachable admin must
            // not silently hide a feature tab the tenant may have enabled.
            $fallback = [
                'recaptcha' => ['enabled' => false, 'site_key' => ''],
                'features'  => [
                    'wallet_enabled' => true,
                    // Local WP toggle — independent of the admin being reachable.
                    'membership_pause_enabled' => \Bottle360\Bridge\Settings\Options::is_membership_pause_enabled(),
                ],
            ];
            return $this->success($fallback);
        }

        $data = is_array($result['data']) ? $result['data'] : [];
        $payload = [
            'recaptcha' => [
                'enabled'  => !empty($data['recaptcha']['enabled']),
                'site_key' => isset($data['recaptcha']['site_key']) ? (string) $data['recaptcha']['site_key'] : '',
            ],
            'features' => [
                // Forward-compat: an older admin without the features block
                // means "show the tab" — never hide a feature because the
                // provider predates this flag. Default TRUE when absent.
                'wallet_enabled' => isset($data['features']['wallet_enabled'])
                    ? (bool) $data['features']['wallet_enabled']
                    : true,
                // Site-wide pause kill switch. Sourced from the LOCAL WP option
                // (a site-builder preference), not the admin config — it layers
                // on top of each club's allow_customer_pause flag. Defaults true.
                'membership_pause_enabled' => \Bottle360\Bridge\Settings\Options::is_membership_pause_enabled(),
            ],
        ];

        set_transient(self::TRANSIENT_KEY, $payload, self::TRANSIENT_TTL);
        return $this->success($payload);
    }

    public static function flushCache(): void
    {
        delete_transient(self::TRANSIENT_KEY);
    }
}
