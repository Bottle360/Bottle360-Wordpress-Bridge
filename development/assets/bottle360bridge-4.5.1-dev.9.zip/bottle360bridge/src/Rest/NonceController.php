<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Support\Nonce;
use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class NonceController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/nonce', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_nonce'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function get_nonce(WP_REST_Request $request)
    {
        return $this->success(['nonce' => Nonce::value()]);
    }
}
