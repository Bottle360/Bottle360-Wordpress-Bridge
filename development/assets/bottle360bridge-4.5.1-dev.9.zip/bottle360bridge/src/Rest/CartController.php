<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class CartController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/cart', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_cart'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/cart/add', [
            'methods'             => 'POST',
            'callback'            => [$this, 'add_item'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/cart/update-qty', [
            'methods'             => 'POST',
            'callback'            => [$this, 'update_qty'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/cart/remove', [
            'methods'             => 'POST',
            'callback'            => [$this, 'remove_item'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function get_cart(WP_REST_Request $request)
    {
        return $this->proxy_get('cart/get');
    }

    public function add_item(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params  = $request->get_json_params();
        $skuCode = sanitize_text_field(wp_unslash($params['sku_code'] ?? ''));
        $qty     = max(1, (int) ($params['qty'] ?? 1));

        if ($skuCode === '') {
            return $this->error('sku_code is required', 400);
        }

        $body = ['sku_code' => $skuCode, 'qty' => $qty];

        if (isset($params['vintage_id'])) {
            $body['vintage_id'] = (int) $params['vintage_id'];
        }
        if (isset($params['product_id'])) {
            $body['product_id'] = (int) $params['product_id'];
        }

        // Optional customer-chosen price for open-amount gift-card SKUs. Admin
        // side enforces that this is only honored for eligible SKUs and throws
        // CUSTOM_PRICE_FORBIDDEN otherwise. Belt-and-braces: require
        // numeric > 0 and <= 10000 before forwarding so a malicious client
        // can't DoS the admin with nonsense.
        if (isset($params['price']) && $params['price'] !== '' && $params['price'] !== null) {
            $price = floatval($params['price']);
            if ($price > 0 && $price <= 10000) {
                $body['price'] = $price;
            }
        }

        return $this->proxy_post('cart/add', $body);
    }

    public function update_qty(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params  = $request->get_json_params();
        $skuCode = sanitize_text_field(wp_unslash($params['sku_code'] ?? ''));
        $qty     = max(1, (int) ($params['qty'] ?? 1));

        if ($skuCode === '') {
            return $this->error('sku_code is required', 400);
        }

        return $this->proxy_post('cart/updateQty', [
            'sku_code' => $skuCode,
            'qty'      => $qty,
        ]);
    }

    public function remove_item(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params  = $request->get_json_params();
        $skuCode = sanitize_text_field(wp_unslash($params['sku_code'] ?? ''));

        if ($skuCode === '') {
            return $this->error('sku_code is required', 400);
        }

        return $this->proxy_post('cart/remove', ['sku_code' => $skuCode]);
    }
}
