<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class CatalogController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/products', [
            'methods'             => 'GET',
            'callback'            => [$this, 'list_products'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/products/by-sku/(?P<sku>[^/]+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'product_by_sku'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/products/(?P<slug>[a-zA-Z0-9_-]+)', [
            'methods'             => 'GET',
            'callback'            => [$this, 'product_detail'],
            'permission_callback' => '__return_true',
        ]);

        // Clean query-param lookup: ?vintage_id=N or ?slug=foo or ?sku=BAR
        // Used by ProductDetail.vue (wines use vintage_id, non-wines use slug, sku is universal)
        register_rest_route(self::NAMESPACE, '/catalog/product', [
            'methods'             => 'GET',
            'callback'            => [$this, 'product_lookup'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/categories', [
            'methods'             => 'GET',
            'callback'            => [$this, 'list_categories'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function list_products(WP_REST_Request $request)
    {
        $page    = max(1, (int) ($request->get_param('page') ?? 1));
        $perPage = min(100, max(1, (int) ($request->get_param('per_page') ?? 24)));

        $params = ['page' => $page, 'per_page' => $perPage];

        $category = $request->get_param('category');
        if ($category) {
            $params['category_slug'] = sanitize_title(wp_unslash($category));
        }

        return $this->proxy_get('catalog/products', $params, ['cache' => 300]);
    }

    /**
     * Query-param product lookup — used by the Vue SPA ProductDetail component.
     *
     * Lookup priority:
     *  1. sku=CODE   — SKU-level lookup (works for any product type)
     *  2. vintage_id=N — Wine lookup by vintage ID (integer, authoritative for
     *                   wines that share a slug across vintages)
     *  3. slug=SLUG  — Non-wine lookup by slug
     *
     * All three are mutually exclusive; the first non-empty param wins.
     */
    public function product_lookup(WP_REST_Request $request)
    {
        $sku = sanitize_text_field((string) ($request->get_param('sku') ?? ''));
        if ($sku !== '') {
            return $this->proxy_get('catalog/product', ['sku' => $sku], ['cache' => 60]);
        }

        $vintageId = absint($request->get_param('vintage_id'));
        if ($vintageId > 0) {
            return $this->proxy_get('catalog/product', ['vintage_id' => $vintageId], ['cache' => 60]);
        }

        $slug = sanitize_title((string) ($request->get_param('slug') ?? ''));
        if ($slug !== '') {
            return $this->proxy_get('catalog/product', ['slug' => $slug], ['cache' => 60]);
        }

        return $this->error('One of sku, vintage_id, or slug is required', 400);
    }

    /**
     * Legacy slug-in-URL product detail — kept for backward compatibility.
     * For wines, prefer the /catalog/product?vintage_id=N route instead.
     */
    public function product_detail(WP_REST_Request $request)
    {
        $slug = sanitize_title($request->get_param('slug'));
        if ($slug === '') {
            return $this->error('slug is required', 400);
        }

        $params = ['slug' => $slug];

        // Forward vintage_id if provided (new field, integer)
        $vintageId = absint($request->get_param('vintage_id'));
        if ($vintageId > 0) {
            $params['vintage_id'] = $vintageId;
        }

        return $this->proxy_get('catalog/product', $params, ['cache' => 300]);
    }

    public function product_by_sku(WP_REST_Request $request)
    {
        $sku = sanitize_text_field($request->get_param('sku'));
        if ($sku === '') {
            return $this->error('sku is required', 400);
        }

        return $this->proxy_get('catalog/product', ['sku' => $sku], ['cache' => 300]);
    }

    public function list_categories(WP_REST_Request $request)
    {
        return $this->proxy_get('catalog/categories', [], ['cache' => 600]);
    }
}
