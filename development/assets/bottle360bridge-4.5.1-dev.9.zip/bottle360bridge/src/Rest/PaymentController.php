<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class PaymentController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/payment/nmi-key', [
            'methods'             => 'GET',
            'callback'            => [$this, 'nmi_key'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/payment/saved-cards', [
            'methods'             => 'GET',
            'callback'            => [$this, 'saved_cards'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/payment/add-card', [
            'methods'             => 'POST',
            'callback'            => [$this, 'add_card'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/payment/delete-card', [
            'methods'             => 'POST',
            'callback'            => [$this, 'delete_card'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function nmi_key(WP_REST_Request $request)
    {
        return $this->proxy_get('payment/nmiKey', [], ['cache' => 3600]);
    }

    public function saved_cards(WP_REST_Request $request)
    {
        return $this->proxy_get('payment/savedCards');
    }

    public function add_card(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $body = $request->get_json_params();
        return $this->proxy_post('payment/addCard', [
            'payment_token'      => sanitize_text_field($body['payment_token'] ?? ''),
            'billing_address_id' => absint($body['billing_address_id'] ?? 0),
        ], $this->withRecaptcha($request));
    }

    public function delete_card(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $body = $request->get_json_params();
        return $this->proxy_post('payment/deleteCard', [
            'billing_id' => sanitize_text_field($body['billing_id'] ?? ''),
        ]);
    }
}
