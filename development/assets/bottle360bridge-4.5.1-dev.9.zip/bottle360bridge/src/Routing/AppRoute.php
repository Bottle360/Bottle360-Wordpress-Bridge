<?php

namespace Bottle360\Bridge\Routing;

use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * Routes sub-paths under the store base path to the SPA page
 * so Vue Router can handle client-side routing.
 */
final class AppRoute
{
    // Bumped to 4 to force a rewrite flush after the homepage-mount support
    // was removed — the old rule set may still contain the SPA_SEGMENTS
    // root pattern from installs that ran an earlier version.
    private const REWRITE_VERSION = 4;
    private const VERSION_OPTION  = 'b360_rewrite_version';

    public function register(): void
    {
        // Inject our rule at the top of every compiled rule set. Using the
        // filter (vs. add_rewrite_rule) guarantees the rule survives every
        // flush, including flushes triggered by WP Engine or other plugins
        // at unpredictable times.
        add_filter('rewrite_rules_array', [$this, 'injectSpaRule']);
        add_action('init', [$this, 'maybeFlush'], 2);
        add_filter('document_title_parts', [$this, 'setTitle']);
        // Keep WP's canonical redirect from bouncing SPA subpaths back to the
        // app page's permalink (critical when the app page is the homepage).
        add_filter('redirect_canonical', [$this, 'preventCanonicalRedirect'], 10, 2);
        // WP core hard-redirects /login, /admin, /dashboard to wp-login.php.
        // Unhook that so /login can reach our SPA when the store owns that slug.
        add_action('template_redirect', [$this, 'unhookAdminLoginRedirect'], 1);
    }

    /**
     * Build the SPA rewrite pattern + target. Returns [pattern, target] or
     * null when the plugin isn't ready (no app page).
     *
     * The SPA always lives under a dedicated sub-path (see
     * Options::get_app_base_path()) — one rewrite maps every request under
     * that prefix to the app page, and Vue Router takes it from there.
     */
    private function buildRule(): ?array
    {
        $page_id = (int) get_option('b360_app_page_id', 0);
        if (!$page_id || get_post_status($page_id) !== 'publish') return null;

        $basePath = trim(Options::get_app_base_path(), '/');
        if ($basePath === '') return null;

        $rx = preg_quote($basePath, '/');
        return ['^' . $rx . '/(.+)/?$', 'index.php?page_id=' . $page_id];
    }

    public function injectSpaRule(array $rules): array
    {
        $rule = $this->buildRule();
        if ($rule === null) return $rules;
        [$pattern, $target] = $rule;
        // Prepend so our rule wins over WP's catch-all page rule.
        return [$pattern => $target] + $rules;
    }

    /**
     * Invalidate the compiled rewrite_rules option when our inputs change
     * (plugin version bump, app page id, or its URL path). WP will regenerate
     * the rules on the next request and our filter will contribute our rule.
     *
     * Deleting the option outright is more reliable on managed hosts (WPE,
     * Kinsta) than calling flush_rewrite_rules() — that function defers to
     * wp_loaded and sometimes its results don't propagate through their
     * object cache or nginx config refresh.
     */
    public function maybeFlush(): void
    {
        if ($this->buildRule() === null) return;

        $page_id = (int) get_option('b360_app_page_id', 0);
        $basePath = Options::get_app_base_path();
        $stamp = self::REWRITE_VERSION . ':' . $page_id . ':' . $basePath;

        if (get_option(self::VERSION_OPTION) === $stamp) return;

        delete_option('rewrite_rules');
        update_option(self::VERSION_OPTION, $stamp, true);
    }

    /**
     * WP core's `wp_redirect_admin_locations()` intercepts requests to
     * `/login`, `/admin`, `/dashboard`, `/wp-login`, `/wp-admin` and sends
     * them to wp-login.php. When the SPA owns a `/login` sub-path (e.g.
     * `/store/login`), suppress that behavior so the SPA can render its
     * own login view.
     */
    public function unhookAdminLoginRedirect(): void
    {
        $path = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), '/');
        if ($path === '') return;

        $basePath = trim(Options::get_app_base_path(), '/');
        if ($basePath === '') return;

        if ($path === $basePath || strpos($path, $basePath . '/') === 0) {
            remove_action('template_redirect', 'wp_redirect_admin_locations', 1000);
        }
    }

    /**
     * When WP has resolved the request to the app page, suppress canonical
     * redirects so subpaths like /store/checkout/ or /checkout/ (homepage case) stay
     * put for the SPA to handle.
     *
     * @param string|false $redirect_url
     * @param string       $requested_url
     * @return string|false
     */
    public function preventCanonicalRedirect($redirect_url, $requested_url)
    {
        $page_id = (int) get_option('b360_app_page_id', 0);
        if (!$page_id) return $redirect_url;
        if (get_queried_object_id() !== $page_id) return $redirect_url;
        return false;
    }

    /**
     * Check if the current request is for the B360 app page.
     */
    private function isAppPage(): bool
    {
        $page_id = (int) get_option('b360_app_page_id', 0);
        if (!$page_id) return false;

        return is_page($page_id);
    }

    public function setTitle(array $title): array
    {
        if (!$this->isAppPage()) {
            return $title;
        }

        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
        $basePath = Options::get_app_base_path();
        // Anchored prefix strip (str_replace would also hit mid-URL matches).
        $path = strpos($uri, $basePath) === 0 ? substr($uri, strlen($basePath)) : $uri;
        $segment = explode('/', trim((string) $path, '/'))[0] ?? '';

        $title['title'] = SpaRoutes::titleFor($segment);
        return $title;
    }
}
