<?php
namespace Bottle360\Bridge\Lifecycle;

use Bottle360\Bridge\Settings\Options;

final class Activator {
    public static function activate(): void {
        // An explicit activation overrides a prior disconnect — the admin is
        // asking for a working install, so rebuild the page + rules.
        delete_option(Options::OPT_APP_DISCONNECTED);
        self::ensureAppPage();
        // Can't flush here — AppRoute's init hook hasn't registered our SPA
        // rule yet, so a flush right now would save the ruleset without it.
        // Instead, clear the version stamp so AppRoute::addRewriteRules()
        // auto-flushes on the next init tick (when the rule IS registered).
        delete_option('b360_rewrite_version');
        // V1 → V2 theme cutover: delete the V1 option outright. There is no
        // migration — the V2 default theme takes over until the site builder
        // visits the Styling Studio.
        delete_option('b360_theme');
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
        delete_option('b360_rewrite_version');
    }

    /**
     * Run the app-page check lazily — covers installs that missed activation
     * (migrated sites, WPE's copy-from-staging, git-deployed plugin, etc.).
     * Cheap: one get_option on the happy path.
     *
     * Respects an explicit admin disconnect (Options::is_app_disconnected()).
     * Without that guard, deleting the app page silently re-creates it on
     * the next init and makes the plugin impossible to detach from a page.
     */
    public static function maybeHeal(): void
    {
        if (Options::is_app_disconnected()) return;

        $stored = (int) get_option('b360_app_page_id', 0);
        if ($stored && get_post_status($stored) === 'publish') return;
        self::ensureAppPage();
    }

    public static function ensureAppPage(): void
    {
        if (Options::is_app_disconnected()) return;

        $slug = trim(Options::get_app_setup_slug(), '/');
        if ($slug === '') {
            $slug = 'store';
        }

        // Check if we already have a stored page ID that's still valid
        $stored_id = (int) get_option('b360_app_page_id', 0);
        if ($stored_id && get_post_status($stored_id) === 'publish') {
            return;
        }

        // Check if page already exists by slug
        $existing = get_page_by_path($slug, OBJECT, 'page');
        if ($existing) {
            // Warn if the existing page doesn't contain our shortcode
            if (strpos($existing->post_content, '[b360_app]') === false) {
                set_transient('b360_page_conflict', $slug, DAY_IN_SECONDS);
            }
            update_option('b360_app_page_id', $existing->ID, true);
            return;
        }

        $page_id = wp_insert_post([
            'post_title'   => wp_strip_all_tags(ucfirst($slug)),
            'post_content' => "<!-- wp:shortcode -->[b360_app]<!-- /wp:shortcode -->",
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_name'    => $slug,
        ]);

        if ($page_id && !is_wp_error($page_id)) {
            update_option('b360_app_page_id', $page_id, true);
        }
    }

    /**
     * Detach the plugin from its app page. Clears `b360_app_page_id` and
     * sets the disconnect flag so maybeHeal won't re-adopt or re-create.
     * The actual WP page is NOT deleted here — if the admin wants it gone,
     * they can delete it from the Pages admin after calling this, and it
     * will stay gone.
     *
     * Rewrite rules are invalidated so the SPA rule disappears on the next
     * init (AppRoute won't build a rule without an app page id).
     *
     * @param bool $deletePage  Also move the app page to Trash.
     */
    public static function disconnect(bool $deletePage = false): void
    {
        $page_id = (int) get_option('b360_app_page_id', 0);

        if ($deletePage && $page_id > 0 && get_post_status($page_id) !== false) {
            // Trash rather than force-delete — reversible, matches WP's
            // normal "delete page" UX.
            wp_delete_post($page_id, false);
        }

        delete_option('b360_app_page_id');
        update_option(Options::OPT_APP_DISCONNECTED, 1, true);

        // Force a rewrite flush so the SPA rule goes away on next init.
        delete_option('b360_rewrite_version');
        delete_option('rewrite_rules');
    }

    /**
     * Clear the disconnect flag and re-run the activator's ensure/heal flow,
     * creating a fresh app page at the setup slug (or adopting an existing
     * page at that slug if the admin has one ready).
     */
    public static function reconnect(): void
    {
        delete_option(Options::OPT_APP_DISCONNECTED);
        self::ensureAppPage();
        delete_option('b360_rewrite_version');
        delete_option('rewrite_rules');
    }
}
