<?php
namespace Bottle360\Bridge\Support;

if (!defined('ABSPATH')) exit;

final class Nonce
{
    public const ACTION = 'b360_nonce';

    public static function value(): string
    {
        return wp_create_nonce(self::ACTION);
    }

    public static function verifyFrom(?array $payload = null, string $key = 'nonce'): bool
    {
        $payload = $payload ?? [];
        $nonce = '';
        if (isset($payload[$key]) && is_string($payload[$key])) {
            $nonce = $payload[$key];
        }
        return $nonce !== '' && (bool) wp_verify_nonce($nonce, self::ACTION);
    }
}
