<?php

namespace Bottle360\Bridge\Api;

if (!defined('ABSPATH')) exit;

final class ApiErrorLog
{
    private const OPTION_KEY  = 'b360_bridge_error_log';
    private const MAX_ENTRIES = 50;

    public static function log(string $method, string $url, int $status, string $error, string $body = ''): void
    {
        $log = get_option(self::OPTION_KEY, []);
        array_unshift($log, [
            'time'   => gmdate('Y-m-d H:i:s'),
            'method' => $method,
            'url'    => $url,
            'status' => $status,
            'error'  => $error,
            'body'   => substr($body, 0, 5000),
        ]);
        $log = array_slice($log, 0, self::MAX_ENTRIES);
        update_option(self::OPTION_KEY, $log, false);
    }

    public static function get_entries(): array
    {
        return get_option(self::OPTION_KEY, []);
    }

    public static function clear(): void
    {
        delete_option(self::OPTION_KEY);
    }

    public static function count(): int
    {
        return count(self::get_entries());
    }
}
