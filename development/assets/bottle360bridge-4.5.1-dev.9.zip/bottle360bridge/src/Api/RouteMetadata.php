<?php

namespace Bottle360\Bridge\Api;

if (!defined('ABSPATH')) exit;

/**
 * Per-route metadata for the Bridge API client.
 *
 * Controls three behaviours for each bridge route path:
 *
 *   requires_session     — if true, a guest token is minted lazily before
 *                          the request fires (replaces the blanket rest_api_init
 *                          mint). False for pure public routes like catalog.
 *
 *   requires_user        — if true, the route needs an authenticated user
 *                          token. A login_required 401 is expected when a
 *                          guest hits one of these. Keep this consistent with
 *                          the bridge controller's userRequiredActions() list.
 *
 *   retry_on_session_dead — if true, a session_dead 401 triggers a mint-and-
 *                           retry exactly once (safe for idempotent reads).
 *                           False for writes/mutations where a silent retry
 *                           would execute the action twice.
 *
 * Default for unlisted routes: all three flags false.
 *
 * Rationale: an unlisted route that genuinely needs a session will surface a
 * single session_dead 401 that shows up in the error log, gets noticed, and
 * gets added here. The alternative — defaulting requires_session to true —
 * silently over-mints guest tokens for every new endpoint and lets this table
 * drift out of sync with the bridge without anyone noticing. Fail loud is the
 * project convention here (see CLAUDE.md "No Fallback Hacks").
 */
final class RouteMetadata
{
    /**
     * @var array<string, array{requires_session: bool, requires_user: bool, retry_on_session_dead: bool}>
     */
    private static array $routes = [

        // Catalog — pure public, no token needed
        'catalog/categories'                          => ['requires_session' => false, 'requires_user' => false, 'retry_on_session_dead' => false],
        'catalog/products'                            => ['requires_session' => false, 'requires_user' => false, 'retry_on_session_dead' => false],
        'catalog/product'                             => ['requires_session' => false, 'requires_user' => false, 'retry_on_session_dead' => false],

        // Auth — public endpoints (no token required)
        'auth/login'                                  => ['requires_session' => false, 'requires_user' => false, 'retry_on_session_dead' => false],
        'auth/register'                               => ['requires_session' => false, 'requires_user' => false, 'retry_on_session_dead' => false],
        'auth/forgotPassword'                         => ['requires_session' => false, 'requires_user' => false, 'retry_on_session_dead' => false],
        'auth/resetPassword'                          => ['requires_session' => false, 'requires_user' => false, 'retry_on_session_dead' => false],

        // Forms — get is pure public; submit needs a session (replay-safe)
        'form/get'                                    => ['requires_session' => false, 'requires_user' => false, 'retry_on_session_dead' => false],
        'form/submit'                                 => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => true],

        // Cart — get is session-required and retry-safe; mutations are not retryable
        'cart/get'                                    => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => true],
        'cart/add'                                    => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'cart/updateQty'                              => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'cart/remove'                                 => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],

        // Auth — session-required mutations (logout is a write; don't retry)
        'auth/logout'                                 => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],

        // Club — public browse routes (session required, not user-required, not retryable writes)
        'club/list'                                   => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'club/detail'                                 => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'club/cancelReasons'                          => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'club/pickupLocations'                        => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],

        // Checkout — session required; guest checkout is allowed at the plugin gate;
        // the bridge enforces its own authed-vs-guest logic per action.
        // None are retryable — all mutate cart/order/payment state.
        'checkout/summary'                            => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/setBillingAddress'                  => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/setShippingAddress'                 => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/setShipmentType'                    => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/setShippingMethod'                  => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/shippingMethods'                    => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/setPickupLocation'                  => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/pickupLocations'                    => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/setPayment'                         => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/confirmOrder'                       => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/applyCoupon'                        => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/removeCoupon'                       => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/applyGiftCard'                      => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/removeGiftCard'                     => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/applyLoyaltyRedemption'             => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/removeLoyaltyRedemption'            => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/calculateTax'                       => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/setOrderNotes'                      => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/giftCardBalance'                    => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/giftRecipient'                      => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/checkEmail'                         => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/states'                             => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/advanceAddressStep'                 => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],
        'checkout/advanceShippingStep'                => ['requires_session' => true,  'requires_user' => false, 'retry_on_session_dead' => false],

        // Auth — user-required account management
        'auth/profile'                                => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'auth/updateProfile'                          => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'auth/changePassword'                         => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],

        // Addresses — user required, all mutations
        'address/list'                                => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'address/create'                              => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'address/update'                              => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'address/delete'                              => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],

        // Orders — user required
        'order/history'                               => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'order/detail'                                => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'order/recreate'                              => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],

        // Payment — user required
        'payment/nmiKey'                              => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'payment/savedCards'                          => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'payment/addCard'                             => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'payment/deleteCard'                          => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],

        // Wallet — user required
        'wallet/balance'                              => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'wallet/redemptionInfo'                       => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'wallet/transactions'                         => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],

        // Club — user-required membership management
        'club/join'                                   => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/memberships'                            => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/membershipDetail'                       => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/pause'                                  => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/resume'                                 => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/cancel'                                 => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/edit'                                   => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/billingHistory'                         => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/shipmentHistory'                        => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/upcomingShipments'                      => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/shipmentCustomization'                  => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/shipmentCustomizationAddons'            => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/shipmentCustomizationItem'              => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/shipmentCustomizationNote'              => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],
        'club/shipmentCustomizationSubmit'            => ['requires_session' => true,  'requires_user' => true,  'retry_on_session_dead' => false],

    ];

    /**
     * Whether this route needs ANY token (guest or authed) before it fires.
     * If true and no token exists, BridgeApiClient will mint a guest token
     * lazily before dispatching the request.
     */
    public static function requiresSession(string $route): bool
    {
        $route = ltrim($route, '/');
        return isset(self::$routes[$route]) && !empty(self::$routes[$route]['requires_session']);
    }

    /**
     * Whether this route requires an authenticated (logged-in) user token.
     * A guest token is insufficient; the bridge will return login_required.
     */
    public static function requiresUser(string $route): bool
    {
        $route = ltrim($route, '/');
        return isset(self::$routes[$route]) && !empty(self::$routes[$route]['requires_user']);
    }

    /**
     * Whether a session_dead 401 on this route should trigger a mint-and-
     * retry exactly once. Only safe for idempotent reads (cart/get, etc.).
     * Never true for mutations — a silent retry would execute the action twice.
     */
    public static function retryOnSessionDead(string $route): bool
    {
        $route = ltrim($route, '/');
        return isset(self::$routes[$route]) && !empty(self::$routes[$route]['retry_on_session_dead']);
    }
}
