<?php

namespace Bottle360\Bridge\Settings;

final class Options
{
    // --- Connection ---
    public const OPT_BASE_URL             = 'b360_bridge_base_url';
    public const OPT_PUBLIC_URL           = 'b360_bridge_public_url';
    public const OPT_BRIDGE_CLIENT_ID     = 'b360_bridge_client_id';
    public const OPT_BRIDGE_CLIENT_SECRET = 'b360_bridge_client_secret';

    // --- App ---
    public const OPT_APP_BASE_PATH    = 'b360_bridge_app_base_path';
    public const OPT_APP_DISCONNECTED = 'b360_app_page_disconnected';

    // --- Squarespace embed (#5237 public_embed client — PUBLIC values only) ---
    // DISTINCT from OPT_BRIDGE_CLIENT_ID/SECRET (the confidential server-to-server
    // client). The embed sends both a public client id and a public embed key;
    // the confidential secret NEVER enters the export path.
    public const OPT_EMBED_CLIENT_ID  = 'b360_embed_client_id';
    public const OPT_EMBED_KEY        = 'b360_embed_key';
    public const OPT_EMBED_BUNDLE_URL = 'b360_embed_bundle_url';

    // --- Storefront ---
    public const OPT_MEMBERSHIP_PAUSE = 'b360_membership_pause_enabled';

    // --- Typography ---
    // Google Fonts *Developer API* key. Used ONLY server-side, to fetch the
    // family catalogue for the Styling Studio dropdown. Never emitted to the
    // browser: the studio calls our own /b360/v1/google-fonts proxy instead.
    // Serving the font FILES needs no key at all.
    public const OPT_GOOGLE_FONTS_API_KEY = 'b360_google_fonts_api_key';

    // --- Advanced ---
    public const OPT_DISABLE_CACHE = 'b360_bridge_disable_cache';
    public const OPT_DEBUG         = 'b360_bridge_debug';

    // --- Connection getters ---

    public static function get_base_url(): string
    {
        return trim((string) get_option(self::OPT_BASE_URL, ''));
    }

    /**
     * Server-to-server URL for the admin site. Empty string when unconfigured —
     * callers that need to act on missing config should check isConfigured() on
     * BridgeApiClient rather than this return value.
     */
    public static function get_base_host(): string
    {
        return rtrim(self::get_base_url(), '/');
    }

    /**
     * Browser-facing URL for images and links.
     * Falls back to get_base_host() if not set.
     */
    public static function get_public_url(): string
    {
        $public = trim((string) get_option(self::OPT_PUBLIC_URL, ''));
        return $public !== '' ? rtrim($public, '/') : self::get_base_host();
    }

    public static function get_bridge_client_id(): string
    {
        return trim((string) get_option(self::OPT_BRIDGE_CLIENT_ID, ''));
    }

    public static function get_bridge_client_secret(): string
    {
        return trim((string) get_option(self::OPT_BRIDGE_CLIENT_SECRET, ''));
    }

    // --- Squarespace embed getters (all PUBLIC — safe to localize to JS) ---

    /**
     * The #5237 public_embed client's id. Distinct from get_bridge_client_id()
     * (the confidential client). Empty string when unconfigured.
     */
    public static function get_embed_client_id(): string
    {
        return trim((string) get_option(self::OPT_EMBED_CLIENT_ID, ''));
    }

    /**
     * The public embed key (`b360e_…`). PUBLIC by design — its authority is
     * bounded server-side by the #5237 exact-origin allowlist + route scopes,
     * so it is safe to store and emit to the browser. This is NOT the secret.
     */
    public static function get_embed_key(): string
    {
        return trim((string) get_option(self::OPT_EMBED_KEY, ''));
    }

    /**
     * Evergreen hosted embed bundle URL. Empty default (hosting decision
     * pending) — the export builder falls back to a placeholder when unset.
     */
    public static function get_embed_bundle_url(): string
    {
        return trim((string) get_option(self::OPT_EMBED_BUNDLE_URL, ''));
    }

    /**
     * Browser-facing bridge origin the EMBED calls, for the Squarespace export.
     * Unlike get_public_url(), this does NOT fall back to the server-to-server
     * admin host (OPT_BASE_URL) — that host may be internal/unreachable from a
     * visitor's browser, and baking it into data-bridge-url would ship a broken
     * snippet. Returns the configured Public Asset URL, or '' so the export
     * falls back to a clearly-marked placeholder the tenant must replace.
     */
    public static function get_embed_bridge_url(): string
    {
        $public = trim((string) get_option(self::OPT_PUBLIC_URL, ''));
        return $public !== '' ? rtrim($public, '/') : '';
    }

    // --- App getters ---

    /**
     * Effective URL path the SPA operates under, derived from the app page itself.
     *
     * Always returns a non-empty, leading-slash prefix (e.g. '/store',
     * '/shop/retail'). The SPA must live at a dedicated sub-path; root-mount
     * ("app page = homepage") is no longer supported, because it forces PHP
     * and JS to maintain parallel hardcoded allowlists of SPA segments to
     * tell SPA links apart from real WP pages at root.
     *
     * If an admin has manually set the app page as `page_on_front` via
     * Reading Settings, `get_permalink()` would resolve it to `/`. We bypass
     * that by reading the page's slug path directly with `get_page_uri()`,
     * and raise an admin notice so the site owner knows the setup is wrong.
     *
     * Falls back to the configured setup slug before the page exists.
     */
    public static function get_app_base_path(): string
    {
        // Memoized for the life of the PHP-FPM worker (NOT just one request —
        // class statics survive between requests handled by the same worker).
        // That's fine here because the inputs (app page id, its slug path)
        // only change when the admin edits the page or runs the activator,
        // both of which invalidate surrounding caches. The per-request
        // misconfiguration check below runs BEFORE the memo, so it still
        // fires on every request even after the path has been computed once.
        static $cached = null;

        $page_id = (int) get_option('b360_app_page_id', 0);

        // Fallback for installs that never recorded the app page id (e.g.
        // plugin was deployed via git without activation): look the page up
        // by the configured setup slug so the SPA still renders correctly.
        if (!$page_id) {
            $slug = trim(self::get_app_setup_slug(), '/');
            if ($slug !== '') {
                $page = get_page_by_path($slug, OBJECT, 'page');
                if ($page && $page->post_status === 'publish') {
                    $page_id = (int) $page->ID;
                }
            }
        }

        // Flag the homepage-mount misconfiguration so the admin can fix it.
        // Runs on every call (per-request option reads are cheap, WP caches
        // them). If the admin fixes Reading Settings, this stops setting the
        // transient and it expires within the hour — the notice goes away
        // on its own, no worker recycle required.
        if ($page_id
            && (int) get_option('page_on_front') === $page_id
            && get_option('show_on_front') === 'page') {
            set_transient('b360_app_page_is_homepage', 1, HOUR_IN_SECONDS);
        }

        if ($cached !== null) {
            return $cached;
        }

        if ($page_id && get_post_status($page_id) === 'publish') {
            // get_page_uri() returns the slug path ("store", "shop/retail")
            // regardless of page_on_front. get_permalink() does not — it
            // collapses the homepage page to "/".
            $uri = get_page_uri($page_id);
            if (is_string($uri) && $uri !== '') {
                $trimmed = trim($uri, '/');
                if ($trimmed !== '') {
                    return $cached = '/' . $trimmed;
                }
            }
        }
        return $cached = self::get_app_setup_slug();
    }

    /**
     * Raw slug setting used at page-creation time (see Activator::ensureAppPage).
     * Not the right thing to use at runtime — use get_app_base_path() instead.
     */
    public static function get_app_setup_slug(): string
    {
        $path = trim((string) get_option(self::OPT_APP_BASE_PATH, '/store'));
        return $path === '' ? '/store' : '/' . trim($path, '/');
    }

    /**
     * Whether the admin has explicitly disconnected the plugin from its app
     * page. When true, Activator::maybeHeal MUST NOT recreate or re-adopt a
     * page — the self-heal loop is what fights admins trying to clean up.
     * Set/cleared by the Disconnect / Reconnect buttons on the settings page.
     */
    public static function is_app_disconnected(): bool
    {
        return (bool) get_option(self::OPT_APP_DISCONNECTED, false);
    }

    // --- Storefront getters ---

    /**
     * Whether members may pause their own memberships from the account UI.
     * Site-wide kill switch layered ON TOP of the per-club admin flag
     * (`club_settings.allow_customer_pause`): the Pause button shows only when
     * BOTH this and the club flag are true. Defaults TRUE so existing sites are
     * unchanged; the site builder flips it off in Settings → Storefront.
     */
    /**
     * Google Fonts Developer API key, or '' when unconfigured. Only the
     * catalogue lookup needs this; font delivery does not.
     */
    public static function get_google_fonts_api_key(): string
    {
        return trim((string) get_option(self::OPT_GOOGLE_FONTS_API_KEY, ''));
    }

    public static function has_google_fonts_api_key(): bool
    {
        return self::get_google_fonts_api_key() !== '';
    }

    public static function is_membership_pause_enabled(): bool
    {
        return (bool) get_option(self::OPT_MEMBERSHIP_PAUSE, true);
    }

    // --- Advanced getters ---

    public static function is_cache_disabled(): bool
    {
        return (bool) get_option(self::OPT_DISABLE_CACHE, false);
    }

    public static function is_debug_enabled(): bool
    {
        return (bool) get_option(self::OPT_DEBUG, false);
    }
}
