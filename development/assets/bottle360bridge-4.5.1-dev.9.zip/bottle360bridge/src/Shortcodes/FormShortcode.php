<?php

namespace Bottle360\Bridge\Shortcodes;

if (!defined('ABSPATH')) exit;

/**
 * [b360_form slug="newsletter"] / [b360-form slug="newsletter"]
 *
 * Optional layout="inline" renders the form as a compact horizontal footer
 * row (fields + submit on one wrapping line) instead of the default stacked
 * card. Anything other than "inline" falls back to "stacked".
 *
 * Emits the placeholder div that FormWidget.vue (registered in Root.vue's
 * widget registry) teleports its rendered Vuetify form into. The Vue bundle
 * is already loaded on every front-end page by Frontend\BridgeBoot, so this
 * shortcode only needs to mark up the mount point.
 */
final class FormShortcode
{
    public function register(): void
    {
        add_shortcode('b360_form', [$this, 'render']);
        add_shortcode('b360-form', [$this, 'render']);
    }

    public function render($atts = []): string
    {
        $atts = shortcode_atts([
            'slug'         => '',
            'submit_label' => '',
            'layout'       => 'stacked',
            'class'        => '',
        ], $atts, 'b360_form');

        $slug = sanitize_title((string) $atts['slug']);
        if ($slug === '') {
            return '';
        }

        $submitLabel = trim((string) $atts['submit_label']);

        $layout = strtolower(trim((string) $atts['layout']));
        if (!in_array($layout, ['stacked', 'inline'], true)) {
            $layout = 'stacked';
        }

        $classes = ['b360-form-container', 'b360-bridge-container'];
        $extra = trim((string) $atts['class']);
        if ($extra !== '') {
            foreach (preg_split('/\s+/', $extra) as $token) {
                $clean = sanitize_html_class((string) $token);
                if ($clean !== '') $classes[] = $clean;
            }
        }

        $attrs = [
            'class="' . esc_attr(implode(' ', $classes)) . '"',
            'data-b360-widget="form"',
            'data-slug="' . esc_attr($slug) . '"',
            'data-layout="' . esc_attr($layout) . '"',
        ];
        if ($submitLabel !== '') {
            $attrs[] = 'data-submit-label="' . esc_attr($submitLabel) . '"';
        }

        return '<div ' . implode(' ', $attrs) . '>'
            . '<div class="b360-loading" aria-live="polite">'
            . esc_html__('Loading…', 'b360-bridge')
            . '</div>'
            . '</div>';
    }
}
