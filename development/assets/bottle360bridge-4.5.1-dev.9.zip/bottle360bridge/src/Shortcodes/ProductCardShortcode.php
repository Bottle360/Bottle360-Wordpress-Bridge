<?php

namespace Bottle360\Bridge\Shortcodes;

use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * [b360_product_card] / [b360-product-card]
 *
 * SKU can be supplied either:
 *  - [b360_product_card sku="Maragas2017Malbec"]
 *  - /promo/?sku=Maragas2017Malbec   (with [b360_product_card] on the page)
 */
final class ProductCardShortcode
{
    public function register(): void
    {
        add_shortcode('b360_product_card', [$this, 'render']);
        add_shortcode('b360-product-card', [$this, 'render']);
    }

    public function render($atts = []): string
    {
        $raw_atts = is_array($atts) ? $atts : [];

        $atts = shortcode_atts([
            'sku'        => '',      // shortcode attribute
            'param'      => 'sku',   // GET param name fallback (default sku)
            'class'      => '',
            'empty'      => 'hide',  // hide|message
            'empty_text' => __('Missing product SKU.', 'b360-bridge'),
        ], $raw_atts, 'b360_product_card');

        // store_url was removed in favor of the canonical Options::get_app_base_path()
        // resolver — every other widget uses it, so the product card now matches.
        // Existing content that still passes store_url="..." gets a one-time notice
        // so the site owner knows the override evaporated rather than silently
        // wondering why their custom path no longer takes.
        if (!empty($raw_atts['store_url'])) {
            _doing_it_wrong(
                '[b360_product_card]',
                'The store_url attribute was removed; the SPA base path is now resolved from the Bridge plugin settings (Options::get_app_base_path).',
                '0.x'
            );
        }

        // Theme tokens come via Assets::emitThemeVars on wp_head — no
        // separate token stylesheet to enqueue.

        // Resolve SKU: shortcode sku wins, else GET[param]
        $sku = '';
        if (!empty($atts['sku']) && is_string($atts['sku'])) {
            $sku = (string) $atts['sku'];
        } else {
            $param = sanitize_key((string) $atts['param']);
            if ($param === '') $param = 'sku';
            if (isset($_GET[$param])) {
                $sku = (string) wp_unslash($_GET[$param]);
            }
        }
        $sku = trim(sanitize_text_field($sku));

        if ($sku === '') {
            if ((string) $atts['empty'] === 'message') {
                return '<div class="b360-product-card-container b360-product-card--empty">' . esc_html((string) $atts['empty_text']) . '</div>';
            }
            return '';
        }

        // Same source of truth every other widget uses (BridgeBoot, AppShortcode,
        // NavShortcode). The placeholder carries the path; the Vue router
        // joins it with the host origin via createWebHistory at click time.
        $basePath = Options::get_app_base_path();

        $id = 'b360-product-card-' . wp_generate_password(6, false);

        $classes = [
            'b360-product-card-container',
            'b360-bridge-container', // styling reuse only
        ];
        // sanitize_html_class strips spaces, so feeding it "foo bar" yields
        // "foobar". Tokenize first so multi-class shortcode usage works.
        $extra = trim((string) $atts['class']);
        if ($extra !== '') {
            foreach (preg_split('/\s+/', $extra) as $token) {
                $clean = sanitize_html_class((string) $token);
                if ($clean !== '') $classes[] = $clean;
            }
        }
        $classes = array_filter($classes, 'strlen');

        ob_start(); ?>
<div id="<?php echo esc_attr($id); ?>"
     class="<?php echo esc_attr(implode(' ', $classes)); ?>"
     data-b360-widget="product-card"
     data-b360-sku="<?php echo esc_attr($sku); ?>"
     data-base-path="<?php echo esc_attr($basePath); ?>">
  <div class="b360-loading" aria-live="polite"><?php echo esc_html__('Loading…', 'b360-bridge'); ?></div>
</div>
<?php
        return (string) ob_get_clean();
    }
}
