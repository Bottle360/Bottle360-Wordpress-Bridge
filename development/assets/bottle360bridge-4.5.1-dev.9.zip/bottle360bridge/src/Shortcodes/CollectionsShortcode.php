<?php

namespace Bottle360\Bridge\Shortcodes;

if (!defined('ABSPATH')) exit;

/**
 * [b360_collections] / [b360-collections]
 *
 * Embeds the full product grid for a given category/collection slug on any
 * WordPress page — identical to navigating to /store/category/{slug} in the
 * SPA. The Vue widget fetches and renders the products client-side.
 *
 * Attributes:
 *   slug     — category slug, e.g. "red-wine" (required). Omit to show all
 *              products (equivalent to the store root listing).
 *   per_page — number of products per page (1–100, default 24).
 *   class    — extra CSS class(es) on the wrapper (optional).
 *
 * Examples:
 *   [b360_collections slug="red-wine"]
 *   [b360_collections slug="white-wine" per_page="12"]
 *   [b360_collections]  <- shows all products
 */
final class CollectionsShortcode
{
    public function register(): void
    {
        add_shortcode('b360_collections', [$this, 'render']);
        add_shortcode('b360-collections', [$this, 'render']);
    }

    public function render($atts = []): string
    {
        $atts = shortcode_atts([
            'slug'     => '',
            'per_page' => '24',
            'class'    => '',
        ], is_array($atts) ? $atts : [], 'b360_collections');

        // --- Sanitize slug ---
        $slug = sanitize_title(trim((string) $atts['slug']));

        // --- Sanitize per_page ---
        $per_page = min(100, max(1, absint($atts['per_page']) ?: 24));

        // --- Sanitize class ---
        $extra_classes = [];
        $class_raw     = trim((string) $atts['class']);
        if ($class_raw !== '') {
            foreach (preg_split('/\s+/', $class_raw) as $token) {
                $clean = sanitize_html_class((string) $token);
                if ($clean !== '') {
                    $extra_classes[] = $clean;
                }
            }
        }

        $classes    = array_merge(['b360-collections'], $extra_classes);
        $data_attrs = ' data-per-page="' . esc_attr((string) $per_page) . '"';
        if ($slug !== '') {
            $data_attrs .= ' data-slug="' . esc_attr($slug) . '"';
        }

        return '<div'
            . ' data-b360-widget="collections"'
            . $data_attrs
            . ' class="' . esc_attr(implode(' ', $classes)) . '">'
            . esc_html__('Loading&hellip;', 'b360-bridge')
            . '</div>';
    }
}
