<?php

namespace Bottle360\Bridge\Shortcodes;

if (!defined('ABSPATH')) exit;

/**
 * [b360_clubs] / [b360-clubs]
 *
 * Embeds a Vue clubs-list widget that fetches and renders club cards.
 *
 * Attributes:
 *   ids   — CSV of club IDs (optional). When set, only those clubs are shown,
 *            in the order given. E.g. ids="7,3,12" (capped at 50 IDs)
 *   cols  — number of columns (1–4, optional). Controls the Vuetify grid column
 *            width. When omitted, defaults to responsive 12/6/4 (like ClubsListing).
 *   class — extra CSS class(es) on the wrapper (optional).
 */
final class ClubsShortcode
{
    public function register()
    {
        add_shortcode('b360_clubs', array($this, 'render'));
        add_shortcode('b360-clubs', array($this, 'render'));
    }

    public function render($atts = array())
    {
        $raw_atts = is_array($atts) ? $atts : array();

        $atts = shortcode_atts(array(
            'ids'   => '',
            'cols'  => '',
            'class' => '',
        ), $raw_atts, 'b360_clubs');

        // Theme tokens come via Assets::emitThemeVars on wp_head — no
        // separate token stylesheet to enqueue.

        // --- Sanitize ids ---
        // Split on commas, absint each token, drop zeros/empties.
        $ids_attr = '';
        $ids_raw = trim((string) $atts['ids']);
        if ($ids_raw !== '') {
            $tokens = explode(',', $ids_raw);
            $clean_ids = array();
            foreach ($tokens as $token) {
                $n = absint($token);
                if ($n > 0) {
                    $clean_ids[] = $n;
                }
            }
            // Cap at 50 IDs to prevent oversized data-* attributes.
            $clean_ids = array_slice($clean_ids, 0, 50);
            if (!empty($clean_ids)) {
                $ids_attr = implode(',', $clean_ids);
            }
        }

        // --- Sanitize cols ---
        // absint, clamp 1–4. 0 or out of range => omit.
        $cols_attr = '';
        $cols_raw = trim((string) $atts['cols']);
        if ($cols_raw !== '') {
            $cols_n = absint($cols_raw);
            if ($cols_n >= 1 && $cols_n <= 4) {
                $cols_attr = (string) $cols_n;
            }
        }

        // --- Sanitize class ---
        // Tokenize on whitespace, sanitize_html_class each token.
        $extra_classes = array();
        $class_raw = trim((string) $atts['class']);
        if ($class_raw !== '') {
            foreach (preg_split('/\s+/', $class_raw) as $token) {
                $clean = sanitize_html_class((string) $token);
                if ($clean !== '') {
                    $extra_classes[] = $clean;
                }
            }
        }

        // Build class attribute
        $classes = array('b360-clubs');
        foreach ($extra_classes as $cls) {
            $classes[] = $cls;
        }

        // Build data attributes
        $data_attrs = '';
        if ($ids_attr !== '') {
            $data_attrs .= ' data-ids="' . esc_attr($ids_attr) . '"';
        }
        if ($cols_attr !== '') {
            $data_attrs .= ' data-cols="' . esc_attr($cols_attr) . '"';
        }

        return '<div'
            . ' data-b360-widget="clubs"'
            . $data_attrs
            . ' class="' . esc_attr(implode(' ', $classes)) . '">'
            . esc_html__('Loading…', 'b360-bridge')
            . '</div>';
    }
}
