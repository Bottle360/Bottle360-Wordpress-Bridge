<?php

namespace Bottle360\Bridge\Shortcodes;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Api\BridgeSession;

if (!defined('ABSPATH')) exit;

/**
 * [b360_nav] — emits the placeholder that BridgeNav.vue teleports into.
 *
 * The placeholder carries the shortcode configuration as data-attributes;
 * BridgeNav reads them via its `host` prop and renders the real nav. Until
 * the Vue bundle mounts, the inline fallback markup keeps the nav visible
 * and fully clickable (server-rendered, static <a> links + an inline-SVG
 * cart pill that visually matches the Vue output).
 *
 * Shortcode attributes match the prior implementation so existing pages
 * with [b360_nav ...] don't need to be touched.
 *
 * Full-mode flags (default 1):
 *   show_shop, show_clubs, show_cart, show_account, class
 *
 * Minimal-mode flags (truthy = 1|true|yes triggers minimal mode):
 *   show_cart, show_login, show_logout
 *
 * Render order: cart is ALWAYS emitted LAST so the layout's
 * `margin-left: auto` rule (in BridgeNav.vue's global styles) pushes it
 * to the right edge of the nav. Account/Sign-In, if present, sits to its
 * left.
 */
final class NavShortcode
{
    /**
     * Inline path data for mdiCartOutline (from @mdi/js v7.x).
     * Mirrored from the icon used in BridgeNav.vue so the server-rendered
     * fallback paints identically to the Vue output. Update both when
     * MDI ships a new revision of this glyph.
     */
    const CART_ICON_PATH = 'M17,18A2,2 0 0,1 19,20A2,2 0 0,1 17,22C15.89,22 15,21.1 15,20C15,18.89 15.89,18 17,18M1,2H4.27L5.21,4H20A1,1 0 0,1 21,5C21,5.17 20.95,5.34 20.88,5.5L17.3,11.97C16.96,12.58 16.3,13 15.55,13H8.1L7.2,14.63L7.17,14.75A0.25,0.25 0 0,0 7.42,15H19V17H7C5.89,17 5,16.1 5,15C5,14.65 5.09,14.32 5.24,14.04L6.6,11.59L3,4H1V2M7,18A2,2 0 0,1 9,20A2,2 0 0,1 7,22C5.89,22 5,21.1 5,20C5,18.89 5.89,18 7,18M16,11L18.78,6H6.14L8.5,11H16Z';

    public function register(): void
    {
        add_shortcode('b360_nav', [$this, 'render']);
        add_shortcode('b360-nav', [$this, 'render']);
    }

    public function render($atts = []): string
    {
        $atts = shortcode_atts([
            'show_shop'    => '1',
            'show_cart'    => '',
            'show_account' => '1',
            'show_clubs'   => '1',
            'class'        => '',
            'show_login'   => '',
            'show_logout'  => '',
        ], $atts, 'b360_nav');

        wp_enqueue_style('b360-nav');

        $base   = Options::get_app_base_path();
        $isAuth = BridgeSession::isAuthenticated();

        $wrapperClass = trim((string) $atts['class']);

        $minimal = $this->isTruthy($atts['show_cart'])
            || $this->isTruthy($atts['show_login'])
            || $this->isTruthy($atts['show_logout']);

        $dataAttrs = [
            'data-b360-widget="nav"',
            'data-base-path="' . esc_attr($base) . '"',
            'data-show-shop="'    . esc_attr((string) $atts['show_shop'])    . '"',
            'data-show-cart="'    . esc_attr((string) $atts['show_cart'])    . '"',
            'data-show-clubs="'   . esc_attr((string) $atts['show_clubs'])   . '"',
            'data-show-login="'   . esc_attr((string) $atts['show_login'])   . '"',
            'data-show-logout="'  . esc_attr((string) $atts['show_logout'])  . '"',
        ];
        // show_account is a FULL-mode flag; in minimal mode it has always been
        // ignored, and BridgeNav.vue now treats a truthy data-show-account as
        // an explicit minimal-mode opt-in (for embed hosts, whose attrs are
        // always author-written). Because shortcode_atts() defaults it to '1',
        // emitting it here in minimal mode would flip every existing WP
        // minimal nav to showing the account item — so suppress it there.
        if (!$minimal) {
            $dataAttrs[] = 'data-show-account="' . esc_attr((string) $atts['show_account']) . '"';
        }
        if ($minimal) {
            $dataAttrs[] = 'data-show-cart-minimal="' . esc_attr((string) $atts['show_cart']) . '"';
        }
        if ($wrapperClass !== '') {
            $dataAttrs[] = 'data-wrapper-class="' . esc_attr(sanitize_html_class($wrapperClass)) . '"';
        }

        $fallback = $this->renderFallback($atts, $base, $isAuth, $minimal);

        return '<div ' . implode(' ', $dataAttrs) . '>' . $fallback . '</div>';
    }

    /**
     * Server-rendered static nav for the moment between page-load and
     * BridgeNav.vue mount. Vue replaces innerHTML on mount, so this only
     * paints during the bundle-fetch window (and on no-JS browsers / SEO
     * crawlers, which is also desirable).
     *
     * Class names exactly match BridgeNav so theme CSS lights up
     * identically in both rendering paths.
     *
     * Cart is always emitted last so the CSS rule
     * `.b360-nav__item--cart { margin-left: auto; }` pushes it right.
     *
     * @param array  $atts
     * @param string $base
     * @param bool   $isAuth
     * @param bool   $minimal
     * @return string
     */
    private function renderFallback($atts, $base, $isAuth, $minimal)
    {
        $items = $minimal
            ? $this->minimalItems($atts, $base, $isAuth)
            : $this->fullItems($atts, $base, $isAuth);

        if (empty($items)) return '';

        $wrapperClass = trim((string) $atts['class']);
        $wrap = 'b360-nav';
        if ($wrapperClass !== '') {
            $wrap .= ' ' . sanitize_html_class($wrapperClass);
        }

        $out  = '<nav class="' . esc_attr($wrap) . '" aria-label="Store navigation">';
        $out .= '<ul class="b360-nav__list">';
        foreach ($items as $item) {
            if ($item['kind'] === 'cart') {
                $out .= '<li class="b360-nav__item b360-nav__item--cart">'
                     . $this->renderCartButton()
                     . '</li>';
            } else {
                $out .= '<li class="b360-nav__item ' . esc_attr($item['class']) . '">'
                     . '<a href="' . esc_url($item['url']) . '" class="b360-nav__link">'
                     . esc_html($item['label']) . '</a>'
                     . '</li>';
            }
        }
        $out .= '</ul></nav>';
        return $out;
    }

    /**
     * Emit the cart pill markup as a button containing the inline cart
     * SVG. Visually matches BridgeNav.vue's cart slot so the server →
     * Vue handoff paints identically.
     *
     * @return string
     */
    private function renderCartButton()
    {
        return '<button type="button" class="b360-nav__cart" data-b360-open-sidebar aria-label="'
            . esc_attr__('Cart', 'b360-bridge')
            . '">'
            . '<svg class="b360-nav__cart-icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">'
            . '<path fill="currentColor" d="' . esc_attr(self::CART_ICON_PATH) . '"/>'
            . '</svg>'
            . '</button>';
    }

    /**
     * Full-mode item list. Cart is appended LAST so the CSS auto-margin
     * pushes it (and only it) to the right edge of the nav.
     */
    private function fullItems($atts, $base, $isAuth)
    {
        $items = [];
        if ((string) $atts['show_shop'] === '1') {
            $items[] = ['kind' => 'link', 'url' => home_url($base . '/'),       'label' => __('Shop', 'b360-bridge'),       'class' => 'b360-nav__item--shop'];
        }
        if ((string) $atts['show_clubs'] === '1') {
            $items[] = ['kind' => 'link', 'url' => home_url($base . '/clubs/'), 'label' => __('Wine Clubs', 'b360-bridge'), 'class' => 'b360-nav__item--clubs'];
        }
        if ((string) $atts['show_account'] === '1') {
            $items[] = [
                'kind'  => 'link',
                'url'   => home_url($base . ($isAuth ? '/account/' : '/login/')),
                'label' => $isAuth ? __('My Account', 'b360-bridge') : __('Sign In', 'b360-bridge'),
                'class' => $isAuth ? 'b360-nav__item--account' : 'b360-nav__item--login',
            ];
        }
        if ((string) $atts['show_cart'] !== '0') {
            $items[] = ['kind' => 'cart'];
        }
        return $items;
    }

    /**
     * Minimal-mode item list. Same ordering invariant — cart last.
     */
    private function minimalItems($atts, $base, $isAuth)
    {
        $items = [];
        if ($this->isTruthy($atts['show_login'])) {
            $items[] = [
                'kind'  => 'link',
                'url'   => home_url($base . ($isAuth ? '/account/' : '/login/')),
                'label' => $isAuth ? __('My Account', 'b360-bridge') : __('Sign In', 'b360-bridge'),
                'class' => $isAuth ? 'b360-nav__item--account' : 'b360-nav__item--login',
            ];
        }
        // show_logout adds an account link when authenticated, but only if
        // show_login didn't already emit the same slot.
        if ($this->isTruthy($atts['show_logout']) && $isAuth && !$this->isTruthy($atts['show_login'])) {
            $items[] = [
                'kind'  => 'link',
                'url'   => home_url($base . '/account/'),
                'label' => __('My Account', 'b360-bridge'),
                'class' => 'b360-nav__item--account',
            ];
        }
        if ($this->isTruthy($atts['show_cart'])) {
            $items[] = ['kind' => 'cart'];
        }
        return $items;
    }

    /**
     * @param string $value
     * @return bool
     */
    private function isTruthy($value)
    {
        $v = strtolower(trim((string) $value));
        return $v === '1' || $v === 'true' || $v === 'yes';
    }
}
