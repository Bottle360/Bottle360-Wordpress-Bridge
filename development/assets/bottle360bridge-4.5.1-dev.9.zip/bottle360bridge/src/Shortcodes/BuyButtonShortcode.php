<?php

namespace Bottle360\Bridge\Shortcodes;

use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * [b360_buy_button] / [b360-buy-button]
 *
 * A live "buy button" for an arbitrary theme/marketing page — renders the
 * [data-b360-widget="buy-button"] placeholder the shared Vue app (Root.vue)
 * fills in with the SKU's real price, sold-out state, and add-to-cart. The
 * Squarespace counterpart is the raw div; on WordPress this shortcode emits
 * the same contract.
 *
 * Usage:
 *   [b360_buy_button sku="21NCS"]
 *   [b360_buy_button sku="21NCS" label="Add to cart" show_price="1"]
 *   [b360_buy_button]              (with ?sku=21NCS in the URL)
 */
final class BuyButtonShortcode
{
    public function register(): void
    {
        add_shortcode('b360_buy_button', [$this, 'render']);
        add_shortcode('b360-buy-button', [$this, 'render']);
    }

    public function render($atts = []): string
    {
        $raw_atts = is_array($atts) ? $atts : [];

        $atts = shortcode_atts([
            'sku'        => '',
            'param'      => 'sku',   // GET param fallback
            'label'      => '',      // button text (widget default when empty)
            'show_price' => '',      // "1" to append the price to the label
            'class'      => '',
            'empty'      => 'hide',  // hide|message
            'empty_text' => __('Missing product SKU.', 'b360-bridge'),
        ], $raw_atts, 'b360_buy_button');

        // Resolve SKU: shortcode sku wins, else GET[param].
        $sku = '';
        if (!empty($atts['sku']) && is_string($atts['sku'])) {
            $sku = (string) $atts['sku'];
        } else {
            $param = sanitize_key((string) $atts['param']);
            if ($param === '') $param = 'sku';
            if (isset($_GET[$param])) {
                $sku = (string) wp_unslash($_GET[$param]);
            }
        }
        $sku = trim(sanitize_text_field($sku));

        if ($sku === '') {
            if ((string) $atts['empty'] === 'message') {
                return '<div class="b360-buy-button-container b360-buy-button--empty">' . esc_html((string) $atts['empty_text']) . '</div>';
            }
            return '';
        }

        $label = trim(sanitize_text_field((string) $atts['label']));
        $showPrice = in_array(strtolower(trim((string) $atts['show_price'])), ['1', 'true', 'yes'], true);

        // Same base-path source every other widget uses (BridgeBoot, AppShortcode).
        $basePath = Options::get_app_base_path();
        $id = 'b360-buy-button-' . wp_generate_password(6, false);

        $classes = ['b360-buy-button-container', 'b360-bridge-container'];
        $extra = trim((string) $atts['class']);
        if ($extra !== '') {
            foreach (preg_split('/\s+/', $extra) as $token) {
                $clean = sanitize_html_class((string) $token);
                if ($clean !== '') $classes[] = $clean;
            }
        }
        $classes = array_filter($classes, 'strlen');

        // Emit data-b360-label / data-b360-show-price only when set, so the
        // widget's own defaults apply otherwise (mirrors the JS-side reads).
        $labelAttr = $label !== '' ? ' data-b360-label="' . esc_attr($label) . '"' : '';
        $showPriceAttr = $showPrice ? ' data-b360-show-price="1"' : '';

        ob_start(); ?>
<div id="<?php echo esc_attr($id); ?>"
     class="<?php echo esc_attr(implode(' ', $classes)); ?>"
     data-b360-widget="buy-button"
     data-b360-sku="<?php echo esc_attr($sku); ?>"<?php echo $labelAttr . $showPriceAttr; ?>
     data-base-path="<?php echo esc_attr($basePath); ?>">
  <div class="b360-loading" aria-live="polite"><?php echo esc_html__('Loading…', 'b360-bridge'); ?></div>
</div>
<?php
        return (string) ob_get_clean();
    }
}
