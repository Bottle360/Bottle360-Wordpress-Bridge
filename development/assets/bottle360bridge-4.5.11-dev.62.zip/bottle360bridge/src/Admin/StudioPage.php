<?php

namespace Bottle360\Bridge\Admin;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Support\Nonce;
use Bottle360\Bridge\Support\ViteAssets;

if (!defined('ABSPATH')) exit;

/**
 * Bridge Styling Studio host page.
 *
 * Registers a submenu under the Bottle360 menu that mounts a fullscreen
 * Vue SPA (frontend/studio.ts) over wp-admin. The admin chrome is left
 * intact in the DOM, the studio root sits above it via position:fixed
 * inset:0 with a high z-index, so we don't have to fight wp-admin's
 * layout or worry about dequeuing scripts.
 */
final class StudioPage
{
    public const SLUG = 'b360_bridge_studio';

    public function register(): void
    {
        \add_action('admin_menu', [$this, 'add_menu'], 20);
        \add_action('admin_enqueue_scripts', [$this, 'maybe_enqueue']);
        \add_filter('admin_body_class', [$this, 'maybe_body_class']);
        // Mint a fresh wp_rest nonce for the studio's save self-heal. admin-ajax
        // is COOKIE-authenticated and runs as the logged-in user, so unlike a
        // REST route it is never demoted to uid 0 when the request carries no
        // (valid) wp_rest nonce, which is exactly why the studio can recover a
        // stale nonce here but not from a public REST endpoint. wp_ajax_ (no
        // _nopriv variant) already requires login; we additionally gate on the
        // studio capability. No CSRF nonce on the request itself (you'd need a
        // nonce to get a nonce); minting is side-effect-free and the response is
        // unreadable cross-origin, so there is nothing to exfiltrate.
        \add_action('wp_ajax_b360_studio_refresh_nonce', [$this, 'ajax_refresh_nonce']);
    }

    public function ajax_refresh_nonce(): void
    {
        if (!\current_user_can('manage_options')) {
            \wp_send_json_error(['message' => 'forbidden'], 403);
        }
        \wp_send_json_success(['wp_rest' => \wp_create_nonce('wp_rest')]);
    }

    public function add_menu(): void
    {
        \add_submenu_page(
            'b360_bridge',
            __('Bridge Styling Studio', 'b360-bridge'),
            __('Styling Studio', 'b360-bridge'),
            'manage_options',
            self::SLUG,
            [$this, 'render']
        );
    }

    private function is_studio_screen(): bool
    {
        $screen = function_exists('get_current_screen') ? \get_current_screen() : null;
        if (!$screen) return false;
        // The screen id for an add_submenu_page() page under a custom parent
        // is "{parent_slug}_page_{slug}". Belt-and-braces: also accept the
        // raw slug for environments that munge it.
        return strpos($screen->id, self::SLUG) !== false;
    }

    public function maybe_body_class(string $classes): string
    {
        if ($this->is_studio_screen()) {
            $classes .= ' b360-studio-fullscreen';
        }
        return $classes;
    }

    public function maybe_enqueue(string $hook): void
    {
        if (!$this->is_studio_screen()) return;

        // WP Media Library, the Brand section opens this modal for logo
        // selection. wp_enqueue_media() loads the core script bundle that
        // exposes window.wp.media() and registers .media-modal markup.
        \wp_enqueue_media();

        // Bridge config + theme vars: the studio reads these on boot to know
        // where the REST API lives and what the current theme looks like.
        \add_action('admin_print_footer_scripts', [$this, 'emit_boot_script'], 1);
        \add_action('admin_head', [$this, 'emit_chrome_css'], 1);
        \add_action('admin_head', [$this, 'emit_theme_vars'], 2);
        \add_action('admin_print_footer_scripts', [$this, 'emit_studio_tags'], 5);
    }

    public function emit_chrome_css(): void
    {
        // CSS lives in assets/css/b360-studio-chrome.css so styling edits
        // don't need a PHP touch. Inlined (not enqueued) to avoid a
        // separate HTTP roundtrip on the studio admin screen and to dodge
        // any flash before the chrome rule paints.
        $path = B360_BRIDGE_DIR . 'assets/css/b360-studio-chrome.css';
        $css  = file_get_contents($path);
        if ($css === false) {
            \wp_die(
                'Bridge Styling Studio: missing required stylesheet at '
                . esc_html($path) . '. Reinstall the plugin.',
                'Bridge Styling Studio',
                ['response' => 500]
            );
        }
        // Belt-and-braces: scrub any stray closing </style> so a malformed
        // stylesheet can't break out of the inline block and inject markup
        // into the admin page. Gated behind manage_options so the surface
        // is low-risk, but cheap to harden.
        $css = str_ireplace('</style>', '', $css);
        echo '<style id="b360-studio-chrome">' . $css . '</style>';
    }

    public function emit_theme_vars(): void
    {
        // Reuse the storefront emitter so the studio chrome can preview
        // tokens too if it wants. Cheap to call; only emits inline CSS.
        if (class_exists('Bottle360\\Bridge\\Frontend\\Assets')) {
            (new \Bottle360\Bridge\Frontend\Assets())->emitThemeVars();
        }
    }

    public function emit_boot_script(): void
    {
        // wp_rest nonce is what WP's REST cookie auth checks via X-WP-Nonce
        // header. Without it, the PUT /b360/v1/theme call would fail
        // permission_callback even with a logged-in admin cookie.
        $base_path = '/store';
        if (class_exists('Bottle360\\Bridge\\Settings\\Options')) {
            $base_path = \Bottle360\Bridge\Settings\Options::get_app_base_path();
        }
        $config = \wp_json_encode([
            'restUrl'      => \esc_url_raw(\rest_url('b360/v1/')),
            'ajaxUrl'      => \esc_url_raw(\admin_url('admin-ajax.php')),
            'nonce'        => Nonce::value(),
            'wpRestNonce'  => \wp_create_nonce('wp_rest'),
            'mode'         => 'studio',
            'previewUrl'   => \home_url('/'),
            'siteUrl'      => \home_url('/'),
            'basePath'     => $base_path,
            // Squarespace export connection, PUBLIC values only. The confidential
            // client secret (Options::get_bridge_client_secret()) must NEVER be
            // referenced here or anywhere else in the export path: the embed key is
            // public by design (#5237 bounds it by origin allowlist + route scopes),
            // but the secret is server-to-server and has no place in the browser.
            'squarespace'  => [
                // get_embed_bridge_url (NOT get_public_url), never falls back to
                // the internal admin host for this browser-facing value.
                'bridgeUrl' => \esc_url_raw(Options::get_embed_bridge_url()),
                'clientId'  => Options::get_embed_client_id(),
                'embedKey'  => Options::get_embed_key(),   // PUBLIC, safe to emit
                'bundleUrl' => \esc_url_raw(Options::get_embed_bundle_url()),
            ],
        ]);
        echo '<script>window.B360Bridge = ' . $config . ';</script>' . "\n";
    }

    public function emit_studio_tags(): void
    {
        echo ViteAssets::renderStudioTags() . "\n";
    }

    public function render(): void
    {
        // The wp-admin shell wraps this output. Our root div uses
        // position:fixed (see emit_chrome_css) to escape that wrapper
        // and cover the whole viewport.
        echo '<div id="b360-studio-root"></div>';
    }
}
