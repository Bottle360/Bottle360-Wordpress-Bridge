<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Settings\Options;
use WP_REST_Request;

if (!defined('ABSPATH')) exit;

/**
 * Google Fonts catalogue proxy for the Styling Studio's font dropdown.
 *
 * Why a proxy rather than calling Google from the studio directly:
 *   - The Developer API key must never reach the browser. Anything shipped to
 *     the client is public, and a leaked key can be run up against the owner's
 *     quota. The key is read from wp_options here and never serialized out.
 *   - The catalogue is ~1500 families and changes rarely, so it is cached in a
 *     transient. The studio can hit this endpoint freely without burning quota.
 *   - We slim the payload down to what the dropdown needs (family, category,
 *     weights). Google's raw response includes per-variant file URLs for every
 *     family, which is megabytes we would only throw away.
 *
 * Note the key is only needed to LIST families. Serving the font files is a
 * plain CSS request to fonts.googleapis.com and needs no credentials, so the
 * storefront keeps working regardless of whether a key is configured.
 */
final class GoogleFontsController extends RestBase
{
    private const CACHE_KEY = 'b360_google_fonts_catalogue';
    private const CACHE_TTL = DAY_IN_SECONDS;
    private const API_URL   = 'https://www.googleapis.com/webfonts/v1/webfonts';

    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/google-fonts', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_fonts'],
            // Admin-only: this is a studio authoring tool, not storefront data.
            'permission_callback' => [$this, 'require_manage_options'],
            'args'                => [
                'refresh' => [
                    'type'              => 'boolean',
                    'required'          => false,
                    'sanitize_callback' => function ($v) { return (bool) $v; },
                ],
            ],
        ]);
    }

    public function require_manage_options(): bool
    {
        return current_user_can('manage_options');
    }

    /**
     * Pulls the machine-readable rejection reason out of Google's error body,
     * per the documented `google.rpc.ErrorInfo` shape:
     *
     *   { "error": { "details": [
     *       { "@type": ".../ErrorInfo", "reason": "API_KEY_INVALID", "domain": "googleapis.com", ... }
     *   ] } }
     *
     * `@type` is compared on its suffix, not equality, because the prefix is
     * a type-server URL that can vary. This is untrusted third-party JSON,
     * `details` may be absent, not an array, or contain entries that aren't
     * arrays or are missing any of these keys, so every access is guarded.
     * Returns '' (never a notice/fatal) when no matching entry is found.
     */
    private static function extract_error_reason($body): string
    {
        if (!is_array($body)) return '';
        $error = $body['error'] ?? null;
        if (!is_array($error)) return '';
        $details = $error['details'] ?? null;
        if (!is_array($details)) return '';

        foreach ($details as $detail) {
            if (!is_array($detail)) continue;

            $type   = isset($detail['@type']) && is_string($detail['@type']) ? $detail['@type'] : '';
            $domain = isset($detail['domain']) && is_string($detail['domain']) ? $detail['domain'] : '';
            $reason = isset($detail['reason']) && is_string($detail['reason']) ? $detail['reason'] : '';

            if ($reason === '' || $domain !== 'googleapis.com') continue;
            if (substr($type, -9) !== 'ErrorInfo') continue;

            return $reason;
        }

        return '';
    }

    /**
     * Maps Google's documented `reason` enum (from `google.rpc.ErrorInfo`) to
     * an actionable next step. This is the primary mechanism, the enum is
     * stable and machine-readable, unlike the prose message it accompanies.
     * Returns '' for a reason we don't map, never guess, since a wrong hint
     * sends the operator to change the wrong setting.
     */
    private static function hint_for_reason(string $reason): string
    {
        $received = __('Reaching this error means the key was received and parsed by Google, the key exists and the request is well-formed. This is a policy setting, not a typo.', 'b360-bridge');

        switch ($reason) {
            // Referrer restriction: this is the one that prompted this mapping.
            // A server-to-server request (which is how this endpoint calls
            // Google, precisely so the key never reaches the browser) sends no
            // Referer header at all, so an HTTP-referrer restriction can never
            // be satisfied here, no list of allowed domains fixes it.
            case 'API_KEY_HTTP_REFERRER_BLOCKED':
                return $received . ' ' . __('The key is restricted to HTTP referrers, but the Bridge calls Google from the server so the browser never sees the key, and a server-to-server request sends no referer. Referrer restrictions cannot work for this request under any configuration, so adding this site\'s domain to the allowed list will not help. In Google Cloud Console, set the key\'s Application restrictions to "None" and keep its API restrictions limited to the Web Fonts Developer API.', 'b360-bridge');

            // IP restriction: the server's outbound address isn't allow-listed.
            case 'API_KEY_IP_ADDRESS_BLOCKED':
                return $received . ' ' . __('The key is restricted to specific IP addresses, and this server\'s address is not on the allowed list. In Google Cloud Console, add this server\'s outbound IP address to the key\'s Application restrictions, or remove the IP restriction.', 'b360-bridge');

            // Key restricted to a mobile app: structurally the same problem
            // as the referrer case, a server-to-server call can never carry
            // proof of an Android/iOS app under any configuration.
            case 'API_KEY_ANDROID_APP_BLOCKED':
            case 'API_KEY_IOS_APP_BLOCKED':
                return $received . ' ' . __('The key is restricted to a mobile app, but the Bridge calls Google from the server, a server-to-server request can never satisfy an Android or iOS app restriction under any configuration. In Google Cloud Console, set the key\'s Application restrictions to "None", or use a separate, unrestricted key for this purpose.', 'b360-bridge');

            // Key's API restrictions don't include this API. Distinct from
            // "API not enabled" (SERVICE_DISABLED) below: this is a setting
            // on the key itself, not on the project.
            case 'API_KEY_SERVICE_BLOCKED':
                return $received . ' ' . __('The key is restricted to a set of APIs that does not include the Web Fonts Developer API. In Google Cloud Console, on the key\'s settings page, either add "Web Fonts Developer API" to its API restrictions or set API restrictions to "Don\'t restrict key". This is a different setting from Application restrictions, check the API restrictions list specifically.', 'b360-bridge');

            // API not enabled for the project.
            case 'SERVICE_DISABLED':
                return $received . ' ' . __('The Web Fonts Developer API is not enabled for the project this key belongs to. In Google Cloud Console, enable the "Web Fonts Developer API" for that project.', 'b360-bridge');

            // Billing not enabled on the project.
            case 'BILLING_DISABLED':
                return $received . ' ' . __('Billing is not enabled on the Google Cloud project this key belongs to. The Web Fonts Developer API requires an active billing account, even within the free tier. Enable billing for the project in Google Cloud Console.', 'b360-bridge');

            // Key invalid or malformed, the only case where the key itself,
            // not a policy setting, is the problem, so the $received preamble
            // (which asserts the key was found and parsed) doesn't apply.
            case 'API_KEY_INVALID':
                return __('The key itself appears to be wrong. Re-copy the API key from Google Cloud Console and re-enter it under Settings → Bottle360 Bridge → Storefront.', 'b360-bridge');

            default:
                return '';
        }
    }

    /**
     * Fallback for when Google's response doesn't include a structured
     * `details[].reason` (older/edge response shapes, or a future change),
     * sniffs the human-readable message instead. Pure function of the
     * message string so it can be exercised directly in tests/manual checks.
     * Returns '' when the reason isn't one we recognise, never guess, since
     * a wrong hint sends the operator to change the wrong setting. Matching
     * is case-insensitive and on distinctive substrings (Google's exact
     * wording shifts over time), and branches are mutually exclusive so at
     * most one hint is ever appended.
     *
     * Order matters: the API-not-enabled markers are checked before the
     * invalid-key markers because Google's legacy "Access Not Configured"
     * message also contains the phrase "Developer Key not valid", checking
     * "not valid" first would misroute that message to the wrong hint.
     */
    private static function hint_for_rejection(string $reason): string
    {
        $reason = strtolower($reason);
        if ($reason === '') return '';

        $received = __('Reaching this error means the key was received and parsed by Google, the key exists and the request is well-formed. This is a policy setting, not a typo.', 'b360-bridge');

        // Referrer restriction: this is the one that prompted this mapping.
        // A server-to-server request (which is how this endpoint calls
        // Google, precisely so the key never reaches the browser) sends no
        // Referer header at all, so an HTTP-referrer restriction can never
        // be satisfied here, no list of allowed domains fixes it.
        $has_referrer_word = strpos($reason, 'referer') !== false || strpos($reason, 'referrer') !== false;
        if ($has_referrer_word && strpos($reason, 'block') !== false) {
            return $received . ' ' . __('The key is restricted to HTTP referrers, but the Bridge calls Google from the server so the browser never sees the key, and a server-to-server request sends no referer. Referrer restrictions cannot work for this request under any configuration, so adding this site\'s domain to the allowed list will not help. In Google Cloud Console, set the key\'s Application restrictions to "None" and keep its API restrictions limited to the Web Fonts Developer API.', 'b360-bridge');
        }

        // IP restriction: the server's outbound address isn't allow-listed.
        if (strpos($reason, 'ip_address_blocked') !== false
            || (strpos($reason, 'ip address') !== false && strpos($reason, 'block') !== false)
        ) {
            return $received . ' ' . __('The key is restricted to specific IP addresses, and this server\'s address is not on the allowed list. In Google Cloud Console, add this server\'s outbound IP address to the key\'s Application restrictions, or remove the IP restriction.', 'b360-bridge');
        }

        // API not enabled for the project. Checked BEFORE the invalid-key
        // branch below: Google's legacy message for this case is "Access Not
        // Configured. Developer Key not valid...", which also contains
        // "not valid" and would otherwise be misrouted there.
        if (strpos($reason, 'has not been used') !== false
            || strpos($reason, 'it is disabled') !== false
            || strpos($reason, 'not enabled') !== false
            || strpos($reason, 'access not configured') !== false
        ) {
            return $received . ' ' . __('The Web Fonts Developer API is not enabled for the project this key belongs to. In Google Cloud Console, enable the "Web Fonts Developer API" for that project.', 'b360-bridge');
        }

        // Key invalid or malformed.
        if (strpos($reason, 'not valid') !== false
            || strpos($reason, 'api_key_invalid') !== false
            || strpos($reason, 'malformed') !== false
        ) {
            return __('The key itself appears to be wrong. Re-copy the API key from Google Cloud Console and re-enter it under Settings → Bottle360 Bridge → Storefront.', 'b360-bridge');
        }

        return '';
    }

    public function get_fonts(WP_REST_Request $request)
    {
        $key = Options::get_google_fonts_api_key();
        if ($key === '') {
            // Not an error the studio should treat as a failure, it renders a
            // "add your key here" hint instead. 200 with a flag keeps that simple.
            return $this->success([
                'configured' => false,
                'fonts'      => [],
                'message'    => __('No Google Fonts API key configured. Add one under Settings → Bottle360 Bridge → Storefront.', 'b360-bridge'),
            ]);
        }

        $refresh = (bool) $request->get_param('refresh');
        if (!$refresh) {
            $cached = get_transient(self::CACHE_KEY);
            if (is_array($cached) && !empty($cached['fonts'])) {
                $cached['configured'] = true;
                $cached['cached']     = true;
                return $this->success($cached);
            }
        }

        $url = add_query_arg(
            ['key' => $key, 'sort' => 'popularity'],
            self::API_URL
        );

        $res = wp_remote_get($url, [
            'timeout' => 15,
            'headers' => ['Accept' => 'application/json'],
        ]);

        if (is_wp_error($res)) {
            return $this->error(
                sprintf(__('Could not reach Google Fonts: %s', 'b360-bridge'), $res->get_error_message()),
                502,
                'b360_gfonts_unreachable'
            );
        }

        $status = (int) wp_remote_retrieve_response_code($res);
        $body   = json_decode(wp_remote_retrieve_body($res), true);

        if ($status === 400 || $status === 403) {
            // Google reports a bad/unauthorised key this way. Surface its own
            // message text, it distinguishes "API not enabled" from "key
            // invalid" from "referrer restricted", which is what the operator
            // needs, and prefer the structured `details[].reason` enum for
            // picking the hint, falling back to sniffing the prose only when
            // no structured reason is present.
            $message_text = (is_array($body) && isset($body['error']['message']) && is_string($body['error']['message']))
                ? $body['error']['message']
                : '';

            $structured_reason = self::extract_error_reason($body);
            $hint = $structured_reason !== ''
                ? self::hint_for_reason($structured_reason)
                : self::hint_for_rejection($message_text);

            $message = trim(__('Google rejected the API key.', 'b360-bridge') . ' ' . $message_text);
            if ($hint !== '') {
                $message .= ' ' . $hint;
            }
            return $this->error(
                $message,
                400,
                'b360_gfonts_key_rejected'
            );
        }
        if ($status !== 200 || !is_array($body) || !isset($body['items']) || !is_array($body['items'])) {
            return $this->error(
                sprintf(__('Unexpected response from Google Fonts (HTTP %d).', 'b360-bridge'), $status),
                502,
                'b360_gfonts_bad_response'
            );
        }

        $fonts = [];
        foreach ($body['items'] as $item) {
            $family = isset($item['family']) ? (string) $item['family'] : '';
            // Same whitelist the theme sanitizer enforces, if a family name
            // can't survive validation there's no point offering it.
            if ($family === '' || !preg_match('/^[A-Za-z0-9 ]+$/', $family)) continue;

            $weights = [];
            foreach ((array) ($item['variants'] ?? []) as $variant) {
                $variant = (string) $variant;
                if ($variant === 'regular') { $weights[] = 400; continue; }
                if ($variant === 'italic')  { continue; }        // italics: not offered in v1
                if (preg_match('/^([1-9]00)$/', $variant, $m)) { $weights[] = (int) $m[1]; }
            }
            $weights = array_values(array_unique($weights));
            sort($weights);
            if (empty($weights)) $weights = [400];

            $fonts[] = [
                'family'   => $family,
                'category' => isset($item['category']) ? (string) $item['category'] : '',
                'weights'  => $weights,
            ];
        }

        $payload = [
            'configured' => true,
            'cached'     => false,
            'count'      => count($fonts),
            'fonts'      => $fonts,
        ];

        set_transient(self::CACHE_KEY, ['count' => $payload['count'], 'fonts' => $fonts], self::CACHE_TTL);

        return $this->success($payload);
    }
}
