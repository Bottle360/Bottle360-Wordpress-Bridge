<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Api\BridgeSession;
use Bottle360\Bridge\Settings\Options;
use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class CheckoutController extends RestBase
{
    public function register_routes(): void
    {
        // No nonce required - public availability check before user has auth state.
        // Anti-abuse: the SPA attaches a reCAPTCHA v3 token via the central
        // api/client.ts metadata (action `checkout/checkEmail`); we forward it
        // upstream via `withRecaptcha()`, mirroring `AuthController::forgot_password`.
        register_rest_route(self::NAMESPACE, '/checkout/check-email', [
            'methods'             => 'GET',
            'callback'            => [$this, 'check_email'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/states', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_states'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/billing-address', [
            'methods'             => 'POST',
            'callback'            => [$this, 'set_billing_address'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/shipping-address', [
            'methods'             => 'POST',
            'callback'            => [$this, 'set_shipping_address'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/address-step', [
            'methods'             => 'POST',
            'callback'            => [$this, 'advance_address_step'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/shipment-type', [
            'methods'             => 'POST',
            'callback'            => [$this, 'set_shipment_type'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/pickup-locations', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_pickup_locations'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/pickup-location', [
            'methods'             => 'POST',
            'callback'            => [$this, 'set_pickup_location'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/shipping-methods', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_shipping_methods'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/shipping-method', [
            'methods'             => 'POST',
            'callback'            => [$this, 'set_shipping_method'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/shipping-step', [
            'methods'             => 'POST',
            'callback'            => [$this, 'advance_shipping_step'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/calculate-tax', [
            'methods'             => 'POST',
            'callback'            => [$this, 'calculate_tax'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/coupon', [
            'methods'             => 'POST',
            'callback'            => [$this, 'apply_coupon'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/remove-coupon', [
            'methods'             => 'POST',
            'callback'            => [$this, 'remove_coupon'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/gift-card', [
            'methods'             => 'POST',
            'callback'            => [$this, 'apply_gift_card'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/remove-gift-card', [
            'methods'             => 'POST',
            'callback'            => [$this, 'remove_gift_card'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/loyalty-redemption', [
            'methods'             => 'POST',
            'callback'            => [$this, 'apply_loyalty_redemption'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/loyalty-redemption', [
            'methods'             => 'DELETE',
            'callback'            => [$this, 'remove_loyalty_redemption'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/summary', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_summary'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/payment', [
            'methods'             => 'POST',
            'callback'            => [$this, 'set_payment'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/gift-card-balance', [
            'methods'             => 'GET',
            'callback'            => [$this, 'gift_card_balance'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/order-notes', [
            'methods'             => 'POST',
            'callback'            => [$this, 'set_order_notes'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/confirm', [
            'methods'             => 'POST',
            'callback'            => [$this, 'confirm_order'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/checkout/gift-recipient', [
            'methods'             => 'POST',
            'callback'            => [$this, 'set_gift_recipient'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function set_gift_recipient(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $body = [
            'first_name' => sanitize_text_field(wp_unslash($params['first_name'] ?? '')),
            'last_name'  => sanitize_text_field(wp_unslash($params['last_name'] ?? '')),
            'email'      => sanitize_email(wp_unslash($params['email'] ?? '')),
            'message'    => sanitize_textarea_field(wp_unslash($params['message'] ?? '')),
        ];

        return $this->proxy_post('checkout/giftRecipient', $body);
    }

    public function check_email(WP_REST_Request $request)
    {
        $email = sanitize_email($request->get_param('email') ?? '');

        if ($email === '') {
            return $this->error('Email is required', 400);
        }

        // Forward the reCAPTCHA v3 token/action headers upstream so the admin
        // can enforce the gate. Mirrors the pattern used by every other
        // protected action (auth/forgotPassword, checkout/applyCoupon, etc.).
        // On verification failure the admin returns 403 + RECAPTCHA_FAILED,
        // which proxy_get/proxy_result forward to the SPA verbatim.
        return $this->proxy_get(
            'checkout/checkEmail',
            ['email' => $email],
            $this->withRecaptcha($request)
        );
    }

    public function get_states(WP_REST_Request $request)
    {
        // No cache: response depends on session shipment_type for SC filtering; see SC fix-round-2 / red-team C1.
        return $this->proxy_get('checkout/states');
    }

    public function set_billing_address(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $body = $this->build_address_body($request->get_json_params());
        // Mirror the core's auth decision onto the local flag, guarded on
        // `user_id` (see mark_authenticated_checkout_response). Lane-neutral by
        // construction: the anon deferred-materialization core strips user_id
        // from checkout-step responses (a guest shell never binds the token),
        // so the flip is a no-op there; the prod early-mint core still returns
        // user_id for an adopted/created guest, and NavShortcode, the AppRoute
        // nocache decision and BridgeApiClient's session_dead semantics all
        // rely on the mirrored flag being set at this point.
        return $this->mark_authenticated_checkout_response(
            $this->proxy_post('checkout/setBillingAddress', $body)
        );
    }

    public function set_shipping_address(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $body = $this->build_address_body($request->get_json_params());
        return $this->proxy_post('checkout/setShippingAddress', $body);
    }

    public function advance_address_step(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $shipmentType = sanitize_text_field(wp_unslash($params['shipment_type'] ?? ''));

        if (!in_array($shipmentType, ['delivery', 'pickup'], true)) {
            return $this->error('Invalid shipment type', 400);
        }

        $body = [
            'shipment_type' => $shipmentType,
        ];

        if ($shipmentType === 'delivery') {
            $shippingAddress = isset($params['shipping_address']) && is_array($params['shipping_address'])
                ? $this->build_address_body($params['shipping_address'])
                : [];
            if (empty($shippingAddress)) {
                return $this->error('Shipping address is required', 400);
            }

            $body['shipping_address'] = $shippingAddress;
            $body['same_as_shipping'] = !empty($params['same_as_shipping']);

            if ($body['same_as_shipping']) {
                $body['billing_address'] = $shippingAddress;
            } else {
                $billingAddress = isset($params['billing_address']) && is_array($params['billing_address'])
                    ? $this->build_address_body($params['billing_address'])
                    : [];
                if (empty($billingAddress)) {
                    return $this->error('Billing address is required', 400);
                }

                $body['billing_address'] = $billingAddress;
            }
        } else {
            $billingAddress = isset($params['billing_address']) && is_array($params['billing_address'])
                ? $this->build_address_body($params['billing_address'])
                : [];
            if (empty($billingAddress)) {
                return $this->error('Billing address is required', 400);
            }

            $body['billing_address'] = $billingAddress;
            $body['pickup_location_id'] = isset($params['pickup_location_id']) ? (int) $params['pickup_location_id'] : 0;
        }

        // user_id-guarded auth-flag mirror; a no-op on the anon core, required on
        // the prod early-mint core (see set_billing_address).
        return $this->mark_authenticated_checkout_response(
            $this->proxy_post('checkout/advanceAddressStep', $body, $this->withRecaptcha($request))
        );
    }

    public function set_shipment_type(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $type = sanitize_text_field(wp_unslash($params['type'] ?? ''));

        if (!in_array($type, ['delivery', 'pickup', 'received'], true)) {
            return $this->error('Invalid shipment type', 400);
        }

        return $this->proxy_post('checkout/setShipmentType', ['type' => $type]);
    }

    public function get_pickup_locations(WP_REST_Request $request)
    {
        return $this->proxy_get('checkout/pickupLocations', [], ['cache' => 1800]);
    }

    public function set_pickup_location(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();

        return $this->proxy_post('checkout/setPickupLocation', [
            'pickup_location_id' => isset($params['pickup_location_id']) ? (int) $params['pickup_location_id'] : 0,
        ]);
    }

    public function get_shipping_methods(WP_REST_Request $request)
    {
        // Shipping-rate lookups hit UPS/FedEx APIs and can be slow. Raise the
        // upstream timeout to 30 s so legitimate real-carrier rate responses
        // don't time out before they arrive. See BD-3924 (Washington UPS timeout).
        return $this->proxy_get('checkout/shippingMethods', [], ['timeout' => 30]);
    }

    public function set_shipping_method(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $methodId = sanitize_text_field(wp_unslash($params['method_id'] ?? ''));
        $shippingOption = isset($params['shipping_option']) ? (int) $params['shipping_option'] : 1;

        if ($methodId === '') {
            return $this->error('method_id is required', 400);
        }

        return $this->proxy_post('checkout/setShippingMethod', [
            'method_id'       => $methodId,
            'shipping_option' => $shippingOption,
        ]);
    }

    public function advance_shipping_step(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $methodId = sanitize_text_field(wp_unslash($params['method_id'] ?? ''));
        $shippingOption = isset($params['shipping_option']) ? (int) $params['shipping_option'] : 1;

        if ($methodId === '') {
            return $this->error('method_id is required', 400);
        }

        return $this->proxy_post('checkout/advanceShippingStep', [
            'method_id'       => $methodId,
            'shipping_option' => $shippingOption,
        ]);
    }

    public function calculate_tax(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $body = [];

        if (isset($params['zip'])) {
            $body['zip'] = sanitize_text_field(wp_unslash($params['zip']));
        }
        if (isset($params['state_id'])) {
            $body['state_id'] = (int) $params['state_id'];
        }

        return $this->proxy_post('checkout/calculateTax', $body);
    }

    public function apply_coupon(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $code = sanitize_text_field(wp_unslash($params['code'] ?? ''));

        if ($code === '') {
            return $this->error('Coupon code is required', 400);
        }

        return $this->proxy_post('checkout/applyCoupon', ['code' => $code], $this->withRecaptcha($request));
    }

    public function remove_coupon(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        return $this->proxy_post('checkout/removeCoupon');
    }

    public function apply_gift_card(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $body = $request->get_json_params();
        $code = sanitize_text_field(wp_unslash($body['code'] ?? ''));

        if ($code === '') {
            return $this->error('Gift card code is required', 400);
        }

        return $this->proxy_post('checkout/applyGiftCard', [
            'code'   => $code,
            'amount' => floatval($body['amount'] ?? 0),
        ], $this->withRecaptcha($request));
    }

    public function remove_gift_card(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        return $this->proxy_post('checkout/removeGiftCard');
    }

    public function apply_loyalty_redemption(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params    = $request->get_json_params();
        $rawPoints = $params['points'] ?? null;

        // N8: Reject non-integer values explicitly, absint() silently
        // truncates 5.5 → 5, which bypasses the server-side validation.
        // Check that the value (when cast to string) is a digit-only integer
        // with no decimal point before passing it through.
        if ($rawPoints !== null) {
            $rawStr = (string) $rawPoints;
            $isValid = ctype_digit(ltrim($rawStr, '-'))
                && strpos($rawStr, '.') === false;
            if (!$isValid) {
                return $this->error(
                    'Points must be a whole number.',
                    400,
                    'INVALID_POINTS'
                );
            }
        }
        $points = (int) ($rawPoints ?? 0);

        if ($points < 1) {
            return $this->error('points must be a positive integer', 400, 'INVALID_POINTS');
        }

        return $this->proxy_post('checkout/applyLoyaltyRedemption', ['points' => $points]);
    }

    public function remove_loyalty_redemption(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        return $this->proxy_post('checkout/removeLoyaltyRedemption');
    }

    public function get_summary(WP_REST_Request $request)
    {
        return $this->proxy_get('checkout/summary');
    }

    public function set_payment(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $body = [];

        $token = sanitize_text_field(wp_unslash($params['payment_token'] ?? ''));
        $billingId = sanitize_text_field(wp_unslash($params['billing_id'] ?? ''));
        $skipPayment = !empty($params['skip_payment']);

        if ($token !== '') {
            $body['payment_token'] = $token;
        }
        if ($billingId !== '') {
            $body['billing_id'] = $billingId;
        }
        if ($skipPayment) {
            $body['skip_payment'] = true;
        }

        if (empty($body)) {
            return $this->error('payment_token or billing_id is required', 400);
        }

        return $this->proxy_post('checkout/setPayment', $body, $this->withRecaptcha($request));
    }

    public function gift_card_balance(WP_REST_Request $request)
    {
        $code = sanitize_text_field(wp_unslash($request->get_param('code') ?? ''));
        if ($code === '') {
            return $this->error('Gift card code is required', 400);
        }
        return $this->proxy_get('checkout/giftCardBalance', ['code' => $code]);
    }

    public function set_order_notes(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $body = [];

        if (isset($params['is_gift'])) {
            $body['is_gift'] = (bool) $params['is_gift'];
        }
        if (isset($params['gift_note'])) {
            $body['gift_note'] = sanitize_textarea_field(wp_unslash($params['gift_note']));
        }
        if (isset($params['special_instructions'])) {
            $body['special_instructions'] = sanitize_textarea_field(wp_unslash($params['special_instructions']));
        }
        if (isset($params['ship_date'])) {
            $body['ship_date'] = sanitize_text_field(wp_unslash($params['ship_date']));
        }

        return $this->proxy_post('checkout/setOrderNotes', $body);
    }

    public function confirm_order(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        // Forward the core's account opt-in fields (create_account + password)
        // when a caller sends them. The shared SPA does not send them yet
        // (account creation goes through the existing AuthDialog/RegisterPage),
        // so this is forward-compatible plumbing for the core anon lane, not a
        // live checkbox. Only whitelisted fields are forwarded. Password is passed VERBATIM: never sanitize or unslash
        // a JSON password: WP_REST_Request::get_json_params() never slashes
        // (that is a $_POST-only behaviour), so wp_unslash() would strip
        // legitimate backslashes and leave the new account un-loginable.
        // AuthController login/register forward JSON passwords the same way.
        $params = $request->get_json_params();
        $body = [];
        if (!empty($params['create_account'])) {
            $body['create_account'] = true;
            if (isset($params['password']) && is_string($params['password'])) {
                $body['password'] = $params['password'];
            }
        }

        // Repeat-guest claim link target. When confirm hits an existing
        // passwordless bridge-guest shell, core emails a "set a password" claim
        // invite; thread the WP set-password page URL so that link resolves to
        // the real Vue recovery page instead of the legacy Yii admin route that
        // WordPress does not serve (404). Same builder the forgot-password flow
        // uses (AuthController::forgot_password). Core validates it against
        // allowed_origins and drops to its admin fallback if the host is unknown.
        $body['return_url'] = home_url(Options::get_app_base_path() . '/recovery/reset');

        return $this->proxy_post('checkout/confirmOrder', $body, $this->withRecaptcha($request));
    }

    private function mark_authenticated_checkout_response($response)
    {
        if ($response instanceof \WP_REST_Response) {
            $data = $response->get_data();
            if (is_array($data) && !empty($data['user_id'])) {
                BridgeSession::setAuthenticated(true);
            }
        }

        return $response;
    }

    private function build_address_body(array $params): array
    {
        $body = [];

        $addressId = isset($params['address_id']) ? (int) $params['address_id'] : 0;
        if ($addressId > 0) {
            $body['address_id'] = $addressId;
        } else {
            $fields = ['first_name', 'last_name', 'company', 'street1', 'street2',
                        'city', 'zip', 'county', 'phone', 'email', 'dob', 'nickname', 'timezone', 'set_primary'];
            foreach ($fields as $f) {
                if (isset($params[$f])) {
                    $body[$f] = sanitize_text_field(wp_unslash($params[$f]));
                }
            }
            if (isset($params['state_id'])) {
                $body['state_id'] = (int) $params['state_id'];
            }
            if (isset($params['country'])) {
                $body['country'] = (int) $params['country'];
            }
            if (!empty($params['set_primary'])) {
                $body['set_primary'] = true;
            }
        }

        return $body;
    }
}
