<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class AddressController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/addresses', [
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'list_addresses'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods'             => 'POST',
                'callback'            => [$this, 'create_address'],
                'permission_callback' => '__return_true',
            ],
        ]);

        register_rest_route(self::NAMESPACE, '/addresses/(?P<id>\d+)', [
            [
                'methods'             => 'POST',
                'callback'            => [$this, 'update_address'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [$this, 'delete_address'],
                'permission_callback' => '__return_true',
            ],
        ]);
    }

    public function list_addresses(WP_REST_Request $request)
    {
        return $this->proxy_get('address/list');
    }

    public function create_address(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $body = $this->sanitize_address_fields($request->get_json_params());
        return $this->proxy_post('address/create', $body);
    }

    public function update_address(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $id = absint($request->get_param('id'));
        if ($id <= 0) {
            return $this->error('address_id is required', 400);
        }

        $body = $this->sanitize_address_fields($request->get_json_params());
        $body['address_id'] = $id;

        return $this->proxy_post('address/update', $body);
    }

    public function delete_address(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $id = absint($request->get_param('id'));
        if ($id <= 0) {
            return $this->error('address_id is required', 400);
        }

        return $this->proxy_post('address/delete', ['address_id' => $id]);
    }

    private function sanitize_address_fields(array $params): array
    {
        $body = [];
        $textFields = ['first_name', 'last_name', 'company', 'street1', 'street2',
                        'city', 'zip', 'county', 'phone', 'email', 'dob', 'nickname'];
        foreach ($textFields as $f) {
            if (isset($params[$f])) {
                $body[$f] = sanitize_text_field(wp_unslash($params[$f]));
            }
        }
        if (isset($params['state_id'])) {
            $body['state_id'] = (int) $params['state_id'];
        }
        if (isset($params['country'])) {
            $body['country'] = (int) $params['country'];
        }
        if (isset($params['is_primary'])) {
            $body['is_primary'] = (bool) $params['is_primary'];
        }
        // Translate `set_primary` -> `is_primary`.
        //
        // Every new-address form emits `set_primary` (SavedAddressSelector,
        // AddressPicker, AddressForm), and nothing here forwarded it, so "Set as
        // my primary address" was silently dropped on each create/update through
        // this controller. Forwarding it VERBATIM does not work either:
        // address/create ignores `set_primary` and acts only on `is_primary`
        // (verified against the dev tenant, same payload, one field name, one
        // primary flag set and one not). The checkout path can send the other
        // name because it posts to a different upstream route
        // (CheckoutController::build_address_body -> checkout/*), so do not
        // "align" the two on one field name.
        if (!empty($params['set_primary'])) {
            $body['is_primary'] = true;
        }
        return $body;
    }
}
