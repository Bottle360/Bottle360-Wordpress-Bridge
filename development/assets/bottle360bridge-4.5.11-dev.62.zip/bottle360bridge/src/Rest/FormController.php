<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class FormController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/forms/(?P<slug>[a-zA-Z0-9_-]+)', [
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'get_form'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods'             => 'POST',
                'callback'            => [$this, 'submit_form'],
                'permission_callback' => '__return_true',
            ],
        ]);
    }

    public function get_form(WP_REST_Request $request)
    {
        $slug = sanitize_title($request->get_param('slug'));
        if ($slug === '') {
            return $this->error('slug is required', 400);
        }

        // HIGH-11 (FORM-BUILDER-AUDIT.md): 300s was long enough that an
        // operator editing a form in the admin would see required-field 422s
        // from submitForm (which always reads live) for up to 5 min while the
        // cached GET served stale schema. 30s keeps the per-page-load load
        // off the upstream without trapping operators during onboarding edits.
        // Proper fix: cache-bust on a forms.updated_time column (would need
        // adding to the legacy schema).
        return $this->proxy_get('form/get', ['slug' => $slug], ['cache' => 30]);
    }

    public function submit_form(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $slug = sanitize_title($request->get_param('slug'));
        if ($slug === '') {
            return $this->error('slug is required', 400);
        }

        $params = $request->get_json_params();
        $fields = $params['fields'] ?? [];
        if (!is_array($fields)) {
            $fields = [];
        }

        // sanitize_textarea_field instead of sanitize_text_field, admin forms
        // can carry textarea fields, and sanitize_text_field collapses newlines,
        // turning multi-paragraph messages into a run-on line. Newlines are
        // valid input across every field type the renderer ships.
        $sanitized = [];
        foreach ($fields as $key => $value) {
            if (!is_scalar($value)) continue;
            $sanitized[sanitize_text_field($key)] = sanitize_textarea_field(wp_unslash((string) $value));
        }

        return $this->proxy_post('form/submit', [
            'slug'   => $slug,
            'fields' => $sanitized,
        ]);
    }
}
