<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Settings\Options;
use WP_REST_Request;

if (!defined('ABSPATH')) exit;

/**
 * "Match my site" style-match extractor.
 *
 * Server-side fetches a winery's own website and parses its DECLARED brand
 * signals into a small StyleMatchSeed (see StyleMatchSeed in
 * shared/studio/composables/useStyleMatch.ts). The seed is a handful of brand
 * INPUT colours plus a few typography / radius guesses, NOT a finished theme.
 * The Vue derivation engine (`deriveBridgeThemeV2` via `deriveThemeFromSeed`)
 * expands it into the full ~45-colour palette. There is deliberately no colour
 * maths here: this controller only produces the seed the ONE engine consumes.
 *
 * WHY SERVER-SIDE: fetching the customer site from the browser would trip CORS
 * and pull the customer origin into the admin page's CSP. Doing it here keeps
 * the studio page clean and lets us follow redirects and every linked
 * stylesheet (cross-origin included, server-side HTTP has no CORS) the browser
 * could not read.
 *
 * WHAT IT CAN'T DO (P1 limit, documented): this reads only DECLARED CSS, inline
 * <style>, linked stylesheets (any origin, @import followed to a shallow
 * depth), and hex/rgb() literals in the markup. It CANNOT see computed or
 * JS-rendered styles (a headless-browser render is the P2 vision path). It is
 * a strong first guess, surfaced for review, never silently saved.
 */
final class StyleMatchController extends RestBase
{
    // PER-REQUEST timeout (seconds): the page fetch and EACH stylesheet fetch
    // get this long individually. It is not an aggregate budget; the wall
    // clock across the whole stylesheet phase is bounded by
    // FETCH_BUDGET_SECONDS below.
    private const FETCH_TIMEOUT   = 10;
    private const MAX_HTML_BYTES  = 2000000;   // 2 MB page cap
    private const MAX_CSS_BYTES   = 512000;    // 512 KB per stylesheet
    private const MAX_STYLESHEETS = 20;        // sheets we fetch, linked + @import, any origin (brand-prioritized)
    private const MAX_TOTAL_CSS_BYTES = 3000000; // total CSS kept across all fetched sheets
    private const MAX_IMPORT_DEPTH = 2;        // @import chains: sheet -> import -> import, no deeper
    // Wall-clock budget (seconds) across the WHOLE stylesheet fetch phase
    // (linked sheets + @imports). Per-request timeouts bound each fetch, but
    // MAX_STYLESHEETS slow hosts at FETCH_TIMEOUT each could still hold the
    // request for minutes; past this budget the loop stops fetching, parses
    // what it already has, and surfaces a truncation note in diagnostics.
    private const FETCH_BUDGET_SECONDS = 45;
    // A realistic browser User-Agent. The old bespoke UA got 403'd by some
    // hosts (e.g. Cakebread) that a normal browser string sails past, so both
    // the page and stylesheet fetches present as a browser to improve coverage.
    private const USER_AGENT      = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

    /**
     * Page-builder / theme-framework custom-property prefixes. These are noise
     * by default, BUT a var here that names an explicit brand ROLE
     * (Elementor's `--e-global-color-primary`) is a genuine brand signal and is
     * allowed through the brand-var picker (see pick_brand_var). They stay
     * excluded from the surface/text picker.
     */
    private const VENDOR_VAR_PREFIXES = ['fc-', 'c7-', 'gutenberg', 'elementor', 'e-global', 'astra-', 'ast-global', 'oceanwp'];

    /**
     * Widget / review-app custom-property prefixes. These ship the APP's OWN
     * themeable colours (a reviews widget's default hues), never the winery's
     * brand, so they are HARD-excluded from the brand pick even when the name
     * carries a brand-role token (e.g. `--jdgm-...-primary`). The WP block-preset
     * palette (`--wp--preset--*`) is hard-excluded the same way (see
     * is_hard_vendor_var): a default palette, not a chosen brand.
     */
    private const VENDOR_APP_PREFIXES = ['jdgm', 'judgeme', 'yotpo', 'stamped', 'loox', 'okendo'];

    /**
     * WordPress-core infrastructure custom-property prefixes. These are fixed
     * across every WP install and carry no brand intent, most notably
     * `--wp-components-color-accent:#cc1818`, WP core's form-validation red,
     * which used to win the accent tier when the winery's real brand CSS wasn't
     * among the fetched sheets. HARD-excluded from the brand pick.
     */
    private const VENDOR_CORE_PREFIXES = ['wp-components', 'wp-admin', 'wp-block', 'wp-preferences'];

    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/style-match/extract', [
            'methods'             => 'POST',
            'callback'            => [$this, 'extract'],
            // Admin-only mutating authoring tool, mirrors ThemeController's
            // save route. WP's REST cookie auth requires a valid wp_rest nonce
            // (X-WP-Nonce) for current_user_can to see the logged-in admin, so
            // the capability check IS the capability + nonce gate.
            'permission_callback' => [$this, 'require_manage_options'],
            'args'                => [
                'url' => [
                    'type'     => 'string',
                    'required' => false,
                ],
            ],
        ]);
    }

    public function require_manage_options(): bool
    {
        return current_user_can('manage_options');
    }

    public function extract(WP_REST_Request $request)
    {
        // SOURCE URL: an explicit `url` param wins; otherwise default to the
        // winery's own site. On WordPress the storefront is mounted inside the
        // winery's WP theme, so home_url() IS the connection's front-facing
        // origin, the site we want to visually match. (get_public_url() is the
        // Bottle360 asset/bridge host, not the winery's marketing site, so it is
        // deliberately NOT used as the default here.)
        $raw = trim((string) $request->get_param('url'));
        if ($raw !== '') {
            // Validate the SHAPE of caller input BEFORE esc_url_raw(): that
            // function "helpfully" coerces a bare word like 'not-a-url' into
            // 'http://not-a-url', which then sails past a `^https?://` guard,
            // so the friendly 400 below used to be dead and garbage reached the
            // network path. normalize_input_url() requires a real dotted host
            // (or IP literal) and returns null for anything that isn't a
            // plausible absolute URL.
            $candidate = self::normalize_input_url($raw);
            if ($candidate === null) {
                return $this->error(
                    __('Enter a valid http(s) URL to match, e.g. https://your-winery.com.', 'b360-bridge'),
                    400,
                    'b360_stylematch_bad_url'
                );
            }
            $url = esc_url_raw($candidate);
        } else {
            // No url given → the winery's own WP site (trusted config).
            $url = esc_url_raw(home_url('/'));
        }

        if ($url === '' || !preg_match('#^https?://#i', $url)) {
            return $this->error(
                __('Enter a valid http(s) URL to match.', 'b360-bridge'),
                400,
                'b360_stylematch_bad_url'
            );
        }

        $fetch = self::fetch($url);
        if ($fetch['error'] !== null) {
            // fetch() maps each failure to its own status/code: a clean
            // NXDOMAIN is a 400 b360_stylematch_not_found (a typo'd domain
            // is not a security block), an address resolving to private/
            // internal space is a 400 b360_stylematch_blocked, and network/
            // HTTP failures stay 502 b360_stylematch_unreachable.
            return $this->error($fetch['error'], $fetch['status'], $fetch['code']);
        }

        $html      = $fetch['body'];
        $final_url = $fetch['final_url'];

        // Gather CSS: inline <style> blocks + every linked stylesheet (any
        // origin, @import followed to MAX_IMPORT_DEPTH). The count of sheets
        // actually fetched is surfaced in diagnostics.found.stylesheets so a
        // coverage regression is visible.
        $inline_css = self::inline_styles($html);
        $linked     = self::linked_css($html, $final_url, $inline_css);
        $linked_css = $linked['css'];
        $all_css    = $inline_css . "\n" . $linked_css;
        // Stylesheet ORIGIN split: inline <style> is the site's own by
        // definition; fetched sheets are split by host (see
        // stylesheet_is_vendor_origin). Platform-CDN CSS ships the PLATFORM's
        // defaults (Commerce7's #3860D6), so the button resolver ranks
        // site-owned tokens above the tier-3 rule and the tier-3 rule above
        // vendor tokens, and the denylist below consults the site CSS.
        $site_css   = $inline_css . "\n" . $linked['site_css'];
        $vendor_css = $linked['vendor_css'];

        // Declared CSS custom properties. The brand-var picker walks the full
        // ordered declaration LIST so a trailing black/white redeclaration of a
        // role var (Shopify inverse colour schemes) can't bury the brand hue;
        // surfaces + diagnostics use the last-wins map.
        $var_list    = self::css_custom_property_list($all_css);
        $vars        = self::vars_map($var_list);
        $brand_var   = self::pick_brand_var($var_list, $site_css);

        // Frequency of literal colours across markup + CSS (fallback signal).
        // <script>/<template> content is stripped first: a reviews/widget app's
        // JSON config (e.g. Judge.me's "all_reviews_text_color":"#108474") lives
        // in a <script> and is the APP's own default colour, not the site's
        // brand, counting it let it hijack the pick on Shopify sites. Denylisted
        // var declarations (wp--preset palette, review apps) are stripped too, so
        // the frequency tier stays consistent with pick_brand_var's exclusions.
        $freq_text   = self::strip_denylisted_declarations(
            self::strip_non_style_markup($html) . "\n" . $all_css
        );
        // Named colours count only from CSS contexts (see colour_frequency):
        // the site's CSS with the same denylisted declarations stripped, and
        // the markup's style="" / SVG fill / stroke attributes, never copy.
        $freq        = self::colour_frequency(
            $freq_text,
            self::strip_denylisted_declarations($all_css),
            self::strip_non_style_markup($html)
        );

        // theme-color meta is an explicit, declared brand signal, but a
        // NEUTRAL one (white/black/washed-out grey) is a chrome hint, not a
        // brand: it is treated as no-signal by the brand cascade (F11).
        $meta_theme  = self::meta_theme_color($html);

        // F12: declared heading text colour and footer/header chrome
        // backgrounds are brand candidates on sites with no button/var
        // signal (caymus: dark brown #3C3430 on every h1-h5 and .footer,
        // while a white theme-color meta used to win the brand). SITE-OWNED
        // CSS only, a platform CDN's heading/footer defaults are not the
        // winery's brand.
        $heading_brand = self::heading_colour_brand($site_css);
        $chrome_brand  = self::chrome_background_brand($site_css);

        // Deterministic primary-button resolver: the declared base-state button
        // colour from globally scoped vars (tiers 1-2) or the winning primary
        // button rule (tier 3). When it resolves, IT is the brand signal, and
        // the button rule's radius/text feed the radius + contrast paths too.
        // The heuristics below stay as the fallback when it finds nothing.
        // The page-surface candidates are computed ONCE, up front: the
        // resolver needs the dark-page decision (a near-white button is the
        // brand only on a dark page) and resolve_surfaces below reads the
        // same list, so the two can never disagree.
        $page_candidates = self::page_surface_candidates($site_css, $vendor_css);
        $page_dark       = self::dark_page_candidate($page_candidates) !== null;
        $button_rule     = self::primary_button_rule($all_css, $site_css, $page_dark);
        $resolved_button = self::resolve_primary_button($site_css, $button_rule, $vendor_css, $page_dark);

        // Resolve the brand colour: the resolved primary button first, then
        // the fallback cascade (see fallback_brand): brand-named var >
        // heading text colour > footer/header background > saturated
        // theme-color meta > the most frequent saturated (non-grey) literal.
        $brand = null;
        $brand_source = null;
        if ($resolved_button !== null) {
            $brand = $resolved_button['hex'];
            $brand_source = $resolved_button['source'];
        } else {
            $fallback = self::fallback_brand($brand_var, $heading_brand, $chrome_brand, $meta_theme, $freq, $all_css, $site_css);
            if ($fallback !== null) {
                $brand = $fallback['hex'];
                $brand_source = $fallback['source'];
            }
        }

        if ($brand === null) {
            return $this->error(
                __('Could not detect any brand colours on that page. Try a different URL, or start from Estate Default and set your colours by hand.', 'b360-bridge'),
                422,
                'b360_stylematch_no_signal'
            );
        }

        // Surfaces + body text, plausibility-clamped. Naively trusting a var
        // named "background"/"card" gave a black storefront on a light winery
        // site (echolandswinery: surfacePage=#1D3637 pine, surfaceCard=#000000),
        // and trusting arbitrary selectors let PhotoSwipe/cookie-consent
        // overlay rules flip bottlethreesixty dark. resolve_surfaces() reads
        // the page surface ONLY from body/html/:root-scoped declarations,
        // rejects a surface that equals the brand or is dark on a light page,
        // falls back to white (never a grey), keeps text/surface contrast from
        // coming back light-on-light, and reports the chosen source.
        // SITE-OWNED CSS leads the scan; a platform CDN's shipped body
        // default (Commerce7's body background:var(--c7-bg) white flipped
        // ridge's dark #3A3A3A site white) is consulted only when the site
        // CSS yields no surface at all (see resolve_surfaces).
        [$surface_page, $surface_card, $text_primary, $surface_note, $surface_source] = self::resolve_surfaces($vars, $site_css, $brand, $vendor_css, $page_candidates);

        // Typography guesses (heading-only display traits + a heading weight).
        $heading_transform = self::heading_text_transform($all_css);
        $heading_ls        = self::heading_letter_spacing($all_css);
        $heading_weight    = self::heading_weight($all_css);
        $fonts             = self::font_families($all_css);

        // Design language BEYOND colour, declared-CSS only (a strong first
        // guess): button/card roundness, heading font CHARACTER (serif vs
        // display sans -> fontSerif), body weight, and flat-vs-elevated depth.
        // A resolved primary-button RULE's own border-radius outranks the
        // population median for radius.control (a stray round element must not
        // outvote the real CTA).
        $radius            = self::radius_overrides($all_css, $button_rule !== null ? $button_rule['radius'] : null);
        $font_character    = self::heading_font_character($all_css);
        $body_weight       = self::body_font_weight($all_css);
        $depth             = self::surface_depth($all_css);

        // Layout density, corroborated declared signals only (see
        // infer_density): stays 'default' unless two independent signals agree.
        $density           = self::infer_density($all_css);

        // Title / label weights, conservative: each tracks a DETECTED source
        // weight and is emitted only when it lands off the estate default
        // (emitting the default would be a pointless no-op override).
        // titleWeight follows the detected heading identity (estate 700);
        // labelWeight sits two steps above the detected body weight, bounded to
        // the 600-700 band label components are designed for (estate 600).
        $title_weight = self::title_weight_override($heading_weight);
        $label_weight = self::label_weight_override($body_weight);

        // Web fonts: families the site GENUINELY loads from Google (a
        // fonts.googleapis.com request in its own markup/CSS), mapped onto the
        // storefront's type roles. A bare font-family NAME proves nothing about
        // hosting, so it never qualifies on its own. Null when nothing
        // confirms, so an unmatched site keeps its existing fonts untouched.
        $google_fonts = self::google_font_requests($html, $all_css);
        $web_fonts    = self::web_fonts_config($google_fonts, $all_css, $heading_weight, $body_weight);

        // F14: the heading slot's stack. A detected heading face that is NOT
        // Google-confirmable leads the character stack (the embed renders
        // inside the winery's own page, so a licensed face already loaded
        // there renders for free when its name leads; dropping straight to
        // the character tail threw an exact match away).
        $font_serif = self::heading_slot_stack($font_character, $google_fonts);

        // Button label treatment (Components > Buttons): casing + tracking,
        // read from BUTTON rules only, never headings or body copy.
        $button_transform  = self::button_text_transform($all_css);
        $button_tracking   = self::button_letter_spacing($all_css);

        // Non-Google custom faces (self-hosted @font-face, Adobe Fonts kits):
        // diagnostics only, never emitted into webFonts (that config is
        // Google-only by design, sanitizer-enforced enum).
        $custom_fonts = self::custom_font_faces($html, $all_css, $google_fonts);

        // Logo candidates.
        $logo = self::logo_candidate($html, $final_url);

        // WCAG check. With a RESOLVED button colour the meaningful pair is the
        // button TEXT against the button BACKGROUND (white-ish text stands in
        // when the site doesn't declare one); brand-vs-page told a winery with
        // a dark page that its dark button "is light", nonsense. Without a
        // resolved button, the legacy brand-vs-card check stands, but only as
        // a proxy: derivation's resolveActionColors decides the button pair
        // SEPARATELY (a white label on the brand) and may keep the white label
        // and change nothing (a dark brand on a dark card), use a dark label,
        // or nudge the fill in-brand, never a substituted constant. PHP does
        // not port that colour maths to find out which, so the note
        // (card_contrast_note) says only that button colours MAY be adjusted.
        // The resolved colour itself is NEVER substituted: it is pinned as
        // actionPrimary below, the note just flags the contrast.
        $contrast_note = null;
        if ($resolved_button !== null) {
            $button_text_hex   = $resolved_button['text'] !== null ? $resolved_button['text'] : '#FFFFFF';
            $brand_contrast    = self::contrast_ratio($button_text_hex, $brand);
            $brand_contrast_ok = $brand_contrast >= 4.5;
            $contrast_note     = self::button_contrast_note($button_text_hex, $brand);
        } else {
            $card_for_contrast = $surface_card ?? '#FFFFFF';
            $brand_contrast    = self::contrast_ratio($brand, $card_for_contrast);
            $brand_contrast_ok = $brand_contrast >= 4.5;
            $contrast_note     = self::card_contrast_note($brand, $card_for_contrast);
        }

        // ---- Build the seed (StyleMatchSeed shape) ----
        $input = ['brandPrimary' => $brand, 'density' => $density];
        if ($surface_page !== null) $input['surfacePage'] = $surface_page;
        if ($surface_card !== null) $input['surfaceCard'] = $surface_card;
        if ($text_primary !== null) $input['textPrimary'] = $text_primary;
        // A CONFIDENT button colour (tier 1, tier 3, or a tier-2 primary-role
        // token) is also emitted as actionPrimary. actionPrimary is in the
        // studio's PINNABLE_INPUT_KEYS, so it pins in the seed and bypasses
        // resolveActionColors' in-brand adjustment: buttons render the site's
        // exact colour instead of a derived shade.
        if ($resolved_button !== null && $resolved_button['confident']) {
            $input['actionPrimary'] = $resolved_button['hex'];
        }

        // fontSans starts at the CSS-armor default and is replaced ONLY when a
        // confident concrete body stack was read from the site's own body/p
        // rules (a system-font stack or var() keeps the armor), or, below,
        // when a Google-hosted body face was confirmed (that write-through
        // wins: it also downloads the face).
        $typography = ['fontSans' => 'inherit'];
        $body_stack = self::declared_body_stack($all_css);
        if ($body_stack !== null) $typography['fontSans'] = $body_stack;
        if ($heading_weight !== null)    $typography['headingWeight']       = $heading_weight;
        if ($heading_transform !== null) $typography['headingTransform']    = $heading_transform;
        if ($heading_ls !== null)        $typography['headingLetterSpacing'] = $heading_ls;
        // fontSerif is CHARACTER matching only (an unverified family would
        // defeat the CSS armor); heading roles render via their own webFont
        // vars, so no heading write-through is needed here.
        if ($font_serif !== null)        $typography['fontSerif']            = $font_serif;
        if ($body_weight !== null)       $typography['bodyWeight']           = $body_weight;
        if ($title_weight !== null)      $typography['titleWeight']          = $title_weight;
        if ($label_weight !== null)      $typography['labelWeight']          = $label_weight;
        // webFonts only when a family was CONFIRMED as Google-hosted. Nothing
        // downstream maps the 'body' role into fontSans (the seed derivation
        // is a pure merge and the CSS-var emitters exclude the body role), so
        // a confirmed body family is written through to fontSans HERE, the
        // same write-through the Studio does at pick time, otherwise the body
        // face is downloaded but never rendered. bodyWeight already carries
        // the body render weight via the $body_weight line above.
        if ($web_fonts !== null) {
            $typography['webFonts'] = $web_fonts;
            if ($web_fonts['body'] !== null) {
                $typography['fontSans'] = self::body_font_stack($web_fonts['body']['family']);
            }
        }

        $overrides = [
            'name'       => self::brand_name($final_url),
            'typography' => $typography,
        ];
        // The -hover sibling of the winning button var, when the site declares
        // one, overrides the derived hover; otherwise hover is left to
        // derivation (darken of actionPrimary).
        if ($resolved_button !== null && $resolved_button['hover'] !== null) {
            $overrides['colors'] = ['actionPrimaryHover' => $resolved_button['hover']];
        }
        if (!empty($radius['keys'])) {
            $overrides['radius'] = $radius['keys'];
        }
        // Components: surface depth and the button label treatment coexist.
        $button = [];
        if ($button_transform !== null) $button['textTransform'] = $button_transform;
        if ($button_tracking !== null)  $button['letterSpacing'] = $button_tracking;

        $components = [];
        if (!empty($depth['surfaces'])) $components['surfaces'] = $depth['surfaces'];
        if (!empty($button))            $components['button']   = $button;
        if (!empty($components))        $overrides['components'] = $components;
        if ($logo !== null) {
            $overrides['assets'] = ['checkoutLogoUrl' => $logo['url']];
        }

        // ---- Diagnostics (which signals were found + confidence + gaps) ----
        // surfacePage/surfaceCard are always resolved (white stands in when a
        // level can't be read; $surface_note records only a PAGE-level
        // fallback), so they are not listed as unresolved.
        $unresolved = [];
        if ($text_primary === null) $unresolved[] = 'textPrimary';
        if ($heading_transform === null && $heading_ls === null && $heading_weight === null
            && $font_serif === null && $body_weight === null) {
            $unresolved[] = 'typography';
        }
        if (empty($radius['keys']))       $unresolved[] = 'radius';
        if ($depth['verdict'] === null)   $unresolved[] = 'depth';
        if ($logo === null) $unresolved[] = 'logo';

        // Confidence: a resolved button rule or a declared brand-named var is
        // high; the inferred declared sources (heading colour, footer/header
        // background, theme-color meta) are medium; a frequency guess is low.
        $confidence = self::brand_confidence($brand_source);

        // Notes: contrast/confidence lines, the surface-fallback note, and a
        // low-confidence flag when the button roundness came from thin evidence.
        $notes = self::merge_notes(
            self::notes($contrast_note, $confidence),
            $surface_note
        );
        if (!empty($radius['lowConfidence'])) {
            $notes[] = __('Button roundness was a guess. Check Corners.', 'b360-bridge');
        }
        // The stylesheet phase ran past its wall-clock budget, so some sheets
        // were skipped and declared styles may be missing from this match.
        if (!empty($linked['truncated'])) {
            $notes[] = __('Some stylesheets were skipped to keep this quick.', 'b360-bridge');
        }
        // F13: the only usable logo was a light/inverse variant, it may be
        // invisible on a light checkout background.
        if ($logo !== null && $logo['note'] !== null) {
            $notes[] = $logo['note'];
        }
        // The requested address landed on a DIFFERENT site entirely (a
        // dot-bounded host comparison on the existing post-redirect URL, so
        // a www/subdomain hop stays silent): say so, the match then
        // describes THAT site's styles (the chateaumontelena shape, a domain
        // redirecting to an unrelated third-party page).
        if (!self::hosts_are_same_site($url, $final_url)) {
            $notes[] = self::redirect_note($final_url);
        }

        $diagnostics = [
            'sourceUrl'       => $final_url,
            'brandColor'      => $brand,
            'brandSource'     => $brand_source,
            // Mirrors brandSource for the surface pick (body@background,
            // html@background, :root@--color-background, fallback:white), so
            // a surface mis-pick is visible in the payload.
            'surfaceSource'   => $surface_source,
            'confidence'      => $confidence,
            'brandContrastOk' => $brand_contrast_ok,
            'brandContrast'   => round($brand_contrast, 2),
            'found'           => [
                'cssVars'         => count($vars),
                'brandNamedVar'   => $brand_var !== null ? $brand_var['name'] : null,
                'themeColorMeta'  => $meta_theme,
                'surfacePage'     => $surface_page,
                'surfaceCard'     => $surface_card,
                'textPrimary'     => $text_primary,
                'headingFont'     => $font_character['face'] !== null ? $font_character['face'] : $fonts['heading'],
                // Follows the SAME resolution the seed's fontSans used, so the
                // diagnostics can't say null while a declared stack shipped.
                'bodyFont'        => self::body_font_diagnostic($body_stack, $fonts['body']),
                // Non-Google faces the site loads (@font-face / Adobe Fonts):
                // reported so the winery knows what we saw, never imported.
                'customFonts'     => !empty($custom_fonts) ? $custom_fonts : null,
                'headingTransform' => $heading_transform,
                'headingWeight'   => $heading_weight,
                'headingFontStyle' => $font_character['style'],
                'bodyWeight'      => $body_weight,
                'titleWeight'     => $title_weight,
                'labelWeight'     => $label_weight,
                // 'default' means "no corroborated signal", reported absent.
                'density'         => $density !== 'default' ? $density : null,
                // The confirmed Google families per mapped role group (the
                // full per-role config lives in the seed's typography).
                'webFonts'        => $web_fonts !== null ? [
                    'headingFamily' => $web_fonts['h1'] !== null ? $web_fonts['h1']['family'] : null,
                    'bodyFamily'    => $web_fonts['body'] !== null ? $web_fonts['body']['family'] : null,
                ] : null,
                'radius'          => !empty($radius['keys']) ? $radius['keys'] : null,
                'surfaceDepth'    => $depth['verdict'],
                'button'          => !empty($button) ? $button : null,
                'logo'            => $logo !== null ? $logo['url'] : null,
                'stylesheets'     => $linked['count'],
            ],
            'unresolved'      => array_values($unresolved),
            'notes'           => $notes,
            // The hard P1 limitation, echoed to the UI so the winery understands
            // this is a declared-styles guess, not a pixel-accurate render.
            'limitation'      => __('This reads your site\'s declared styles only, it cannot see JavaScript-rendered colours. Review the suggestion before saving.', 'b360-bridge'),
        ];

        return $this->success([
            'seed' => [
                'input'     => $input,
                'overrides' => $overrides,
            ],
            'diagnostics' => $diagnostics,
        ]);
    }

    // --------------------------------------------------------------------- //
    //  HTTP                                                                 //
    // --------------------------------------------------------------------- //

    /**
     * Fetch a URL server-side. Returns
     *   ['body' => string, 'final_url' => string, 'error' => string|null]
     * plus, on failure, 'status' and 'code' for the REST error funnel.
     * `error` is a human message when the fetch failed; body is '' then.
     */
    private static function fetch(string $url): array
    {
        // SSRF guard, layer 1, our OWN host check. WP core's
        // wp_http_validate_url() does NOT block link-local 169.254.0.0/16 (the
        // AWS/GCP/Azure instance-metadata range), CGNAT, or several other
        // non-public ranges, so wp_safe_remote_get() alone is not enough:
        // http://169.254.169.254/ validates as a normal URL. host_is_blocked()
        // resolves the host over BOTH A (IPv4) and AAAA (IPv6) records and
        // rejects the host if any resolved address is in a private / loopback /
        // link-local / reserved range (v4 and v6 alike).
        //
        // ERROR COPY: the gate fails CLOSED on no records, which used to hand
        // a typo'd domain the scary private-network message. A CLEAN
        // no-records answer (host_is_unresolvable, NXDOMAIN both families)
        // now gets a friendly not-found message instead; the guard copy stays
        // for everything that actually resolves to (or might resolve to)
        // private/internal space. The gate itself is unchanged: any ambiguous
        // or partial resolution state still blocks.
        if (self::host_is_blocked($url)) {
            $blocked = self::blocked_fetch_error(self::host_is_unresolvable($url));
            return [
                'body'      => '',
                'final_url' => $url,
                'status'    => $blocked['status'],
                'code'      => $blocked['code'],
                'error'     => $blocked['error'],
            ];
        }

        // SSRF guard, layer 2, wp_safe_remote_get() runs wp_http_validate_url()
        // and sets reject_unsafe_urls, rejecting the request (and each redirect
        // hop) for loopback / RFC1918 / non-standard ports. Belt and suspenders
        // with layer 1, which covers the ranges core misses.
        $res = wp_safe_remote_get($url, [
            'timeout'     => self::FETCH_TIMEOUT,
            'redirection' => 5,
            'user-agent'  => self::USER_AGENT,
            'headers'     => ['Accept' => 'text/html,application/xhtml+xml'],
            // Don't let a giant page hang the request; we cap the body below too.
            'limit_response_size' => self::MAX_HTML_BYTES,
        ]);

        if (is_wp_error($res)) {
            return [
                'body'      => '',
                'final_url' => $url,
                'status'    => 502,
                'code'      => 'b360_stylematch_unreachable',
                'error'     => sprintf(
                    /* translators: %s: underlying network error */
                    __('Could not reach that site: %s', 'b360-bridge'),
                    $res->get_error_message()
                ),
            ];
        }

        $status = (int) wp_remote_retrieve_response_code($res);
        if ($status < 200 || $status >= 400) {
            return [
                'body'      => '',
                'final_url' => $url,
                'status'    => 502,
                'code'      => 'b360_stylematch_unreachable',
                'error'     => sprintf(
                    /* translators: %d: HTTP status code */
                    __('That site returned HTTP %d, it may be down or blocking automated requests.', 'b360-bridge'),
                    $status
                ),
            ];
        }

        $body = (string) wp_remote_retrieve_body($res);
        if (strlen($body) > self::MAX_HTML_BYTES) {
            $body = substr($body, 0, self::MAX_HTML_BYTES);
        }
        if (trim($body) === '') {
            return [
                'body'      => '',
                'final_url' => $url,
                'status'    => 502,
                'code'      => 'b360_stylematch_unreachable',
                'error'     => __('That site returned an empty page.', 'b360-bridge'),
            ];
        }

        // Resolve the TRUE post-redirect URL from the response object. Redirects
        // are followed internally, so the final response is a 200 with NO
        // Location header, reading a Location header would leave final_url stuck
        // at the requested URL on any apex→www / http→https site (the common
        // case), and every same-origin stylesheet + relative href would then
        // resolve against the wrong origin.
        $final = self::resolve_final_url($res, $url);

        // SSRF defence-in-depth: a redirect chain could have landed on an
        // internal host even though the initial URL validated. Re-check the
        // resolved final host with BOTH our range check (covers link-local /
        // metadata that core misses) and core's validator, and bail on either.
        // Accepted residual: a DNS-rebind TOCTOU window exists between this
        // resolve and the socket connect, out of P1 scope, and mitigated by
        // this route being manage_options + nonce gated.
        if (self::final_url_blocked($final)) {
            return [
                'body'      => '',
                'final_url' => $final,
                'status'    => 400,
                'code'      => 'b360_stylematch_blocked',
                'error'     => __('That site redirected to an address we can\'t fetch. Try a different URL.', 'b360-bridge'),
            ];
        }

        return ['body' => $body, 'final_url' => $final, 'error' => null];
    }

    /**
     * The true URL after redirects. wp_remote_get() follows redirects
     * internally, so the aggregated response is a 200 with no Location header;
     * the resolved URL lives on the underlying Requests\Response instead. Guard
     * for the key/method being absent (older WP, or a response short-circuited
     * by a `pre_http_request` filter) and fall back to the requested URL.
     */
    private static function resolve_final_url(array $res, string $requested): string
    {
        if (isset($res['http_response'])
            && is_object($res['http_response'])
            && method_exists($res['http_response'], 'get_response_object')) {
            $obj = $res['http_response']->get_response_object();
            if (is_object($obj) && isset($obj->url) && is_string($obj->url) && $obj->url !== '') {
                return $obj->url;
            }
        }
        return $requested;
    }

    /**
     * SSRF re-check for a RESOLVED post-redirect URL: blocked when either our
     * range check (link-local / metadata / CGNAT ranges core misses) or
     * core's own validator rejects it. Shared by the page fetch and every
     * stylesheet fetch, so a redirect chain can never land a fetched-and-
     * parsed body on an internal host regardless of which path followed it.
     */
    private static function final_url_blocked(string $final): bool
    {
        return self::host_is_blocked($final) || wp_http_validate_url($final) === false;
    }

    /**
     * The error payload for a host_is_blocked() refusal. $unresolvable says
     * the block came from a CLEAN no-records DNS answer (a typo'd domain,
     * see host_is_unresolvable): that gets a friendly not-found message
     * instead of the security-guard copy, which stays for every address
     * that actually resolves (or ambiguously might resolve) to private or
     * internal space. Pure, so the mapping is unit-pinnable.
     *
     * @return array{status:int,code:string,error:string}
     */
    private static function blocked_fetch_error(bool $unresolvable): array
    {
        if ($unresolvable) {
            return [
                'status' => 400,
                'code'   => 'b360_stylematch_not_found',
                'error'  => __('We couldn\'t find that website. Check the spelling and try again.', 'b360-bridge'),
            ];
        }
        return [
            'status' => 400,
            'code'   => 'b360_stylematch_blocked',
            'error'  => __('That address isn\'t allowed, it resolves to a private or internal network.', 'b360-bridge'),
        ];
    }

    // --------------------------------------------------------------------- //
    //  CSS collection                                                       //
    // --------------------------------------------------------------------- //

    /** Concatenate every inline <style>…</style> block. */
    private static function inline_styles(string $html): string
    {
        if (!preg_match_all('#<style\b[^>]*>(.*?)</style>#is', $html, $m)) {
            return '';
        }
        return implode("\n", $m[1]);
    }

    /**
     * Fetch up to MAX_STYLESHEETS linked stylesheets, ANY origin, and return
     * their concatenated CSS plus the count actually fetched. The fetch is
     * server-side so there is no CORS: cross-origin sheets (CDN-hosted themes,
     * Adobe Fonts kits) carry real brand CSS and used to be skipped, which
     * left found.stylesheets at 1 on sites whose brand lived on a CDN.
     * @import statements (in fetched sheets AND in the page's inline CSS) are
     * followed to MAX_IMPORT_DEPTH. Budgets: MAX_STYLESHEETS sheets,
     * MAX_CSS_BYTES per sheet, MAX_TOTAL_CSS_BYTES overall, and
     * FETCH_BUDGET_SECONDS wall clock across the whole phase ('truncated' in
     * the return reports when the time budget cut fetching short).
     *
     * ORIGIN attribution: alongside the combined 'css', each fetched sheet is
     * bucketed by its TRUE post-redirect host into 'site_css' (the winery's
     * own CSS, plus any host not on the platform-CDN list, the trust level
     * every sheet had before) or 'vendor_css' (known platform CDNs, see
     * stylesheet_is_vendor_origin), so the button resolver can rank the
     * site's own tokens above a platform's shipped defaults.
     *
     * @return array{css:string,site_css:string,vendor_css:string,count:int,truncated:bool}
     */
    private static function linked_css(string $html, string $base, string $inline_css): array
    {
        $queue = self::stylesheet_candidates($html, $base);
        $seen  = [];
        foreach ($queue as $cand) $seen[$cand['href']] = true;

        // @imports declared directly in inline <style> blocks join the queue
        // at depth 1 (they are one hop from the page, like a linked sheet's
        // own imports).
        foreach (self::css_import_urls($inline_css, $base) as $import) {
            if (isset($seen[$import])) continue;
            $seen[$import] = true;
            $queue[] = ['href' => $import, 'order' => 0, 'score' => 0, 'depth' => 1];
        }

        $css = '';
        $site_sheet_css = '';
        $vendor_sheet_css = '';
        $fetched = 0;
        $total_bytes = 0;
        $truncated = false;
        // Wall-clock budget over the whole stylesheet phase: the timer starts
        // before the first stylesheet fetch and is checked before EACH fetch.
        $fetch_started = microtime(true);
        while (!empty($queue)) {
            if ($fetched >= self::MAX_STYLESHEETS) break;
            if ($total_bytes >= self::MAX_TOTAL_CSS_BYTES) break;
            if (microtime(true) - $fetch_started > self::FETCH_BUDGET_SECONDS) {
                // Out of time: stop fetching more sheets and parse what we
                // have. Surfaced to the winery via a diagnostics note.
                $truncated = true;
                break;
            }
            $cand = array_shift($queue);
            $href = $cand['href'];

            // Same two-layer SSRF guard as the page fetch, on EVERY sheet URL,
            // linked or @imported, before the request goes out: our
            // host_is_blocked() range check (covers link-local / metadata core
            // misses) and wp_safe_remote_get()'s validator both apply.
            if (self::host_is_blocked($href)) continue;
            $res = wp_safe_remote_get($href, [
                'timeout'             => self::FETCH_TIMEOUT,
                'redirection'         => 3,
                'user-agent'          => self::USER_AGENT,
                'headers'             => ['Accept' => 'text/css,*/*;q=0.1'],
                'limit_response_size' => self::MAX_CSS_BYTES,
            ]);
            if (is_wp_error($res)) continue;
            if ((int) wp_remote_retrieve_response_code($res) !== 200) continue;
            // SSRF defence-in-depth, the SAME post-fetch re-check the page
            // fetch runs: core's redirect follower validates each hop with
            // wp_http_validate_url() only, which resolves no hostnames and
            // does not block link-local 169.254.0.0/16 (cloud instance
            // metadata) or CGNAT, so a matched site could 302 a stylesheet to
            // an internal host and this body would be internal content, not
            // brand CSS. Resolve the TRUE post-redirect URL and DISCARD the
            // body when its host is blocked; a legitimate redirect to an
            // allowed host still concatenates. NOTE the residual vs the core
            // port: the core port re-runs hostIsBlocked() BEFORE every hop it
            // follows, so it never even sends the request; here core's
            // follower has already fetched each hop by the time this check
            // runs, so a malicious redirect can still cause one blind GET to
            // a link-local/internal host. This check only guarantees such a
            // body is discarded, never PARSED, equivalence holds for what is
            // parsed, not for what is requested.
            $final = self::resolve_final_url($res, $href);
            if (self::final_url_blocked($final)) continue;
            $body = (string) wp_remote_retrieve_body($res);
            if (strlen($body) > self::MAX_CSS_BYTES) $body = substr($body, 0, self::MAX_CSS_BYTES);
            // A sheet that FILLED the byte cap was cut mid-stream: drop the
            // dangling tail after its last complete rule so it can't bleed
            // across the newline join into the next sheet's first harvested
            // selector (see trim_truncated_css). The sheet still counts in
            // found.stylesheets and the truncation note is unaffected.
            if (strlen($body) === self::MAX_CSS_BYTES) $body = self::trim_truncated_css($body);
            $css .= "\n" . $body;
            // Origin attribution by the TRUE post-redirect host: platform-CDN
            // sheets carry the platform's defaults, everything else keeps the
            // site-owned trust it always had.
            if (self::stylesheet_is_vendor_origin($final)) {
                $vendor_sheet_css .= "\n" . $body;
            } else {
                $site_sheet_css .= "\n" . $body;
            }
            $fetched++;
            $total_bytes += strlen($body);

            // Follow this sheet's @imports (resolved against its TRUE
            // post-redirect URL), depth-capped. Each queued import passes the
            // same per-URL SSRF gates above before it is ever fetched.
            if ($cand['depth'] < self::MAX_IMPORT_DEPTH) {
                foreach (self::css_import_urls($body, $final) as $import) {
                    if (isset($seen[$import])) continue;
                    $seen[$import] = true;
                    $queue[] = ['href' => $import, 'order' => 0, 'score' => 0, 'depth' => $cand['depth'] + 1];
                }
            }
        }
        return ['css' => $css, 'site_css' => $site_sheet_css, 'vendor_css' => $vendor_sheet_css, 'count' => $fetched, 'truncated' => $truncated];
    }

    /**
     * Trim a byte-cap-TRUNCATED stylesheet back to the end of its last
     * complete rule. A sheet cut mid-declaration at MAX_CSS_BYTES leaves a
     * dangling tail (`.x{font-family:var(--vi`) that bleeds across the
     * concatenation boundary into the NEXT sheet's first harvested selector
     * (rasavineyards: the bleed prefixed the brandSource scope label).
     * Everything after the last closing brace goes; a sheet ending exactly
     * at a complete rule is unchanged, and a truncated sheet with no
     * complete rule at all contributes nothing rather than junk. The
     * newline join between sheets stays as the independent second guard so
     * two sheets can never fuse tokens even where a path misses the trim.
     */
    private static function trim_truncated_css(string $css): string
    {
        $last = strrpos($css, '}');
        if ($last === false) return '';
        return substr($css, 0, $last + 1);
    }

    /**
     * Every linked-stylesheet URL on the page (deduped, ANY origin), sorted by
     * brand-likelihood score then document order, each tagged depth 0. Split
     * out from the fetch loop so the collection stays pure and testable. The
     * priority sort exists because, in document order, the first sheets are
     * usually WP-core + plugin infrastructure (wp-includes, block-editor,
     * genesis-blocks) with no brand intent, spending the whole budget there
     * would miss the winery's own theme / Elementor CSS (e.g.
     * uploads/elementor/css/post-N.css where the real --e-global-color-primary
     * lives).
     *
     * @return array<int,array{href:string,order:int,score:int,depth:int}>
     */
    private static function stylesheet_candidates(string $html, string $base): array
    {
        if (!preg_match_all('#<link\b[^>]*>#i', $html, $links)) {
            return [];
        }
        $candidates = [];
        $seen = [];
        foreach ($links[0] as $idx => $tag) {
            // rel must contain "stylesheet".
            if (!preg_match('#rel\s*=\s*["\']?[^"\'>]*stylesheet#i', $tag)) continue;
            if (!preg_match('#href\s*=\s*["\']([^"\']+)["\']#i', $tag, $hm)) continue;

            $href = self::absolute_url(html_entity_decode($hm[1]), $base);
            if ($href === '' || !preg_match('#^https?://#i', $href)) continue;
            if (isset($seen[$href])) continue;
            $seen[$href] = true;
            $candidates[] = ['href' => $href, 'order' => $idx, 'score' => self::stylesheet_priority($href), 'depth' => 0];
        }
        if (empty($candidates)) return [];

        // Score desc, then document order asc, deterministic.
        usort($candidates, static function ($a, $b) {
            if ($a['score'] !== $b['score']) return $b['score'] <=> $a['score'];
            return $a['order'] <=> $b['order'];
        });
        return $candidates;
    }

    /**
     * Absolute http(s) URLs of the @import statements in a CSS body, resolved
     * against the sheet's own URL, deduped, in document order. Both forms
     * (@import url(...) and @import "..."), trailing media queries ignored.
     *
     * @return string[]
     */
    private static function css_import_urls(string $css, string $base): array
    {
        $out = [];
        if (!preg_match_all('/@import\s+(?:url\(\s*)?["\']?([^"\'()\s;]+)["\']?/i', $css, $m)) {
            return $out;
        }
        foreach ($m[1] as $raw) {
            $abs = self::absolute_url(html_entity_decode((string) $raw), $base);
            if ($abs === '' || !preg_match('#^https?://#i', $abs)) continue;
            if (!in_array($abs, $out, true)) $out[] = $abs;
        }
        return $out;
    }

    /**
     * Brand-likelihood score for a same-origin stylesheet href. Higher = fetch
     * sooner. Infra / framework sheets (WP core, block editor, common vendor
     * libraries) score negative so they're read last (usually past the cap);
     * the winery's own theme + page-builder CSS scores high. Deterministic and
     * case-insensitive.
     */
    private static function stylesheet_priority(string $href): int
    {
        $h = strtolower($href);
        $score = 0;

        // Infra / framework: no brand intent, deprioritise hard.
        $infra = ['/wp-includes/', '/wp-admin/', 'wp-block', 'wp-preferences', 'wp-components', 'genesis-blocks', 'dist/components', 'jquery', 'bootstrap', 'fontawesome', 'font-awesome', 'normalize', 'reset'];
        foreach ($infra as $p) {
            if (strpos($h, $p) !== false) { $score -= 20; break; }
        }
        // Generic plugin sheets are mild noise (a plugin CAN carry brand, so a
        // softer penalty than core infra).
        if (strpos($h, '/plugins/') !== false) $score -= 5;

        // Brand-likely locations.
        if (strpos($h, '/wp-content/themes/') !== false) $score += 20;
        if (strpos($h, 'uploads/elementor') !== false)   $score += 20;

        // Brand-likely name tokens.
        $prefer = ['global' => 8, 'theme' => 6, 'custom' => 6, 'main' => 5, 'style' => 4, 'app' => 4];
        foreach ($prefer as $tok => $pts) {
            if (strpos($h, $tok) !== false) $score += $pts;
        }
        return $score;
    }

    /**
     * Known platform-CDN stylesheet hosts. CSS served from these carries the
     * PLATFORM's shipped defaults (Commerce7 ships --c7-primary-color:#3860D6
     * from cdn.commerce7.com on every store; WineDirect/Vin65 templates and
     * Shopify vendor bundles are the same class), never the winery's own
     * choices, so vars harvested from them rank BELOW the site's own CSS and
     * below the tier-3 button rule. Matched by exact host or a dot-boundary
     * suffix; short and extensible by design.
     */
    private const VENDOR_CDN_HOSTS = ['cdn.commerce7.com', 'winedirect.com', 'vin65.com', 'cdn.shopify.com'];

    /**
     * Known platform-BUNDLED stylesheet paths: vendor origin even when a
     * winery serves them from its OWN host. A self-hosted copy of a
     * platform's shipped stylesheet carries the same defaults as the CDN
     * copy (frogsleap serves Commerce7's commerce7.css, with
     * `--c7-primary-color: #3860d6`, from its own host), so the host alone
     * cannot tell. Only the Commerce7 theme's bundled platform FILE is
     * listed, never the theme directory: that directory also carries the
     * winery's own assets/styles/style.css (frogsleap's #656A4C brand),
     * which must stay site-owned. The Commerce7 plugin directories (the
     * wordpress.org slug wp-commerce7, and a bare commerce7 install) are
     * platform code a winery never edits. Lowercase fragments matched
     * anywhere in the URL path (a WordPress install in a subdirectory still
     * matches); short and named by design.
     */
    private const VENDOR_STYLESHEET_PATHS = ['/wp-content/themes/commerce7/assets/styles/commerce7.css', '/wp-content/plugins/wp-commerce7/', '/wp-content/plugins/commerce7/'];

    /**
     * True when a stylesheet URL is served from a known platform CDN (see
     * VENDOR_CDN_HOSTS: host equality or a dot-boundary suffix match, so a
     * lookalike host `notvin65.com` never matches) or from a known
     * platform-bundled path on any host (see VENDOR_STYLESHEET_PATHS). Any
     * other origin, the winery's own domain or an unknown CDN it chose to
     * host on, keeps the SITE-OWNED trust every sheet had before this split.
     */
    private static function stylesheet_is_vendor_origin(string $url): bool
    {
        $host = strtolower((string) (wp_parse_url($url, PHP_URL_HOST) ?: ''));
        if ($host === '') return false;
        foreach (self::VENDOR_CDN_HOSTS as $vendor) {
            if ($host === $vendor) return true;
            if (substr($host, -(strlen($vendor) + 1)) === '.' . $vendor) return true;
        }
        $path = strtolower((string) (wp_parse_url($url, PHP_URL_PATH) ?: ''));
        foreach (self::VENDOR_STYLESHEET_PATHS as $vendor_path) {
            if (strpos($path, $vendor_path) !== false) return true;
        }
        return false;
    }

    // --------------------------------------------------------------------- //
    //  Signal extraction                                                    //
    // --------------------------------------------------------------------- //

    /**
     * Every colour-valued custom-property declaration, in DOCUMENT ORDER and
     * NOT deduped: array<int,array{name:string,hex:string}>. Multi-scheme sites
     * (Shopify) redeclare the same var name once per colour scheme, the brand
     * hue can sit in an early scheme while a later inverse scheme sets the SAME
     * name to black/white. Ranking the brand var needs to see every declared
     * value, so pick_brand_var() walks this list; a last-wins map would hide the
     * brand hue behind a trailing black/white redeclaration.
     *
     * @return array<int,array{name:string,hex:string}>
     */
    private static function css_custom_property_list(string $css): array
    {
        $out = [];
        if (!preg_match_all('/--([a-zA-Z0-9\-_]+)\s*:\s*([^;{}]+)/', $css, $m, PREG_SET_ORDER)) {
            return $out;
        }
        foreach ($m as $decl) {
            $name  = strtolower(trim(isset($decl[1]) ? $decl[1] : ''));
            $value = self::clean_var_value(isset($decl[2]) ? $decl[2] : '');
            // Bare-triplet parsing is enabled ONLY when the var name carries an
            // explicit colour token, so `--spacing: 8 16 24` can't become a
            // colour while `--color-button`/`--brand` still do.
            $hex   = self::to_hex($value, self::name_allows_triplet($name));
            if ($hex === null) continue;
            // A colour WORD in a font var is a family name (`--brand-font:
            // Crimson`), never a colour; see name_is_font_var.
            if (self::name_is_font_var($name) && self::named_colour_hex($value) !== null) continue;
            $out[] = ['name' => $name, 'hex' => $hex];
        }
        return $out;
    }

    /**
     * Colour-token gate for bare-triplet parsing. True when the custom-property
     * name contains a word that marks it as a colour var, so an ambiguous bare
     * "r,g,b"/"r g b" value is only read as a colour in that context. Hex,
     * rgb() and named-colour values are unambiguous and never gated (hsl() is
     * not parsed at all, see to_hex).
     */
    private static function name_allows_triplet(string $name): bool
    {
        static $tokens = ['color', 'colour', 'brand', 'accent', 'swatch', 'palette', 'background', 'fill', 'stroke', 'foreground', 'link', 'button'];
        foreach ($tokens as $t) {
            if (strpos($name, $t) !== false) return true;
        }
        return false;
    }

    /**
     * True when a custom-property name marks a FONT variable: it carries
     * font, family or typeface, or face as a whole word (so surface and
     * interface never match), and no colour word (color / colour / bg /
     * background / fill / stroke, so `--font-color` stays a colour var). A
     * colour WORD in such a var is a family name (`--brand-font: Crimson`,
     * `--card-font: Linen`), so the var list builders never read it as a
     * named colour; a hex or rgb() value in the same var keeps today's
     * behaviour.
     */
    private static function name_is_font_var(string $name): bool
    {
        if (!preg_match('/font|family|typeface|(?<![a-z])face(?![a-z])/', $name)) return false;
        return !preg_match('/colou?r|(?<![a-z])bg(?![a-z])|background|fill|stroke/', $name);
    }

    /**
     * True when any var name a var() chain dereferenced (resolve_var_reference's
     * $visited) is a font var: a colour WORD reached through one
     * (`--c7-primary-button-bg: var(--brand-font)` with `--brand-font:
     * Crimson`) is a family name, never a colour. Hex values are unaffected.
     *
     * @param string[] $names
     */
    private static function var_chain_has_font_var(array $names): bool
    {
        foreach ($names as $name) {
            if (self::name_is_font_var((string) $name)) return true;
        }
        return false;
    }

    /**
     * Normalise a custom-property VALUE before colour parsing: drop any inline
     * CSS comment and a trailing `!important` flag, so a declared value like
     * `#7C3AED !important` (Elementor) or `0,110,255 !important` still resolves
     * to a colour. Falls back to the raw value if preg_replace errors.
     */
    private static function clean_var_value(string $value): string
    {
        $v = preg_replace('#/\*.*?\*/#s', ' ', $value);
        if (!is_string($v)) $v = $value;
        $stripped = preg_replace('/!\s*important\s*$/i', '', $v);
        if (is_string($stripped)) $v = $stripped;
        return trim($v);
    }

    /**
     * Last-wins [name => hex] map built from a declaration list, for the surface
     * and diagnostics paths (which want one value per name in cascade order).
     *
     * @param array<int,array{name:string,hex:string}> $list
     * @return array<string,string>
     */
    private static function vars_map(array $list): array
    {
        $out = [];
        foreach ($list as $decl) {
            $name = isset($decl['name']) ? $decl['name'] : '';
            if ($name === '') continue;
            $out[$name] = isset($decl['hex']) ? $decl['hex'] : '';   // last wins
        }
        return $out;
    }

    /**
     * True when a custom-property name is framework/plugin noise. Covers BOTH
     * the soft page-builder prefixes and the hard widget/preset ones, so the
     * surface/text picker (pick_named_var) excludes every kind of vendor var as
     * before. The brand-var picker uses is_hard_vendor_var separately to let a
     * builder ROLE var through.
     */
    private static function is_vendor_var(string $name): bool
    {
        foreach (self::VENDOR_VAR_PREFIXES as $p) {
            if (strpos($name, $p) === 0) {
                return true;
            }
        }
        return self::is_hard_vendor_var($name);
    }

    /**
     * True when a var is HARD vendor noise: a widget/review app's own colours,
     * or a WP block-preset palette entry. These are never the winery's brand,
     * so the brand-var picker excludes them even if the name carries a brand
     * role token.
     */
    private static function is_hard_vendor_var(string $name): bool
    {
        foreach (self::VENDOR_APP_PREFIXES as $p) {
            if (strpos($name, $p) === 0) {
                return true;
            }
        }
        foreach (self::VENDOR_CORE_PREFIXES as $p) {
            if (strpos($name, $p) === 0) {
                return true;
            }
        }
        // WP block-preset palette vars, wherever the fragment appears.
        return strpos($name, 'wp--preset') !== false;
    }

    /**
     * Platform DEFAULT colour values. Commerce7 ships
     * `--c7-primary-color:#3860D6` from cdn.commerce7.com on every store
     * (cakebread's CSS carries the matching rgba(56,96,214,.25) focus ring),
     * so that value winning any brand pick means the matcher read the
     * PLATFORM's default, not the winery's brand, UNLESS a SITE-OWNED
     * declaration carries the same value (then the winery genuinely chose
     * it). Values are normalized #RRGGBB uppercase, derived from the
     * platform's shipped :root defaults (see PLATFORM_DEFAULT_TOKENS for the
     * source and the hex-to-token table).
     */
    private const PLATFORM_DEFAULT_HEX = ['#3860D6', '#3251AE', '#264BBA', '#CA0505', '#FFEBEB', '#FBA213', '#016047'];

    /**
     * The platform's OWN default-token names (no leading --). A declaration
     * of one of these is the platform's shipped default wherever the sheet
     * is served from (a self-hosted commerce7.css declares
     * `--c7-primary-color: #3860d6` exactly like the CDN copy), so it never
     * confirms that the site chose the value, but ONLY while it still carries
     * THAT token's own shipped default: a token re-declared to any other
     * value (another palette hex included, `--c7-primary-color: #016047`) is
     * the winery's choice and confirms it like any site declaration.
     *
     * DATA SOURCE for this token => default map and PLATFORM_DEFAULT_HEX (its
     * distinct values): the :root blocks of Commerce7's shipped commerce7.css
     * (v7.0.4, the copy frogsleap self-hosts). Every `--c7-*` token whose
     * default is a colour the brand pipeline could pick (not near-white,
     * near-black or greyish by the extractor's own gates, the ones
     * most_frequent_saturated applies) maps to that default:
     * --c7-primary-color-text is the default link colour and
     * --c7-primary-color-dark the default button hover.
     * --c7-primary-color-focus ships rgba(56, 96, 214, 0.25), not a hex, so it
     * carries no literal that could confirm anything and is not mapped.
     * Neutral defaults are left out (those gates already drop them): #232324,
     * #50505A, #000000, #FFFFFF, #F7F8FA, #E3E3E8, #F3F6FF, #B2B2B8, #DEDFE3,
     * #CECFD4, #F1F1F4 (--c7-info-bg, the only info colour Commerce7 ships),
     * #FFF6E5, #E8FCF7 and #E6E8ED. Re-derive both together when the platform
     * ships new defaults.
     */
    private const PLATFORM_DEFAULT_TOKENS = [
        'c7-primary-color'      => '#3860D6',
        'c7-primary-color-text' => '#3251AE',
        'c7-primary-color-dark' => '#264BBA',
        'c7-error'              => '#CA0505',
        'c7-notification'       => '#CA0505',
        'c7-error-bg'           => '#FFEBEB',
        'c7-warning'            => '#FBA213',
        'c7-success'            => '#016047',
    ];

    /**
     * True when a candidate hex is a denylisted platform default that the
     * SITE'S OWN CSS never declares (a case-insensitive literal check on the
     * site-owned CSS; a site confirming the value via rgb() notation is an
     * accepted miss, the denylist stays conservative). Consulted by every
     * brand pick: the resolver tiers, the tier-3 rule's background fill, and
     * the legacy pick_brand_var walk (jordan's #3860D6 came through legacy).
     */
    private static function is_denylisted_platform_default(string $hex, string $site_css): bool
    {
        if (!in_array(strtoupper($hex), self::PLATFORM_DEFAULT_HEX, true)) return false;
        // A platform token declaration is discounted only while it still
        // carries THAT token's own shipped default (see
        // PLATFORM_DEFAULT_TOKENS): such a declaration is blanked, so a
        // site-written declaration of any OTHER property or var, or a token
        // re-declared to a different value, still confirms the colour. This
        // also covers a self-hosted platform sheet that no
        // VENDOR_STYLESHEET_PATHS entry knows about.
        $owned = $site_css;
        foreach (self::PLATFORM_DEFAULT_TOKENS as $token => $default) {
            $blanked = preg_replace_callback('/(?<![\w\-])--' . preg_quote($token, '/') . '\s*:\s*([^;{}]*)/i', static function ($m) use ($default) {
                return self::to_hex(self::clean_var_value($m[1])) === $default ? ' ' : $m[0];
            }, $owned);
            if (is_string($blanked)) $owned = $blanked;
        }
        return stripos($owned, $hex) === false;
    }

    /**
     * Strip CSS comments from harvested SELECTOR text. Compiled CSS
     * (Squarespace's LESS pipeline) interleaves annotation comments with the
     * rules ("line 12, src/less/theme.less" style), and the flat style_rules
     * tokenizer captures everything since the previous brace as the
     * "selector", comment included, so the junk used to break the
     * exact-match scope gates (global_scope_of never saw a clean ':root')
     * AND leak into the operator-facing brandSource label. Complete comment
     * pairs, an unterminated head (opener with no closer in the captured
     * range), and an orphaned tail (a closer whose opener the tokenizer cut
     * off at a brace) are all dropped, each replaced by a SPACE so two
     * selector tokens can never fuse into a false scope match. Falls back
     * to the raw text if preg_replace errors.
     */
    private static function strip_selector_comments(string $sel): string
    {
        $v = preg_replace('#/\*.*?\*/#s', ' ', $sel);   // complete pairs
        if (!is_string($v)) return $sel;
        $head = preg_replace('#/\*.*$#s', ' ', $v);     // unterminated head
        if (is_string($head)) $v = $head;
        $tail = preg_replace('#^.*\*/#s', ' ', $v);     // orphaned tail
        if (is_string($tail)) $v = $tail;
        return $v;
    }

    /**
     * Sanitise selector-derived text for the human-facing diagnostics
     * labels (the brandSource/surfaceSource scope suffix): comments
     * stripped (see strip_selector_comments), whitespace collapsed, and
     * hard-capped at 60 chars with an ellipsis, so no junk a tokenizer
     * captures can flood the label shown to the operator. EVERY emission
     * path that appends a selector/scope suffix routes through here.
     */
    private static function clean_scope_label(string $sel): string
    {
        $v = self::strip_selector_comments($sel);
        $collapsed = preg_replace('/\s+/', ' ', $v);
        if (is_string($collapsed)) $v = $collapsed;
        $v = trim($v);
        if (strlen($v) <= 60) return $v;
        // Byte-capped without splitting a multibyte char: mb_strcut backs up
        // to the previous UTF-8 boundary, so a char straddling byte 57 can
        // never leave invalid UTF-8 in the diagnostic label.
        return mb_strcut($v, 0, 57, 'UTF-8') . '...';
    }

    /**
     * The selector that declares a custom property composing to the given
     * hex, for brandSource attribution on the legacy pick_brand_var path
     * (brandSource always carries a scope suffix now; the sweep's worst
     * mis-pick had none). First declaring rule wins, matching the picker's
     * document-order walk; comments strip, whitespace collapses and long
     * selector lists truncate (see clean_scope_label) so diagnostics stay
     * readable. 'unscoped' when no rule can be attributed (a declaration
     * outside any brace pair).
     */
    private static function var_declaring_scope(string $css, string $name, string $hex): string
    {
        foreach (self::style_rules($css) as $rule) {
            if (!preg_match_all('/--([a-zA-Z0-9\-_]+)\s*:\s*([^;{}]+)/', $rule['body'], $m, PREG_SET_ORDER)) continue;
            foreach ($m as $decl) {
                $decl_name = strtolower(trim(isset($decl[1]) ? $decl[1] : ''));
                if ($decl_name !== $name) continue;
                $value = self::clean_var_value(isset($decl[2]) ? $decl[2] : '');
                if (self::to_hex($value, self::name_allows_triplet($decl_name)) !== $hex) continue;
                $sel = self::clean_scope_label($rule['sel']);
                if ($sel === '') return 'unscoped';
                return $sel;
            }
        }
        return 'unscoped';
    }

    /**
     * Pick the strongest brand-named colour var from the full declaration list.
     * Ranks names by how brand-ish they are; skips vendor noise, denylisted
     * platform defaults the site never declares, and near-white/near-black
     * values (those are surfaces or text, not a brand hue). Walking the list
     * (not a last-wins map) means a black/white redeclaration of a role var in
     * a trailing scheme can't bury the brand hue declared for that same var
     * earlier.
     *
     * @param array<int,array{name:string,hex:string}> $decls
     * @param string $site_css SITE-OWNED CSS backing the platform-default denylist
     * @return array{name:string,hex:string}|null
     */
    private static function pick_brand_var(array $decls, string $site_css = ''): ?array
    {
        $ranked = [];
        foreach ($decls as $decl) {
            $name = isset($decl['name']) ? $decl['name'] : '';
            $hex  = isset($decl['hex']) ? $decl['hex'] : '';
            if ($name === '' || $hex === '') continue;
            // Hard vendor noise (review apps, WP block presets) is never brand,
            // even when the name carries a role token.
            if (self::is_hard_vendor_var($name)) continue;
            // A platform's shipped default value never wins the legacy picker
            // either (jordan: the vendor-default #3860D6 came through here).
            if (self::is_denylisted_platform_default($hex, $site_css)) continue;
            // Reject near-white (surface/text) and any low-chroma neutral (pure
            // black, dark or mid grey). The dark end is gated on CHROMA, not
            // luminance: a very dark but CHROMATIC brand hue, oxblood #461612
            // (luminance ~0.019, just under the near-black cutoff), burgundy,
            // deep navy, is legitimate and must survive. is_greyish already
            // rejects #000/#111 (zero chroma) and neutral greys, so a plain
            // luminance near-black test is not needed here (it wrongly dropped
            // dark maroons). A neutral `--color-button:#333333` is still skipped.
            if (self::is_near_white($hex)) continue;
            if (self::is_greyish($hex)) continue;
            $semantic = self::semantic_role_score($name);
            // Soft page-builder noise is skipped UNLESS the var names a brand
            // ROLE, Elementor's `--e-global-color-primary` IS the site's brand
            // even though the `e-global` prefix is otherwise noise.
            if ($semantic <= 0 && self::is_vendor_var($name)) continue;
            $score = self::brand_name_score($name);
            if ($score <= 0) continue;
            $ranked[] = ['name' => $name, 'hex' => $hex, 'score' => $score];
        }
        if (empty($ranked)) return null;
        usort($ranked, static function ($a, $b) {
            return $b['score'] <=> $a['score'];
        });
        return ['name' => $ranked[0]['name'], 'hex' => $ranked[0]['hex']];
    }

    /** Higher = more likely a real brand colour. 0 = not brand-named. */
    private static function brand_name_score(string $name): int
    {
        // HIGHEST tier: semantic brand-interactive ROLE vars. Modern theme
        // systems (Shopify especially) name the brand hue by the role it plays:
        // --color-button, --color-link, rather than "brand", and that role
        // var is the strongest brand signal on the page. Checked before the
        // generic brand/primary/accent tiers below so a role var always wins.
        $semantic = self::semantic_role_score($name);
        if ($semantic > 0) return $semantic;

        // Exact, unambiguous brand tokens.
        $strong = ['brand', 'brand-primary', 'brand-color', 'brand-colour', 'primary', 'color-primary', 'colour-primary', 'accent', 'color-accent', 'colour-accent', 'theme-primary', 'main-color'];
        if (in_array($name, $strong, true)) return 100;
        // Contains a brand word.
        if (strpos($name, 'brand') !== false)   return 80;
        if (strpos($name, 'primary') !== false) return 70;
        if (strpos($name, 'accent') !== false)  return 60;
        // Generic "color-*" / "theme-*" custom props, weak but usable.
        if (strpos($name, 'theme') === 0)        return 30;
        if (strpos($name, 'color-') === 0 || strpos($name, 'colour-') === 0) return 20;
        return 0;
    }

    /**
     * Score a var name against the semantic brand-role tiers, most
     * brand-defining first. Returns 0 when the name carries no role token. The
     * name only has to CONTAIN a token, so a scheme prefix or suffix still
     * matches (Shopify emits e.g. `--color-button` inside per-scheme blocks).
     * Priority: button > link > primary > brand > (bare) brand/primary >
     * accent > (bare) accent > foreground (a weaker last-resort fallback).
     */
    private static function semantic_role_score(string $name): int
    {
        // [token, score], highest priority first. Both US/UK spellings.
        $tiers = [
            ['color-button', 200], ['colour-button', 200],
            ['color-link', 190],   ['colour-link', 190],
            ['color-primary', 180], ['colour-primary', 180],
            ['color-brand', 170],  ['colour-brand', 170],
            ['brand', 160],
            ['primary', 150],
            ['color-accent', 140], ['colour-accent', 140],
            ['accent', 130],
            ['color-foreground', 110], ['colour-foreground', 110],
        ];
        foreach ($tiers as $tier) {
            if (strpos($name, $tier[0]) !== false) return $tier[1];
        }
        return 0;
    }

    // --------------------------------------------------------------------- //
    //  Deterministic primary-button resolver                                //
    // --------------------------------------------------------------------- //

    /**
     * Selector scopes trusted for GLOBAL brand tokens. A var declared under a
     * section/component scope, or under a non-primary Shopify colour scheme
     * (.color-scheme-N for N > 1), is that block's local accent, not the
     * site's primary (silveroak: .color-scheme-3 carried #461612 while :root
     * carried the real 0 0 0). The bare universal selector counts as global
     * too: ridge declares its ENTIRE Commerce7 var block under `* { ... }`,
     * and dropping it left tier 1 blind there. Only the EXACT part '*'
     * qualifies (global_scope_of compares whole comma-separated parts), so
     * `*.qualified` and descendant forms stay out.
     */
    private const GLOBAL_VAR_SCOPES = [':root', 'html', 'body', '.color-scheme-1', '*'];

    /**
     * Tier-3 primary-button selectors, base state only, in PRIORITY order:
     * primary-NAMED platform CTA classes first (Commerce7's .c7-btn--primary
     * and Foundation's .button.primary, jordan's real sage CTA, included),
     * then the generic fallbacks. The first candidate that RESOLVES a
     * background wins, NOT document order across candidates: ridge's
     * Contact Form 7 white submit rule sat earlier in the CSS than
     * Commerce7's real .c7-btn--primary and used to win the resolve.
     * Compared per comma-separated selector part, exact after
     * quote-stripping, so `.section .button--primary` (component scope) and
     * `.button--primary:hover` (state) never match.
     */
    private const PRIMARY_BUTTON_SELECTORS = ['.button--primary', '.btn-primary', '.c7-btn--primary', '.button.primary', 'button[type=submit]', 'a.button'];

    /**
     * Form-plugin selector tokens (Contact Form 7, Gravity Forms, Ninja
     * Forms, WPForms). A rule whose selector list carries one of these
     * styles a contact-form control, not the brand CTA, so tier 3 skips the
     * whole rule (ridge: `input[type=submit],button[type=submit],.wpcf7-submit`
     * declares a WHITE background that used to become brandPrimary).
     */
    private const FORM_PLUGIN_TOKENS = ['wpcf7', 'gform', 'ninja-form', 'wpforms'];

    /** True when a selector carries a form-plugin token (tier 3 skips the rule). */
    private static function selector_is_form_plugin(string $sel): bool
    {
        foreach (self::FORM_PLUGIN_TOKENS as $t) {
            if (strpos($sel, $t) !== false) return true;
        }
        return false;
    }

    /**
     * Resolve the site's primary-button colour DETERMINISTICALLY, in tier
     * order, stopping at the first non-empty tier. $css is the SITE-OWNED
     * CSS (inline + same-site sheets); $vendor_css the known platform-CDN
     * sheets (see stylesheet_is_vendor_origin). Ordering with origin:
     *   1  site tier 1  a base-state primary-button background var in a
     *      global scope, in TWO passes: names that explicitly say
     *      background/bg win outright, and the broader primary-button-*
     *      wildcard runs only when no explicit-background name exists (so
     *      the LABEL colour of a -color/-background pair can never outrank
     *      its sibling); alt/secondary/ghost tokens never match (that is the
     *      SECONDARY button, see var_name_is_alt_role)
     *   2  site tier 2  a named brand/primary token var in a global scope (a
     *      Shopify "r g b" triple composes to hex via the to_hex triplet path)
     *   3  tier 3       the declared background of the winning primary-button
     *      rule, resolved across the FULL cascade (all sheets), so a site
     *      sheet's later .c7-btn--primary override beats a vendor CDN's
     *      earlier rule (var() backgrounds resolve through the global-scope
     *      var map, chains included)
     *   4  vendor tier 1, 5  vendor tier 2  the same var tiers over the
     *      platform-CDN CSS, last: a platform's SHIPPED default (jordan's
     *      #3860D6) must never beat the site's own declarations, and
     *      denylisted default values are skipped outright unless the site's
     *      own CSS carries the same value.
     * A near-white colour (is_near_white, the same test the frequency tier
     * uses) never wins at ANY tier on a LIGHT or unknown page: a white or
     * ghost button there is not the brand, so it passes the turn exactly like
     * a transparent background and the later tiers, then extract()'s
     * fallback cascade, run. On a DARK page ($page_dark, the same
     * dark_page_candidate decision resolve_surfaces makes) a near-white
     * button is the site's real CTA and stays eligible at its own tier.
     * State vars (hover/active/focus/disabled) never win, hard vendor vars
     * (review apps, WP presets) never win, and the source string carries the
     * declaring scope (`css-var:<name>@<selector>`, '[vendor]'-suffixed for
     * a vendor-CDN pick) so a scope bug like the .color-scheme-3 pick is
     * visible in diagnostics. With no vendor CSS the order is the familiar
     * tier 1 > tier 2 > tier 3.
     *
     * 'confident' marks a colour safe to pin as actionPrimary: tiers 1 and 3
     * name the button itself; tier 2 only when the token is an explicit
     * primary role ('brand'/'accent' tokens set brandPrimary but leave the
     * button to derivation).
     *
     * @param array|null  $button_rule primary_button_rule() result (shared scan)
     * @param string|null $vendor_css  platform-CDN CSS (null/empty: none)
     * @return array{hex:string,source:string,tier:int,confident:bool,hover:?string,text:?string}|null
     */
    private static function resolve_primary_button(string $css, ?array $button_rule, ?string $vendor_css = null, bool $page_dark = false): ?array
    {
        $site_scoped   = self::scoped_var_list($css);
        $vendor_scoped = ($vendor_css !== null && $vendor_css !== '') ? self::scoped_var_list($vendor_css) : [];
        $scoped        = array_merge($site_scoped, $vendor_scoped);
        $text          = self::resolve_button_text($scoped, $button_rule);

        // Site-owned tokens first.
        $pick = self::tier1_var_pick($site_scoped, $scoped, $css, $text, '', $page_dark);
        if ($pick !== null) return $pick;
        $pick = self::tier2_var_pick($site_scoped, $scoped, $css, $text, '', $page_dark);
        if ($pick !== null) return $pick;

        // Tier 3: the winning primary-button rule's declared background
        // (resolved across the full cascade; primary_button_rule's own
        // denylist already dropped a vendor-default bg the site never
        // declares, letting the site's later override rule fill the field).
        if ($button_rule !== null && $button_rule['bg'] !== null) {
            return [
                'hex'       => $button_rule['bg'],
                'source'    => 'button-rule:' . self::clean_scope_label($button_rule['selector']),
                'tier'      => 3,
                'confident' => true,
                'hover'     => null,
                'text'      => $text,
            ];
        }

        // Vendor-CDN tokens only when nothing site-owned resolved.
        $pick = self::tier1_var_pick($vendor_scoped, $scoped, $css, $text, '[vendor]', $page_dark);
        if ($pick !== null) return $pick;
        return self::tier2_var_pick($vendor_scoped, $scoped, $css, $text, '[vendor]', $page_dark);
    }

    /**
     * Tier-1 scan over ONE origin's scoped vars (two passes: explicit
     * background names, then the primary-button-* wildcard). $all_scoped
     * feeds the hover-sibling lookup so a base var still finds its -hover
     * sibling wherever it is declared; $site_css backs the platform-default
     * denylist (a site-owned candidate trivially passes it, its own CSS
     * carries the value); $origin suffixes the source ('' site, '[vendor]').
     *
     * @return array{hex:string,source:string,tier:int,confident:bool,hover:?string,text:?string}|null
     */
    private static function tier1_var_pick(array $scoped, array $all_scoped, string $site_css, ?string $text, string $origin, bool $page_dark = false): ?array
    {
        foreach ([true, false] as $explicit_pass) {
            foreach ($scoped as $decl) {
                if (self::is_hard_vendor_var($decl['name'])) continue;
                $matches = $explicit_pass
                    ? self::tier1_explicit_bg_matches($decl['name'])
                    : self::tier1_wildcard_matches($decl['name']);
                if (!$matches) continue;
                if (self::is_denylisted_platform_default($decl['hex'], $site_css)) continue;
                if (!$page_dark && self::is_near_white($decl['hex'])) continue;   // a white button is the brand only on a dark page
                return [
                    'hex'       => $decl['hex'],
                    'source'    => 'css-var:' . $decl['name'] . '@' . self::clean_scope_label($decl['scope']) . $origin,
                    'tier'      => 1,
                    'confident' => true,
                    'hover'     => self::hover_sibling($all_scoped, $decl['name']),
                    'text'      => $text,
                ];
            }
        }
        return null;
    }

    /**
     * Tier-2 scan over ONE origin's scoped vars: the first named
     * brand/primary token. Same denylist / hover / origin plumbing as
     * tier1_var_pick.
     *
     * @return array{hex:string,source:string,tier:int,confident:bool,hover:?string,text:?string}|null
     */
    private static function tier2_var_pick(array $scoped, array $all_scoped, string $site_css, ?string $text, string $origin, bool $page_dark = false): ?array
    {
        foreach ($scoped as $decl) {
            if (self::is_hard_vendor_var($decl['name'])) continue;
            $token = self::tier2_brand_token($decl['name']);
            if ($token === null) continue;
            if (self::is_denylisted_platform_default($decl['hex'], $site_css)) continue;
            if (!$page_dark && self::is_near_white($decl['hex'])) continue;   // a white button is the brand only on a dark page
            return [
                'hex'       => $decl['hex'],
                'source'    => 'css-var:' . $decl['name'] . '@' . self::clean_scope_label($decl['scope']) . $origin,
                'tier'      => 2,
                'confident' => in_array($token, ['color-primary', 'colour-primary', 'primary'], true),
                'hover'     => self::hover_sibling($all_scoped, $decl['name']),
                'text'      => $text,
            ];
        }
        return null;
    }

    /**
     * Colour-valued custom properties declared in a GLOBAL scope (see
     * GLOBAL_VAR_SCOPES), document order, with the scope kept:
     * array<int,array{name:string,hex:string,scope:string}>. Bare "r g b"
     * triplets compose to hex under the same colour-named gate as the flat
     * list. A var()-valued declaration resolves through the GLOBAL-scope raw
     * var map (recursively, cycle-guarded), so a token chain like cakebread's
     * `--c7-primary-button-bg: var(--c7-primary-color)` ->
     * `var(--color-primary)` -> #833921 still composes; an unresolvable
     * reference drops the declaration as before. Near-black/grey values are
     * NOT filtered here: a #252525 or #000000 primary button is legitimate
     * (ridge/silveroak are exactly that), the brand-var picker's chroma gates
     * apply only to its own tiers.
     */
    private static function scoped_var_list(string $css): array
    {
        $out = [];
        $raw_vars = self::global_raw_var_map($css);
        foreach (self::style_rules($css) as $rule) {
            $scope = self::global_scope_of($rule['sel']);
            if ($scope === null) continue;
            if (!preg_match_all('/--([a-zA-Z0-9\-_]+)\s*:\s*([^;{}]+)/', $rule['body'], $m, PREG_SET_ORDER)) continue;
            foreach ($m as $decl) {
                $name  = strtolower(trim(isset($decl[1]) ? $decl[1] : ''));
                $value = self::clean_var_value(isset($decl[2]) ? $decl[2] : '');
                if ($name === '') continue;
                $hex = self::to_hex($value, self::name_allows_triplet($name));
                $parsed = $value;
                $chain = [];
                if ($hex === null && stripos($value, 'var(') === 0) {
                    $resolved = self::resolve_var_reference($value, $raw_vars, $chain);
                    if ($resolved !== null) {
                        $hex = self::to_hex($resolved, self::name_allows_triplet($name));
                        $parsed = $resolved;
                    }
                }
                if ($hex === null) continue;
                // A colour WORD in a font var, or reached through one in the
                // var() chain, is a family name, never a colour.
                if (self::named_colour_hex($parsed) !== null
                    && (self::name_is_font_var($name) || self::var_chain_has_font_var($chain))) continue;
                $out[] = ['name' => $name, 'hex' => $hex, 'scope' => $scope];
            }
        }
        return $out;
    }

    /**
     * The global scope a selector declares vars for, or null. Any
     * comma-separated part that IS (exactly) one of GLOBAL_VAR_SCOPES
     * qualifies the rule; a descendant/qualified form (`.section :root`?,
     * `.color-scheme-3`, `body .hero`) never does.
     */
    private static function global_scope_of(string $sel): ?string
    {
        foreach (explode(',', $sel) as $part) {
            $part = trim($part);
            foreach (self::GLOBAL_VAR_SCOPES as $scope) {
                if ($part === $scope) return $scope;
            }
        }
        return null;
    }

    /**
     * Raw (uncomposed) custom-property values declared in a GLOBAL scope
     * (GLOBAL_VAR_SCOPES, the same scopes tier 1 trusts, `*` included), as a
     * last-wins [name => value] map in cascade order. Used to resolve var()
     * references in tier-3 button declarations and the CTA radius
     * preference. Values stay RAW (not composed to hex) so a one-step var
     * chain (a var whose value is another var) can still resolve.
     *
     * @return array<string,string>
     */
    private static function global_raw_var_map(string $css): array
    {
        $out = [];
        foreach (self::style_rules($css) as $rule) {
            if (self::global_scope_of($rule['sel']) === null) continue;
            if (!preg_match_all('/--([a-zA-Z0-9\-_]+)\s*:\s*([^;{}]+)/', $rule['body'], $m, PREG_SET_ORDER)) continue;
            foreach ($m as $decl) {
                $name  = strtolower(trim(isset($decl[1]) ? $decl[1] : ''));
                $value = self::clean_var_value(isset($decl[2]) ? $decl[2] : '');
                if ($name === '' || $value === '') continue;
                $out[$name] = $value;   // last wins (cascade order)
            }
        }
        return $out;
    }

    /**
     * Follow a `var(--x)` / `var(--x, fallback)` reference through the
     * GLOBAL-scope raw var map, RECURSIVELY: real token systems chain three
     * or more deep (cakebread: --c7-primary-button-bg -> --c7-primary-color
     * -> --color-primary -> #833921, which a 2-lookup cap misclassified as
     * not-a-colour). Dereferences are capped at 8 with a seen-set cycle
     * guard (A -> B -> A resolves to null, never loops); an unknown name
     * falls to the reference's own fallback when it has one, and the
     * fallback may itself be a reference or carry parens (`var(--x,
     * rgb(1 2 3))`). Returns the resolved VALUE string, still unvalidated
     * (the caller parses it as a colour or a length; to_hex accepts modern
     * `rgb(r g b / a)` forms and, name-gated, bare "r g b" triples), or null
     * when the input is not a var() reference or the reference cannot be
     * resolved, so the caller skips the declaration instead of emitting a
     * literal `var()`.
     */
    private static function resolve_var_reference(string $value, array $raw_vars, ?array &$visited = null): ?string
    {
        // $visited (optional, by reference) receives every DECLARED var name
        // the chain dereferenced, so a colour caller can refuse a colour WORD
        // reached through a font var (see var_chain_has_font_var).
        $visited = [];
        $v = trim($value);
        $was_var = false;
        $seen = [];
        for ($depth = 0; $depth < 8; $depth++) {
            if (!preg_match('/^var\(\s*--([a-zA-Z0-9\-_]+)\s*(?:,\s*(.+))?\)$/is', $v, $m)) break;
            $was_var = true;
            $name = strtolower($m[1]);
            if (isset($seen[$name])) return null;   // cycle: unresolvable
            $seen[$name] = true;
            if (isset($raw_vars[$name])) {
                // Only a DECLARED var joins the chain: an undefined font var
                // never gates its own fallback (`var(--heading-font, navy)`).
                $visited[] = $name;
                $v = trim($raw_vars[$name]);
            } elseif (isset($m[2]) && trim($m[2]) !== '') {
                $v = trim($m[2]);
            } else {
                return null;
            }
        }
        if (!$was_var) return null;
        // A chain still unresolved past the cap is never emitted raw.
        if (stripos($v, 'var(') === 0) return null;
        return $v;
    }

    /**
     * A declared colour value as hex: a literal via to_hex, else a var()
     * reference resolved through the GLOBAL-scope raw var map (tier-3
     * button backgrounds and text colours are commonly references to vars
     * tier 1 trusts, Commerce7's `background: var(--c7-primary-button-bg)`).
     * Null when neither parses; a resolved value must still be a hex/rgb()
     * literal or a CSS named colour (bare triplets stay out of this path).
     */
    private static function colour_or_var_hex(string $value, array $raw_vars): ?string
    {
        $v = self::clean_var_value($value);
        $hex = self::to_hex($v);
        if ($hex !== null) return $hex;
        $chain = [];
        $resolved = self::resolve_var_reference($v, $raw_vars, $chain);
        if ($resolved === null) return null;
        // A colour WORD reached through a font var is a family name.
        if (self::named_colour_hex($resolved) !== null && self::var_chain_has_font_var($chain)) return null;
        return self::to_hex($resolved);
    }

    /** True when a var name carries a non-resting state token (never a base colour). */
    private static function var_name_is_state(string $name): bool
    {
        foreach (['hover', 'active', 'focus', 'disabled'] as $t) {
            if (strpos($name, $t) !== false) return true;
        }
        return false;
    }

    /**
     * True when a var name carries an alt/secondary-role token: that names
     * the SECONDARY (alt/ghost/tertiary/outline) button, never the primary
     * fill, so tiers 1 and 2 exclude it entirely. Cakebread's unresolvable
     * primary used to fall through to `--c7-alt-button-bg: #dedfe3` (the
     * secondary button); an unresolvable primary must drop to tier 3 (the
     * button rule), NEVER to another token.
     */
    private static function var_name_is_alt_role(string $name): bool
    {
        foreach (['alt', 'secondary', 'ghost', 'tertiary', 'outline'] as $t) {
            if (strpos($name, $t) !== false) return true;
        }
        return false;
    }

    /**
     * Shared tier-1 exclusions: non-resting state tokens, alt/secondary-role
     * tokens, and the non-fill sibling roles (text/label/border/...), so
     * neither tier-1 pass can pick anything but the PRIMARY button's own fill.
     */
    private static function tier1_excluded(string $name): bool
    {
        if (self::var_name_is_state($name)) return true;
        if (self::var_name_is_alt_role($name)) return true;
        foreach (['text', 'label', 'border', 'outline', 'shadow', 'radius', 'font'] as $t) {
            if (strpos($name, $t) !== false) return true;
        }
        return false;
    }

    /**
     * Tier-1 PASS 1: a base-state button var whose name EXPLICITLY says
     * background: 'bg' or 'background' as a whole hyphen-delimited segment of
     * a button/btn-named var (--c7-primary-button-bg,
     * --color-primary-button-background, --button-bg, --btn-primary-bg,
     * --button-background), plus Shopify Dawn's bare fill var --color-button
     * (an "r g b" triple that composes via the to_hex triplet path; its
     * -text/-hover siblings fall to the shared exclusions). These names can
     * never be the label colour, so they always outrank the wildcard pass.
     */
    private static function tier1_explicit_bg_matches(string $name): bool
    {
        if (self::tier1_excluded($name)) return false;
        if (preg_match('/(?:^|-)(?:bg|background)(?:-|$)/', $name)
            && (strpos($name, 'button') !== false || strpos($name, 'btn') !== false)) {
            return true;
        }
        if (strpos($name, 'color-button') !== false || strpos($name, 'colour-button') !== false) {
            return true;
        }
        return false;
    }

    /**
     * Tier-1 PASS 2: the --primary-button-* wildcard, run only when no
     * explicit-background name exists. Names ending in -color/-colour are the
     * TEXT colour by the -color/-background pairing convention
     * (--primary-button-color pairs with --primary-button-background), so the
     * SUFFIX is excluded here; a name merely CONTAINING 'color'
     * (--color-primary-button-background) is legitimate and belongs to the
     * explicit pass, so no bare-substring exclusion.
     */
    private static function tier1_wildcard_matches(string $name): bool
    {
        if (self::tier1_excluded($name)) return false;
        if (preg_match('/-colou?r$/', $name)) return false;
        return strpos($name, 'primary-button-') === 0;
    }

    /**
     * Tier-2 match: the brand/primary token the name carries, or null. Exact
     * token, optionally with a colour-ish suffix (-rgb / -color / -colour),
     * so --color-primary-rgb (Shopify triple) matches while
     * --color-primary-button-background (tier 1's territory) and
     * --jdgm-primary-color (prefixed vendor noise) do not. Alt/secondary-role
     * names are excluded outright (see var_name_is_alt_role), the exact-token
     * shapes can't carry them anyway.
     */
    private static function tier2_brand_token(string $name): ?string
    {
        if (self::var_name_is_state($name)) return null;
        if (self::var_name_is_alt_role($name)) return null;
        foreach (['color-primary', 'colour-primary', 'brand', 'primary', 'accent'] as $token) {
            if ($name === $token) return $token;
            foreach (['-rgb', '-color', '-colour'] as $suffix) {
                if ($name === $token . $suffix) return $token;
            }
        }
        return null;
    }

    /** The -hover sibling of a var, from the same scoped list, or null. */
    private static function hover_sibling(array $scoped, string $name): ?string
    {
        foreach ($scoped as $decl) {
            if ($decl['name'] === $name . '-hover') return $decl['hex'];
        }
        return null;
    }

    /**
     * The primary button's declared TEXT colour: a base-state button text /
     * label / foreground var in a global scope, else the tier-3 rule's own
     * `color:` declaration, else null (the caller assumes white-ish). Kept
     * conservative on purpose: a bare `--color-button` names the FILL on
     * Shopify, so a text/label/foreground token is required.
     */
    private static function resolve_button_text(array $scoped, ?array $button_rule): ?string
    {
        foreach ($scoped as $decl) {
            $name = $decl['name'];
            if (self::var_name_is_state($name)) continue;
            if (self::is_hard_vendor_var($name)) continue;
            if (strpos($name, 'button') === false) continue;
            if (strpos($name, 'text') === false && strpos($name, 'label') === false
                && strpos($name, 'foreground') === false) continue;
            if (strpos($name, 'bg') !== false || strpos($name, 'background') !== false) continue;
            return $decl['hex'];
        }
        if ($button_rule !== null && $button_rule['text'] !== null) return $button_rule['text'];
        return null;
    }

    /**
     * The WINNING primary-button rule set, with its declared background /
     * text colour / border-radius. Rules are matched per comma-separated
     * selector part, exact after quote-stripping; a pseudo-STATE part can
     * never match by construction (no candidate carries ':'), while a BASE
     * part inside a rule that bundles state parts in one selector list
     * still matches (jordan's Foundation `.button.primary,
     * .button.primary.disabled:focus, ...` base rule used to be dropped
     * whole by a rule-level gate); form-plugin rules (see
     * selector_is_form_plugin) never match. The winner is the FIRST entry
     * of PRIMARY_BUTTON_SELECTORS whose rules RESOLVE a background, so a
     * primary-named platform CTA always beats a generic submit rule
     * regardless of document order (ridge: CF7's white submit came first
     * and used to win). The turn passes to the next candidate ONLY when a
     * background was DECLARED and failed to resolve: a denylisted platform
     * default (jordan's CDN .c7-btn--primary) or an unresolvable var. A
     * candidate that never declares a background HOLDS the walk instead
     * (bg null, the legacy pipeline decides the colour): its rules are
     * silent about the background, and walking on would let a generic
     * white a.button pin a colour the padding-only primary never chose.
     * Each field is taken from the first of the winner's rules that
     * declares it, document order, so a split ruleset (colour in one rule,
     * radius in another) still resolves; when NO candidate resolves a
     * background, the first matched candidate stands so its text/radius
     * still feed the contrast and radius paths.
     * Background/text values may be var() references, resolved through the
     * GLOBAL-scope var map (an unresolvable reference leaves the field to a
     * later rule). A background resolving to a DENYLISTED platform default
     * the site never declares is skipped the same way (jordan: the vendor
     * CDN's `background: var(--c7-primary-color)` #3860D6 rule came first in
     * the cascade; skipping it lets the site's own later .c7-btn--primary
     * override fill the field). Null when no rule matches at all.
     *
     * @param string|null $site_css SITE-OWNED CSS backing the denylist; a
     *                              caller that never split origins treats the
     *                              whole input as site-owned.
     * @return array{selector:string,bg:?string,text:?string,radius:?string}|null
     */
    private static function primary_button_rule(string $css, ?string $site_css = null, bool $page_dark = false): ?array
    {
        if ($site_css === null) $site_css = $css;
        $raw_vars = self::global_raw_var_map($css);

        // Matched rules per candidate, in document order. A rule matching
        // several candidates counts once, for its highest-priority one.
        $matched = [];
        foreach (self::PRIMARY_BUTTON_SELECTORS as $target) {
            $matched[$target] = [];
        }
        foreach (self::style_rules($css) as $rule) {
            // Pseudo-STATE gating is per PART by construction: no candidate
            // carries ':', so a ':hover'/':focus' part can never exact-match,
            // while a base part inside a rule that also lists state parts
            // still does. Form-plugin rules are skipped whole.
            if (self::selector_is_form_plugin($rule['sel'])) continue;
            $best = null;
            foreach (explode(',', $rule['sel']) as $part) {
                $part = str_replace(['"', "'"], '', trim($part));
                foreach (self::PRIMARY_BUTTON_SELECTORS as $priority => $target) {
                    if ($part !== $target) continue;
                    if ($best === null || $priority < $best) $best = $priority;
                }
            }
            if ($best === null) continue;
            $matched[self::PRIMARY_BUTTON_SELECTORS[$best]][] = $rule;
        }

        $fallback = null;
        foreach (self::PRIMARY_BUTTON_SELECTORS as $target) {
            if (empty($matched[$target])) continue;
            $found = ['selector' => $target, 'bg' => null, 'text' => null, 'radius' => null];
            $declared_bg = false;
            foreach ($matched[$target] as $rule) {
                if ($found['bg'] === null) {
                    if (!$declared_bg && self::declares_background($rule['body'])) $declared_bg = true;
                    $bg = self::declared_background_hex($rule['body'], $raw_vars);
                    // A near-white background (is_near_white, the frequency
                    // tier's own test) is never a button brand on a LIGHT or
                    // unknown page: like transparent, it is a
                    // declared-but-failed background and the turn passes. On
                    // a DARK page ($page_dark, see dark_page_candidate) it is
                    // the site's real CTA and stays eligible.
                    if ($bg !== null && !self::is_denylisted_platform_default($bg, $site_css) && ($page_dark || !self::is_near_white($bg))) {
                        $found['bg'] = $bg;
                    }
                }
                if ($found['text'] === null
                    && preg_match('/(?<![a-z\-])color\s*:\s*([^;}]+)/i', $rule['body'], $m)) {
                    $hex = self::colour_or_var_hex(trim($m[1]), $raw_vars);
                    if ($hex !== null) $found['text'] = $hex;
                }
                if ($found['radius'] === null) {
                    $radius = self::last_border_radius($rule['body']);
                    if ($radius !== null) $found['radius'] = $radius;
                }
            }
            // The background IS the primary signal: the first candidate that
            // resolves one wins outright; the first matched candidate stands
            // as the fallback so its text/radius still feed the contrast +
            // radius paths when no candidate resolves a background.
            if ($found['bg'] !== null) return $found;
            if ($fallback === null) $fallback = $found;
            // HOLD: this candidate never declared a background at all, so
            // the walk stops and the first matched candidate stands (bg
            // null, the legacy pipeline decides). The turn passes only past
            // a declared-but-failed background (denylisted / unresolvable).
            if (!$declared_bg) return $fallback;
        }
        return $fallback;
    }

    /**
     * True when a rule body carries a raw background(-color) PROPERTY at
     * all, i.e. declared_background_hex had input to work on, whether or not
     * it resolved. The candidate walk uses this to tell "declared but
     * failed" (denylisted / unresolvable, the turn passes) from "never
     * declared" (the candidate is held and the legacy pipeline decides).
     */
    private static function declares_background(string $body): bool
    {
        return (bool) preg_match('/(?:background-color|(?<![a-z\-])background)\s*:\s*[^;}]/i', $body);
    }

    /**
     * A rule body's declared background colour as hex: background-color
     * preferred, else the background shorthand's colour: first from its LAST
     * comma-separated layer outside any gradient (the only place a background
     * colour can sit), else the first colour anywhere in the value with
     * gradient stops included (see first_background_colour), else a
     * background(-color) value that IS a var() reference, resolved through
     * the GLOBAL-scope raw var map (Commerce7's
     * `.c7-btn--primary { background: var(--c7-primary-button-bg); }`).
     * Null when nothing parses or the reference is unresolvable (a literal
     * `var()` string is never emitted).
     */
    private static function declared_background_hex(string $body, array $raw_vars): ?string
    {
        if (preg_match('/background-color\s*:\s*([^;}]+)/i', $body, $m)) {
            $hex = self::colour_or_var_hex(trim($m[1]), $raw_vars);
            if ($hex !== null) return $hex;
        }
        if (preg_match('/(?<![a-z\-])background\s*:\s*([^;}]+)/i', $body, $m)) {
            // 1) The background COLOUR can only sit in the LAST comma-separated
            //    layer, outside any gradient: a tint overlay
            //    `linear-gradient(var(--overlay), var(--overlay)), #8B2332`
            //    must never let a gradient stop outrank the real colour. A
            //    named colour counts exactly where a hex literal would, and a
            //    top-level var() resolves in place.
            //    Before that, a layer carrying a COVERING gradient (see
            //    covering_gradient_stop) paints over the colour beneath it
            //    (`linear-gradient(90deg, #8B2332, #A83240), #fff` paints the
            //    red), so the first covering gradient's own first qualifying
            //    stop is the answer.
            $layers = self::top_level_layers($m[1]);
            foreach ($layers as $layer) {
                $cover = self::covering_gradient_stop($layer);
                if ($cover !== null) return $cover;
            }
            $final = self::first_background_colour($layers[count($layers) - 1], $raw_vars, false);
            if ($final[1] !== null) return $final[1];
            // 2) Otherwise the first colour anywhere in the value, gradient
            //    stops included (a gradient-only button background such as
            //    `-webkit-gradient(..., from(#8B2332), ...)`).
            $walk = self::first_background_colour($m[1], $raw_vars, true);
            if ($walk[0]) return $walk[1];
            $hex = self::colour_or_var_hex(trim($m[1]), $raw_vars);
            if ($hex !== null) return $hex;
        }
        return null;
    }

    /**
     * The alpha of an rgb()/rgba() literal as 0..1 (a percentage divided by
     * 100), null when the literal carries no alpha part (a hex, a named
     * colour, rgb() with three components), or -1.0 when the alpha cannot be
     * read (a var() or a blanked body), which is neither opaque nor zero.
     */
    private static function literal_alpha(string $literal): ?float
    {
        if (!preg_match('/^rgba?\((.*)\)$/is', trim($literal), $m)) return null;
        $inner = $m[1];
        if (strpos($inner, '/') !== false) {
            $alpha = trim(substr($inner, strrpos($inner, '/') + 1));
        } elseif (substr_count($inner, ',') === 3) {
            $alpha = trim(substr($inner, strrpos($inner, ',') + 1));
        } else {
            return null;
        }
        if (!preg_match('/^(\d*\.?\d+)(%?)$/', $alpha, $am)) return -1.0;
        $value = (float) $am[1];
        return $am[2] === '%' ? $value / 100 : $value;
    }

    /**
     * The colour a COVERING gradient in a background layer paints, or null
     * when the layer carries none. A gradient covers what lies beneath it
     * when every colour stop is an opaque literal colour (a 3/6-digit hex, an
     * rgb()/rgba() with no alpha or an opaque one, or a named colour) and at
     * least one stop QUALIFIES: saturated (not near-white, near-black or
     * greyish) or dark (relative luminance below 0.2, the bound
     * resolve_surfaces uses for a dark page), so a muted brand like #3C3430,
     * #252525 or #000000 covers as well as a bright one. The answer is the
     * FIRST qualifying stop, the gradient's own colour, never whatever
     * precedes it in the value. A var(), transparent, currentColor,
     * translucent or unreadable stop makes it an overlay, and a gradient of
     * light neutrals only (a white sheen) has no qualifying stop, so neither
     * ever covers and the last-layer colour read stays. Legacy
     * -webkit-gradient from() / to() / color-stop() stops are read too.
     */
    private static function covering_gradient_stop(string $layer): ?string
    {
        if (!preg_match('/(?<![\w\-])((?:-(?:webkit|moz|o|ms)-)?(?:repeating-)?(?:linear|radial|conic)-gradient|-webkit-gradient)\(/i', $layer, $gm, PREG_OFFSET_CAPTURE)) return null;
        $open  = $gm[0][1] + strlen($gm[1][0]);
        $end   = self::balanced_call_end($layer, $open);
        $args  = self::top_level_layers(substr($layer, $open + 1, max(0, $end - $open - 2)));
        $first = null;
        foreach ($args as $arg) {
            $a = trim($arg);
            if (preg_match('/^(?:from|to|color-stop)\((.*)\)$/is', $a, $sm)) {
                $inner = self::top_level_layers($sm[1]);
                $a = trim($inner[count($inner) - 1]);
            }
            if ($a === '') continue;
            if (stripos($a, 'var(') !== false || preg_match('/(?<![\w\-])(?:transparent|currentcolor)(?![\w\-])/i', $a)) return null;
            $hex = null;
            if (preg_match_all('/#[0-9a-fA-F]+\b|(?:rgba?|hsla?|hwb|lab|lch|oklab|oklch|color)\([^)]*\)/i', $a, $cm)) {
                if (count($cm[0]) !== 1) return null;
                $alpha = self::literal_alpha($cm[0][0]);
                if ($alpha !== null && $alpha < 1.0) return null;
                $hex = self::to_hex($cm[0][0]);
                if ($hex === null) return null;   // an 8-digit hex, hsl() or other unparsed colour: opacity unknown
            } else {
                $named = self::named_colour_tokens($a);
                if (count($named) > 1) return null;
                if (count($named) === 1) $hex = $named[0][1];
            }
            if ($hex === null) continue;   // a direction, shape, position or colour hint
            if ($first === null
                && (self::luminance($hex) < 0.2
                    || (!self::is_near_white($hex) && !self::is_near_black($hex) && !self::is_greyish($hex)))) {
                $first = $hex;
            }
        }
        return $first;
    }

    /**
     * The first colour in a background value as [hit, hex], candidates taken
     * in order of position: the FIRST hex/rgb() literal, the FIRST named
     * colour, and every var() call mask_function_bodies reports (each
     * resolved in place, so an unresolved var still yields its colour
     * fallback while one that resolves nothing gives way to the next
     * candidate). hit turns true once a literal or named colour is reached (a
     * literal that does not parse answers null) or a var() resolves. With
     * $keep_gradients false, gradient bodies are blanked too, so only a
     * colour outside every gradient can answer.
     *
     * @return array{0:bool,1:?string}
     */
    private static function first_background_colour(string $value, array $raw_vars, bool $keep_gradients): array
    {
        $var_calls  = [];
        $scan       = self::mask_function_bodies($value, $var_calls, $keep_gradients);
        // The first literal that is not fully transparent: an alpha-0 rgb()
        // (`rgba(0,0,0,0)`, `rgb(0 0 0 / 0%)`) is no colour, like `transparent`.
        $literal    = null;
        if (preg_match_all('/#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b|rgba?\([^)]*\)/i', $scan, $lm, PREG_OFFSET_CAPTURE)) {
            foreach ($lm[0] as $hit) {
                if (self::literal_alpha($hit[0]) === 0.0) continue;
                $literal = $hit;
                break;
            }
        }
        $named      = self::named_colour_tokens($scan);
        $candidates = [];
        if ($literal !== null) $candidates[] = [$literal[1], 'literal', $literal[0]];
        if (!empty($named)) $candidates[] = [$named[0][0], 'named', $named[0][1]];
        foreach ($var_calls as $var_call) $candidates[] = [$var_call[0], 'var', $var_call[1]];
        usort($candidates, static function ($a, $b) {
            return $a[0] <=> $b[0];
        });
        foreach ($candidates as $cand) {
            if ($cand[1] === 'literal') return [true, self::to_hex($cand[2])];
            if ($cand[1] === 'named') return [true, $cand[2]];
            $hex = self::colour_or_var_hex($cand[2], $raw_vars);
            if ($hex !== null) return [true, $hex];
        }
        return [false, null];
    }

    /**
     * A CSS value split at its TOP-level commas (never inside parens or quoted
     * strings, never an escaped comma): a multi-layer background's layers in
     * order. A value with no such comma is a single layer.
     *
     * @return string[]
     */
    private static function top_level_layers(string $value): array
    {
        $layers = [];
        $len    = strlen($value);
        $depth  = 0;
        $quote  = '';
        $start  = 0;
        for ($j = 0; $j < $len; $j++) {
            $c = $value[$j];
            if ($c === '\\') {
                $j++;
                continue;
            }
            if ($quote !== '') {
                if ($c === $quote) $quote = '';
                continue;
            }
            if ($c === '"' || $c === "'") {
                $quote = $c;
            } elseif ($c === '(') {
                $depth++;
            } elseif ($c === ')') {
                if ($depth > 0) $depth--;
            } elseif ($c === ',' && $depth === 0) {
                $layers[] = substr($value, $start, $j - $start);
                $start = $j + 1;
            }
        }
        $layers[] = substr($value, $start);
        return $layers;
    }

    /**
     * Blank every function call in a CSS value (name, parens and body, same
     * length so offsets hold) EXCEPT the colour-bearing ones a colour scan
     * must still see: rgb()/rgba() and the (vendor-prefixed, repeating)
     * linear/radial/conic gradients, whose bodies stay visible with any
     * nested function inside them still blanked. So `var(--x, white)`,
     * `color-mix(in srgb, var(--x) 80%, white)` and `url(white.png)` carry
     * no scannable colour, while `linear-gradient(tomato, #000)` does. An
     * unbalanced call is blanked to the end of the value. The legacy
     * `-webkit-gradient(linear, ..., from(#x), to(#y))` form is a kept
     * gradient too, and from() / to() / color-stop() stay visible inside
     * any kept gradient (outside one they are blanked like any other call).
     * Balancing skips backslash escapes and quoted strings, so
     * `url(a\(1.png)` and `url("img(1).png")` close where CSS closes them.
     * Every var() call the walk itself blanks is reported in $var_calls as
     * [offset, call text] so the caller can resolve it in place: one at the
     * top level or directly inside a kept gradient / rgb() is reported, one
     * nested inside any other blanked call is part of that call and never
     * is. With $keep_gradients false, gradients are blanked like any other
     * call, so only var() calls outside every gradient are reported.
     *
     * @param array<int,array{0:int,1:string}>|null $var_calls
     */
    private static function mask_function_bodies(string $value, ?array &$var_calls = null, bool $keep_gradients = true): string
    {
        $var_calls = [];
        $out   = '';
        $len   = strlen($value);
        $i     = 0;
        $stack = [];   // open kept calls and bare parens: true for a gradient
        while ($i < $len) {
            if (preg_match('/\G([a-zA-Z_\-][a-zA-Z0-9_\-]*)\(/', $value, $fm, 0, $i)) {
                $name        = strtolower($fm[1]);
                $is_gradient = (bool) preg_match('/^(?:(?:-(?:webkit|moz|o|ms)-)?(?:repeating-)?(?:linear|radial|conic)-gradient|-webkit-gradient)$/', $name);
                $keep        = ($is_gradient && $keep_gradients)
                    || $name === 'rgb'
                    || $name === 'rgba'
                    || (in_array(true, $stack, true) && in_array($name, ['from', 'to', 'color-stop'], true));
                if ($keep) {
                    $out    .= $fm[0];
                    $i      += strlen($fm[0]);
                    $stack[] = $is_gradient;
                    continue;
                }
                $end = self::balanced_call_end($value, $i + strlen($fm[1]));
                if ($name === 'var') $var_calls[] = [$i, substr($value, $i, $end - $i)];
                $out .= str_repeat(' ', $end - $i);
                $i    = $end;
                continue;
            }
            $c = $value[$i];
            if ($c === '(') {
                $stack[] = false;
            } elseif ($c === ')' && !empty($stack)) {
                array_pop($stack);
            }
            $out .= $c;
            $i++;
        }
        return $out;
    }

    /**
     * Offset just past the `)` that closes the call whose `(` sits at $open,
     * skipping backslash-escaped characters and quoted strings; the value's
     * length when the call never closes.
     */
    private static function balanced_call_end(string $value, int $open): int
    {
        $len   = strlen($value);
        $depth = 0;
        $quote = '';
        for ($j = $open; $j < $len; $j++) {
            $c = $value[$j];
            if ($c === '\\') {
                $j++;
                continue;
            }
            if ($quote !== '') {
                if ($c === $quote) $quote = '';
                continue;
            }
            if ($c === '"' || $c === "'") {
                $quote = $c;
                continue;
            }
            if ($c === '(') {
                $depth++;
            } elseif ($c === ')') {
                $depth--;
                if ($depth === 0) return $j + 1;
            }
        }
        return $len;
    }

    /**
     * Note line when the button's TEXT fails 4.5:1 against the button's own
     * BACKGROUND, else null. The copy never claims the colour "is light" (the
     * old note did, and was wrong on dark sites) and the colour is never
     * substituted, the winery just gets a pointer to the Colours tab.
     */
    private static function button_contrast_note(string $text_hex, string $bg_hex): ?string
    {
        if (self::contrast_ratio($text_hex, $bg_hex) >= 4.5) return null;
        return __('Button text may be hard to read on the button colour. Adjust on Colours.', 'b360-bridge');
    }

    /**
     * Brand-vs-card contrast note for the no-resolved-button path, or null at
     * 4.5:1 or better. HEDGED on purpose: derivation's resolveActionColors
     * decides the button pair separately (a white label on the brand) and may
     * keep the label and change nothing, darken the label, or nudge the fill
     * instead. PHP does not port that colour maths, so the copy only says the
     * button colours MAY be adjusted, never that something was.
     */
    private static function card_contrast_note(string $brand_hex, string $card_hex): ?string
    {
        if (self::contrast_ratio($brand_hex, $card_hex) >= 4.5) return null;
        return __('Button colours may be adjusted for readability. Fine-tune on Colours.', 'b360-bridge');
    }

    /**
     * The cross-site redirect note. The host is lowercased and drops a leading
     * "www." so it reads the same as the Studio's "Matched from <host>" title
     * (which lowercases through browser URL parsing, so `Example.COM` must
     * read `example.com` in both). Trailing dots are never printed: an FQDN
     * `example.com.` shows `example.com`, and a host that is only "www." shows
     * `www` (the lowercased raw host without its trailing dots) rather than
     * nothing or a doubled period. A URL with no parseable host, or a host
     * that is nothing but dots, falls back to the raw URL.
     */
    private static function redirect_note(string $final_url): string
    {
        $host  = wp_parse_url($final_url, PHP_URL_HOST);
        $shown = $final_url;
        if (is_string($host) && $host !== '') {
            $lower = strtolower($host);
            $bare  = rtrim((string) preg_replace('/^www\./', '', $lower), '.');
            if ($bare === '') $bare = rtrim($lower, '.');
            if ($bare !== '') $shown = $bare;
        }
        return sprintf(
            /* translators: %s: the host the request ended up on */
            __('The site redirected to %s.', 'b360-bridge'),
            $shown
        );
    }

    /**
     * Pick a named var whose name contains one of $needles, preferring the
     * lightest (background) or darkest (text) match. Vendor noise skipped.
     */
    private static function pick_named_var(array $vars, array $needles, bool $prefer_light): ?string
    {
        $best = null;
        $best_lum = null;
        foreach ($vars as $name => $hex) {
            if (self::is_vendor_var($name)) continue;
            // Overlay/modal/cookie-consent/tooltip-named vars are widget
            // chrome, hard-excluded from every surface/text pick (the same
            // token list that gates surface SELECTORS).
            if (self::has_surface_excluded_token($name)) continue;
            $match = false;
            foreach ($needles as $n) {
                if (strpos($name, $n) !== false) { $match = true; break; }
            }
            if (!$match) continue;
            $lum = self::luminance($hex);
            if ($best === null
                || ($prefer_light && $lum > $best_lum)
                || (!$prefer_light && $lum < $best_lum)) {
                $best = $hex;
                $best_lum = $lum;
            }
        }
        // Guard against nonsense: a "background" that's actually dark, or a
        // "text" that's actually light, is probably a mis-named var, but we
        // still return it; derivation copes and diagnostics show the value.
        return $best;
    }

    /**
     * Strip content that isn't declared page styling before frequency-counting:
     * <script> blocks (reviews/widget app JSON config, JSON-LD) and <template>
     * blocks. Colours that appear ONLY inside these must not influence the brand
     * pick. Declared CSS is counted separately via $all_css, so nothing real is
     * lost. Falls back to the input untouched if preg_replace errors.
     */
    private static function strip_non_style_markup(string $html): string
    {
        $out = preg_replace('#<script\b[^>]*>.*?</script>#is', ' ', $html);
        if (!is_string($out)) $out = $html;
        $out2 = preg_replace('#<template\b[^>]*>.*?</template>#is', ' ', $out);
        if (is_string($out2)) $out = $out2;
        return $out;
    }

    /**
     * Remove denylisted custom-property DECLARATIONS (WP block-preset palette,
     * review/widget apps) from text before frequency-counting, so a colour that
     * only appears as such a var value, e.g.
     * `--wp--preset--color--vivid-red:#cf2e2e`, can't win the frequency tier
     * either. Keeps the frequency fallback consistent with is_hard_vendor_var.
     * Falls back to the input untouched if preg_replace errors.
     */
    private static function strip_denylisted_declarations(string $text): string
    {
        $pattern = '/--(?:wp--preset|wp-components|wp-admin|wp-block|wp-preferences|jdgm|judgeme|yotpo|stamped|loox|okendo)[a-zA-Z0-9\-_]*\s*:\s*[^;{}]*;?/i';
        $out = preg_replace($pattern, ' ', $text);
        return is_string($out) ? $out : $text;
    }

    /**
     * True for a CSS property whose value can carry a colour (the frequency
     * tier's named-colour context): any *-color property, the background /
     * border / outline shorthands, fill, stroke, the shadows, text-decoration,
     * text-emphasis and column-rule, vendor-prefixed forms included.
     * font-family and friends never qualify, so a face named "Crimson Text"
     * never counts as crimson.
     */
    private static function is_colour_property(string $prop): bool
    {
        return (bool) preg_match('/^(?:-[a-z]+-)?(?:[a-z\-]*colou?r|background(?:-image)?|border(?:-(?:top|right|bottom|left|block|inline)(?:-(?:start|end))?)?|outline|fill|stroke|box-shadow|text-shadow|text-decoration|text-emphasis|column-rule)$/', $prop);
    }

    /**
     * Count colours. Returns [hex => count]. Hex and rgb()/rgba() literals
     * count wherever they appear in $text (markup + CSS, as always). A CSS
     * named colour counts only from CSS CONTEXTS, never page copy or
     * framework bindings (`<p>The wine color: gold</p>`, `:color="red"`):
     * a token in a colour-carrying declaration of $css (the site's
     * stylesheets and <style> blocks) or of a style="" attribute in
     * $markup, a colour-named custom property in $css whose whole value is
     * one (`--accent: teal`; a non-colour name like `--club-tier: gold` or a
     * font var never counts), or an SVG fill / stroke attribute in $markup.
     * With no $css / $markup, named colours never count.
     */
    private static function colour_frequency(string $text, string $css = '', string $markup = ''): array
    {
        $counts = [];
        if (preg_match_all('/#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b/', $text, $m)) {
            foreach ($m[0] as $raw) {
                $hex = self::to_hex($raw);
                if ($hex !== null) $counts[$hex] = ($counts[$hex] ?? 0) + 1;
            }
        }
        if (preg_match_all('/rgba?\([^)]*\)/i', $text, $m)) {
            foreach ($m[0] as $raw) {
                $hex = self::to_hex($raw);
                if ($hex !== null) $counts[$hex] = ($counts[$hex] ?? 0) + 1;
            }
        }
        // Named colours, CSS contexts only. style="" attribute values join
        // the declaration scan (a bound `:style` / `data-style` never does).
        $declarations = $css;
        if (preg_match_all('/(?<![\w\-:@.])style\s*=\s*(?:"([^"]*)"|\'([^\']*)\')/i', $markup, $m, PREG_SET_ORDER)) {
            foreach ($m as $attr) {
                $declarations .= "\n;" . (isset($attr[2]) && $attr[2] !== '' ? $attr[2] : $attr[1]);
            }
        }
        if (preg_match_all('/(?<![\w\-])(-?[a-z][a-z\-]*)\s*:\s*([^;{}<>]*)/', $declarations, $m, PREG_SET_ORDER)) {
            foreach ($m as $decl) {
                if (!self::is_colour_property($decl[1])) continue;
                foreach (self::named_colour_tokens($decl[2]) as $tok) {
                    $counts[$tok[1]] = ($counts[$tok[1]] ?? 0) + 1;
                }
            }
        }
        if (preg_match_all('/(?<![\w\-])--([a-zA-Z0-9\-_]+)\s*:\s*([^;{}]+)/', $css, $m, PREG_SET_ORDER)) {
            foreach ($m as $decl) {
                $name = strtolower($decl[1]);
                if (!self::name_allows_triplet($name) || self::name_is_font_var($name)) continue;
                $hex = self::named_colour_hex(self::clean_var_value($decl[2]));
                if ($hex !== null) $counts[$hex] = ($counts[$hex] ?? 0) + 1;
            }
        }
        if (preg_match_all('/(?<![\w\-:@.])(?:fill|stroke)\s*=\s*["\']\s*([A-Za-z]+)\s*["\']/i', $markup, $m)) {
            foreach ($m[1] as $raw) {
                $hex = self::named_colour_hex($raw);
                if ($hex !== null) $counts[$hex] = ($counts[$hex] ?? 0) + 1;
            }
        }
        return $counts;
    }

    /**
     * Most frequent saturated (non-grey, non-white/black) colour, or null.
     * With $site_css given, a denylisted platform default is skipped under
     * the same ownership rule every other brand pick applies (see
     * is_denylisted_platform_default), so a commerce7.css copy at a path no
     * VENDOR_STYLESHEET_PATHS entry knows cannot win on frequency (its
     * #3860d6 literal and rgba(56,96,214,.25) focus ring count twice) and a
     * site colour wins by rule, never by insertion order.
     */
    private static function most_frequent_saturated(array $freq, ?string $site_css = null): ?string
    {
        arsort($freq);
        foreach ($freq as $hex => $count) {
            if (self::is_near_white($hex) || self::is_near_black($hex)) continue;
            if (self::is_greyish($hex)) continue;
            if ($site_css !== null && self::is_denylisted_platform_default((string) $hex, $site_css)) continue;
            return $hex;
        }
        return null;
    }

    /** <meta name="theme-color" content="#…">, an explicit declared brand colour. */
    private static function meta_theme_color(string $html): ?string
    {
        if (preg_match('#<meta[^>]*name\s*=\s*["\']theme-color["\'][^>]*content\s*=\s*["\']([^"\']+)["\']#i', $html, $m)
            || preg_match('#<meta[^>]*content\s*=\s*["\']([^"\']+)["\'][^>]*name\s*=\s*["\']theme-color["\']#i', $html, $m)) {
            return self::to_hex(trim($m[1]));
        }
        return null;
    }

    /**
     * F12: the brand fallback cascade AFTER the deterministic button
     * resolver, first non-empty tier wins:
     *   1  brand-named var (the legacy picker, a declared brand token is a
     *      deliberate brand choice)
     *   2  heading text colour (heading_colour_brand)
     *   3  footer/header background (chrome_background_brand)
     *   4  a SATURATED theme-color meta (F11: a neutral one, white/black/
     *      washed-out grey, is a browser-chrome hint, not a brand, and is
     *      treated as no-signal; caymus shipped brand #FFFFFF this way)
     *   5  the most frequent saturated literal (the legacy remainder)
     *
     * @param array{name:string,hex:string}|null $brand_var
     * @param array{hex:string,source:string}|null $heading_brand
     * @param array{hex:string,source:string}|null $chrome_brand
     * @return array{hex:string,source:string}|null
     */
    private static function fallback_brand(?array $brand_var, ?array $heading_brand, ?array $chrome_brand, ?string $meta_theme, array $freq, string $all_css, ?string $site_css = null): ?array
    {
        if ($brand_var !== null) {
            // The legacy path carries the harvesting scope too now: the sweep's
            // worst mis-pick (jordan's vendor-default c7-primary-color) shipped
            // with no scope suffix, so it was invisible WHERE the value came
            // from. 'unscoped' when no declaring rule can be attributed.
            return [
                'hex'    => $brand_var['hex'],
                'source' => 'css-var:' . $brand_var['name'] . '@'
                    . self::var_declaring_scope($all_css, $brand_var['name'], $brand_var['hex']),
            ];
        }
        if ($heading_brand !== null) return $heading_brand;
        if ($chrome_brand !== null) return $chrome_brand;
        if ($meta_theme !== null && !self::theme_colour_is_neutral($meta_theme)) {
            return ['hex' => $meta_theme, 'source' => 'meta:theme-color'];
        }
        // The frequency tier skips denylisted platform defaults too, judged
        // against the SITE-OWNED CSS (the whole CSS when a caller never split
        // origins).
        $saturated = self::most_frequent_saturated($freq, $site_css !== null ? $site_css : $all_css);
        if ($saturated !== null) {
            return ['hex' => $saturated, 'source' => 'frequency'];
        }
        return null;
    }

    /**
     * Brand confidence from the brandSource string: a resolved button rule
     * or declared brand var is high; the inferred declared sources (heading
     * colour, footer/header background, theme-color meta) are medium; the
     * frequency guess (or no source) is low.
     */
    private static function brand_confidence(?string $brand_source): string
    {
        if ($brand_source === null) return 'low';
        if (strpos($brand_source, 'css-var:') === 0 || strpos($brand_source, 'button-rule:') === 0) {
            return 'high';
        }
        if (strpos($brand_source, 'heading-color:') === 0
            || strpos($brand_source, 'footer-bg:') === 0
            || strpos($brand_source, 'header-bg:') === 0
            || $brand_source === 'meta:theme-color') {
            return 'medium';
        }
        return 'low';
    }

    /**
     * HSL saturation 0..1 of a hex colour (chroma over the lightness
     * headroom). Blows up toward 1 near white/black by construction, so
     * every neutrality gate pairs it with a luminance check.
     */
    private static function hsl_saturation(string $hex): float
    {
        [$r, $g, $b] = self::rgb($hex);
        $max = max($r, $g, $b);
        $min = min($r, $g, $b);
        if ($max === $min) return 0.0;
        $l2  = $max + $min;                              // 2 * lightness * 255
        $den = $l2 <= 255 ? $l2 : (510 - $l2);
        if ($den <= 0) return 0.0;
        return ($max - $min) / $den;
    }

    /**
     * NEUTRAL gate for the declared-colour brand candidates (heading colour,
     * footer/header background; theme_colour_is_neutral adds the black end
     * for the meta path). Rejects white/off-white (luminance), TRUE neutrals
     * (near-equal channels), and washed-out greys (HSL saturation), but
     * keeps a deliberately dark, low-chroma brand like caymus's #3C3430
     * (channel spread 12, saturation ~11%), which the standard is_greyish
     * gate (spread <= 16) would wrongly swallow. Mirrors how the button
     * resolver bypasses the grey gate for role-named sources: a consistently
     * declared heading/footer colour is a deliberate choice, only a
     * genuinely colourless value is noise. A saturated NEAR-BLACK (oxblood
     * #461612) stays eligible here, deliberately no luminance floor.
     */
    private static function is_neutral_declared_colour(string $hex): bool
    {
        if (self::luminance($hex) >= 0.8) return true;   // white / off-white
        [$r, $g, $b] = self::rgb($hex);
        if ((max($r, $g, $b) - min($r, $g, $b)) <= 8) return true;   // true neutral (#333, #000)
        return self::hsl_saturation($hex) < 0.08;        // washed-out grey
    }

    /**
     * F11: a NEUTRAL theme-color meta (white, black, or saturation below
     * ~8%) is a browser-chrome hint, never the brand; the cascade treats it
     * as no-signal and falls through. A saturated theme-color stays a valid
     * low-tier candidate as before.
     */
    private static function theme_colour_is_neutral(string $hex): bool
    {
        return self::is_near_black($hex) || self::is_neutral_declared_colour($hex);
    }

    /**
     * F12: brand candidate from the DOMINANT declared heading text colour,
     * SITE-OWNED CSS only, gated by SUBJECT: a rule votes only through
     * comma parts whose subject is the h1-h3 heading ITSELF (a qualifier
     * on the heading still counts: `h2.section-title`), or a bare anchor
     * directly under a bare h1-h3 heading (`h2 a`, `h1 > a`; linked
     * headings carry the visible colour on the anchor). A selector that
     * merely REFERENCES a heading around a deeper subject
     * (`.hero h2 .accent-star`) never votes; see
     * heading_colour_subject_level. Each resting (non-pseudo-state)
     * qualifying rule's color: declarations vote; var() values resolve
     * through the global-scope map; neutral values (see
     * is_neutral_declared_colour) never vote. The most DECLARED value wins
     * (ties break toward the higher heading level, then document order),
     * and the source names the best qualifying level it was seen on
     * (caymus: #3C3430 on every h1-h3 subject -> 'heading-color:h1').
     *
     * @return array{hex:string,source:string}|null
     */
    private static function heading_colour_brand(string $css): ?array
    {
        $raw_vars = self::global_raw_var_map($css);
        $votes = [];
        foreach (self::heading_rules_with_level($css) as $rule) {
            if (self::selector_is_pseudo_state($rule['sel'])) continue;   // resting colour only
            $level = self::heading_colour_subject_level($rule['sel']);    // h1-h3 subjects only
            if ($level === 0) continue;
            if (!preg_match_all('/(?<![a-z\-])color\s*:\s*([^;}]+)/i', $rule['body'], $m)) continue;
            foreach ($m[1] as $value) {
                $hex = self::colour_or_var_hex(trim((string) $value), $raw_vars);
                if ($hex === null) continue;
                if (self::is_neutral_declared_colour($hex)) continue;
                if (!isset($votes[$hex])) {
                    $votes[$hex] = ['count' => 0, 'level' => $level];
                }
                $votes[$hex]['count']++;
                if ($level < $votes[$hex]['level']) $votes[$hex]['level'] = $level;
            }
        }
        if (empty($votes)) return null;
        $best_hex = null;
        $best     = null;
        foreach ($votes as $hex => $vote) {
            if ($best === null
                || $vote['count'] > $best['count']
                || ($vote['count'] === $best['count'] && $vote['level'] < $best['level'])) {
                $best     = $vote;
                $best_hex = (string) $hex;
            }
        }
        return ['hex' => $best_hex, 'source' => 'heading-color:' . self::clean_scope_label('h' . $best['level'])];
    }

    /**
     * F12 subject gate for the heading-colour vote: the highest (lowest
     * number) h1-h3 level among a selector's comma parts whose SUBJECT is
     * the heading, or 0 when none qualifies. Two subject shapes qualify:
     * the heading tag as the last compound, optionally with a class / id /
     * attribute qualifier on it (`h2`, `h2.section-title`, `h1#title`,
     * `h3[data-x]`, matching heading_rules_with_level), and ONE deliberate
     * extension, a BARE anchor whose parent compound is a bare h1-h3
     * heading (`h2 a`, `h1 > a`), because linked headings carry the
     * visible colour on the anchor. Nothing else votes: deeper descendants
     * and non-anchor children (`.hero h2 .accent-star`, `h2 span`),
     * classed anchors (`h2 a.btn`), sibling anchors (`h2 + a`), and
     * pseudo-carrying subjects (`h2:first-child`) all fail the gate.
     */
    private static function heading_colour_subject_level(string $sel): int
    {
        $best = 0;
        foreach (explode(',', $sel) as $part) {
            $part = trim($part);
            if ($part === '') continue;
            if (preg_match('/(?:^|[\s>+~])h([1-3])(?:[.#\[][^\s>+~:]*)?$/', $part, $m)
                || preg_match('/(?:^|[\s>+~])h([1-3])(?:\s*>\s*|\s+)a$/', $part, $m)) {
                $level = (int) $m[1];
                if ($best === 0 || $level < $best) $best = $level;
            }
        }
        return $best;
    }

    /**
     * Footer/header chrome selectors trusted as F12 brand-background
     * subjects, in PRIORITY order (footers carry brand ground more often
     * than headers), each with its brandSource label prefix.
     */
    private const CHROME_BRAND_SUBJECTS = [
        ['.footer', 'footer-bg'],
        ['footer', 'footer-bg'],
        ['.site-footer', 'footer-bg'],
        ['.header', 'header-bg'],
        ['.site-header', 'header-bg'],
    ];

    /**
     * F12: brand candidate from the declared background of footer/header
     * chrome, SITE-OWNED CSS only, ranked below the heading colour. The
     * SUBJECT (last simple selector of a comma part) must be one of
     * CHROME_BRAND_SUBJECTS exactly (`.footer a` styles the link, not the
     * chrome); resting rules only; var() backgrounds resolve through the
     * global map; neutral values never qualify. The first eligible
     * background per subject (document order) stands, and the
     * highest-priority subject with one wins (caymus: .footer #3C3430).
     *
     * @return array{hex:string,source:string}|null
     */
    private static function chrome_background_brand(string $css): ?array
    {
        $raw_vars = self::global_raw_var_map($css);
        $found = [];
        foreach (self::style_rules($css) as $rule) {
            if (self::selector_is_pseudo_state($rule['sel'])) continue;
            $subjects = self::chrome_brand_subjects_of($rule['sel']);
            if (empty($subjects)) continue;
            $hex = self::declared_background_hex($rule['body'], $raw_vars);
            if ($hex === null) continue;
            if (self::is_neutral_declared_colour($hex)) continue;
            foreach ($subjects as $subject) {
                if (!isset($found[$subject])) $found[$subject] = $hex;   // first eligible wins
            }
        }
        foreach (self::CHROME_BRAND_SUBJECTS as $cand) {
            if (isset($found[$cand[0]])) {
                return ['hex' => $found[$cand[0]], 'source' => $cand[1] . ':' . self::clean_scope_label($cand[0])];
            }
        }
        return null;
    }

    /**
     * The CHROME_BRAND_SUBJECTS a selector targets: a comma part qualifies
     * only when its SUBJECT (last simple selector) IS one of them exactly;
     * a pseudo-carrying subject never does.
     *
     * @return string[]
     */
    private static function chrome_brand_subjects_of(string $sel): array
    {
        $out = [];
        foreach (explode(',', $sel) as $part) {
            $part = trim($part);
            if ($part === '') continue;
            $bits = preg_split('/[\s>+~]+/', $part);
            $subject = is_array($bits) && !empty($bits) ? trim((string) end($bits)) : '';
            if ($subject === '' || strpos($subject, ':') !== false) continue;
            foreach (self::CHROME_BRAND_SUBJECTS as $cand) {
                if ($subject === $cand[0] && !in_array($cand[0], $out, true)) $out[] = $cand[0];
            }
        }
        return $out;
    }

    /**
     * Heading text-transform, from h1-h6 rules ONLY. Never body/nav/buttons,
     * heading treatments are heading-only by design. Returns a valid enum or null.
     */
    private static function heading_text_transform(string $css): ?string
    {
        $rules = self::heading_rule_bodies($css);
        foreach ($rules as $body) {
            if (preg_match('/text-transform\s*:\s*(uppercase|lowercase|capitalize|none)\b/i', $body, $m)) {
                return strtolower($m[1]);
            }
        }
        return null;
    }

    /** Coarse heading letter-spacing → named step. Heading rules only. */
    private static function heading_letter_spacing(string $css): ?string
    {
        $rules = self::heading_rule_bodies($css);
        foreach ($rules as $body) {
            if (preg_match('/letter-spacing\s*:\s*(-?[0-9.]+)(em|px|rem)\b/i', $body, $m)) {
                $val  = (float) $m[1];
                $unit = strtolower($m[2]);
                // Normalise roughly to em (px≈/16).
                $em = $unit === 'px' ? $val / 16 : $val;
                if ($em <= -0.01) return 'tight';
                if ($em >= 0.12)  return 'widest';
                if ($em >= 0.08)  return 'wider';
                if ($em >= 0.02)  return 'wide';
                return 'normal';
            }
        }
        return null;
    }

    /** Heading font-weight (h1-h6 rules only), snapped to the 100-900 scale. */
    private static function heading_weight(string $css): ?int
    {
        $rules = self::heading_rule_bodies($css);
        foreach ($rules as $body) {
            if (preg_match('/font-weight\s*:\s*(\d{3})\b/i', $body, $m)) {
                $w = (int) $m[1];
                if ($w >= 100 && $w <= 900 && $w % 100 === 0) return $w;
            }
            if (preg_match('/font-weight\s*:\s*(bold|normal)\b/i', $body, $m)) {
                return strtolower($m[1]) === 'bold' ? 700 : 400;
            }
        }
        return null;
    }

    /**
     * Collect the declaration bodies of rules whose selector targets a heading
     * (h1-h6). Deliberately excludes body/nav/button/label selectors.
     *
     * @return string[] declaration bodies (the text between { and }).
     */
    private static function heading_rule_bodies(string $css): array
    {
        $out = [];
        foreach (self::heading_rules_with_level($css) as $rule) {
            $out[] = $rule['body'];
        }
        return $out;
    }

    /**
     * Heading rules with their DOMINANT level weight (h1 = 6 .. h6 = 1), used to
     * weight the font-character vote toward the h1/h2 heading identity. A rule
     * targeting several levels (e.g. `h2, h3`) takes the highest (lowest-number)
     * one. The selector must reference a bare heading TAG, but now a class / id
     * / attribute qualifier immediately after it counts too (`h2.section-title`,
     * `h1#title`, `h3[data-x]`), which a trailing char class of only
     * `[\s,>+~){:]` used to miss (those headings then went unstyled). The
     * (lowercased) selector rides along so per-rule consumers (the F12
     * heading-colour vote) can apply selector gates.
     *
     * @return array<int,array{weight:int,body:string,sel:string}>
     */
    private static function heading_rules_with_level(string $css): array
    {
        $out = [];
        if (!preg_match_all('/([^{}]+)\{([^{}]*)\}/', $css, $m, PREG_SET_ORDER)) {
            return $out;
        }
        foreach ($m as $rule) {
            $selector = strtolower(isset($rule[1]) ? $rule[1] : '');
            if (!preg_match_all('/(^|[\s,>+~(])h([1-6])([\s,>+~){:.#\[]|$)/', $selector, $hm)) continue;
            $min = 7;
            foreach ($hm[2] as $digit) {
                $n = (int) $digit;
                if ($n >= 1 && $n <= 6 && $n < $min) $min = $n;
            }
            if ($min === 7) continue;
            $out[] = ['weight' => 7 - $min, 'body' => isset($rule[2]) ? $rule[2] : '', 'sel' => trim($selector)];
        }
        return $out;
    }

    /**
     * Best-effort heading + body font-family names (diagnostic only). A bare
     * family NAME here never reaches fontSans: only a body family CONFIRMED
     * as Google-hosted is written through (see extract()), because forcing an
     * unverified family would defeat the CSS armor.
     *
     * @return array{heading:?string,body:?string}
     */
    private static function font_families(string $css): array
    {
        $heading = null;
        $body    = null;

        foreach (self::heading_rule_bodies($css) as $rule) {
            if ($heading === null && preg_match('/font-family\s*:\s*([^;]+)/i', $rule, $m)) {
                $heading = self::first_family($m[1]);
            }
        }
        if (preg_match('/(^|[{}\s,])(body|html)\s*\{([^{}]*)\}/i', $css, $bm)) {
            if (isset($bm[3]) && preg_match('/font-family\s*:\s*([^;]+)/i', $bm[3], $m)) {
                $body = self::first_family($m[1]);
            }
        }
        return ['heading' => $heading, 'body' => $body];
    }

    /** First family name in a font-family stack, cleaned (see clean_family_name). */
    private static function first_family(string $stack): ?string
    {
        $parts = explode(',', $stack);
        $first = self::clean_family_name(trim($parts[0]));
        if ($first === '' || strlen($first) > 64) return null;
        // Ignore CSS-wide keywords.
        if (in_array(strtolower($first), ['inherit', 'initial', 'unset', 'revert'], true)) return null;
        return $first;
    }

    /**
     * F15: normalise ONE captured family name: drop any !important flag,
     * strip stray/unbalanced quotes, collapse whitespace. Scribe declared
     * `font-family: 'Historic Italic' !important`, and the flag plus a
     * leftover quote survived into diagnostics ("Historic Italic' !important")
     * while making the face unusable, so the heading slot was dropped.
     * Shared by every consumer that reads a family name out of declared CSS
     * (families, stacks, diagnostics alike).
     */
    private static function clean_family_name(string $family): string
    {
        $f = preg_replace('/!\s*important/i', ' ', $family);
        if (!is_string($f)) $f = $family;
        $f = str_replace(['"', "'"], '', $f);
        $collapsed = preg_replace('/\s+/', ' ', trim($f));
        return is_string($collapsed) ? $collapsed : trim($f);
    }

    // --------------------------------------------------------------------- //
    //  Design language BEYOND colour: radius / font character / depth       //
    // --------------------------------------------------------------------- //

    /**
     * Every top-level style rule as ['sel' => lowercased selector,
     * 'body' => declaration body]. Shared by the radius + depth samplers. Same
     * flat, brace-pair tokenizer as heading_rule_bodies (nested at-rule blocks
     * surface their inner rules, which is what we want). The captured
     * selector is comment-stripped AT HARVEST (see strip_selector_comments):
     * the flat capture runs since the previous brace, so a LESS/annotation
     * comment ahead of a rule rode along as selector text, broke the
     * exact-match scope gates, and leaked into the brandSource label.
     *
     * @return array<int,array{sel:string,body:string}>
     */
    private static function style_rules(string $css): array
    {
        $out = [];
        if (!preg_match_all('/([^{}]+)\{([^{}]*)\}/', $css, $m, PREG_SET_ORDER)) {
            return $out;
        }
        foreach ($m as $rule) {
            $sel  = strtolower(trim(self::strip_selector_comments(isset($rule[1]) ? $rule[1] : '')));
            $body = isset($rule[2]) ? $rule[2] : '';
            if ($sel === '') continue;
            $out[] = ['sel' => $sel, 'body' => $body];
        }
        return $out;
    }

    /**
     * Classify a selector into the surface family it styles, for radius + depth
     * sampling: 'button' (filled CTAs / submit inputs), 'card' (cards / tiles /
     * panels), 'input' (text fields), or null. Button is tested FIRST so a
     * submit input (input[type=submit]) isn't miscounted as a text field.
     */
    private static function selector_kind(string $sel): ?string
    {
        if (strpos($sel, 'button') !== false
            || strpos($sel, '.btn') !== false
            || strpos($sel, 'submit') !== false) {
            return 'button';
        }
        if (strpos($sel, 'card') !== false
            || strpos($sel, 'tile') !== false
            || strpos($sel, 'panel') !== false) {
            return 'card';
        }
        if (strpos($sel, 'input') !== false
            || strpos($sel, 'textarea') !== false) {
            return 'input';
        }
        return null;
    }

    /**
     * Round-control / icon-button selector tokens. A rule whose selector carries
     * one of these is an icon / close / social / round control whose radius (a
     * 50% circle, a round FAB) is NOT the site's CTA corner language, so it is
     * excluded from the radius sample. Without this, a handful of round icon
     * buttons outvote the real rectangular CTAs and force a FALSE pill.
     */
    private const ICON_BUTTON_TOKENS = [
        'icon', 'avatar', 'circle', 'close', 'social', '-fab', 'dot', 'badge',
        'chip', 'toggle', 'radio', 'reset', 'swatch', 'slideshow', 'pagination',
        'pager', 'stepper', 'arrow', 'caret', 'scroll-to',
    ];

    /**
     * Minimum measured button radius (px) that reads as a stadium PILL. 1.5rem
     * (24px, Tailwind rounded-3xl) is a rounded button, not a pill, so the bar
     * sits above it. A literal 999px/9999px clears it comfortably.
     */
    private const PILL_MIN_PX = 32.0;

    /** True when a selector looks like a round/icon control (excluded from radius). */
    private static function selector_is_icon_button(string $sel): bool
    {
        foreach (self::ICON_BUTTON_TOKENS as $t) {
            if (strpos($sel, $t) !== false) return true;
        }
        return false;
    }

    /** True when a selector targets a non-resting pseudo-state (:hover/:focus/:active). */
    private static function selector_is_pseudo_state(string $sel): bool
    {
        return strpos($sel, ':hover') !== false
            || strpos($sel, ':focus') !== false
            || strpos($sel, ':active') !== false;
    }

    /**
     * WP-core / Gutenberg vendor button selector tokens. These style WordPress's
     * own block buttons and editor chrome, not the winery's CTA language, so
     * they must not vote on the storefront's button casing or tracking.
     */
    private const VENDOR_BUTTON_TOKENS = ['wp-block-button', 'wp-element-button', '.editor-', 'wp-admin'];

    /** True when a selector is WP-core vendor button noise (excluded from the button vote). */
    private static function selector_is_vendor_button(string $sel): bool
    {
        foreach (self::VENDOR_BUTTON_TOKENS as $t) {
            if (strpos($sel, $t) !== false) return true;
        }
        return false;
    }

    /**
     * Layout-wrapper selector tokens around buttons (.button-group, .btn-group,
     * .button-bar, ...). These legitimately set letter-spacing/text-transform on
     * the wrapper element but are not the CTA itself, so they must not vote on
     * the button casing or tracking.
     */
    private const BUTTON_WRAPPER_TOKENS = ['button-group', 'buttons-group', 'btn-group', 'button-wrapper', 'buttons-wrap', 'button-bar', 'button-toolbar', 'button-list', 'button-row', 'button-container'];

    /** True when a selector is a button layout wrapper (excluded from the button vote). */
    private static function selector_is_button_wrapper(string $sel): bool
    {
        foreach (self::BUTTON_WRAPPER_TOKENS as $t) {
            if (strpos($sel, $t) !== false) return true;
        }
        return false;
    }

    /**
     * Button label text-transform, from BUTTON rules only (never headings or
     * body copy). Each resting, non-icon, non-vendor, non-wrapper button rule that declares
     * a text-transform casts one vote: uppercase counts as 'uppercase' and
     * anything else (none/lowercase/capitalize) collapses to 'none', since the
     * button enum only has those two steps. The MAJORITY wins so a single
     * outlier rule can't flip the casing; a tie or no votes returns null and
     * the estate default stands.
     */
    private static function button_text_transform(string $css): ?string
    {
        $uppercase = 0;
        $none      = 0;
        foreach (self::style_rules($css) as $rule) {
            $sel = $rule['sel'];
            if (self::selector_kind($sel) !== 'button') continue;
            if (self::selector_is_icon_button($sel)) continue;
            // Resting state only, mirroring the depth/radius samplers.
            if (self::selector_is_pseudo_state($sel)) continue;
            if (self::selector_is_vendor_button($sel)) continue;
            if (self::selector_is_button_wrapper($sel)) continue;
            if (preg_match('/text-transform\s*:\s*(uppercase|lowercase|capitalize|none)\b/i', $rule['body'], $m)) {
                if (strtolower($m[1]) === 'uppercase') {
                    $uppercase++;
                } else {
                    $none++;
                }
            }
        }
        if ($uppercase > $none) return 'uppercase';
        if ($none > $uppercase) return 'none';
        return null;
    }

    /**
     * Button letter-spacing -> named step ('normal'|'wide'|'wider'). Same rule
     * filter as button_text_transform. Values normalise to em (px at 16px per
     * em) and the MEDIAN across button rules resists outliers. The button enum
     * has no 'tight'/'widest' steps: negatives and near-zero values collapse
     * to 'normal'. Returns null when no button rule declares letter-spacing.
     */
    private static function button_letter_spacing(string $css): ?string
    {
        $ems = [];
        foreach (self::style_rules($css) as $rule) {
            $sel = $rule['sel'];
            if (self::selector_kind($sel) !== 'button') continue;
            if (self::selector_is_icon_button($sel)) continue;
            // Resting state only, mirroring the depth/radius samplers.
            if (self::selector_is_pseudo_state($sel)) continue;
            if (self::selector_is_vendor_button($sel)) continue;
            if (self::selector_is_button_wrapper($sel)) continue;
            if (preg_match('/letter-spacing\s*:\s*(-?[0-9.]+)(em|px|rem)\b/i', $rule['body'], $m)) {
                $val  = (float) $m[1];
                $unit = strtolower($m[2]);
                $ems[] = $unit === 'px' ? $val / 16 : $val;
            }
        }
        if (empty($ems)) return null;
        $em = self::median($ems);
        // Bands: >= 0.075em is 'wider', >= 0.035em is 'wide', below that stays
        // 'normal' so hairline tracking (under about half a pixel at 16px) is
        // not misread as wide. The storefront renders wide at ~0.04em and wider
        // at ~0.08em (ComponentsSection BTN_TRACKING_EM), so these buckets snap
        // the measured value to the nearest rendered step.
        if ($em >= 0.075) return 'wider';
        if ($em >= 0.035) return 'wide';
        return 'normal';
    }

    /**
     * Button / input / card border-radius mapped into radius override keys.
     * Returns ['keys' => array<string,string>, 'lowConfidence' => bool]. Only
     * keys actually detected are present; the rest fall back to defaults.
     *
     * Button radius -> radius.control. Pill (control + pill = '999px') ONLY when
     * the measured CTA radius is genuinely stadium: median >= PILL_MIN_PX (~32px)
     * or a literal 999px/9999px. A 24-31px radius is a rounded button, emitted as
     * the measured value, NOT a pill. Round icon buttons (pseudo-state rules and
     * icon/close/social/round selectors) and WP-core vendor button chrome
     * (VENDOR_BUTTON_TOKENS: the classic-theme `.wp-block-button__link` pill
     * ships on sites that never render block buttons, and was ridge's ONLY
     * radius voter) are excluded so they can't skew the vote, and a bare
     * 50%/100% ('round') never votes on its own. Card radius ->
     * radius.card AND radius.panel. The MEDIAN across rules resists outliers.
     *
     * When a real control radius was measured, the small-radius steps are
     * derived from it too: xs at half the control radius, sm at three quarters,
     * each clamped into [1px, control]. A stadium control ('999px') gives no
     * usable base for that maths, so xs/sm take fixed hairline steps instead.
     * No control measurement means NO xs/sm (defaults stand).
     *
     * $button_radius, when given, is the RESOLVED primary-button rule's own
     * border-radius (see primary_button_rule) and outranks the population
     * median for the control radius: the real CTA's corner beats a vote in
     * which some non-CTA round element slipped past the exclusions (ridge:
     * a 999px voter forced a pill while the actual CTA is 2px). The median
     * stays as the fallback, and the card path is untouched. A var() rule
     * radius resolves through the GLOBAL-scope var map before parsing.
     */
    private static function radius_overrides(string $css, ?string $button_radius = null): array
    {
        $button_px = [];
        $input_px  = [];
        $card_px   = [];

        foreach (self::style_rules($css) as $rule) {
            $sel = $rule['sel'];
            // Resting radius only, never a round icon control, and never
            // WP-core vendor button chrome (.wp-block-button__link etc).
            if (self::selector_is_pseudo_state($sel)) continue;
            if (self::selector_is_icon_button($sel)) continue;
            if (self::selector_is_vendor_button($sel)) continue;
            $kind = self::selector_kind($sel);
            if ($kind === null) continue;
            $raw = self::last_border_radius($rule['body']);
            if ($raw === null) continue;
            $val = self::parse_radius($raw);
            if ($val === null) continue;
            // A bare 50%/100% ('round') is a round-control tell; it does not vote
            // for a pill on its own (only a genuine large px does).
            if ($val === 'round') continue;
            if ($kind === 'button') {
                $button_px[] = (float) $val;
            } elseif ($kind === 'input') {
                $input_px[] = (float) $val;
            } else { // card
                $card_px[] = (float) $val;
            }
        }

        $keys = [];
        $low_confidence = false;

        // The resolved primary-button rule's own radius, when parseable,
        // becomes the control measurement outright ('round' 50% corners are
        // a circle tell, not a CTA corner, and never carry over). A var()
        // radius resolves through the same GLOBAL-scope var map as the
        // tier-3 background (Commerce7 declares
        // `.c7-btn { border-radius: var(--c7-button-border-radius); }` and
        // ridge sets that var to 0px under `*`); an unresolvable reference
        // stays unparseable and the population median stands.
        $button_rule_px = null;
        if ($button_radius !== null) {
            $radius_value = trim($button_radius);
            if (stripos($radius_value, 'var(') === 0) {
                $resolved = self::resolve_var_reference($radius_value, self::global_raw_var_map($css));
                $radius_value = $resolved !== null ? $resolved : '';
            }
            if ($radius_value !== '') {
                $parsed = self::parse_radius($radius_value);
                if ($parsed !== null && $parsed !== 'round') $button_rule_px = (float) $parsed;
            }
        }

        // Control roundness: the resolved CTA rule first, then the button
        // median, then form inputs.
        $control_samples = !empty($button_px) ? $button_px : $input_px;
        if ($button_rule_px !== null || !empty($control_samples)) {
            $med = $button_rule_px !== null ? $button_rule_px : self::median($control_samples);
            if ($med >= self::PILL_MIN_PX) {
                $keys['control'] = '999px';
                $keys['pill']    = '999px';
                // A stadium control gives no usable small-step base (half of
                // '999px' is nonsense), so xs/sm take fixed hairline steps.
                $keys['xs'] = '2px';
                $keys['sm'] = '3px';
            } else {
                $control_px      = (int) round($med);
                $keys['control'] = $control_px . 'px';
                // Small-radius steps derived from the measured control radius:
                // xs at half, sm at three quarters, each clamped into
                // [1px, control] so they stay visibly smaller than the control
                // corner. A square-cornered site (control 0px) keeps 0px steps.
                if ($control_px < 1) {
                    $keys['xs'] = $control_px . 'px';
                    $keys['sm'] = $control_px . 'px';
                } else {
                    $keys['xs'] = min($control_px, max(1, (int) round($control_px * 0.5))) . 'px';
                    $keys['sm'] = min($control_px, max(1, (int) round($control_px * 0.75))) . 'px';
                }
            }
            // A measured CTA rule is confident evidence on its own; the
            // thin-evidence flag applies to the population median path only.
            if ($button_rule_px === null && count($control_samples) < 2) $low_confidence = true;
        }

        // Card corners drive card + panel together.
        if (!empty($card_px)) {
            $card_val = ((int) round(self::median($card_px))) . 'px';
            $keys['card']  = $card_val;
            $keys['panel'] = $card_val;
        }

        return ['keys' => $keys, 'lowConfidence' => $low_confidence];
    }

    /** Last-declared border-radius value in a rule body, or null. */
    private static function last_border_radius(string $body): ?string
    {
        if (!preg_match_all('/border-radius\s*:\s*([^;}]+)/i', $body, $m) || empty($m[1])) {
            return null;
        }
        $last = end($m[1]);
        return is_string($last) ? trim($last) : null;
    }

    /**
     * Parse a border-radius token to a px NUMBER (float), the string 'round' for
     * a large % (a circle/round-control tell, not a stadium pill), or null.
     * Handles the shorthand (first value only) and px/rem/em (rem/em at 16px). A
     * literal 999px/9999px stays a large float so a genuine pill still clears
     * PILL_MIN_PX via the numeric path; % never becomes a numeric vote.
     *
     * @return float|string|null
     */
    private static function parse_radius(string $value)
    {
        $v = strtolower(trim($value));
        if ($v === '') return null;
        $v = preg_replace('/!\s*important/i', '', $v);
        if (!is_string($v)) return null;
        // Elliptical radii ("Xpx / Ypx") and the shorthand ("Xpx Ypx …") both
        // reduce to the first horizontal value.
        $slash = strpos($v, '/');
        if ($slash !== false) $v = substr($v, 0, $slash);
        $v = trim($v);
        $parts = preg_split('/\s+/', $v);
        $first = is_array($parts) && isset($parts[0]) ? $parts[0] : $v;

        if (preg_match('/^([0-9]*\.?[0-9]+)%$/', $first, $m)) {
            $pct = (float) $m[1];
            return $pct >= 25.0 ? 'round' : null;   // a large % corner is a round control
        }
        if (preg_match('/^([0-9]*\.?[0-9]+)(px|rem|em)?$/', $first, $m)) {
            $num  = (float) $m[1];
            $unit = isset($m[2]) ? $m[2] : 'px';
            if ($unit === 'rem' || $unit === 'em') $num *= 16.0;
            return $num;
        }
        return null;
    }

    /** Median of a float list. Returns 0.0 for an empty list. */
    private static function median(array $vals): float
    {
        $n = count($vals);
        if ($n === 0) return 0.0;
        sort($vals);
        $mid = (int) floor($n / 2);
        if ($n % 2 === 1) return (float) $vals[$mid];
        return ((float) $vals[$mid - 1] + (float) $vals[$mid]) / 2.0;
    }

    /** True when $needle appears in $family as a whole token (alnum boundaries). */
    private static function family_has_token(string $family, string $needle): bool
    {
        return preg_match('/(?<![a-z0-9])' . preg_quote($needle, '/') . '(?![a-z0-9])/', $family) === 1;
    }

    /**
     * Classify ONE font-family stack's CHARACTER. Returns
     * ['style' => 'serif'|'display'|'sans', 'stack' => ?string, 'face' => ?string,
     *  'known' => bool, 'rank' => int]. 'rank' orders candidates at the same
     * heading level (serif-known 4 > serif-generic 3 > display 2 > plain-sans
     * with a usable face 1 > sans-with-no-usable-face 0). A non-null 'stack' is
     * what makes a candidate USABLE (something to echo). Face/serif matching is
     * TOKEN-bounded on the FIRST family, and a known serif face is only honoured
     * when the stack does NOT also carry a sans-serif generic, so a sans face
     * whose NAME contains a serif word (e.g. "Times Square Sans", sans-serif) is
     * not misread as serif.
     */
    private static function classify_font_stack(string $raw): array
    {
        $low            = strtolower($raw);
        $parts          = explode(',', $raw);
        // F15: the lead family is cleaned (no !important flag, no stray
        // quotes) so a sloppy declaration still classifies and echoes.
        $first_raw      = self::clean_family_name(trim(isset($parts[0]) ? $parts[0] : ''));
        $first          = strtolower($first_raw);
        $has_sans_generic = strpos($low, 'sans-serif') !== false;

        // Known serif faces -> a stack ending in ',serif' that echoes the face.
        // Gated on the stack NOT carrying a sans-serif generic (FIX: token/anti
        // sans-serif guard) so a sans face containing a serif word isn't serif.
        $serif_map = [
            'playfair'     => '"Playfair Display", Georgia, serif',
            'baskerville'  => '"Libre Baskerville", Georgia, serif',
            'cormorant'    => '"Cormorant Garamond", Georgia, serif',
            'merriweather' => 'Merriweather, Georgia, serif',
            'lora'         => 'Lora, Georgia, serif',
            'garamond'     => '"EB Garamond", Georgia, serif',
            'cardo'        => 'Cardo, Georgia, serif',
            'pt serif'     => '"PT Serif", Georgia, serif',
            'spectral'     => 'Spectral, Georgia, serif',
            'frank ruhl'   => '"Frank Ruhl Libre", Georgia, serif',
            'georgia'      => 'Georgia, "Times New Roman", serif',
            'times'        => 'Georgia, "Times New Roman", serif',
        ];
        if (!$has_sans_generic) {
            foreach ($serif_map as $needle => $stack) {
                if ($first !== '' && self::family_has_token($first, $needle)) {
                    return ['style' => 'serif', 'stack' => $stack, 'face' => $first_raw, 'known' => true, 'rank' => 4];
                }
            }
        }

        // Condensed / display sans -> a condensed-sans fallback stack. (Display
        // faces legitimately pair with a sans-serif generic, so no anti guard.)
        $display_faces = ['oswald', 'bebas', 'anton', 'archivo narrow', 'arial narrow', 'teko', 'antonio', 'league gothic'];
        foreach ($display_faces as $needle) {
            if ($first !== '' && self::family_has_token($first, $needle)) {
                return ['style' => 'display', 'stack' => '"Oswald","Archivo Narrow","Arial Narrow",sans-serif', 'face' => $first_raw, 'known' => true, 'rank' => 2];
            }
        }

        // Generic serif keyword (but NOT sans-serif) -> an unknown-serif stack.
        if (!$has_sans_generic && strpos($low, 'serif') !== false) {
            return ['style' => 'serif', 'stack' => 'Georgia, "Times New Roman", serif', 'face' => ($first_raw !== '' ? $first_raw : 'serif'), 'known' => false, 'rank' => 3];
        }

        // Plain sans with a real, usable heading family -> echo it in a SANS
        // stack so the storefront heading renders SANS (matches the site) rather
        // than the default serif. A var()/keyword/generic-only first family is
        // NOT usable and yields no stack (leave the default).
        if (self::is_usable_family($first_raw)) {
            $stack = '"' . $first_raw . '", system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
            return ['style' => 'sans', 'stack' => $stack, 'face' => $first_raw, 'known' => false, 'rank' => 1];
        }

        // No usable face, but the stack DECLARES sans-serif (e.g. a var() face
        // with a sans-serif generic): the heading identity is confidently sans,
        // so the fontSerif slot gets a bare SANS tail rather than falling back
        // to the estate serif (a serif fallback misrepresents a sans brand).
        if ($has_sans_generic) {
            return ['style' => 'sans', 'stack' => 'system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif', 'face' => null, 'known' => false, 'rank' => 1];
        }

        return ['style' => 'sans', 'stack' => null, 'face' => null, 'known' => false, 'rank' => 0];
    }

    /** True when a first-family token is a real, echo-able family name. */
    private static function is_usable_family(string $family): bool
    {
        if ($family === '' || strlen($family) > 48) return false;
        if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9 \-]*$/', $family)) return false;
        $keywords = ['inherit', 'initial', 'unset', 'revert', 'serif', 'sans-serif', 'monospace', 'cursive', 'fantasy', 'system-ui'];
        return !in_array(strtolower($family), $keywords, true);
    }

    /**
     * Heading font CHARACTER across ALL declared heading faces (not the exact
     * face, webfonts do NOT load on the storefront, so this is character
     * matching only). Candidates are WEIGHTED BY HEADING LEVEL: h1/h2 are the
     * dominant heading identity, so a serif face appearing only on a minor level
     * (an h4-h6 eyebrow/kicker) does NOT override a sans face on h1/h2. Among the
     * usable candidates the highest-weight one wins (ties break by character
     * rank). For serif / display it echoes the face; for a plain-sans dominant
     * face it echoes a SANS stack so headings render sans; only a stack-less
     * (var/keyword) dominant leaves fontSerif unset. Returns
     * ['style' => 'serif'|'display'|'sans'|null, 'stack' => ?string, 'face' => ?string].
     */
    private static function heading_font_character(string $css): array
    {
        $candidates = [];
        $raw_vars = self::global_raw_var_map($css);
        foreach (self::heading_rules_with_level($css) as $rule) {
            if (!preg_match_all('/font-family\s*:\s*([^;{}]+)/i', $rule['body'], $m)) continue;
            foreach ($m[1] as $stack) {
                $stack = trim((string) $stack);
                if ($stack === '') continue;
                // A `font-family: var(--font-heading)` chain resolves through
                // the global var map before classification (cakebread lost
                // its heading character to an unresolved var).
                $c = self::classify_font_stack(self::resolve_font_family_value($stack, $raw_vars));
                $c['weight'] = $rule['weight'];
                $candidates[] = $c;
            }
        }
        if (empty($candidates)) return ['style' => null, 'stack' => null, 'face' => null];

        // Only candidates with something to echo (a non-null stack) can win.
        $best = null;
        foreach ($candidates as $c) {
            if ($c['stack'] === null) continue;
            if ($best === null
                || $c['weight'] > $best['weight']
                || ($c['weight'] === $best['weight'] && $c['rank'] > $best['rank'])) {
                $best = $c;
            }
        }
        if ($best !== null) {
            return ['style' => $best['style'], 'stack' => $best['stack'], 'face' => $best['face']];
        }
        // Heading faces existed but none were usable (all var()/keyword) -> sans,
        // no stack, so the default heading font stands.
        return ['style' => 'sans', 'stack' => null, 'face' => null];
    }

    /**
     * F14: the heading (fontSerif) slot's stack. The character stack from
     * heading_font_character is the base; when the detected heading FACE is
     * a real family that is NOT confirmed as Google-hosted, it LEADS the
     * stack (quoted as needed) with the character tail behind it. The embed
     * renders inside the winery's own page, so a Typekit/licensed face
     * already loaded there (rombauer's ivymode, tablas' Crimson Pro)
     * renders for free when its name leads; dropping straight to the
     * character tail (Georgia) threw an exact match away. A Google-confirmed
     * face is left alone: heading roles render it via their own webFont
     * vars, the character stack is only their fallback.
     *
     * @param array{style:?string,stack:?string,face:?string} $font_character
     * @param array<string,int[]> $google confirmed Google font requests
     */
    private static function heading_slot_stack(array $font_character, array $google): ?string
    {
        $stack = isset($font_character['stack']) ? $font_character['stack'] : null;
        $face  = isset($font_character['face']) ? $font_character['face'] : null;
        if ($stack === null) return null;
        if ($face === null || !self::is_usable_family($face)) return $stack;
        if (self::first_confirmed_family([$face], $google) !== null) return $stack;
        return self::lead_stack_with_family($face, $stack);
    }

    /**
     * Lead a font stack with a family (quoted as needed); a stack already
     * leading with that family (case-insensitive) is returned untouched.
     */
    private static function lead_stack_with_family(string $family, string $stack): string
    {
        $lead = self::first_family($stack);
        if ($lead !== null && strcasecmp($lead, $family) === 0) return $stack;
        return self::quote_family($family) . ', ' . $stack;
    }

    /**
     * Body font-weight from body / html / p rules, snapped to the 100-900
     * scale, or null. Mirrors heading_weight but for body copy, with two
     * additions the plain reader missed on ridge: rules whose SUBJECT is
     * body/html outrank p-subject rules (`.social p` must not out-vote the
     * real `body` rule), and the `font:` SHORTHAND votes too. The shorthand
     * RESETS font-weight, so a shorthand with no weight token is an
     * explicit 400 vote, not silence.
     */
    private static function body_font_weight(string $css): ?int
    {
        $rules = self::body_copy_rules($css);
        // Subject priority: body-subject rules first, then html, then
        // p-subject rules, so a reset/preflight html rule or a component p
        // can never out-vote the site's real body rule.
        foreach (['body', 'html', 'p'] as $subject) {
            foreach ($rules as $rule) {
                if ($rule['subject'] !== $subject) continue;
                $body = $rule['body'];
                if (preg_match('/font-weight\s*:\s*(\d{3})\b/i', $body, $m)) {
                    $w = (int) $m[1];
                    if ($w >= 100 && $w <= 900 && $w % 100 === 0) return $w;
                }
                if (preg_match('/font-weight\s*:\s*(bold|normal)\b/i', $body, $m)) {
                    return strtolower($m[1]) === 'bold' ? 700 : 400;
                }
                $shorthand = self::font_shorthand($body);
                if ($shorthand !== null) return $shorthand['weight'];
            }
        }
        return null;
    }

    /**
     * typography.titleWeight override from the detected heading weight, or
     * null when no heading weight was detected or it equals the estate
     * default (700): emitting the default would be a pointless no-op override.
     */
    private static function title_weight_override(?int $heading_weight): ?int
    {
        if ($heading_weight === null || $heading_weight === 700) return null;
        return $heading_weight;
    }

    /**
     * typography.labelWeight override: two steps above the detected body
     * weight, bounded to the 600-700 band label components are designed for,
     * or null when no body weight was detected or the bounded candidate lands
     * on the estate default (600).
     */
    private static function label_weight_override(?int $body_weight): ?int
    {
        if ($body_weight === null) return null;
        $candidate = min(700, max(600, $body_weight + 200));
        return $candidate === 600 ? null : $candidate;
    }

    /**
     * Declaration bodies of rules whose selector TARGETS body copy: the
     * SUBJECT (last simple selector of a comma-separated part) must be the
     * body / html / p element itself, optionally with a class / id / attr
     * qualifier attached (body.home, p.lead). Deliberately excludes headings
     * (they have their own weight path), rules merely SCOPED under body
     * (`body h1`, `body .site-title`: those style the descendant, not body
     * copy, and used to leak a heading's 700 into bodyWeight), and subjects
     * carrying a pseudo (`p:hover`, `body::before`, `p:first-child`: a state
     * or generated content, not the resting body copy).
     *
     * @return string[]
     */
    private static function body_rule_bodies(string $css): array
    {
        $out = [];
        foreach (self::body_copy_rules($css) as $rule) {
            $out[] = $rule['body'];
        }
        return $out;
    }

    /**
     * Widget-chrome selector tokens excluded from ALL body-copy inference: a
     * lightbox / modal / cookie-consent / tooltip widget's own p styling is
     * the WIDGET's typography, never the page's body copy (rombauer:
     * `.sbi_lightbox_username p { font-weight:700 }`, an Instagram-feed
     * lightbox label, fed bodyWeight). Deliberately NARROWER than
     * SURFACE_EXCLUDE_TOKENS: 'social' stays out because `.social p` is a
     * pinned legitimate p-subject fallback (ridge).
     */
    private const BODY_COPY_EXCLUDE_TOKENS = ['lightbox', 'pswp', 'modal', 'overlay', 'backdrop', 'tooltip', 'popup', 'cookie', 'consent'];

    /** True when a selector carries a widget-chrome token (excluded from body-copy votes). */
    private static function selector_is_body_copy_excluded(string $sel): bool
    {
        foreach (self::BODY_COPY_EXCLUDE_TOKENS as $t) {
            if (strpos($sel, $t) !== false) return true;
        }
        return false;
    }

    /**
     * Body-copy rules with their SUBJECT CLASS kept: 'body' for a body
     * subject, 'html' for an html subject, 'p' for a p subject (bare,
     * classed, or descendant), document order. The split exists because a
     * family/weight found on `.social p` must not beat the site's real
     * `body` rule (ridge), and a reset/preflight `html` rule must not beat
     * it either (tablas: `html{font-family:PT Sans,...}` out-voted the real
     * `body{font-family:Crimson Pro,...}` while both counted as 'body'):
     * the family/weight readers walk body, then html, then p. Rules inside
     * widget chrome (see BODY_COPY_EXCLUDE_TOKENS) never collect.
     *
     * @return array<int,array{subject:string,body:string}>
     */
    private static function body_copy_rules(string $css): array
    {
        $out = [];
        if (!preg_match_all('/([^{}]+)\{([^{}]*)\}/', $css, $m, PREG_SET_ORDER)) {
            return $out;
        }
        foreach ($m as $rule) {
            $selector = strtolower(isset($rule[1]) ? $rule[1] : '');
            if (self::selector_is_body_copy_excluded($selector)) continue;
            $subject = self::body_copy_subject($selector);
            if ($subject === null) continue;
            $out[] = ['subject' => $subject, 'body' => isset($rule[2]) ? $rule[2] : ''];
        }
        return $out;
    }

    /**
     * True when any comma-separated part of a selector has body/html/p as its
     * SUBJECT (its last simple selector), i.e. the rule styles body copy
     * itself rather than something inside it. A subject carrying a pseudo
     * (any ':' in the subject token: `p:hover`, `body::before`) never votes,
     * only plain body/html/p subjects, class/id/attr qualifiers included, do.
     */
    private static function selector_targets_body_copy(string $selector): bool
    {
        return self::body_copy_subject($selector) !== null;
    }

    /**
     * The body-copy SUBJECT CLASS of a selector: 'body' when any
     * comma-separated part has body as its subject (last simple selector,
     * class/id/attr qualifiers allowed, pseudo subjects excluded), else
     * 'html' for an html subject, else 'p' for a p subject, else null.
     * body > html > p when one rule targets several (`body, p { ... }` is
     * authored for the page's base copy). A p whose own qualifier names a
     * TITLE role (see p_subject_is_title) is a styled heading, not body
     * copy, and never votes (rombauer: Commerce7's
     * `.c7-form p.c7-account__profile__title { font-weight: bold }` fed
     * bodyWeight 700 while the live body is 400).
     */
    private static function body_copy_subject(string $selector): ?string
    {
        $subject = null;
        foreach (explode(',', $selector) as $part) {
            $part = trim($part);
            if ($part === '') continue;
            if (preg_match('/(?:^|[\s>+~])body(?:[.#\[][^\s>+~:]*)?$/', $part)) return 'body';
            if (preg_match('/(?:^|[\s>+~])html(?:[.#\[][^\s>+~:]*)?$/', $part)) {
                $subject = 'html';
            } elseif ($subject === null
                && preg_match('/(?:^|[\s>+~])p((?:[.#\[][^\s>+~:]*)?)$/', $part, $pm)) {
                if (self::p_subject_is_title(isset($pm[1]) ? $pm[1] : '')) continue;
                $subject = 'p';
            }
        }
        return $subject;
    }

    /**
     * True when a p subject's own qualifier names a heading/title role
     * (p.card-title, p.c7-account__profile__title): that p is a styled
     * heading, so its family/weight must never vote as body copy.
     */
    private static function p_subject_is_title(string $qualifier): bool
    {
        if ($qualifier === '') return false;
        foreach (['title', 'heading', 'headline', 'eyebrow', 'kicker', 'caption'] as $t) {
            if (strpos($qualifier, $t) !== false) return true;
        }
        return false;
    }

    /**
     * Parse a `font:` SHORTHAND out of a rule body: the family list
     * (everything after the size[/line-height] token) and the effective
     * weight. Only the numeric-size form (`13px/1.4 Family, ...`) is
     * parseable here; system keyword shorthands (`font: menu`) and keyword
     * sizes carry no readable family list and yield null. The shorthand
     * RESETS font-weight, so when no bold/100-900 token precedes the size
     * the weight is an EXPLICIT 400, not unknown (ridge's only real body
     * rule is `body{font:13px/1.4 CenturyGothicStd,...}`, which the
     * family/weight readers used to miss entirely; `bolder`/`lighter` are
     * relative tokens a declared-styles guess cannot resolve, so they read
     * as the reset too).
     *
     * @return array{family:string,weight:int}|null
     */
    private static function font_shorthand(string $body): ?array
    {
        if (!preg_match('/(?<![a-z\-])font\s*:\s*([^;}]+)/i', $body, $m)) return null;
        $value = self::clean_var_value($m[1]);
        if (!preg_match('/^(.*?)([0-9]*\.?[0-9]+)(px|pt|pc|em|rem|%|vw|vh)\s*(?:\/\s*[0-9]*\.?[0-9]+[a-z%]*)?\s+(.+)$/i', $value, $fm)) {
            return null;
        }
        $family = trim(isset($fm[4]) ? $fm[4] : '');
        if ($family === '') return null;
        $weight = 400;   // the shorthand resets font-weight; no token = 400
        $pre = strtolower(isset($fm[1]) ? $fm[1] : '');
        if (preg_match('/(?:^|\s)bold(?:\s|$)/', $pre)) {
            $weight = 700;
        } elseif (preg_match('/(?:^|\s)([1-9]00)(?:\s|$)/', $pre, $wm)) {
            $weight = (int) $wm[1];
        }
        return ['family' => $family, 'weight' => $weight];
    }

    // --------------------------------------------------------------------- //
    //  Density + web-font signals                                           //
    // --------------------------------------------------------------------- //

    /**
     * Layout density inferred from declared CSS. CONSERVATIVE by design: the
     * result is 'default' unless BOTH available signals exist AND agree on the
     * same non-default direction, a single value is never enough to move a
     * storefront off the neutral default.
     *
     * Signals (thresholds commented inline):
     *  - body line-height RATIO: <= 1.4 reads compact, >= 1.75 reads airy.
     *  - dominant section/container VERTICAL padding (median px): <= 24px
     *    reads compact, >= 80px reads airy.
     * A value between a signal's bands is neutral and casts no vote.
     */
    private static function infer_density(string $css): string
    {
        $votes = [];

        $lh = self::body_line_height($css);
        if ($lh !== null) {
            // <= 1.4 is tighter than the browser default (~1.5): compact.
            // >= 1.75 is open, editorial leading: airy. Between: no vote.
            if ($lh <= 1.4) {
                $votes[] = 'compact';
            } elseif ($lh >= 1.75) {
                $votes[] = 'airy';
            }
        }

        $pad = self::section_vertical_padding($css);
        if ($pad !== null) {
            // <= 24px of section padding is a dense layout: compact. >= 80px
            // is generous editorial spacing: airy. Between: no vote.
            if ($pad <= 24.0) {
                $votes[] = 'compact';
            } elseif ($pad >= 80.0) {
                $votes[] = 'airy';
            }
        }

        // Corroboration gate: at least two agreeing votes, never one alone.
        if (count($votes) >= 2 && count(array_unique($votes)) === 1) {
            return $votes[0];
        }
        return 'default';
    }

    /**
     * Declared body-copy line-height as a RATIO, or null. Unitless values are
     * the ratio directly; em is equivalent; % divides by 100; a px value only
     * counts when the same rule declares a px font-size to divide by. Last
     * declaration wins (cascade order). rem, var() and keyword values are out
     * of scope for a declared-styles guess.
     */
    private static function body_line_height(string $css): ?float
    {
        $found = null;
        foreach (self::body_rule_bodies($css) as $body) {
            if (!preg_match_all('/line-height\s*:\s*([0-9.]+)\s*(px|em|rem|%)?/i', $body, $m, PREG_SET_ORDER)) {
                continue;
            }
            foreach ($m as $decl) {
                $val  = (float) $decl[1];
                $unit = isset($decl[2]) ? strtolower($decl[2]) : '';
                if ($val <= 0.0) continue;
                if ($unit === '' || $unit === 'em') {
                    $found = $val;
                } elseif ($unit === '%') {
                    $found = $val / 100.0;
                } elseif ($unit === 'px') {
                    if (preg_match('/font-size\s*:\s*([0-9.]+)px\b/i', $body, $fm) && (float) $fm[1] > 0.0) {
                        $found = $val / (float) $fm[1];
                    }
                }
                // rem has no reliable local base here: no vote.
            }
        }
        return $found;
    }

    /**
     * Section / container-scale layout selector tokens for the density padding
     * sampler. Broad on purpose (the signal is a MEDIAN and must be
     * corroborated before it can act), but still scoped to layout-block naming
     * so a chip or button padding can't vote.
     */
    private const SECTION_TOKENS = ['section', 'container', 'wrapper', 'hero', 'banner'];

    /**
     * Median declared VERTICAL padding (px) across section/container-scale
     * rules, or null when none is declared. Reads padding-top / padding-bottom
     * and the padding shorthand's first (top) value; px/rem/em only (rem/em at
     * 16px). %, var() and calc() are out of scope, and a horizontal-only
     * shorthand gutter (padding: 0 20px) casts no vertical vote. Pseudo-state
     * rules are skipped like every other sampler.
     */
    private static function section_vertical_padding(string $css): ?float
    {
        $samples = [];
        foreach (self::style_rules($css) as $rule) {
            $sel = $rule['sel'];
            if (self::selector_is_pseudo_state($sel)) continue;
            $match = false;
            foreach (self::SECTION_TOKENS as $t) {
                if (strpos($sel, $t) !== false) { $match = true; break; }
            }
            if (!$match) continue;
            if (preg_match_all('/padding-(?:top|bottom)\s*:\s*([0-9.]+)(px|rem|em)\b/i', $rule['body'], $m, PREG_SET_ORDER)) {
                foreach ($m as $pm) {
                    $samples[] = strtolower($pm[2]) === 'px' ? (float) $pm[1] : (float) $pm[1] * 16.0;
                }
            }
            // The shorthand's FIRST value is the top padding. The lookbehind
            // keeps 'scroll-padding' out of this branch ('padding-top' already
            // fails the \s*: that must follow). Parsing the WHOLE value lets
            // the helper drop a horizontal-only gutter (padding: 0 20px) that
            // must not cast a 0 vertical vote.
            if (preg_match_all('/(?<![a-z\-])padding\s*:\s*([^;{}]+)/i', $rule['body'], $m, PREG_SET_ORDER)) {
                foreach ($m as $pm) {
                    $sample = self::shorthand_top_padding_px((string) $pm[1]);
                    if ($sample !== null) $samples[] = $sample;
                }
            }
        }
        if (empty($samples)) return null;
        return self::median($samples);
    }

    /**
     * Top (vertical) padding in px out of a padding SHORTHAND value, or null
     * when the sample must not vote. A horizontal-only gutter like
     * `padding: 0 20px` says nothing about vertical rhythm, so a 0 vertical
     * component whose horizontal component is non-zero (or unreadable) is
     * excluded; a genuine all-zero `padding: 0` still votes 0. px/rem/em only
     * (rem/em at 16px) plus unitless 0, matching the longhand sampler; a
     * first component in any other unit (%/var()/calc()) casts no vote.
     */
    private static function shorthand_top_padding_px(string $value): ?float
    {
        $tokens = preg_split('/\s+/', trim($value));
        if (!is_array($tokens) || !isset($tokens[0])) return null;
        $top = self::padding_component_px((string) $tokens[0]);
        if ($top === null) return null;
        if ($top === 0.0 && isset($tokens[1])) {
            // 2+ values: the second is the horizontal component. Only a
            // provably all-zero shorthand may vote 0.
            $horizontal = self::padding_component_px((string) $tokens[1]);
            if ($horizontal === null || $horizontal > 0.0) return null;
        }
        return $top;
    }

    /** One padding component -> px (px/rem/em at 16px, unitless 0), else null. */
    private static function padding_component_px(string $token): ?float
    {
        if (preg_match('/^([0-9.]+)(px|rem|em)$/i', $token, $m)) {
            return strtolower($m[2]) === 'px' ? (float) $m[1] : (float) $m[1] * 16.0;
        }
        if (preg_match('/^0+(?:\.0+)?$/', $token)) return 0.0;
        return null;
    }

    /**
     * Google-hosted font families the site ITSELF requests, parsed from
     * <link href="...fonts.googleapis.com/css..."> tags in the HTML and
     * @import url(...fonts.googleapis.com...) statements in the CSS. Only such
     * a genuine request can confirm provider:'google', a font-family NAME in a
     * CSS rule proves nothing about where the face is hosted. Returns
     * [family => int[] requested weights], weights sorted and deduped, [400]
     * when a request names no explicit weights.
     *
     * @return array<string,int[]>
     */
    private static function google_font_requests(string $html, string $css): array
    {
        $urls = [];
        if (preg_match_all('#<link\b[^>]*href\s*=\s*["\']([^"\']*fonts\.googleapis\.com/css2?\?[^"\']*)["\']#i', $html, $m)) {
            foreach ($m[1] as $u) $urls[] = html_entity_decode($u);
        }
        // ';' is ALLOWED inside the captured URL: css2 weight lists are
        // ';'-separated (family=Lora:wght@400;700) and stopping at ';' used to
        // truncate the request to its first weight. The URL still terminates
        // at a quote, a paren or whitespace, which closes both the url(...)
        // and the quoted @import forms before the statement's final ';'.
        if (preg_match_all('#@import\s+(?:url\(\s*)?["\']?([^"\'()\s]*fonts\.googleapis\.com/css2?\?[^"\'()\s]*)#i', $css, $m)) {
            foreach ($m[1] as $u) $urls[] = $u;
        }

        $out = [];
        foreach ($urls as $url) {
            foreach (self::parse_google_font_url($url) as $font) {
                $family = $font['family'];
                if (!isset($out[$family])) {
                    $out[$family] = $font['weights'];
                } else {
                    $merged = array_values(array_unique(array_merge($out[$family], $font['weights'])));
                    sort($merged);
                    $out[$family] = $merged;
                }
            }
        }
        return $out;
    }

    /**
     * Parse one Google Fonts CSS URL into
     * [['family' => name, 'weights' => int[]], ...]. Handles the css2 API
     * (family=Name:wght@400;700, repeatable, ital tuples) and the legacy css
     * API (family=Name:400,700|Other). '+' decodes to a space. A family name
     * outside Google's letters/digits/spaces shape is dropped.
     */
    private static function parse_google_font_url(string $url): array
    {
        $query = '';
        $qpos = strpos($url, '?');
        if ($qpos !== false) $query = substr($url, $qpos + 1);
        if ($query === '') return [];

        $out = [];
        foreach (explode('&', $query) as $param) {
            if (stripos($param, 'family=') !== 0) continue;
            $value = rawurldecode(str_replace('+', ' ', substr($param, 7)));
            // The legacy css API packs several families into ONE param with '|'.
            foreach (explode('|', $value) as $entry) {
                $entry = trim($entry);
                if ($entry === '') continue;
                $colon  = strpos($entry, ':');
                $family = trim($colon !== false ? substr($entry, 0, $colon) : $entry);
                if ($family === '' || strlen($family) > 80 || !preg_match('/^[A-Za-z0-9 ]+$/', $family)) continue;
                $spec = $colon !== false ? substr($entry, $colon + 1) : '';
                $out[] = ['family' => $family, 'weights' => self::google_font_weights($spec)];
            }
        }
        return $out;
    }

    /**
     * Weights out of a Google Fonts family SPEC (the part after the colon):
     * css2 'wght@400;700' / 'ital,wght@0,400;1,700' tuples, or the legacy
     * '400,700italic' list. Only discrete 100-900 hundred-step weights count
     * (variable-font ranges like 'wght@200..700' are skipped, a range is not a
     * discrete download list); an empty result falls back to [400], the face
     * Google serves when no weight is asked for.
     *
     * @return int[]
     */
    private static function google_font_weights(string $spec): array
    {
        $weights = [];
        $spec = trim($spec);
        if ($spec !== '') {
            $at = strpos($spec, '@');
            if ($at !== false) {
                // css2 axis form: axis names before '@', ';'-separated tuples
                // after; the weight is each tuple's LAST component.
                foreach (explode(';', substr($spec, $at + 1)) as $tuple) {
                    if (strpos($tuple, '..') !== false) continue;   // range: skip
                    $parts = explode(',', $tuple);
                    $last  = trim((string) end($parts));
                    if (preg_match('/^\d{3}$/', $last)) {
                        $w = (int) $last;
                        if ($w >= 100 && $w <= 900 && $w % 100 === 0) $weights[] = $w;
                    }
                }
            } else {
                // Legacy list: '400,700italic,300i'.
                foreach (explode(',', $spec) as $token) {
                    if (preg_match('/^(\d{3})/', trim($token), $wm)) {
                        $w = (int) $wm[1];
                        if ($w >= 100 && $w <= 900 && $w % 100 === 0) $weights[] = $w;
                    }
                }
            }
        }
        $weights = array_values(array_unique($weights));
        sort($weights);
        if (empty($weights)) $weights = [400];
        return $weights;
    }

    /**
     * First-family names declared on heading (h1-h6) rules, in document order.
     *
     * @return string[]
     */
    private static function heading_family_candidates(string $css): array
    {
        $out = [];
        foreach (self::heading_rule_bodies($css) as $body) {
            if (!preg_match_all('/font-family\s*:\s*([^;{}]+)/i', $body, $m)) continue;
            foreach ($m[1] as $stack) {
                $fam = self::first_family((string) $stack);
                if ($fam !== null) $out[] = $fam;
            }
        }
        return $out;
    }

    /**
     * First-family names declared on body/html/p rules, in SUBJECT-PRIORITY
     * order (body rules' families first, then html, then p, document order
     * within each). The order matters because first_confirmed_family takes
     * the FIRST Google-confirmed candidate: tablas' preflight
     * `html{font-family:PT Sans,...}` used to put PT Sans ahead of the real
     * `body{font-family:Crimson Pro,...}`, so the webFonts write-through
     * shipped PT Sans into fontSans over the actual body face.
     *
     * @return string[]
     */
    private static function body_family_candidates(string $css): array
    {
        $out = [];
        $rules = self::body_copy_rules($css);
        foreach (['body', 'html', 'p'] as $subject) {
            foreach ($rules as $rule) {
                if ($rule['subject'] !== $subject) continue;
                if (!preg_match_all('/font-family\s*:\s*([^;{}]+)/i', $rule['body'], $m)) continue;
                foreach ($m[1] as $stack) {
                    $fam = self::first_family((string) $stack);
                    if ($fam !== null) $out[] = $fam;
                }
            }
        }
        return $out;
    }

    /** First candidate family with a confirmed Google request (case-insensitive), or null. */
    private static function first_confirmed_family(array $candidates, array $google): ?string
    {
        foreach ($candidates as $cand) {
            foreach (array_keys($google) as $family) {
                if (strcasecmp($cand, (string) $family) === 0) return (string) $family;
            }
        }
        return null;
    }

    /**
     * Build a WebFontsConfig (typography.webFonts) from CONFIRMED Google font
     * requests only. A family qualifies for a role group when a heading
     * (h1-h6) or body/html/p rule names it AND the site itself requests it
     * from fonts.googleapis.com; the request's weight list becomes the
     * download list. The heading family fans across h1..h6 (the storefront's
     * semantic levels); the body family maps to 'body', and the CALLER writes
     * it through to typography.fontSans (nothing downstream does, the CSS-var
     * emitters exclude the body role). Roles without a confirmed family stay
     * null, and NO config is returned at all when nothing confirms, so an
     * unmatched site keeps its existing fonts untouched.
     *
     * @param array<string,int[]> $google family => requested weights
     */
    private static function web_fonts_config(array $google, string $css, ?int $heading_weight, ?int $body_weight): ?array
    {
        if (empty($google)) return null;

        $heading_family = self::first_confirmed_family(self::heading_family_candidates($css), $google);
        $body_family    = self::first_confirmed_family(self::body_family_candidates($css), $google);
        if ($heading_family === null && $body_family === null) return null;

        $config = [
            'provider' => 'google',
            'h1' => null, 'h2' => null, 'h3' => null,
            'h4' => null, 'h5' => null, 'h6' => null,
            'accent' => null, 'body' => null,
        ];

        if ($heading_family !== null) {
            // Headings render at the detected heading weight; 700 stands in
            // when no heading weight was declared (headings are bold by role).
            $render = $heading_weight !== null ? $heading_weight : 700;
            $font = self::web_font_entry($heading_family, $google[$heading_family], $render);
            foreach (['h1', 'h2', 'h3', 'h4', 'h5', 'h6'] as $role) {
                $config[$role] = $font;
            }
        }
        if ($body_family !== null) {
            // Body renders at the detected body weight, else the 400 default.
            $render = $body_weight !== null ? $body_weight : 400;
            $config['body'] = self::web_font_entry($body_family, $google[$body_family], $render);
        }
        return $config;
    }

    /**
     * One WebFont entry: family + the site's requested weights + the role's
     * render weight. INVARIANT (mirrors ThemeOptions::sanitize_web_font):
     * weight is always in weights, because rendering a weight that isn't
     * downloaded gets a browser-synthesised fake, so a missing render weight
     * is pushed into the download list.
     *
     * @param int[] $weights
     */
    private static function web_font_entry(string $family, array $weights, int $weight): array
    {
        if (!in_array($weight, $weights, true)) {
            $weights[] = $weight;
            sort($weights);
        }
        // Cap to the sanitizer's 6-weight budget OURSELVES, keeping the 6
        // weights CLOSEST to the render weight (ties drop the heavier).
        // ThemeOptions::sanitize_web_font keeps only the 6 LIGHTEST on save,
        // so a >6 list with a heavy render weight (e.g. 800) would have that
        // weight evicted and reset to 400, a fake-bold. Capping here makes
        // the sanitizer's slice a no-op and the render weight (distance 0)
        // always survives, so the weight-in-weights invariant holds.
        if (count($weights) > 6) {
            usort($weights, static function ($a, $b) use ($weight) {
                $da = abs($a - $weight);
                $db = abs($b - $weight);
                if ($da !== $db) return $da <=> $db;
                return $a <=> $b;   // equal distance: the lighter is kept
            });
            $weights = array_slice($weights, 0, 6);
            sort($weights);
        }
        return ['family' => $family, 'weights' => array_values($weights), 'weight' => $weight];
    }

    /**
     * Concrete body font-family stack for a CONFIRMED Google body family,
     * mirroring the Studio's webFontStack(family, 'body') in
     * shared/studio/composables/useGoogleFonts.ts: the quoted family first,
     * then the same generic sans fallback the Studio appends. Written into
     * typography.fontSans by extract() so the downloaded body face actually
     * renders on the storefront.
     */
    private static function body_font_stack(string $family): string
    {
        return '"' . $family . '", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
    }

    /**
     * Generic tails for a declared body stack: the sans tail matches the
     * Studio's BODY fallback (body_font_stack) and the serif tail matches the
     * estate default fontSerif, so fallback rendering stays consistent with
     * the rest of the theme system.
     */
    private const BODY_SANS_TAIL  = 'ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
    private const BODY_SERIF_TAIL = 'Georgia, Cambria, "Times New Roman", serif';

    /**
     * Ubiquitous system / web-safe faces. A body stack LEADING with one of
     * these is the platform's default typography, not a brand choice, so it is
     * not confident evidence and the CSS-armor 'inherit' stands (example.com's
     * -apple-system/system-ui stack must keep producing today's seed).
     */
    private const SYSTEM_FAMILIES = [
        '-apple-system', 'blinkmacsystemfont', 'system-ui', 'ui-sans-serif',
        'ui-serif', 'ui-monospace', 'ui-rounded', 'segoe ui', 'roboto',
        'helvetica', 'helvetica neue', 'arial', 'verdana', 'tahoma',
        'trebuchet ms', 'georgia', 'cambria', 'times', 'times new roman',
        'courier', 'courier new', 'noto sans', 'liberation sans', 'cantarell',
    ];

    /** True when a family name is a system / web-safe default face. */
    private static function is_system_family(string $family): bool
    {
        return in_array(strtolower($family), self::SYSTEM_FAMILIES, true);
    }

    /**
     * CONCRETE body font stack read from the site's own body/p rules, or null
     * when nothing confident was declared (fontSans then keeps the CSS-armor
     * 'inherit'). Rules whose SUBJECT is body/html outrank p-subject rules
     * (ridge: `.social p`'s CenturyGothicStd-Bold used to beat the real
     * `body` rule), and the `font:` SHORTHAND's family list counts alongside
     * `font-family:` (ridge's only real body rule is the shorthand).
     * Confidence gate: the FIRST declared family must be a real,
     * echo-able, non-system face (ridge's CenturyGothicStd, silveroak's Adobe
     * Garamond Pro qualify; -apple-system stacks and var() faces do not). The
     * emitted stack leads with up to two declared families (quoted as needed)
     * and closes with a generic tail matching the declared CHARACTER: a serif
     * body face gets the serif tail, anything else the sans tail. The result
     * is plain text well under the sanitizer's 240-char cap, so it round-trips
     * ThemeOptions::sanitize_font_stack unchanged.
     */
    private static function declared_body_stack(string $css): ?string
    {
        $rules = self::body_copy_rules($css);
        $raw_vars = self::global_raw_var_map($css);
        // Subject priority: body-subject rules first, then html, then
        // p-subject rules, so the site's real `body` rule always outranks a
        // reset/preflight `html` rule (tablas) and component p rules. A
        // `font-family: var(--font-body)` chain resolves through the global
        // var map before the confidence gate (cakebread declared Nimbus Sans
        // L this way and used to be lost to 'inherit').
        foreach (['body', 'html', 'p'] as $subject) {
            foreach ($rules as $rule) {
                if ($rule['subject'] !== $subject) continue;
                if (preg_match('/font-family\s*:\s*([^;}]+)/i', $rule['body'], $m)) {
                    $stack = self::concrete_stack_from(self::resolve_font_family_value((string) $m[1], $raw_vars));
                    if ($stack !== null) return $stack;
                }
                $shorthand = self::font_shorthand($rule['body']);
                if ($shorthand !== null) {
                    $stack = self::concrete_stack_from(self::resolve_font_family_value($shorthand['family'], $raw_vars));
                    if ($stack !== null) return $stack;
                }
            }
        }
        return null;
    }

    /**
     * Build the concrete stack for one declared font-family value, or null
     * when its first family is not confident brand evidence (see
     * declared_body_stack).
     */
    private static function concrete_stack_from(string $raw): ?string
    {
        $parts = explode(',', $raw);
        // F15: family names are cleaned (no !important, no stray quotes)
        // before the usability gates, so a sloppy declaration still ships.
        $first = self::clean_family_name(trim(isset($parts[0]) ? $parts[0] : ''));
        if (!self::is_usable_family($first)) return null;
        if (self::is_system_family($first)) return null;

        $leading = [self::quote_family($first)];
        // Keep the site's own declared second face as the first fallback when
        // it is usable (system faces are fine HERE, they are the site's real
        // fallback, only the LEAD family carries the confidence gate).
        if (isset($parts[1])) {
            $second = self::clean_family_name(trim($parts[1]));
            if (self::is_usable_family($second) && strcasecmp($second, $first) !== 0) {
                $leading[] = self::quote_family($second);
            }
        }

        // Serif vs sans character decides the generic tail:
        // classify_font_stack encodes the (anti-sans-generic-gated) serif
        // heuristics, and a LEAD family carrying a classic serif name
        // (garamond, baskerville, times, ...) reads serif even when the
        // declared stack trails a sans-serif generic (silveroak's "Adobe
        // Garamond Pro" body used to ship with the sans tail that way).
        $character = self::classify_font_stack($raw);
        $tail = ($character['style'] === 'serif' || self::family_reads_serif($first))
            ? self::BODY_SERIF_TAIL
            : self::BODY_SANS_TAIL;
        return implode(', ', $leading) . ', ' . $tail;
    }

    /**
     * Classic serif family-name tokens for the body-tail decision. A lead
     * family carrying one of these is a serif face by NAME; a name that also
     * says 'sans' (e.g. "Times Square Sans") never reads serif.
     */
    private const SERIF_NAME_TOKENS = ['garamond', 'baskerville', 'caslon', 'georgia', 'times', 'palatino', 'minion', 'didot', 'bodoni', 'roman', 'serif'];

    /** True when a family NAME reads as a classic serif face (see SERIF_NAME_TOKENS). */
    private static function family_reads_serif(string $family): bool
    {
        $low = strtolower($family);
        if (strpos($low, 'sans') !== false) return false;
        foreach (self::SERIF_NAME_TOKENS as $t) {
            if (strpos($low, $t) !== false) return true;
        }
        return false;
    }

    /**
     * Resolve a font-family VALUE whose lead is a var() reference through the
     * GLOBAL-scope raw var map, keeping any declared tail
     * (`var(--font-body), sans-serif` resolves the reference and keeps the
     * generic). The reference's matching close paren is found by scanning so
     * a parenthesised fallback survives; an unresolvable reference returns
     * the value untouched (the usability gates then reject it as before).
     */
    private static function resolve_font_family_value(string $raw, array $raw_vars): string
    {
        $v = trim($raw);
        if (stripos($v, 'var(') !== 0) return $raw;
        $open = strpos($v, '(');
        if ($open === false) return $raw;
        $depth = 0;
        $end = -1;
        $len = strlen($v);
        for ($i = $open; $i < $len; $i++) {
            $c = $v[$i];
            if ($c === '(') $depth++;
            if ($c === ')') {
                $depth--;
                if ($depth === 0) { $end = $i; break; }
            }
        }
        if ($end === -1) return $raw;
        $resolved = self::resolve_var_reference(substr($v, 0, $end + 1), $raw_vars);
        if ($resolved === null) return $raw;
        return $resolved . substr($v, $end + 1);
    }

    /**
     * found.bodyFont diagnostic: the lead family of the SAME resolved stack
     * the seed's fontSans shipped (so the diagnostics can never say null
     * while a declared stack resolved), falling back to the legacy
     * font_families() read when no stack resolved.
     */
    private static function body_font_diagnostic(?string $body_stack, ?string $legacy): ?string
    {
        if ($body_stack !== null) {
            $lead = self::first_family($body_stack);
            if ($lead !== null) return $lead;
        }
        return $legacy;
    }

    /**
     * Quote a family name for a font-family value when it is not a valid
     * unquoted CSS identifier sequence: a leading digit ('9Lives'), a leading
     * hyphen-digit, or any character outside [A-Za-z0-9_-] (spaces included,
     * as before) all require quotes to stay valid CSS.
     */
    private static function quote_family(string $family): string
    {
        $needs_quotes = preg_match('/^-?[0-9]/', $family) === 1
            || preg_match('/[^A-Za-z0-9_-]/', $family) === 1;
        return $needs_quotes ? '"' . $family . '"' : $family;
    }

    /**
     * Non-Google custom faces the site loads, DIAGNOSTICS ONLY (never written
     * into typography.webFonts, whose provider enum is Google-only by design):
     * families declared via @font-face in the parsed CSS (Google-confirmed
     * families excluded, they are already reported via webFonts), plus a
     * marker when an Adobe Fonts (Typekit) kit is referenced.
     *
     * @param array<string,int[]> $google confirmed Google families
     * @return string[]
     */
    private static function custom_font_faces(string $html, string $css, array $google): array
    {
        $out = [];
        foreach (self::style_rules($css) as $rule) {
            if (strpos($rule['sel'], '@font-face') === false) continue;
            if (!preg_match_all('/font-family\s*:\s*([^;}]+)/i', $rule['body'], $m)) continue;
            foreach ($m[1] as $stack) {
                $fam = self::first_family((string) $stack);
                if ($fam === null) continue;
                $is_google = false;
                foreach (array_keys($google) as $gfam) {
                    if (strcasecmp($fam, (string) $gfam) === 0) { $is_google = true; break; }
                }
                if ($is_google) continue;
                if (!in_array($fam, $out, true)) $out[] = $fam;
            }
        }
        if (preg_match('#use\.typekit\.(net|com)#i', $html . "\n" . $css)) {
            $out[] = 'Adobe Fonts (Typekit kit)';
        }
        return array_slice($out, 0, 12);
    }

    /**
     * Flat vs elevated surface language, from box-shadow + border on
     * card / tile / panel selectors. Returns
     * ['verdict' => 'flat'|'elevated'|null, 'surfaces' => array]. 'surfaces' is
     * empty (verdict null) when there is no card evidence at all, so the
     * elevated Bridge defaults stand (the ambiguous default per the skill).
     *
     * Only RESTING rules count: a :hover / :focus / :active rule is skipped, so a
     * flat-at-rest card that only lifts a shadow on hover is not misread as
     * elevated (a resting shadow is what indicates elevation).
     */
    private static function surface_depth(string $css): array
    {
        $saw_card         = false;
        $card_real_shadow = false;
        $card_border      = false;

        foreach (self::style_rules($css) as $rule) {
            if (self::selector_is_pseudo_state($rule['sel'])) continue;
            if (self::selector_kind($rule['sel']) !== 'card') continue;
            $saw_card = true;
            if (self::rule_has_real_shadow($rule['body'])) $card_real_shadow = true;
            if (self::rule_has_border($rule['body']))      $card_border      = true;
        }

        if ($card_real_shadow) {
            return [
                'verdict'  => 'elevated',
                'surfaces' => [
                    'card'        => ['border' => true,  'shadow' => 'sm'],
                    'elevated'    => ['border' => true,  'shadow' => 'md'],
                    'productCard' => ['border' => false, 'shadow' => 'sm'],
                ],
            ];
        }
        if ($saw_card) {
            return [
                'verdict'  => 'flat',
                'surfaces' => [
                    'productCard' => ['border' => false,       'shadow' => 'none'],
                    'card'        => ['border' => $card_border, 'shadow' => 'none'],
                    'elevated'    => ['border' => true,        'shadow' => 'sm'],
                ],
            ];
        }
        return ['verdict' => null, 'surfaces' => []];
    }

    /** True when a rule declares a box-shadow with a real (nonzero) blur. */
    private static function rule_has_real_shadow(string $body): bool
    {
        if (!preg_match_all('/box-shadow\s*:\s*([^;}]+)/i', $body, $m)) return false;
        foreach ($m[1] as $val) {
            if (self::shadow_value_is_real((string) $val)) return true;
        }
        return false;
    }

    /**
     * A box-shadow value counts as a real drop-shadow when any layer has a
     * nonzero blur (the 3rd length). 'none', offset-only, and inset rings
     * (0-blur) read as flat.
     */
    private static function shadow_value_is_real(string $value): bool
    {
        $v = strtolower(trim($value));
        if ($v === '' || $v === 'none') return false;
        // Strip colour functions so their commas/numbers don't confuse layering.
        $v = preg_replace('/(rgba?|hsla?)\([^)]*\)/i', ' ', $v);
        if (!is_string($v)) return false;
        $v = str_replace('inset', ' ', $v);
        $layers = explode(',', $v);
        foreach ($layers as $layer) {
            if (!preg_match_all('/-?[0-9]*\.?[0-9]+(?:px|rem|em)?/', $layer, $lm) || empty($lm[0])) {
                continue;
            }
            $lengths = [];
            foreach ($lm[0] as $tok) {
                $lengths[] = (float) $tok;
            }
            if (count($lengths) >= 3 && $lengths[2] > 0.0) return true;
        }
        return false;
    }

    /** True when a rule declares a visible (non-none, nonzero-width) border. */
    private static function rule_has_border(string $body): bool
    {
        if (!preg_match_all('/border(?:-(?:top|right|bottom|left))?\s*:\s*([^;}]+)/i', $body, $m)) {
            return false;
        }
        foreach ($m[1] as $val) {
            $v = strtolower(trim((string) $val));
            if ($v === '' || strpos($v, 'none') !== false) continue;
            if (preg_match('/(-?[0-9]*\.?[0-9]+)px/', $v, $wm)) {
                if ((float) $wm[1] > 0.0) return true;
            } elseif (strpos($v, 'solid') !== false || strpos($v, 'dashed') !== false || strpos($v, 'dotted') !== false) {
                return true;
            }
        }
        return false;
    }

    /**
     * Inverse-variant logo filename tokens (F13). A path/filename carrying
     * one of these (letter-bounded, so 'highlight' never matches 'light')
     * names a light-on-transparent variant, invisible on a light checkout
     * (caymus shipped logo-white.svg onto a white page).
     */
    private const LOGO_INVERSE_PATTERN = '/(?<![a-z])(white|light|inverse|reverse)(?![a-z])/';

    /**
     * Badge / certification-mark tokens (F13). An image whose URL path or
     * class attribute carries one of these is an award badge, not the
     * winery's mark (tablas: a "CA Green Medal" sustainability badge beat
     * the Tablas Creek logo). Boundaries: every token needs a left letter
     * boundary, and badge/medal/award/seal are CLOSED on the right too
     * (hyphen/underscore/digit/end still bound, so `green-medal.png` and
     * `award_seal.svg` match while `medallion` / `sealed` / `awarded`
     * never do); certif/accreditation/sustainab stay open-right as
     * deliberate stems (certified, certification, sustainability).
     */
    private const LOGO_BADGE_PATTERN = '/(?<![a-z])(?:(?:badge|medal|award|seal)(?![a-z])|certif|accreditation|sustainab)/';

    /** True when a logo URL's path/filename names an inverse (white/light) variant. */
    private static function logo_url_is_inverse(string $url): bool
    {
        $path = strtolower($url);
        $q = strpos($path, '?');
        if ($q !== false) $path = substr($path, 0, $q);
        return (bool) preg_match(self::LOGO_INVERSE_PATTERN, $path);
    }

    /**
     * True when an img reads as a badge/certification mark. Classified
     * from the URL PATH (query string stripped) and the tag's class
     * attribute ONLY: alt text is deliberately ignored, because marketing
     * copy like alt="Award-winning Napa winery" on the genuine header
     * logo was demoting it below the fallback derivatives.
     */
    private static function logo_tag_is_badge(string $tag, string $url): bool
    {
        $path = strtolower($url);
        $q = strpos($path, '?');
        if ($q !== false) $path = substr($path, 0, $q);
        if (preg_match(self::LOGO_BADGE_PATTERN, $path)) return true;
        if (preg_match('/(?<![\w\-])class\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'>]+))/i', $tag, $m)) {
            $class = $m[1] !== '' ? $m[1] : (isset($m[2]) && $m[2] !== '' ? $m[2] : (isset($m[3]) ? $m[3] : ''));
            if (preg_match(self::LOGO_BADGE_PATTERN, strtolower($class))) return true;
        }
        return false;
    }

    /**
     * One IMAGE-pool candidate out of an <img> tag, or null when it has no
     * usable source. Carries the heuristic tier (0 header, 1 logo-classed)
     * plus the F13 inverse/badge classification.
     *
     * @return array{url:string,source:string,tier:int,inverse:bool,badge:bool}|null
     */
    private static function logo_pool_entry(string $tag, string $base, int $tier, string $source): ?array
    {
        $src = self::img_src($tag);
        if ($src === null) return null;
        $url = self::absolute_url(html_entity_decode($src), $base);
        if ($url === '') return null;
        return [
            'url'     => $url,
            'source'  => $source,
            'tier'    => $tier,
            'inverse' => self::logo_url_is_inverse($url),
            'badge'   => self::logo_tag_is_badge($tag, $url),
        ];
    }

    /**
     * F13: choose from the IMAGE candidate pool (header imgs + logo-classed
     * imgs). Sort: non-badge before badge, then non-inverse before inverse
     * (the sibling preference: a plain logo.svg beats logo-white.svg at any
     * image tier), then tier, then document order. An inverse pick carries
     * a note (the mark may be light-on-transparent); a badge pick is
     * flagged so the caller demotes it below og:image / touch icon /
     * favicon (an award badge is a worse logo than any of those).
     *
     * @param array<int,array{url:string,source:string,tier:int,inverse:bool,badge:bool}> $pool
     * @return array{url:string,source:string,note:?string,badge:bool}|null
     */
    private static function pick_logo_from_pool(array $pool): ?array
    {
        $best = null;
        $best_key = null;
        foreach ($pool as $order => $cand) {
            $key = [$cand['badge'] ? 1 : 0, $cand['inverse'] ? 1 : 0, $cand['tier'], $order];
            if ($best === null || $key < $best_key) {
                $best = $cand;
                $best_key = $key;
            }
        }
        if ($best === null) return null;
        $note = null;
        if ($best['inverse']) {
            $note = __('Logo may be light on a light background. Check the logo below.', 'b360-bridge');
        }
        return ['url' => $best['url'], 'source' => $best['source'], 'note' => $note, 'badge' => $best['badge']];
    }

    /**
     * Best logo candidate. Preference order: a real logo IMAGE in the page's
     * own markup (every <img> inside <header>, then any <img> whose tag
     * mentions "logo", ranked by pick_logo_from_pool: non-badge before
     * badge, non-inverse before inverse), then og:image, then the
     * apple-touch-icon / favicon (tiny square derivatives, ridge's 57px
     * touch icon lost to the theme's actual logo_large.png), and an image
     * pool holding ONLY badges last of all. Returns absolute URL + which
     * signal + an optional caller-facing note, or null.
     *
     * @return array{url:string,source:string,note:?string}|null
     */
    private static function logo_candidate(string $html, string $base): ?array
    {
        // IMAGE pool: every <img> inside the page's <header> element (tier
        // 0, document order), then every <img> whose tag mentions "logo"
        // (class/id/src/alt; tier 1), deduped by URL (best tier kept).
        $pool = [];
        $seen = [];
        if (preg_match('#<header\b[^>]*>(.*?)</header>#is', $html, $hm)
            && preg_match_all('#<img\b[^>]*>#i', $hm[1], $him)) {
            foreach ($him[0] as $tag) {
                $cand = self::logo_pool_entry($tag, $base, 0, 'header-img');
                if ($cand === null || isset($seen[$cand['url']])) continue;
                $seen[$cand['url']] = true;
                $pool[] = $cand;
            }
        }
        if (preg_match_all('#<img\b[^>]*>#i', $html, $all)) {
            foreach ($all[0] as $tag) {
                if (stripos($tag, 'logo') === false) continue;
                $cand = self::logo_pool_entry($tag, $base, 1, 'logo-img');
                if ($cand === null || isset($seen[$cand['url']])) continue;
                $seen[$cand['url']] = true;
                $pool[] = $cand;
            }
        }
        $pick = self::pick_logo_from_pool($pool);
        if ($pick !== null && !$pick['badge']) {
            return ['url' => $pick['url'], 'source' => $pick['source'], 'note' => $pick['note']];
        }
        // og:image
        if (preg_match('#<meta[^>]*property\s*=\s*["\']og:image["\'][^>]*content\s*=\s*["\']([^"\']+)["\']#i', $html, $m)
            || preg_match('#<meta[^>]*content\s*=\s*["\']([^"\']+)["\'][^>]*property\s*=\s*["\']og:image["\']#i', $html, $m)) {
            $u = self::absolute_url(html_entity_decode($m[1]), $base);
            if ($u !== '') return ['url' => $u, 'source' => 'og:image', 'note' => null];
        }
        // apple-touch-icon
        if (preg_match('#<link[^>]*rel\s*=\s*["\'][^"\']*apple-touch-icon[^"\']*["\'][^>]*href\s*=\s*["\']([^"\']+)["\']#i', $html, $m)) {
            $u = self::absolute_url(html_entity_decode($m[1]), $base);
            if ($u !== '') return ['url' => $u, 'source' => 'apple-touch-icon', 'note' => null];
        }
        // favicon (rel="icon" / "shortcut icon")
        if (preg_match('#<link[^>]*rel\s*=\s*["\'][^"\']*icon["\'][^>]*href\s*=\s*["\']([^"\']+)["\']#i', $html, $m)) {
            $u = self::absolute_url(html_entity_decode($m[1]), $base);
            if ($u !== '') return ['url' => $u, 'source' => 'favicon', 'note' => null];
        }
        // A badge-only image pool is the last resort of all: better a badge
        // than nothing, but never over a real derivative.
        if ($pick !== null) {
            return ['url' => $pick['url'], 'source' => $pick['source'], 'note' => $pick['note']];
        }
        return null;
    }

    /**
     * An <img> tag's usable source: src, else data-src (lazy-load), skipping
     * data: URIs (an inlined placeholder is not a linkable logo). The
     * lookbehind keeps `src=` from matching inside `data-src=`.
     */
    private static function img_src(string $tag): ?string
    {
        foreach (['src', 'data-src'] as $attr) {
            if (preg_match('#(?<![a-zA-Z0-9_-])' . $attr . '\s*=\s*["\']([^"\']+)["\']#i', $tag, $m)) {
                $v = trim($m[1]);
                if ($v !== '' && stripos($v, 'data:') !== 0) return $v;
            }
        }
        return null;
    }

    /**
     * Human-facing note lines for the diagnostics panel. The contrast line is
     * computed by the caller (its pair and copy depend on whether a button
     * colour was resolved); this just orders it ahead of the confidence line.
     */
    private static function notes(?string $contrast_note, string $confidence): array
    {
        $notes = [];
        if ($contrast_note !== null) {
            $notes[] = $contrast_note;
        }
        if ($confidence === 'low') {
            $notes[] = __('Brand colour was a guess from the most common colour on the page. Check it below.', 'b360-bridge');
        }
        return $notes;
    }

    // --------------------------------------------------------------------- //
    //  Colour helpers                                                       //
    // --------------------------------------------------------------------- //

    /**
     * Normalise a CSS colour value to #RRGGBB, or null when it is not a plain
     * hex or rgb()/rgba() literal or a CSS named colour (hsl()/hsla(), var()
     * and gradients are out of scope for a declared-styles guess, and the
     * non-colour keywords transparent / currentcolor / inherit / initial /
     * unset / revert / none always stay null).
     *
     * $allow_triplet enables the bare "r,g,b" / "r g b" branch. It is OFF by
     * default and only turned on for custom-property values whose NAME carries
     * an explicit colour token (see name_allows_triplet). A bare triplet is
     * ambiguous with a layout value like "8 16 24", so gating it to a colour
     * context stops e.g. `--spacing: 8 16 24` becoming a colour.
     */
    private static function to_hex(string $value, bool $allow_triplet = false): ?string
    {
        $v = trim($value);

        if (preg_match('/^#([0-9a-fA-F]{6})$/', $v, $m)) {
            return '#' . strtoupper($m[1]);
        }
        if (preg_match('/^#([0-9a-fA-F]{3})$/', $v, $m)) {
            $c = $m[1];
            return '#' . strtoupper($c[0] . $c[0] . $c[1] . $c[1] . $c[2] . $c[2]);
        }
        // An alpha in any numeric spelling is accepted (1, 1.0, 1.00, 100%,
        // or a translucent value, which keeps the base colour), except a
        // FULLY TRANSPARENT one: alpha 0 in any form is no colour, exactly
        // like `transparent`, on every path that parses colours.
        if (preg_match('/^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*[0-9]*\.?[0-9]+%?\s*)?\)$/i', $v, $m)) {
            if (self::literal_alpha($v) === 0.0) return null;
            $r = min(255, (int) $m[1]);
            $g = min(255, (int) $m[2]);
            $b = min(255, (int) $m[3]);
            return sprintf('#%02X%02X%02X', $r, $g, $b);
        }
        // Modern space-separated syntax, `rgb(r g b)` / `rgb(r g b / a)`:
        // unambiguous (the rgb() wrapper is explicit), so never gated, and
        // common at the end of a token chain (cakebread-style var systems).
        // The alpha accepts any numeric/percent form (Shopify emits
        // `rgb(249 248 244 / 1.0)`); like the comma branch, the alpha is
        // dropped, the composed hex is the base colour.
        if (preg_match('/^rgba?\(\s*(\d{1,3})\s+(\d{1,3})\s+(\d{1,3})\s*(?:\/\s*[0-9]*\.?[0-9]+%?\s*)?\)$/i', $v, $m)) {
            if (self::literal_alpha($v) === 0.0) return null;
            $r = min(255, (int) $m[1]);
            $g = min(255, (int) $m[2]);
            $b = min(255, (int) $m[3]);
            return sprintf('#%02X%02X%02X', $r, $g, $b);
        }
        // Bare RGB triplet: Shopify's semantic vars carry the brand hue as
        // "0,110,255" (comma-separated) and Tailwind as "0 110 255"
        // (space-separated), with NO #/rgb() wrapper, so the literal detectors
        // above miss them. Accept exactly three components, each 0-255. The
        // <= 255 guard rejects non-colour triplets like "2020,1,1". Only parsed
        // in a colour-named var context ($allow_triplet), so a layout value like
        // "8 16 24" is never mistaken for a colour.
        if ($allow_triplet && preg_match('/^(\d{1,3})[\s,]+(\d{1,3})[\s,]+(\d{1,3})$/', $v, $m)) {
            $r = (int) $m[1];
            $g = (int) $m[2];
            $b = (int) $m[3];
            if ($r <= 255 && $g <= 255 && $b <= 255) {
                return sprintf('#%02X%02X%02X', $r, $g, $b);
            }
        }
        // CSS named colour, case-insensitive (`white`, `DarkSlateGray`): it
        // resolves to exactly the #RRGGBB its hex literal would, so every
        // downstream gate treats the two identically. transparent,
        // currentcolor, the CSS-wide keywords and none are not in the table.
        return self::named_colour_hex($v);
    }

    /**
     * The CSS Color 4 named colours: the 147 CSS3/SVG names (gray and grey
     * spellings both) plus rebeccapurple, 148 entries. Lowercase keys,
     * #RRGGBB uppercase values in the same normal form to_hex emits.
     * transparent and currentcolor are deliberately absent (neither is a
     * concrete colour), as are the CSS-wide keywords and none.
     */
    private const NAMED_COLOURS = [
        'aliceblue' => '#F0F8FF', 'antiquewhite' => '#FAEBD7', 'aqua' => '#00FFFF', 'aquamarine' => '#7FFFD4',
        'azure' => '#F0FFFF', 'beige' => '#F5F5DC', 'bisque' => '#FFE4C4', 'black' => '#000000',
        'blanchedalmond' => '#FFEBCD', 'blue' => '#0000FF', 'blueviolet' => '#8A2BE2', 'brown' => '#A52A2A',
        'burlywood' => '#DEB887', 'cadetblue' => '#5F9EA0', 'chartreuse' => '#7FFF00', 'chocolate' => '#D2691E',
        'coral' => '#FF7F50', 'cornflowerblue' => '#6495ED', 'cornsilk' => '#FFF8DC', 'crimson' => '#DC143C',
        'cyan' => '#00FFFF', 'darkblue' => '#00008B', 'darkcyan' => '#008B8B', 'darkgoldenrod' => '#B8860B',
        'darkgray' => '#A9A9A9', 'darkgreen' => '#006400', 'darkgrey' => '#A9A9A9', 'darkkhaki' => '#BDB76B',
        'darkmagenta' => '#8B008B', 'darkolivegreen' => '#556B2F', 'darkorange' => '#FF8C00', 'darkorchid' => '#9932CC',
        'darkred' => '#8B0000', 'darksalmon' => '#E9967A', 'darkseagreen' => '#8FBC8F', 'darkslateblue' => '#483D8B',
        'darkslategray' => '#2F4F4F', 'darkslategrey' => '#2F4F4F', 'darkturquoise' => '#00CED1', 'darkviolet' => '#9400D3',
        'deeppink' => '#FF1493', 'deepskyblue' => '#00BFFF', 'dimgray' => '#696969', 'dimgrey' => '#696969',
        'dodgerblue' => '#1E90FF', 'firebrick' => '#B22222', 'floralwhite' => '#FFFAF0', 'forestgreen' => '#228B22',
        'fuchsia' => '#FF00FF', 'gainsboro' => '#DCDCDC', 'ghostwhite' => '#F8F8FF', 'gold' => '#FFD700',
        'goldenrod' => '#DAA520', 'gray' => '#808080', 'green' => '#008000', 'greenyellow' => '#ADFF2F',
        'grey' => '#808080', 'honeydew' => '#F0FFF0', 'hotpink' => '#FF69B4', 'indianred' => '#CD5C5C',
        'indigo' => '#4B0082', 'ivory' => '#FFFFF0', 'khaki' => '#F0E68C', 'lavender' => '#E6E6FA',
        'lavenderblush' => '#FFF0F5', 'lawngreen' => '#7CFC00', 'lemonchiffon' => '#FFFACD', 'lightblue' => '#ADD8E6',
        'lightcoral' => '#F08080', 'lightcyan' => '#E0FFFF', 'lightgoldenrodyellow' => '#FAFAD2', 'lightgray' => '#D3D3D3',
        'lightgreen' => '#90EE90', 'lightgrey' => '#D3D3D3', 'lightpink' => '#FFB6C1', 'lightsalmon' => '#FFA07A',
        'lightseagreen' => '#20B2AA', 'lightskyblue' => '#87CEFA', 'lightslategray' => '#778899', 'lightslategrey' => '#778899',
        'lightsteelblue' => '#B0C4DE', 'lightyellow' => '#FFFFE0', 'lime' => '#00FF00', 'limegreen' => '#32CD32',
        'linen' => '#FAF0E6', 'magenta' => '#FF00FF', 'maroon' => '#800000', 'mediumaquamarine' => '#66CDAA',
        'mediumblue' => '#0000CD', 'mediumorchid' => '#BA55D3', 'mediumpurple' => '#9370DB', 'mediumseagreen' => '#3CB371',
        'mediumslateblue' => '#7B68EE', 'mediumspringgreen' => '#00FA9A', 'mediumturquoise' => '#48D1CC', 'mediumvioletred' => '#C71585',
        'midnightblue' => '#191970', 'mintcream' => '#F5FFFA', 'mistyrose' => '#FFE4E1', 'moccasin' => '#FFE4B5',
        'navajowhite' => '#FFDEAD', 'navy' => '#000080', 'oldlace' => '#FDF5E6', 'olive' => '#808000',
        'olivedrab' => '#6B8E23', 'orange' => '#FFA500', 'orangered' => '#FF4500', 'orchid' => '#DA70D6',
        'palegoldenrod' => '#EEE8AA', 'palegreen' => '#98FB98', 'paleturquoise' => '#AFEEEE', 'palevioletred' => '#DB7093',
        'papayawhip' => '#FFEFD5', 'peachpuff' => '#FFDAB9', 'peru' => '#CD853F', 'pink' => '#FFC0CB',
        'plum' => '#DDA0DD', 'powderblue' => '#B0E0E6', 'purple' => '#800080', 'rebeccapurple' => '#663399',
        'red' => '#FF0000', 'rosybrown' => '#BC8F8F', 'royalblue' => '#4169E1', 'saddlebrown' => '#8B4513',
        'salmon' => '#FA8072', 'sandybrown' => '#F4A460', 'seagreen' => '#2E8B57', 'seashell' => '#FFF5EE',
        'sienna' => '#A0522D', 'silver' => '#C0C0C0', 'skyblue' => '#87CEEB', 'slateblue' => '#6A5ACD',
        'slategray' => '#708090', 'slategrey' => '#708090', 'snow' => '#FFFAFA', 'springgreen' => '#00FF7F',
        'steelblue' => '#4682B4', 'tan' => '#D2B48C', 'teal' => '#008080', 'thistle' => '#D8BFD8',
        'tomato' => '#FF6347', 'turquoise' => '#40E0D0', 'violet' => '#EE82EE', 'wheat' => '#F5DEB3',
        'white' => '#FFFFFF', 'whitesmoke' => '#F5F5F5', 'yellow' => '#FFFF00', 'yellowgreen' => '#9ACD32',
    ];

    /** #RRGGBB for a whole-value CSS named colour (case-insensitive), else null. */
    private static function named_colour_hex(string $word): ?string
    {
        $key = strtolower(trim($word));
        return isset(self::NAMED_COLOURS[$key]) ? self::NAMED_COLOURS[$key] : null;
    }

    /**
     * Named-colour tokens inside a declaration VALUE, in order, as
     * [[offset, hex], ...]. url(...) and quoted strings are blanked first
     * (same length, so offsets hold), so a file name like url(red-bg.png)
     * never votes. A token must be a whole word: no letter, digit, _, -, .
     * or # on either side and not a function name, so --white, no-repeat,
     * white.png and #fade never match.
     *
     * @return array<int,array{0:int,1:string}>
     */
    private static function named_colour_tokens(string $value): array
    {
        $masked = preg_replace_callback('/url\([^)]*\)|"[^"]*"|\'[^\']*\'/i', static function ($m) {
            return str_repeat(' ', strlen($m[0]));
        }, $value);
        if (!is_string($masked)) return [];
        $out = [];
        if (preg_match_all('/(?<![A-Za-z0-9_\-.#])[A-Za-z]+(?![A-Za-z0-9_\-.(])/', $masked, $m, PREG_OFFSET_CAPTURE)) {
            foreach ($m[0] as $tok) {
                $hex = self::named_colour_hex($tok[0]);
                if ($hex !== null) $out[] = [$tok[1], $hex];
            }
        }
        return $out;
    }

    /** [r,g,b] 0-255 from a #RRGGBB hex. */
    private static function rgb(string $hex): array
    {
        $hex = ltrim($hex, '#');
        return [
            hexdec(substr($hex, 0, 2)),
            hexdec(substr($hex, 2, 2)),
            hexdec(substr($hex, 4, 2)),
        ];
    }

    /** WCAG relative luminance 0..1. */
    private static function luminance(string $hex): float
    {
        [$r, $g, $b] = self::rgb($hex);
        $chan = static function ($c) {
            $c = $c / 255;
            return $c <= 0.03928 ? $c / 12.92 : pow(($c + 0.055) / 1.055, 2.4);
        };
        return 0.2126 * $chan($r) + 0.7152 * $chan($g) + 0.0722 * $chan($b);
    }

    /** WCAG contrast ratio between two hex colours. */
    private static function contrast_ratio(string $a, string $b): float
    {
        $la = self::luminance($a);
        $lb = self::luminance($b);
        $hi = max($la, $lb);
        $lo = min($la, $lb);
        return ($hi + 0.05) / ($lo + 0.05);
    }

    private static function is_near_white(string $hex): bool
    {
        return self::luminance($hex) >= 0.92;
    }

    private static function is_near_black(string $hex): bool
    {
        return self::luminance($hex) <= 0.02;
    }

    /** Low chroma → grey/neutral (unlikely to be a brand hue). */
    private static function is_greyish(string $hex): bool
    {
        [$r, $g, $b] = self::rgb($hex);
        $max = max($r, $g, $b);
        $min = min($r, $g, $b);
        return ($max - $min) <= 16;   // near-equal channels
    }

    /** Mix a hex toward white by $amt (0..1). */
    private static function lighten_hex(string $hex, float $amt): string
    {
        [$r, $g, $b] = self::rgb($hex);
        $r = (int) round($r + (255 - $r) * $amt);
        $g = (int) round($g + (255 - $g) * $amt);
        $b = (int) round($b + (255 - $b) * $amt);
        return sprintf('#%02X%02X%02X', $r, $g, $b);
    }

    // --------------------------------------------------------------------- //
    //  Surface resolution                                                   //
    // --------------------------------------------------------------------- //

    /** Surfaces must clear this luminance to count as a usable LIGHT surface. */
    private const SURFACE_LIGHT_MIN = 0.6;

    /**
     * Selector/var-name tokens HARD-excluded from ALL surface inference (page
     * and card): overlays, modals, cookie-consent chrome, tooltips, sliders,
     * shadows and social widgets paint their OWN backdrop, never the page
     * surface. bottlethreesixty is LIGHT (html #F6F2FD, body #fff) but
     * PhotoSwipe's .pswp__bg black, CookieYes' .cky-overlay and Elementor
     * social/divider rules used to outvote the real declarations and flip the
     * whole theme dark.
     */
    private const SURFACE_EXCLUDE_TOKENS = ['overlay', 'backdrop', 'modal', 'lightbox', 'pswp', 'tooltip', 'cky', 'cookie', 'consent', 'swiper', 'shadow', 'social'];

    /**
     * Global page-background var names trusted for the page surface. EXACT
     * names only (a contains-check would pull --button-background /
     * --card-bg back into the page pick this list exists to prevent); the
     * var must additionally be declared at a GLOBAL scope (see
     * global_background_var).
     */
    private const PAGE_BACKGROUND_VAR_NAMES = ['background', 'background-color', 'background-colour', 'color-background', 'colour-background', 'page-bg', 'body-bg', 'page-background', 'body-background', 'site-background', 'site-bg', 'bg'];

    /** True when a selector or var name carries a surface-excluded token. */
    private static function has_surface_excluded_token(string $s): bool
    {
        foreach (self::SURFACE_EXCLUDE_TOKENS as $t) {
            if (strpos($s, $t) !== false) return true;
        }
        return false;
    }

    /**
     * The page-surface SUBJECT of a selector: 'body' when any comma-separated
     * part has body as its subject (class/id/attr qualifiers allowed:
     * body.home; pseudo subjects and body's DESCENDANTS never, `body .promo`
     * styles the promo, not the page), 'html' for an html subject or a bare
     * :root part (:root IS the html element), else null. body outranks html
     * when one rule targets both.
     */
    private static function page_surface_subject(string $selector): ?string
    {
        $subject = null;
        foreach (explode(',', $selector) as $part) {
            $part = trim($part);
            if ($part === '') continue;
            if (preg_match('/(?:^|[\s>+~])body(?:[.#\[][^\s>+~:]*)?$/', $part)) return 'body';
            if ($part === ':root'
                || preg_match('/(?:^|[\s>+~])html(?:[.#\[][^\s>+~:]*)?$/', $part)) {
                $subject = 'html';
            }
        }
        return $subject;
    }

    /**
     * Rank of a selector's body-subject parts for the page-surface scan: 0
     * for a bare `body` part, 1 for a qualified one (body.dark-mode), 2 for
     * an ancestored one (.dark body). The BEST (lowest) rank across the
     * comma parts stands. The default render of a site is its bare-body
     * rule; classed and ancestored body rules are opt-in modes (theme
     * switchers, .dark wrappers) and must not beat it via last-wins. Null
     * when no part has body as its subject.
     */
    private static function body_subject_rank(string $selector): ?int
    {
        $rank = null;
        foreach (explode(',', $selector) as $part) {
            $part = trim($part);
            if ($part === '') continue;
            $r = null;
            if ($part === 'body') {
                $r = 0;
            } elseif (preg_match('/^body(?:[.#\[][^\s>+~:]*)?$/', $part)) {
                $r = 1;
            } elseif (preg_match('/(?:^|[\s>+~])body(?:[.#\[][^\s>+~:]*)?$/', $part)) {
                $r = 2;
            }
            if ($r !== null && ($rank === null || $r < $rank)) $rank = $r;
        }
        return $rank;
    }

    /**
     * Remove @media (prefers-color-scheme: dark) { ... } blocks, balanced
     * braces (nested rules included), tolerant of an unbalanced tail. The
     * SURFACE scan alone runs on the stripped CSS: the page surface must
     * reflect the site's DEFAULT render, and the flat style_rules tokenizer
     * is scope-blind, so a dark-scheme `body { background:#111 }` would
     * otherwise beat the real light body rule via last-wins and seed a full
     * dark theme on a light site. Brand/typography scans keep the full CSS:
     * a colour or face declared only for dark mode is still the site's own.
     */
    private static function strip_dark_scheme_blocks(string $css): string
    {
        $out = '';
        $len = strlen($css);
        $pos = 0;
        while ($pos < $len) {
            if (!preg_match('/@media[^{;]*prefers-color-scheme\s*:\s*dark[^{;]*\{/i', $css, $m, PREG_OFFSET_CAPTURE, $pos)) {
                $out .= substr($css, $pos);
                break;
            }
            $start = (int) $m[0][1];
            $out .= substr($css, $pos, $start - $pos);
            // Walk the block's balanced braces (depth 1 at the prelude's
            // opening brace) and drop everything through its close.
            $i = $start + strlen($m[0][0]);
            $depth = 1;
            while ($i < $len && $depth > 0) {
                $c = $css[$i];
                if ($c === '{') $depth++;
                elseif ($c === '}') $depth--;
                $i++;
            }
            $pos = $i;
        }
        return $out;
    }

    /**
     * The declared page background per SUBJECT level, read ONLY from rules
     * whose subject is body or html/:root (see page_surface_subject), never
     * an arbitrary selector, with overlay/widget chrome hard-excluded. Last
     * declaration wins per level (cascade order), except that at the body
     * level a better body_subject_rank always outranks document order (a
     * .dark wrapper never beats the bare body rule), background-color
     * preferred within a rule, and a var() background resolves through the
     * GLOBAL-scope var map (chains included). The caller may hand in a
     * COMBINED site+vendor var map so a site body rule referencing a
     * platform-defined var still resolves; a lone caller keeps the own-CSS
     * map it always had. Returns ['body' => ?hex, 'html' => ?hex].
     */
    private static function scoped_page_background(string $css, ?array $raw_vars = null): array
    {
        if ($raw_vars === null) $raw_vars = self::global_raw_var_map($css);
        $found = ['body' => null, 'html' => null];
        $body_rank = null;
        foreach (self::style_rules($css) as $rule) {
            if (self::has_surface_excluded_token($rule['sel'])) continue;
            $subject = self::page_surface_subject($rule['sel']);
            if ($subject === null) continue;
            $hex = self::declared_background_hex($rule['body'], $raw_vars);
            if ($hex === null) continue;
            if ($subject === 'body') {
                // The default render of a site is its BARE body rule;
                // qualified (body.dark-mode) and ancestored (.dark body)
                // rules are opt-in modes and must not beat it via
                // last-wins document order.
                $rank = self::body_subject_rank($rule['sel']);
                if ($body_rank !== null && $rank > $body_rank) continue;
                $found['body'] = $hex;   // last wins within a rank
                $body_rank = $rank;
            } else {
                $found['html'] = $hex;   // last wins per level (cascade order)
            }
        }
        return $found;
    }

    /**
     * The page-background var declared at a GLOBAL scope: exact names from
     * PAGE_BACKGROUND_VAR_NAMES only, last declaration wins. Returns
     * ['hex' => ?string, 'source' => ?string] with the source naming the
     * declaring scope and var (e.g. ':root@--color-background').
     */
    private static function global_background_var(string $css): array
    {
        $hex = null;
        $source = null;
        foreach (self::scoped_var_list($css) as $decl) {
            if (!in_array($decl['name'], self::PAGE_BACKGROUND_VAR_NAMES, true)) continue;
            $hex    = $decl['hex'];   // last wins (cascade order)
            $source = self::clean_scope_label($decl['scope']) . '@--' . $decl['name'];
        }
        return ['hex' => $hex, 'source' => $source];
    }

    /**
     * The page-surface candidates in precedence order (body > html/:root
     * declaration > global page-background var), each ['hex', 'source'].
     * SITE-OWNED CSS leads: the platform-CDN bucket is consulted only when
     * the site CSS yields no surface at all, and @media
     * (prefers-color-scheme: dark) blocks are stripped first so the list
     * reflects the site's DEFAULT render. resolve_surfaces reads the page
     * surface from this list, and extract() computes it once up front so the
     * brand resolver's dark-page gate reads the SAME list (see
     * dark_page_candidate). Empty when nothing is declared.
     *
     * @return array<int,array{hex:string,source:string}>
     */
    private static function page_surface_candidates(string $css, ?string $vendor_css = null): array
    {
        // Surface must reflect the site's DEFAULT render: dark-scheme media
        // blocks describe the opt-in dark render and would surface
        // scope-blind through the flat tokenizer, so the surface scan (and
        // only it) runs on CSS with them stripped.
        $css    = self::strip_dark_scheme_blocks($css);
        $vendor = ($vendor_css !== null && $vendor_css !== '') ? self::strip_dark_scheme_blocks($vendor_css) : '';

        // var() backgrounds resolve through the COMBINED global var map,
        // vendor first so a site redeclaration of a vendor token wins by
        // last-wins while an un-overridden vendor token still resolves (a
        // site body rule may reference a platform-defined var either way).
        $raw_vars = self::global_raw_var_map($vendor . "\n" . $css);

        $declared = self::scoped_page_background($css, $raw_vars);
        $bg_var   = self::global_background_var($css);
        // Site-over-vendor discipline, the same F8 rule the brand resolver
        // applies: a platform CDN's shipped body default (Commerce7 declares
        // bare body{background:var(--c7-bg)} white on every store) must
        // never outvote the site's own body rule at equal rank whatever the
        // fetch-priority concatenation order was (ridge: #3A3A3A). The
        // vendor bucket is consulted ONLY when the site CSS yields no
        // body/html/:root surface at all, so a pure platform-hosted site
        // still resolves instead of falling back to white.
        if ($vendor !== '' && $declared['body'] === null && $declared['html'] === null && $bg_var['hex'] === null) {
            $declared = self::scoped_page_background($vendor, $raw_vars);
            $bg_var   = self::global_background_var($vendor);
        }

        // Page candidates in precedence order: body > html/:root declaration
        // > global background var.
        $page_candidates = [];
        if ($declared['body'] !== null) $page_candidates[] = ['hex' => $declared['body'], 'source' => 'body@background'];
        if ($declared['html'] !== null) $page_candidates[] = ['hex' => $declared['html'], 'source' => 'html@background'];
        if ($bg_var['hex'] !== null)    $page_candidates[] = ['hex' => $bg_var['hex'], 'source' => $bg_var['source']];
        return $page_candidates;
    }

    /**
     * The top-precedence page candidate when it is DARK (relative luminance
     * below 0.2), else null. This is the single dark-page decision:
     * resolve_surfaces uses it to choose the dark theme, and the brand
     * resolver uses it to decide whether a near-white button colour may be
     * the brand (on a dark page it is the real CTA), so the two can never
     * disagree. An unknown page (no candidate at all) is not dark.
     *
     * @param array<int,array{hex:string,source:string}> $page_candidates
     * @return array{hex:string,source:string}|null
     */
    private static function dark_page_candidate(array $page_candidates): ?array
    {
        $primary = isset($page_candidates[0]) ? $page_candidates[0] : null;
        if ($primary !== null && self::luminance($primary['hex']) < 0.2) return $primary;
        return null;
    }

    /**
     * Resolve surfacePage, surfaceCard, (body) textPrimary and the SOURCE of
     * the page pick, so "Match my site" can't return a black storefront on a
     * light winery site. Returns
     * [surfacePage, surfaceCard, textPrimary|null, note|null, surfaceSource].
     *
     * Rules:
     *  - surfacePage comes ONLY from body/html/:root-subject background
     *    declarations (body > html, last-wins within a level) or a global
     *    page-background var; overlay/modal/cookie-consent chrome never votes
     *    and "the darkest colour found" is never picked. theme-color meta
     *    stays a brand signal only: with this strict precedence there is no
     *    tie left for it to break, so it is deliberately never a primary
     *    surface source.
     *  - SITE-OWNED CSS leads, the F8 site-over-vendor rule the brand
     *    resolver already applies: the platform-CDN bucket ($vendor_css) is
     *    consulted only when the site CSS yields no body/html/:root surface
     *    at all, so a platform's shipped body default never outvotes the
     *    site's own rule at equal rank. var() values resolve through the
     *    COMBINED var map (a site redeclaration of a vendor token wins).
     *  - A site is genuinely DARK only when the CHOSEN source is itself dark;
     *    then surfaces stay dark, text is forced light, and the dark note
     *    fires (it can no longer fire off an overlay black).
     *  - Otherwise the site is LIGHT: a candidate is accepted only if it is
     *    actually light AND not (near-)equal to the brand colour; the
     *    fallback walks body -> html -> global var -> #FFFFFF, never a grey
     *    constant, and surfaceSource reports what was chosen
     *    ('fallback:white' included).
     *  - Dark-scheme wrapper styling never flips a light site: @media
     *    (prefers-color-scheme: dark) blocks are stripped before the scan
     *    (see strip_dark_scheme_blocks) and a bare body declaration outranks
     *    qualified/ancestored ones (see body_subject_rank), so the surface
     *    reflects the site's DEFAULT render.
     *  - The low-confidence note fires ONLY when the page surface genuinely
     *    fell back to white; a missing named card var alone stays silent.
     *  - On a light surface, body text must be dark: a light detected text
     *    colour is dropped (null → derivation's dark default stands).
     */
    private static function resolve_surfaces(array $vars, string $css, string $brand, ?string $vendor_css = null, ?array $page_candidates = null): array
    {
        // The page candidates (see page_surface_candidates), computed here
        // unless extract() already computed them up front for the brand
        // resolver's dark-page gate; either way the list is identical.
        if ($page_candidates === null) $page_candidates = self::page_surface_candidates($css, $vendor_css);

        // Genuinely dark site: only the CHOSEN top-precedence source may say
        // so (see dark_page_candidate). Honour it, but keep it legible.
        $primary = self::dark_page_candidate($page_candidates);
        if ($primary !== null) {
            $named_card   = self::pick_named_var($vars, ['surface', 'card-bg', 'card', 'panel-bg'], false /* prefer dark */);
            $surface_card = ($named_card !== null && self::luminance($named_card) < 0.4)
                ? $named_card
                : self::lighten_hex($primary['hex'], 0.08);
            // Dark surfaces need light text.
            $note = __('Dark site detected, using a dark theme.', 'b360-bridge');
            return [$primary['hex'], $surface_card, '#F5F5F5', $note, $primary['source']];
        }

        // Light site: keep the first candidate that is actually light and not
        // the brand colour.
        $surface_page   = null;
        $surface_source = null;
        foreach ($page_candidates as $cand) {
            if (self::first_plausible_light([$cand['hex']], $brand) === null) continue;
            $surface_page   = $cand['hex'];
            $surface_source = $cand['source'];
            break;
        }

        $named_card   = self::pick_named_var($vars, ['surface', 'card-bg', 'card', 'panel-bg', 'white'], true);
        $surface_card = self::first_plausible_light($named_card !== null ? [$named_card] : [], $brand);

        // The note fires ONLY when the PAGE surface itself fell back: a
        // resolved body/html/:root source is a confident read, and most
        // sites never NAME a card var, so a white card stand-in alone is
        // the norm, not low confidence (the note used to fire on every
        // such site, cakebread/frogsleap included).
        $note = null;
        if ($surface_page === null) {
            // The fallback is WHITE, never a grey constant, and the note says
            // what was assumed.
            $note = __('Page background not detected, using white. Adjust on Surfaces.', 'b360-bridge');
            $surface_page   = '#FFFFFF';
            $surface_source = 'fallback:white';
        }
        if ($surface_card === null) $surface_card = '#FFFFFF';

        // Light surface → body text must be dark. Only keep a detected text
        // colour when it is genuinely dark; otherwise leave null and let the
        // derivation engine supply its dark default (never light-on-light).
        $named_text = self::pick_named_var($vars, ['text', 'body-color', 'font-color', 'foreground', 'ink'], false);
        $text_primary = ($named_text !== null && self::luminance($named_text) <= 0.4) ? $named_text : null;

        return [$surface_page, $surface_card, $text_primary, $note, $surface_source];
    }

    /**
     * First candidate that is a plausible LIGHT surface: light enough
     * (luminance >= SURFACE_LIGHT_MIN) and not (near-)equal to the brand colour
     * (a near-1:1 contrast means it IS the brand). Null when none qualify.
     */
    private static function first_plausible_light(array $candidates, string $brand): ?string
    {
        foreach ($candidates as $hex) {
            if (!is_string($hex) || $hex === '') continue;
            if (self::luminance($hex) < self::SURFACE_LIGHT_MIN) continue;
            if (self::contrast_ratio($hex, $brand) < 1.3) continue;   // ~ equals brand
            return $hex;
        }
        return null;
    }

    /** Append a non-empty note to a notes list. */
    private static function merge_notes(array $notes, ?string $extra): array
    {
        if (is_string($extra) && $extra !== '') $notes[] = $extra;
        return $notes;
    }

    // --------------------------------------------------------------------- //
    //  URL helpers                                                          //
    // --------------------------------------------------------------------- //

    /** scheme://host[:port] of a URL, lowercased. '' when unparseable. */
    private static function origin_of(string $url): string
    {
        $p = wp_parse_url($url);
        if (!is_array($p) || empty($p['host'])) return '';
        $scheme = isset($p['scheme']) ? strtolower($p['scheme']) : 'https';
        $host   = strtolower($p['host']);
        $port   = isset($p['port']) ? ':' . $p['port'] : '';
        return $scheme . '://' . $host . $port;
    }

    /**
     * Normalise + shape-validate a caller-supplied URL. Returns an absolute
     * http(s) URL with a real (dotted, or IP-literal, or bracketed-v6) host, or
     * null when the input isn't a plausible absolute URL. Runs BEFORE
     * esc_url_raw() because esc_url_raw('not-a-url') → 'http://not-a-url' would
     * otherwise pass a bare `^https?://` check.
     */
    private static function normalize_input_url(string $raw): ?string
    {
        $candidate = preg_match('#^https?://#i', $raw) ? $raw : 'https://' . ltrim($raw, '/');
        if (filter_var($candidate, FILTER_VALIDATE_URL) === false) return null;
        $host = (string) (wp_parse_url($candidate, PHP_URL_HOST) ?: '');
        if ($host === '') return null;
        $host = trim($host, '[]');
        $plausible = strpos($host, '.') !== false               // dotted hostname / IPv4
            || strpos($host, ':') !== false                     // IPv6 literal
            || filter_var($host, FILTER_VALIDATE_IP) !== false; // bare IP
        return $plausible ? $candidate : null;
    }

    /**
     * SSRF host allow-check: true = BLOCK. Resolves the URL's host to IP(s),
     * BOTH A (IPv4) and AAAA (IPv6) records, and rejects the host if ANY
     * resolved address falls in a private / loopback / link-local / reserved
     * range. This exists because WP core's wp_http_validate_url() does NOT block
     * link-local 169.254.0.0/16 (cloud instance-metadata), CGNAT, or several
     * other non-public ranges, so it alone can't stop a metadata fetch.
     *
     * Both address families are checked because a hostname can carry a public A
     * record AND an internal AAAA record (e.g. AAAA → ::1 / ::ffff:169.254.169.254);
     * curl/Requests may then connect over IPv6 (happy-eyeballs) to the internal
     * address even though the A record looked safe. Checking only A records
     * would leave that bypass open.
     *
     * Fails CLOSED: an unparseable host, or one that resolves to no usable A or
     * AAAA record, is blocked (rare for a real winery site, which resolves to
     * public addresses).
     */
    private static function host_is_blocked(string $url): bool
    {
        $host = (string) (wp_parse_url($url, PHP_URL_HOST) ?: '');
        if ($host === '') return true;
        $host = trim($host, '[]');   // unwrap bracketed IPv6 literal

        // An IP literal is checked directly, no DNS.
        if (filter_var($host, FILTER_VALIDATE_IP) !== false) {
            return self::ip_is_blocked($host);
        }

        $ips = [];

        // A records (IPv4). gethostbynamel returns all A records, or false.
        $v4 = gethostbynamel($host);
        if (is_array($v4)) $ips = array_merge($ips, $v4);

        // AAAA records (IPv6). dns_get_record can be slow or unavailable on some
        // hosts and emits warnings on failure, so call it defensively; a false /
        // empty result just contributes no v6 addresses.
        $aaaa = @dns_get_record($host, DNS_AAAA);
        if (is_array($aaaa)) {
            foreach ($aaaa as $rec) {
                if (isset($rec['ipv6']) && is_string($rec['ipv6']) && $rec['ipv6'] !== '') {
                    $ips[] = $rec['ipv6'];
                }
            }
        }

        if (empty($ips)) return true;   // no usable A or AAAA record → fail closed

        foreach ($ips as $ip) {
            if (self::ip_is_blocked($ip)) return true;
        }
        return false;
    }

    /**
     * True ONLY for a hostname with a CLEAN no-records DNS answer (NXDOMAIN
     * or an empty zone over BOTH A and AAAA): the "typo'd domain" case that
     * deserves a friendly not-found message instead of the private-network
     * guard copy. This NEVER weakens the SSRF gate: host_is_blocked() stays
     * the security decision and still fails closed on no records; this only
     * refines the ERROR COPY for an already-blocked host. Fails CLOSED
     * itself: an IP literal, a resolver error (false from dns_get_record),
     * or ANY records at all (even non-address ones) report false, keeping
     * the guard copy.
     */
    private static function host_is_unresolvable(string $url): bool
    {
        $host = (string) (wp_parse_url($url, PHP_URL_HOST) ?: '');
        if ($host === '') return false;
        $host = trim($host, '[]');
        // An IP literal never "fails to resolve": its block is a range block.
        if (filter_var($host, FILTER_VALIDATE_IP) !== false) return false;
        $a    = @dns_get_record($host, DNS_A);
        $aaaa = @dns_get_record($host, DNS_AAAA);
        return self::dns_answers_show_no_records($a, $aaaa);
    }

    /**
     * Pure classifier over the two DNS answers: true ONLY when BOTH lookups
     * ANSWERED (arrays, not false) and both came back with zero records.
     * SECURITY INVARIANT (fail closed): a resolver error mid-way (false on
     * either side) or any record at all never reads as not-found, the
     * caller then keeps the blocked branch.
     *
     * @param array|false $a    dns_get_record($host, DNS_A) result
     * @param array|false $aaaa dns_get_record($host, DNS_AAAA) result
     */
    private static function dns_answers_show_no_records($a, $aaaa): bool
    {
        return is_array($a) && is_array($aaaa) && count($a) === 0 && count($aaaa) === 0;
    }

    /** True when an IP (v4 or v6) is in a private / loopback / reserved range. */
    private static function ip_is_blocked(string $ip): bool
    {
        if (strpos($ip, ':') !== false) {
            return self::ipv6_is_blocked($ip);
        }
        $long = ip2long($ip);
        if ($long === false) return true;
        // Assumes a 64-bit PHP build: 0xFFFFFFFF is an int here, so the bit ops
        // below stay integer. On a 32-bit build it would be a float and the mask
        // math would be unreliable, fine on the php84 container and any real
        // modern host, none of which are 32-bit.
        $long &= 0xFFFFFFFF;

        // [network, prefix-bits]. Link-local 169.254/16 and CGNAT 100.64/10 are
        // the notable ones core's validator omits.
        $ranges = [
            ['0.0.0.0',      8],   // "this" network
            ['10.0.0.0',     8],   // RFC1918
            ['100.64.0.0',  10],   // CGNAT
            ['127.0.0.0',    8],   // loopback
            ['169.254.0.0', 16],   // link-local / cloud metadata
            ['172.16.0.0',  12],   // RFC1918
            ['192.0.0.0',   24],   // IETF protocol assignments
            ['192.88.99.0', 24],   // 6to4 anycast relay
            ['192.168.0.0', 16],   // RFC1918
            ['198.18.0.0',  15],   // benchmarking
            ['224.0.0.0',    4],   // multicast
            ['240.0.0.0',    4],   // future-use / reserved
            ['255.255.255.255', 32], // limited broadcast
        ];
        foreach ($ranges as $range) {
            [$net, $bits] = $range;
            $netlong = ip2long($net) & 0xFFFFFFFF;
            // /0 → mask 0; /32 → all-ones. 0xFFFFFFFF is an int on 64-bit PHP
            // (see note above), keeping this shift/AND integer-exact.
            $mask = $bits === 0 ? 0 : ((0xFFFFFFFF << (32 - $bits)) & 0xFFFFFFFF);
            if (($long & $mask) === ($netlong & $mask)) return true;
        }
        return false;
    }

    /** True when an IPv6 address is loopback / link-local / ULA / mapped-private. */
    private static function ipv6_is_blocked(string $ip): bool
    {
        $bin = @inet_pton($ip);
        if ($bin === false || strlen($bin) !== 16) return true;

        if ($bin === str_repeat("\0", 16)) return true;                 // ::
        if ($bin === str_repeat("\0", 15) . "\x01") return true;        // ::1

        $b0 = ord($bin[0]);
        $b1 = ord($bin[1]);
        if ($b0 === 0xFE && ($b1 & 0xC0) === 0x80) return true;         // fe80::/10 link-local
        if (($b0 & 0xFE) === 0xFC) return true;                         // fc00::/7 ULA

        // ::ffff:a.b.c.d, IPv4-mapped: re-check the embedded IPv4.
        if (substr($bin, 0, 10) === str_repeat("\0", 10)
            && ord($bin[10]) === 0xFF && ord($bin[11]) === 0xFF) {
            $v4 = inet_ntop(substr($bin, 12, 4));
            if (is_string($v4)) return self::ip_is_blocked($v4);
        }
        return false;
    }

    /** Resolve a possibly-relative href against a base URL. */
    private static function absolute_url(string $href, string $base): string
    {
        $href = trim($href);
        if ($href === '') return '';
        if (preg_match('#^https?://#i', $href)) return esc_url_raw($href);
        if (strpos($href, '//') === 0) {
            $scheme = wp_parse_url($base, PHP_URL_SCHEME) ?: 'https';
            return esc_url_raw($scheme . ':' . $href);
        }
        $origin = self::origin_of($base);
        if ($origin === '') return '';
        if (strpos($href, '/') === 0) {
            return esc_url_raw($origin . $href);
        }
        // Relative to the base path's directory.
        $path = (string) (wp_parse_url($base, PHP_URL_PATH) ?: '/');
        $slash = strrpos($path, '/');
        $dir  = $slash !== false ? substr($path, 0, $slash + 1) : '/';
        if ($dir === '') $dir = '/';
        return esc_url_raw($origin . $dir . $href);
    }

    /**
     * True when two URLs' hosts belong to the same site: equal after a
     * leading-www strip, or one is a dot-bounded suffix of the other (an
     * apex -> www or apex -> shop.host hop stays same-site). A cheap
     * registrable-domain approximation on the existing post-redirect data,
     * used only to NOTE a cross-site redirect, never to block. Unparseable
     * hosts read as same-site so the note stays silent rather than crying
     * wolf.
     */
    private static function hosts_are_same_site(string $a, string $b): bool
    {
        $ha = strtolower((string) (wp_parse_url($a, PHP_URL_HOST) ?: ''));
        $hb = strtolower((string) (wp_parse_url($b, PHP_URL_HOST) ?: ''));
        $ha_stripped = preg_replace('/^www\./', '', $ha);
        $hb_stripped = preg_replace('/^www\./', '', $hb);
        if (is_string($ha_stripped)) $ha = $ha_stripped;
        if (is_string($hb_stripped)) $hb = $hb_stripped;
        // An FQDN trailing dot (`example.com.`) names the same host.
        $ha = rtrim($ha, '.');
        $hb = rtrim($hb, '.');
        if ($ha === '' || $hb === '') return true;
        if ($ha === $hb) return true;
        if (substr($ha, -(strlen($hb) + 1)) === '.' . $hb) return true;
        if (substr($hb, -(strlen($ha) + 1)) === '.' . $ha) return true;
        return false;
    }

    /** A friendly theme name from the host, e.g. "Bjornson Wine". */
    private static function brand_name(string $url): string
    {
        $host = (string) (wp_parse_url($url, PHP_URL_HOST) ?: '');
        $host = preg_replace('/^www\./', '', strtolower($host));
        $label = explode('.', $host)[0] ?? $host;
        $label = str_replace(['-', '_'], ' ', $label);
        $label = trim($label);
        if ($label === '') return 'Matched theme';
        return ucwords($label);
    }
}
