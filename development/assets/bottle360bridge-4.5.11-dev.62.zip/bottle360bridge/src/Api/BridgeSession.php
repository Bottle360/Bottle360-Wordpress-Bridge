<?php

namespace Bottle360\Bridge\Api;

if (!defined('ABSPATH')) exit;

/**
 * Manages the bridge API session token.
 *
 * The token is stored in a first-party cookie rather than a PHP $_SESSION.
 * This is the only approach that works reliably on managed WordPress hosts
 * (WP Engine, Kinsta, Pantheon) where PHP sessions are unsupported or behave
 * unpredictably behind Varnish / multi-server backends.
 *
 * Token lifecycle:
 * - Guest: BridgeApiClient calls initGuest() lazily before session-required
 *   routes, rather than blanket-minting on every REST request.
 * - Login: calls auth/login, replaces the guest token with a user token
 * - Logout: calls auth/logout, clears both cookies
 *
 * Cookie properties:
 * - HttpOnly         : not readable from JS; XSS can't exfiltrate
 * - Secure           : HTTPS only (when served over HTTPS)
 * - SameSite=Lax     : blocks cross-site POSTs while keeping normal navigation
 * - Path=/           : so subpath REST requests all carry it
 */
final class BridgeSession
{
    /**
     * Cookie names use the `wordpress_` prefix for a specific reason:
     *
     * WP Engine (and similar Varnish-fronted managed hosts) strip ALL incoming
     * cookies from requests unless AT LEAST ONE cookie name matches their
     * passthrough allowlist. That allowlist includes `wordpress_*`,
     * `wp_woocommerce_session_*`, and `comment_author_*` among others.
     *
     * Custom cookies like `b360_bridge_token` get silently stripped; PHP
     * then sees an empty $_COOKIE, mints a fresh guest token on every REST
     * request, and the user's real session is invisible. Using the
     * `wordpress_` prefix keeps our cookies visible to PHP.
     */
    private const TOKEN_COOKIE = 'wordpress_b360_token';
    private const AUTH_COOKIE  = 'wordpress_b360_auth';
    /**
     * JS-readable "a bridge session exists" marker (value '1'), written and
     * cleared alongside the httponly token cookie. The SPA reads it on boot to
     * SKIP the cart fetch for a visitor who has no session yet (their cart is
     * empty by definition): one fewer PHP request per page view for every
     * first-time visitor, which is exactly the crowd an email blast brings.
     * Never trusted server-side; the token cookie remains the only truth.
     */
    private const SESSION_MARKER_COOKIE = 'wordpress_b360_sess';
    /**
     * STANDARD-NAMED logged-in marker (value '1', no secret). Every managed
     * host / page-cache product (WP Engine, NitroPack, WP Rocket, Cloudflare
     * APO…) treats a `wordpress_logged_in_*` cookie as "logged-in user, do
     * not serve from cache" out of the box; none of them know our
     * `wordpress_b360_*` names. Moshin 2026-08-17: authenticated account
     * responses were edge-cached and served cross-user because our sessions
     * looked anonymous to three cache layers. This cookie makes the default
     * exclusions fire with zero host configuration. Written/cleared exactly
     * with the auth marker; never read by us. It does not collide with WP
     * core's own cookie (that one is `wordpress_logged_in_` + COOKIEHASH, an
     * md5, never "b360").
     */
    private const LOGGED_IN_MARKER_COOKIE = 'wordpress_logged_in_b360';

    /** Legacy names, kept only for the clearToken call so stale cookies get wiped. */
    private const LEGACY_COOKIES = ['b360_bridge_token', 'b360_bridge_auth'];

    /** Default fallback lifetime when the API doesn't return expires_at (24h). */
    private const DEFAULT_LIFETIME = 86400;

    /**
     * In-request overlay: the token/expires we've written this request, so
     * subsequent getToken() calls in the SAME request return the new value
     * before the browser has roundtripped back.
     */
    private static ?string $pendingToken = null;
    private static int     $pendingExpires = 0;

    /**
     * Register any WordPress hooks needed by this component.
     *
     * PR-2 change: the blanket `rest_api_init` → `ensureSession` hook has been
     * removed. Guest tokens are now minted lazily by BridgeApiClient::get() /
     * post() only for routes flagged `requires_session: true` in RouteMetadata.
     * Pure catalog routes (catalog/categories, catalog/products, etc.) no longer
     * trigger a mint on every REST request.
     */
    public function register(): void
    {
        // No blanket mint on rest_api_init; lazy minting is handled per-route
        // in BridgeApiClient. If this method needs future hooks, add them here.
    }

    /**
     * Ensure we have a valid bridge token. If the cookie is missing or
     * expired, request a fresh guest token from the admin bridge.
     *
     * Called as an instance method by the legacy hook path (tests, etc.) and
     * indirectly by initGuest(). After PR-2, BridgeApiClient calls initGuest()
     * directly; this method is kept for backward compatibility.
     */
    public function ensureSession(): void
    {
        $token = self::getToken();

        if ($token === '' || self::isExpired()) {
            $this->initGuestSession();
        }
    }

    /**
     * Public static entry point for lazy guest-token minting.
     *
     * BridgeApiClient::get() and BridgeApiClient::post() call this before
     * dispatching any request to a route where RouteMetadata::requiresSession()
     * returns true and no valid token is currently present.
     *
     * Delegates to the private initGuestSession() instance method via a
     * transient instance so we don't need to thread a singleton through the
     * class. The instance is ephemeral; only the static token state ($pendingToken,
     * $pendingExpires, $_COOKIE) persists across calls.
     */
    public static function initGuest(): void
    {
        (new self())->initGuestSession();
    }

    private function initGuestSession(): void
    {
        $result = BridgeApiClient::instance()->post('default/initSession');

        if ($result['ok'] && isset($result['data']['token'])) {
            self::setToken(
                (string) $result['data']['token'],
                (string) ($result['data']['expires_at'] ?? '')
            );
        }
    }

    public static function getToken(): string
    {
        if (self::$pendingToken !== null) {
            return self::$pendingToken;
        }
        return trim((string) ($_COOKIE[self::TOKEN_COOKIE] ?? ''));
    }

    public static function setToken(string $token, string $expiresAt = ''): void
    {
        $expireUnix = 0;
        if ($expiresAt !== '') {
            $parsed = strtotime($expiresAt);
            if ($parsed !== false) {
                $expireUnix = $parsed;
            }
        }
        if ($expireUnix <= time()) {
            $expireUnix = time() + self::DEFAULT_LIFETIME;
        }

        self::$pendingToken   = $token;
        self::$pendingExpires = $expireUnix;
        $_COOKIE[self::TOKEN_COOKIE] = $token;

        self::writeCookie(self::TOKEN_COOKIE, $token, $expireUnix, true);
        $_COOKIE[self::SESSION_MARKER_COOKIE] = '1';
        self::writeCookie(self::SESSION_MARKER_COOKIE, '1', $expireUnix, false);
        // Any bridge session (guest cart included) is per-person: the
        // standard-named marker makes cookie-blind page/edge caches bypass for
        // this visitor too, not only after login. First-time anonymous visitors
        // hold no session (fan-out 4→0), so public pages stay cacheable.
        $_COOKIE[self::LOGGED_IN_MARKER_COOKIE] = '1';
        self::writeCookie(self::LOGGED_IN_MARKER_COOKIE, '1', $expireUnix, true);
    }

    public static function clearToken(): void
    {
        self::$pendingToken   = '';
        self::$pendingExpires = 0;
        unset($_COOKIE[self::TOKEN_COOKIE], $_COOKIE[self::AUTH_COOKIE], $_COOKIE[self::SESSION_MARKER_COOKIE],
            $_COOKIE[self::LOGGED_IN_MARKER_COOKIE]);

        self::writeCookie(self::TOKEN_COOKIE, '', time() - 3600, true);
        self::writeCookie(self::AUTH_COOKIE,  '', time() - 3600, false);
        self::writeCookie(self::SESSION_MARKER_COOKIE, '', time() - 3600, false);
        self::writeCookie(self::LOGGED_IN_MARKER_COOKIE, '', time() - 3600, true);

        // Sweep any legacy-named cookies from previous plugin versions.
        foreach (self::LEGACY_COOKIES as $legacy) {
            unset($_COOKIE[$legacy]);
            self::writeCookie($legacy, '', time() - 3600, true);
        }
    }

    public static function hasToken(): bool
    {
        return self::getToken() !== '' && !self::isExpired();
    }

    /**
     * Mark the session as belonging to an authenticated (logged-in) user.
     * The auth cookie is NOT httponly; JS reads it to render the correct
     * nav state without a round trip.
     *
     * Its expiry tracks the bridge token's expiry, so the two cookies can't
     * drift out of sync and leave the UI thinking it's authenticated with
     * no valid token behind it.
     */
    public static function setAuthenticated(bool $auth): void
    {
        if ($auth) {
            $expire = self::$pendingExpires > 0
                ? self::$pendingExpires
                : time() + self::DEFAULT_LIFETIME;
            $_COOKIE[self::AUTH_COOKIE] = '1';
            self::writeCookie(self::AUTH_COOKIE, '1', $expire, false);
            $_COOKIE[self::LOGGED_IN_MARKER_COOKIE] = '1';
            self::writeCookie(self::LOGGED_IN_MARKER_COOKIE, '1', $expire, true);
        } else {
            unset($_COOKIE[self::AUTH_COOKIE], $_COOKIE[self::LOGGED_IN_MARKER_COOKIE]);
            self::writeCookie(self::AUTH_COOKIE, '', time() - 3600, false);
            self::writeCookie(self::LOGGED_IN_MARKER_COOKIE, '', time() - 3600, true);
        }
    }

    /**
     * Authenticated iff the auth marker AND a live bridge token are both
     * present. Without this, a dangling auth cookie (token expired, marker
     * didn't) would let the frontend treat the user as logged in until the
     * next API call 401s, the "session invalid but doesn't clear" symptom.
     */
    public static function isAuthenticated(): bool
    {
        if (empty($_COOKIE[self::AUTH_COOKIE])) return false;
        return self::hasToken();
    }

    private static function isExpired(): bool
    {
        if (self::$pendingExpires > 0) {
            return self::$pendingExpires <= time();
        }
        // Browsers drop expired cookies automatically, so the presence of the
        // cookie implies it's still valid from their perspective. Trust that;
        // the admin site will 401 otherwise and we retry with a fresh token.
        return false;
    }

    private static function writeCookie(string $name, string $value, int $expires, bool $httpOnly): void
    {
        if (headers_sent($file, $line)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log("[B360Bridge] cannot set {$name} cookie; headers already sent at {$file}:{$line}");
            }
            return;
        }

        setcookie($name, $value, [
            'expires'  => $expires,
            'path'     => defined('COOKIEPATH') && COOKIEPATH ? COOKIEPATH : '/',
            'domain'   => defined('COOKIE_DOMAIN') ? COOKIE_DOMAIN : '',
            'secure'   => is_ssl(),
            'httponly' => $httpOnly,
            'samesite' => 'Lax',
        ]);
    }
}
