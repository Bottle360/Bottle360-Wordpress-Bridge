<?php

namespace Bottle360\Bridge\Api;

use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * Central HTTP client for the Bridge API.
 *
 * All plugin code that needs to talk to the admin site's bridge module
 * should use this class instead of RemoteStore, Http\Client, or direct
 * wp_remote_* calls.
 *
 * Handles:
 * - Bridge client auth headers (X-Bridge-Client-Id / X-Bridge-Client-Secret)
 * - Bearer token for customer sessions (via BridgeSession)
 * - JSON request/response handling
 * - Transient caching for catalog data
 * - Typed 401 recovery via maybeRecover401 (four-code taxonomy)
 * - Lazy per-route session minting (replaces blanket rest_api_init mint)
 */
final class BridgeApiClient
{
    private static ?self $instance = null;

    /**
     * Bridge routes behind core's card-vault gate (BD-4524). A 401
     * login_required from one of these is the vault refusing an unverified
     * account, NOT a sign-out; maybeRecover401 must leave the auth flag alone
     * (4.5.9). Mirrored in shared/api/client.ts (VAULT_GATE_PATHS) and
     * shared/api/ss/embedSession.ts (VAULT_GATE_ROUTES).
     */
    private const VAULT_GATE_ROUTES = [
        'payment/savedCards',
        'payment/addCard',
        'payment/deleteCard',
        'club/join',
    ];

    public static function instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Whether the plugin has the minimum config needed to talk to the admin.
     */
    private function isConfigured(): bool
    {
        return Options::get_base_host()              !== ''
            && Options::get_bridge_client_id()     !== ''
            && Options::get_bridge_client_secret() !== '';
    }

    /**
     * Standard "not configured" error envelope matching parseResponse's shape
     * so callers don't need a special path.
     */
    private function notConfiguredResult(): array
    {
        return [
            'ok'            => false,
            'status'        => 503,
            'data'          => null,
            'meta'          => null,
            'error'         => 'The store plugin is not configured. Please contact the site administrator.',
            'error_code'    => 'BRIDGE_NOT_CONFIGURED',
            'error_context' => null,
        ];
    }

    /**
     * GET request to bridge API.
     *
     * @param string $route  e.g. 'catalog/products'
     * @param array  $params Query string params
     * @param array  $opts   Options: 'token' => bearer token, 'cache' => seconds (0 = no cache)
     * @return array{ok: bool, status: int, data: mixed, error: ?string}
     */
    public function get(string $route, array $params = [], array $opts = []): array
    {
        if (!$this->isConfigured()) {
            return $this->notConfiguredResult();
        }

        // Lazy per-route minting: only mint a guest token when the route
        // actually requires one. Catalog/public routes never trigger a mint.
        if (RouteMetadata::requiresSession($route) && !BridgeSession::hasToken()) {
            BridgeSession::initGuest();
        }

        $url = $this->buildUrl($route, $params);
        $cacheKey = '';

        // Check transient cache
        $cacheTtl = (int) ($opts['cache'] ?? 0);
        if ($cacheTtl > 0 && !Options::is_cache_disabled()) {
            $cacheKey = 'b360_api_' . md5($url);
            $cached = get_transient($cacheKey);
            if ($cached !== false) {
                return $cached;
            }
        }

        // Last-known-good copy (stale-while-error). Only for responses that
        // don't depend on WHO is asking: no bearer/session on the call and no
        // per-viewer payload (responseVariesByViewer). Written on every
        // successful GET (even cache=0 routes), read only when upstream is
        // failing or the breaker is open, never as a freshness shortcut.
        // Keyed by ROUTE + params (not the full URL): last-known-good must
        // survive an admin base-host change (failover / DNS move), the
        // exact moment it is needed most.
        $staleKey = $this->staleEligible($route, $opts)
            ? 'b360_api_stale_' . md5(ltrim($route, '/') . '?' . http_build_query($params))
            : '';

        // UpstreamGuard: fail fast (no socket) when the breaker is open or this
        // request's upstream budget is spent, serving stale where we can.
        if (UpstreamGuard::shouldFailFast($route)) {
            $stale = $staleKey !== '' ? get_transient($staleKey) : false;
            if (is_array($stale)) {
                $stale['stale'] = true;
                return $stale;
            }
            $ff = UpstreamGuard::failFastResult($route);
            ApiErrorLog::log('GET', $url, $ff['status'], $ff['error_code'], '');
            return $ff;
        }

        $t0 = microtime(true);
        $response = wp_remote_get($url, [
            'timeout'     => isset($opts['timeout']) ? (int) $opts['timeout'] : UpstreamGuard::timeoutFor('GET', $route),
            'redirection' => 0,
            'headers'     => $this->buildHeaders($opts),
        ]);
        $wpRemoteMs = (int) round((microtime(true) - $t0) * 1000);

        $result = $this->parseResponse($response);
        $result['timing'] = $this->extractTiming($response, $wpRemoteMs);
        UpstreamGuard::record(UpstreamGuard::isUpstreamFailure($result), $wpRemoteMs);

        // Upstream down/slow → last-known-good beats an error page for
        // viewer-independent GETs (catalog, categories, club lists…).
        if (!$result['ok'] && $staleKey !== '' && UpstreamGuard::isUpstreamFailure($result)) {
            $stale = get_transient($staleKey);
            if (is_array($stale)) {
                ApiErrorLog::log('GET', $url, $result['status'], ($result['error'] ?? 'upstream failure') . ', served stale copy', '');
                $stale['stale'] = true;
                return $stale;
            }
        }

        $result = $this->maybeRecover401(
            $result,
            $route,
            $opts,
            function () use ($route, $params, $opts) {
                return $this->retryWithFreshGuestToken('GET', $route, $params, [], $opts);
            }
        );

        if (!$result['ok']) {
            ApiErrorLog::log('GET', $url, $result['status'], $result['error'] ?? 'Unknown error', is_wp_error($response) ? '' : wp_remote_retrieve_body($response));
        }

        // Cache successful GET responses, EXCEPT ones whose payload varies by
        // viewer. A secure SKU carries a per-viewer `locked` flag (membership/
        // group access), but the transient key is URL-only (no bearer/viewer
        // component), so caching it would serve one viewer's `locked` to
        // another. The dangerous direction is a guest-warmed cache pinning an
        // entitled member into the "locked" dead-end, i.e. the exact bug this
        // whole feature exists to fix. The set of secure SKUs in a response is
        // viewer-independent (only the `locked` VALUE differs), so presence of
        // any secure SKU reliably marks the response as un-cacheable. Non-secure
        // catalog (the overwhelming majority) still caches normally.
        if ($result['ok'] && $cacheKey !== '' && !$this->responseVariesByViewer($result)) {
            set_transient($cacheKey, $result, $cacheTtl);
        }
        if ($result['ok'] && $staleKey !== '' && !$this->responseVariesByViewer($result)) {
            set_transient($staleKey, $result, (int) apply_filters('b360_bridge_stale_ttl', 12 * HOUR_IN_SECONDS));
        }

        return $result;
    }

    /**
     * A GET may keep a last-known-good copy only when nothing about the
     * answer depends on the caller: no bearer token passed, no session-scoped
     * route (cart/checkout/profile…), and (checked at write time) no
     * per-viewer payload. Everything else is per-person and never stale-served.
     */
    private function staleEligible(string $route, array $opts): bool
    {
        if (!empty($opts['token'])) {
            return false;
        }
        if (RouteMetadata::requiresSession($route)) {
            return false;
        }
        // ALLOWLIST, not "everything that isn't session-scoped": a route that
        // is missing from RouteMetadata reads as session-free (fail-open), and
        // the stale key has no viewer component, so only routes that are
        // shared data by construction may ever be stale-served.
        $route = ltrim($route, '/');
        $shared = strpos($route, 'catalog/') === 0
            || $route === 'form/get'
            || strpos($route, 'default/') === 0;
        return (bool) apply_filters('b360_bridge_stale_eligible', $shared, $route);
    }

    /**
     * Whether a successful GET response carries per-viewer state and so must
     * not be written to the URL-keyed transient cache.
     *
     * Today the only such state is a secure SKU's per-viewer `locked` flag, so
     * we scan the payload for any truthy `secure_sku`. The scan is a bounded
     * recursive walk of the decoded `data` (catalog payloads, product lists,
     * single products, categories, are small); it short-circuits on the first
     * hit. Kept content-based (not route-based) so any future per-viewer field
     * on a cached route is covered as long as it rides alongside `secure_sku`,
     * and so non-secure catalog keeps its full cache benefit.
     *
     * @param array $result parseResponse envelope
     * @return bool
     */
    private function responseVariesByViewer(array $result): bool
    {
        $data = isset($result['data']) ? $result['data'] : null;
        if (!is_array($data)) {
            return false;
        }
        return $this->hasSecureSku($data);
    }

    /**
     * Recursively scan a decoded array for a truthy `secure_sku` entry.
     *
     * @param array $node
     * @return bool
     */
    private function hasSecureSku(array $node): bool
    {
        foreach ($node as $key => $value) {
            // secure_sku marks a per-viewer product; a category-level lock
            // (locked / lock_message, admin CatalogService) is per-viewer too.
            if (($key === 'secure_sku' || $key === 'locked') && $value) {
                return true;
            }
            if (is_array($value) && $this->hasSecureSku($value)) {
                return true;
            }
        }
        return false;
    }

    /**
     * POST request to bridge API.
     *
     * @param string $route e.g. 'auth/login'
     * @param array  $body  JSON body
     * @param array  $opts  Options: 'token' => bearer token
     * @return array{ok: bool, status: int, data: mixed, error: ?string}
     */
    public function post(string $route, array $body = [], array $opts = []): array
    {
        if (!$this->isConfigured()) {
            return $this->notConfiguredResult();
        }

        // Lazy per-route minting, same logic as get().
        if (RouteMetadata::requiresSession($route) && !BridgeSession::hasToken()) {
            BridgeSession::initGuest();
        }

        $url = $this->buildUrl($route);

        // UpstreamGuard: breaker open / budget spent → fail fast (payment
        // routes are exempt, see UpstreamGuard::isPaymentRoute).
        if (UpstreamGuard::shouldFailFast($route)) {
            $ff = UpstreamGuard::failFastResult($route);
            ApiErrorLog::log('POST', $url, $ff['status'], $ff['error_code'], '');
            return $ff;
        }

        $t0 = microtime(true);
        $response = wp_remote_post($url, [
            'timeout'     => isset($opts['timeout']) ? (int) $opts['timeout'] : UpstreamGuard::timeoutFor('POST', $route),
            'redirection' => 0,
            'headers'     => array_merge($this->buildHeaders($opts), [
                'Content-Type' => 'application/json',
            ]),
            'body'        => wp_json_encode($body),
        ]);
        $wpRemoteMs = (int) round((microtime(true) - $t0) * 1000);

        $result = $this->parseResponse($response);
        $result['timing'] = $this->extractTiming($response, $wpRemoteMs);
        UpstreamGuard::record(UpstreamGuard::isUpstreamFailure($result), $wpRemoteMs);

        $result = $this->maybeRecover401(
            $result,
            $route,
            $opts,
            function () use ($route, $body, $opts) {
                return $this->retryWithFreshGuestToken('POST', $route, [], $body, $opts);
            }
        );

        if (!$result['ok']) {
            ApiErrorLog::log('POST', $url, $result['status'], $result['error'] ?? 'Unknown error', is_wp_error($response) ? '' : wp_remote_retrieve_body($response));
        }

        return $result;
    }

    /**
     * Decide what to do with a 401. Switches on the typed taxonomy code emitted
     * directly by the bridge (PR 3+). Legacy adapter (mapLegacyAuthCodes) removed
     * in PR 6, the bridge now emits only the four-code taxonomy.
     *
     * ============================================================
     * INVARIANT (DO NOT REGRESS): a request dispatched on behalf of
     * an authenticated user MUST NOT be silently replaced with a
     * guest-token retry. Doing so wipes the user's cart, checkout
     * state, addresses, and order context, and has broken production
     * twice. The typed taxonomy makes this invariant explicit in code:
     * user_session_expired clears token + auth flag; session_dead on a
     * non-retry route propagates; neither silently downgrades auth.
     * ============================================================
     *
     * Four-code taxonomy reactions:
     *   client_auth_failed   , bad plugin config → log + return 500/BRIDGE_NOT_CONFIGURED
     *   session_dead         , no/unknown guest token → clear; retry if route allows it
     *   login_required       , valid token but guest hitting authed route → keep token, clear auth flag
     *   user_session_expired , authed token gone → clear token + auth flag, propagate
     *
     * @param array    $result  Result envelope from parseResponse.
     * @param string   $route   Original route (for route-metadata lookups).
     * @param array    $opts    Original call opts (unused post-refactor; kept for callsite compat).
     * @param callable $retry   Thunk that performs the guest-mint + retry.
     * @return array
     */
    private function maybeRecover401(array $result, string $route, array $opts, callable $retry): array
    {
        if ($result['status'] !== 401) {
            return $result;
        }

        $code = $result['error_code'] ?? '';

        switch ($code) {
            case 'client_auth_failed':
                ApiErrorLog::log('CONFIG', $route, 401, 'Bridge client auth failed, check plugin settings (X-Bridge-Client-Id / X-Bridge-Client-Secret)');
                $result['status']     = 500;
                $result['error_code'] = 'BRIDGE_NOT_CONFIGURED';
                $result['error']      = 'The store plugin is not configured. Please contact the site administrator.';
                return $result;

            case 'session_dead':
                // If our local flag says the user WAS logged in, the bridge's
                // "session_dead" means their token row was GC'd or explicitly
                // deleted server-side (e.g. password change, logout on another
                // device). Upgrade to user_session_expired so the frontend
                // clears identity and shows the expired toast, rather than
                // silently treating an authenticated user as a fresh guest.
                //
                // This is the permanent Option Light discriminator: without
                // server-side tombstones we use the plugin's local auth flag
                // as the fallback signal. PR 6 does NOT delete this block.
                if (BridgeSession::isAuthenticated()) {
                    BridgeSession::setAuthenticated(false);
                    BridgeSession::clearToken();
                    BridgeSession::initGuest();
                    $result['error_code'] = 'user_session_expired';
                    return $result;
                }
                // No valid token on the server. Clear the stale local token so
                // the next request can mint fresh. If the route permits a
                // mint-and-retry, do it exactly once.
                BridgeSession::clearToken();
                if (RouteMetadata::retryOnSessionDead($route)) {
                    $retried = $retry();
                    if ($retried !== null) {
                        return $retried;
                    }
                }
                return $result;

            case 'user_session_expired':
                // The user's token is gone. Clear auth state and mint a fresh
                // guest token so the next request has something to send,
                // otherwise a session-expired customer eats two sequential 401s
                // (this one, then a session_dead on the next call because the
                // lazy-mint only fires for routes flagged requires_session).
                BridgeSession::setAuthenticated(false);
                BridgeSession::clearToken();
                BridgeSession::initGuest();
                return $result;

            case 'login_required':
                // Vault gate (4.5.9 hotfix): core's card vault (BD-4524,
                // AuthService::isClaimedForVault) answers login_required for a
                // SIGNED-IN account whose password_set_at is NULL with no charged
                // order, i.e. every account created via the backend admin, POS,
                // legacy storefront or import. The token is fine: every other
                // authed route on it returns 200. Clearing the auth flag here
                // demoted the member, they signed in again, the next card call
                // 401'd again: an endless loop. Propagate untouched so the SPA
                // can show its verify notice instead.
                if (in_array($route, self::VAULT_GATE_ROUTES, true)) {
                    return $result;
                }
                // Token is valid as a guest token, the server accepted it.
                // Only the "this user is logged in" flag is wrong. Keep the
                // token; clear only the authenticated flag. No retry, no mint.
                BridgeSession::setAuthenticated(false);
                return $result;

            case 'CHECKOUT_STEP_REQUIRED':
                // NOT an auth problem. The anon-guest checkout-scope gate emits
                // this 401 when setPayment/confirmOrder is reached before the
                // billing step is complete (billing_address_id not set). The
                // token and session are perfectly valid; the caller simply
                // skipped (or lost) the address step. Propagate it QUIETLY so
                // it reaches the SPA as an ordinary error, not an auth event:
                //   - do NOT log UNKNOWN_AUTH_CODE / a WP_DEBUG BUG line (this
                //     is an expected code, not a taxonomy regression),
                //   - do NOT call setAuthenticated(false): clearing auth here
                //     would wrongly bounce a signed-in customer to sign-in for
                //     what is really a "finish your address" response.
                return $result;

            default:
                // Unknown 401 error code reached the recovery layer. Either the bridge
                // emitted a code we don't recognize (regression in the bridge taxonomy)
                // or we've introduced a new code without wiring its handler here. Log
                // and treat as a propagation, the SPA will surface as a generic error,
                // but the log entry gives ops something to grep for.
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    error_log('[B360Bridge] BUG: maybeRecover401 saw unknown 401 code on '
                        . $route . ': ' . $code);
                }
                ApiErrorLog::log('UNKNOWN_AUTH_CODE', $route, 401, 'Unknown 401 code: ' . $code);
                return $result;
        }
    }

    /**
     * On a session_dead 401, mint a fresh guest token via initSession and
     * retry the original request exactly once with the new token.
     *
     * Returns the retried result on success, or null if recovery failed
     * (so the caller can propagate the original failure).
     *
     * Guest-cart caveat: minting a new guest token starts a fresh admin-side
     * session, so any guest cart tied to the old token is gone. This is
     * acceptable for session_dead (the old session was already dead server-side).
     *
     * @param string $method  'GET' or 'POST'
     * @param string $route   The failing route
     * @param array  $params  Query params (GET only)
     * @param array  $body    Request body (POST only)
     * @param array  $opts    Original call options
     * @return array|null
     */
    private function retryWithFreshGuestToken(string $method, string $route, array $params, array $body, array $opts): ?array
    {
        // Defense-in-depth: refuse to wipe an authenticated session via a retry.
        if (BridgeSession::isAuthenticated()) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[B360Bridge] BUG: retryWithFreshGuestToken invoked while authenticated on ' . $route . ', refusing');
            }
            return null;
        }

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[B360Bridge] session_dead on ' . $route . ', minting fresh guest token and retrying');
        }

        // Mint a fresh guest token by calling initSession directly.
        if (UpstreamGuard::shouldFailFast('default/initSession')) {
            return null;
        }
        $initUrl = $this->buildUrl('default/initSession');
        $t0 = microtime(true);
        $initResponse = wp_remote_post($initUrl, [
            'timeout'     => UpstreamGuard::timeoutFor('MINT', 'default/initSession'),
            'redirection' => 0,
            'headers'     => array_merge($this->buildClientHeaders(), [
                'Content-Type' => 'application/json',
            ]),
            'body'        => wp_json_encode([]),
        ]);

        $initResult = $this->parseResponse($initResponse);
        UpstreamGuard::record(UpstreamGuard::isUpstreamFailure($initResult), (int) round((microtime(true) - $t0) * 1000));
        if (is_wp_error($initResponse)) {
            return null;
        }
        if (!$initResult['ok'] || empty($initResult['data']['token'])) {
            return null;
        }

        BridgeSession::setToken(
            $initResult['data']['token'],
            $initResult['data']['expires_at'] ?? ''
        );

        // Retry the original request with the freshly-minted token in opts.
        $retryOpts = $opts;
        unset($retryOpts['token']); // let buildHeaders() pick up the stored token

        $t1 = microtime(true);
        if ($method === 'GET') {
            $url = $this->buildUrl($route, $params);
            $retryResponse = wp_remote_get($url, [
                'timeout'     => UpstreamGuard::timeoutFor('GET', $route),
                'redirection' => 0,
                'headers'     => $this->buildHeaders($retryOpts),
            ]);
        } else {
            $url = $this->buildUrl($route);
            $retryResponse = wp_remote_post($url, [
                'timeout'     => UpstreamGuard::timeoutFor('POST', $route),
                'redirection' => 0,
                'headers'     => array_merge($this->buildHeaders($retryOpts), [
                    'Content-Type' => 'application/json',
                ]),
                'body'        => wp_json_encode($body),
            ]);
        }

        $retryResult = $this->parseResponse($retryResponse);
        UpstreamGuard::record(UpstreamGuard::isUpstreamFailure($retryResult), (int) round((microtime(true) - $t1) * 1000));

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[B360Bridge] Retry after guest-token mint for ' . $route . ', status: ' . $retryResult['status']);
        }

        return $retryResult;
    }

    /**
     * Whether the result is already normalized to BRIDGE_NOT_CONFIGURED.
     * Used as an early-exit guard, a guest-token refresh won't help.
     */
    private function isNotConfigured(array $result): bool
    {
        return ($result['error_code'] ?? '') === 'BRIDGE_NOT_CONFIGURED';
    }

    /**
     * Build the full URL for a bridge API route.
     */
    private function buildUrl(string $route, array $params = []): string
    {
        $base = rtrim(Options::get_base_host(), '/');
        $url = $base . '/bridge/' . ltrim($route, '/');

        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }

        return $url;
    }

    /**
     * Build request headers with bridge client auth, optional bearer token,
     * and the capability-negotiation header.
     *
     * Recognized keys in $opts:
     *   - 'token'             (string): overrides the session bearer token
     *   - 'recaptcha_token'   (string): forwarded as X-Recaptcha-Token
     *   - 'recaptcha_action'  (string): forwarded as X-Recaptcha-Action
     */
    private function buildHeaders(array $opts = []): array
    {
        $headers = $this->buildClientHeaders();

        $token = $opts['token'] ?? BridgeSession::getToken();
        if ($token !== '' && $token !== null) {
            $headers['Authorization'] = 'Bearer ' . $token;
        }

        if (!empty($opts['recaptcha_token'])) {
            $headers['X-Recaptcha-Token'] = (string) $opts['recaptcha_token'];
        }
        if (!empty($opts['recaptcha_action'])) {
            $headers['X-Recaptcha-Action'] = (string) $opts['recaptcha_action'];
        }

        return $headers;
    }

    /**
     * Build just the client credential headers (no bearer token).
     * Used for initSession calls where no session token exists yet.
     */
    private function buildClientHeaders(): array
    {
        $headers = [
            'Accept'                  => 'application/json',
            'X-Bridge-Client-Id'      => Options::get_bridge_client_id(),
            'X-Bridge-Client-Secret'  => Options::get_bridge_client_secret(),
        ];

        // Forward the REAL shopper IP so core can rate-limit carding-sensitive
        // routes per client, not per WP egress. Everything on the WP->core hop
        // otherwise arrives from this one host, so without this header a whole
        // WordPress tenant shares a single IP and core cannot tell one shopper's
        // burst from the tenant's normal traffic. Core trusts this header ONLY
        // because the request also carries the confidential client_secret above
        // (a browser can't send that), and it is a DEDICATED header, core's
        // other IP logic still ignores X-Forwarded-For from a public peer.
        $clientIp = $this->client_ip();
        if ($clientIp !== '') {
            $headers['X-Bridge-Client-IP'] = $clientIp;
        }

        return $headers;
    }

    /**
     * Best-effort real visitor IP as this WP host sees it. Prefers the
     * managed-host / CDN forwarding headers (WP Engine populates
     * X-Forwarded-For with the real client), then REMOTE_ADDR. Returns the
     * first VALID public IP; if none is public (e.g. a private-network staging
     * hit) the first valid IP; '' when nothing parses, which tells core to skip
     * per-IP limiting rather than key on a bogus value.
     *
     * DEPLOY NOTE: confirm which header carries the true client on the target
     * WP Engine install before relying on the ceiling, a wrong pick keys the
     * limiter on the load balancer. A site can override via the
     * `b360_bridge_client_ip` filter.
     */
    private function client_ip(): string
    {
        $candidates = [];
        foreach (['HTTP_TRUE_CLIENT_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $key) {
            if (empty($_SERVER[$key])) {
                continue;
            }
            // X-Forwarded-For is a comma list (client, proxy1, ...); the
            // left-most is the originating client on WP Engine's inbound hop.
            foreach (explode(',', (string) $_SERVER[$key]) as $part) {
                $ip = trim($part);
                if ($ip !== '' && filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                    $candidates[] = $ip;
                }
            }
        }

        $firstValid = '';
        foreach ($candidates as $ip) {
            if ($firstValid === '') {
                $firstValid = $ip;
            }
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                return (string) apply_filters('b360_bridge_client_ip', $ip);
            }
        }

        return (string) apply_filters('b360_bridge_client_ip', $firstValid);
    }

    /**
     * Parse a WP HTTP API response into a standardized result array.
     *
     * This method is intentionally free of session side-effects. Token
     * lifecycle is managed exclusively by maybeRecover401.
     */
    private function parseResponse($response): array
    {
        if (is_wp_error($response)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[B360Bridge] API connection error: ' . $response->get_error_message());
            }
            return [
                'ok'     => false,
                'status' => 0,
                'data'   => null,
                'error'  => 'Unable to connect to the store service. Please try again.',
            ];
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);
        $json = json_decode($body, true);

        if (!is_array($json)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[B360Bridge] Invalid JSON response from API: ' . substr($body, 0, 500));
            }

            return [
                'ok'     => false,
                'status' => $status,
                'data'   => null,
                'error'  => 'Invalid JSON response from bridge API',
            ];
        }

        $ok = ($json['success'] ?? false) === true;
        $errorBlock = is_array($json['error'] ?? null) ? $json['error'] : null;

        return [
            'ok'            => $ok,
            'status'        => $status,
            'data'          => $json['data'] ?? null,
            'meta'          => $json['meta'] ?? null,
            'error'         => $ok ? null : ($errorBlock['message'] ?? ($json['error'] ?? 'Unknown error')),
            'error_code'    => $ok ? null : ($errorBlock['code'] ?? null),
            'error_context' => $ok ? null : (is_array($errorBlock['context'] ?? null) ? $errorBlock['context'] : null),
        ];
    }

    /**
     * Pack the wall-clock time of the wp_remote_* call together with any
     * Server-Timing header the admin side sent back. The result envelope
     * carries this so RestBase can re-emit it as a Server-Timing header
     * on the WP REST response, giving us devtools-visible breakdowns of
     * where latency lives in the WP → admin → Google chain.
     *
     * @param mixed $response wp_remote_* return value
     * @param int   $wpRemoteMs wall-clock around wp_remote_post/get
     * @return array{wp_remote_ms:int, admin_server_timing:string}
     */
    private function extractTiming($response, int $wpRemoteMs): array
    {
        $adminTiming = '';
        if (!is_wp_error($response)) {
            $adminTiming = (string) wp_remote_retrieve_header($response, 'server-timing');
        }
        return [
            'wp_remote_ms'        => $wpRemoteMs,
            'admin_server_timing' => $adminTiming,
        ];
    }

    /**
     * Invalidate all cached bridge API responses.
     */
    public static function flushCache(): void
    {
        global $wpdb;
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
                '_transient_b360_api_%',
                '_transient_timeout_b360_api_%'
            )
        );
    }
}
