<?php

namespace Bottle360\Bridge\Shortcodes;

use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * [b360_app], emits the placeholder that the unified bridge bundle
 * teleports the full Vue SPA into.
 *
 * The bundle itself is loaded unconditionally by Frontend\BridgeBoot on
 * every front-end page, so this shortcode only needs to mark up the
 * mount point and flag the page so theme CSS can adapt.
 */
final class AppShortcode
{
    public function register(): void
    {
        add_shortcode('b360_app', [$this, 'render']);
    }

    public function render($atts): string
    {
        // Flag the page so theme / plugin CSS can target storefront pages.
        // Guarded with a static so repeated shortcode calls on the same
        // request don't pile up filter callbacks.
        static $flagged = false;
        if (!$flagged) {
            $flagged = true;
            $isRoot = self::isRootRoute();
            add_filter('body_class', static function (array $classes) use ($isRoot): array {
                $classes[] = 'b360-app-active';
                $classes[] = 'b360-has-storefront';
                // Every SPA sub-path (product, cart, checkout, ...) resolves to
                // this same WP page, so any extra blocks the merchant placed
                // alongside [b360_app] would otherwise render on every route.
                // Scope them to the root route via this class + CSS below.
                // This is only the INITIAL state for the request that
                // rendered the page: the SPA navigates client-side, so
                // shared/router/bodyRouteClass.ts swaps the two classes on
                // every route change from then on.
                $classes[] = $isRoot ? 'b360-app-root' : 'b360-app-subroute';
                return $classes;
            });
        }

        $basePath = Options::get_app_base_path();

        return
            // Inline CSS to beat WP theme defaults (title, large margins)
            // before the bundle has a chance to mount.
              '<style>'
            .   file_get_contents(__DIR__ . '/app-shortcode.css')
            . '</style>'

            . '<div class="b360-app"'
            . ' data-b360-widget="app"'
            . ' data-base-path="' . esc_attr($basePath) . '"'
            . '>'
            // Pre-mount spinner; Root.vue clears innerHTML before teleport.
            . file_get_contents(__DIR__ . '/app-spinner.html')
            . '</div>';
    }

    /**
     * True when the current request targets the store's base path itself
     * (e.g. /store/) rather than a sub-route like /store/product/foo.
     * Mirrors the prefix-strip AppRoute::setTitle() uses for the same URI.
     */
    private static function isRootRoute(): bool
    {
        $uri = (string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
        $path = trim($uri, '/');

        // Strip the site's own subdirectory prefix first (e.g. /blog for a
        // subdirectory install), otherwise it throws off the base-path
        // comparison below and the actual root gets misread as a sub-route.
        $homePath = trim((string) parse_url(home_url(), PHP_URL_PATH), '/');
        if ($homePath !== '' && strpos($path, $homePath) === 0) {
            $path = trim(substr($path, strlen($homePath)), '/');
        }

        $basePath = trim(Options::get_app_base_path(), '/');
        if ($basePath !== '' && strpos($path, $basePath) === 0) {
            $path = trim(substr($path, strlen($basePath)), '/');
        }

        return $path === '';
    }
}
