<?php

namespace Bottle360\Bridge\Routing;

if (!defined('ABSPATH')) exit;

/**
 * Single source of truth for SPA route metadata.
 *
 * Every place that needs to know about a top-level SPA segment, the server
 * <title>, SEO og:title, nav-item active-state mapping, post-navigation
 * DOM sync in Vue, reads from here. This used to be duplicated across
 * AppRoute::setTitle(), MetaTags::$static, NavShortcode::$items, and
 * frontend/router/index.ts (titleMap + segmentMap). Adding a new route
 * meant editing four places and crossing your fingers.
 *
 * The client-side consumer is seeded from window.B360Bridge.routes, which
 * AppShortcode emits from this class as JSON.
 */
final class SpaRoutes
{
    /**
     * Segment → page <title>. The empty-string key is the base path itself
     * (e.g. /store/), the storefront listing.
     *
     * @return array<string, string>
     */
    public static function titles(): array
    {
        return [
            ''           => __('Shop', 'b360-bridge'),
            'collection' => __('Shop', 'b360-bridge'),
            'wine'       => __('Shop', 'b360-bridge'),
            'product'    => __('Shop', 'b360-bridge'),
            'bundle'     => __('Shop', 'b360-bridge'),
            'checkout'   => __('Checkout', 'b360-bridge'),
            'login'      => __('Sign In', 'b360-bridge'),
            'register'   => __('Create Account', 'b360-bridge'),
            'account'    => __('My Account', 'b360-bridge'),
            'clubs'      => __('Wine Clubs', 'b360-bridge'),
            'recovery'   => __('Reset Password', 'b360-bridge'),
        ];
    }

    /**
     * Page <title> for a given segment, with a sensible default for unknown
     * segments (dynamic sub-routes that don't have their own title baked in).
     */
    public static function titleFor(string $segment): string
    {
        $titles = self::titles();
        return $titles[$segment] ?? $titles[''];
    }
}
