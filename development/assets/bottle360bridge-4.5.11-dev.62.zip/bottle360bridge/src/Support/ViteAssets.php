<?php

namespace Bottle360\Bridge\Support;

if (!defined('ABSPATH')) exit;

/**
 * Resolves Vite assets for both dev (HMR) and production (built files).
 *
 * Dev mode is an explicit, per-environment choice driven by the `B360_DEV`
 * constant. When defined to a non-empty string, that string is used as the
 * Vite dev server origin (e.g. http://localhost:5173) and the storefront
 * loads modules directly from Vite. When undefined, production mode reads
 * the built manifest under assets/dist/.vite/manifest.json.
 *
 * b360-bridge.php seeds B360_DEV from the `B360_DEV` env var so docker-compose
 * controls dev mode on the local stack. No hot file, no liveness probe, no
 * fallback: if you set B360_DEV and Vite isn't running, script tags fail
 * loudly in the browser console instead of silently serving stale prod
 * assets. That is the desired property, see docs/local-dev.md.
 */
final class ViteAssets
{
    private static ?string $devOrigin = null;
    private static bool $checked = false;
    private static bool $clientEmitted = false;
    private static ?array $manifest = null;
    /** CSS files already emitted this request (avoid duplicates across entry points). */
    private static array $emittedCss = [];
    /** Whether the bridge bundle has been emitted this request. */
    private static bool $bridgeEmitted = false;
    /** Whether the studio bundle has been emitted this request. */
    private static bool $studioEmitted = false;
    /** Cached staleness check result for the current request. */
    private static ?bool $manifestStale = null;

    /**
     * Returns the Vite dev server origin when B360_DEV is set, else null.
     */
    public static function devOrigin(): ?string
    {
        if (!self::$checked) {
            self::$checked = true;
            if (defined('B360_DEV')) {
                $val = constant('B360_DEV');
                if (is_string($val) && $val !== '' && $val !== '0') {
                    self::$devOrigin = rtrim($val, '/');
                }
            }
        }
        return self::$devOrigin;
    }

    public static function isDev(): bool
    {
        return self::devOrigin() !== null;
    }

    /**
     * Renders all <script> and <link> tags needed for the unified bridge bundle.
     *
     * Idempotent, safe to call from multiple places (e.g. the app shortcode
     * and the every-page bootstrap). The bundle is emitted at most once per
     * request; subsequent calls return an empty string.
     */
    public static function renderBridgeTags(): string
    {
        if (self::$bridgeEmitted) return '';
        self::$bridgeEmitted = true;
        return self::renderEntry('shared/bridge.ts');
    }

    /**
     * Renders <script>/<link> tags for the admin Styling Studio bundle.
     * Idempotent like renderBridgeTags(). Storefront and studio never
     * share a request, but the same per-request guard keeps things safe.
     */
    public static function renderStudioTags(): string
    {
        if (self::$studioEmitted) return '';
        self::$studioEmitted = true;
        return self::renderEntry('shared/studio.ts');
    }

    /**
     * Renders tags for a given Vite entry point.
     *
     * Dev mode: loads the HMR client + the entry module from the dev server.
     * Production: reads the manifest, collects all transitive CSS deps, and
     * emits <link> tags for each, followed by the entry JS <script>.
     */
    private static function renderEntry(string $entrySource): string
    {
        $origin = self::devOrigin();

        if ($origin !== null) {
            $html = '';
            if (!self::$clientEmitted) {
                self::$clientEmitted = true;
                $html .= "<script type=\"module\" src=\"{$origin}/@vite/client\"></script>\n";
            }
            $html .= "<script type=\"module\" src=\"{$origin}/{$entrySource}\"></script>";
            return $html;
        }

        // Production, read manifest and resolve all CSS for this entry
        $manifest = self::loadManifest();
        if ($manifest === null || !isset($manifest[$entrySource])) {
            return '<!-- ViteAssets: entry not found in manifest. Run `npm run build`. -->';
        }

        // Loud-failure dev safeguard: when WP_DEBUG is on but B360_DEV is off,
        // the operator is testing the prod build locally. If any frontend/
        // source is newer than the manifest, surface it as an HTML comment +
        // console warning rather than silently serving stale assets.
        $stalenessNote = '';
        if (self::manifestIsStale()) {
            $stalenessNote = "<!-- ViteAssets: assets/dist/ is older than frontend/. "
                . "Either enable B360_DEV (run `npm run dev`) or rebuild with `npm run build`. -->\n"
                . "<script>console.warn('[Bottle360 Bridge] Static bundle is older than frontend/ sources. "
                . "Run `npm run build` or enable B360_DEV.');</script>\n";
        }

        $entry = $manifest[$entrySource];
        $distUrl = plugins_url('assets/dist/', B360_BRIDGE_FILE);
        $distDir = B360_BRIDGE_DIR . 'assets/dist/';

        $html = $stalenessNote;

        // Collect all CSS files from this entry and its transitive imports
        $cssFiles = self::collectCss($entrySource, $manifest);
        foreach ($cssFiles as $cssFile) {
            if (isset(self::$emittedCss[$cssFile])) {
                continue; // already emitted by another entry point on this page
            }
            self::$emittedCss[$cssFile] = true;
            $fullPath = $distDir . $cssFile;
            if (file_exists($fullPath)) {
                $ver = filemtime($fullPath);
                $url = esc_url($distUrl . $cssFile . '?v=' . $ver);
                $html .= "<link rel=\"stylesheet\" href=\"{$url}\" />\n";
            }
        }

        // Emit the entry JS. Deliberately NO ?v=<mtime> cache-buster here, the
        // filename is already content-hashed by Vite (the `De7p7wg-` in
        // b360-bridge-De7p7wg-.js), so a query string adds nothing for cache
        // invalidation but breaks something more important: ES module identity.
        //
        // Any SPA view that's reached only via a dynamic import (e.g. a route
        // component) but statically imports something Rollup already inlined
        // into this entry chunk (router/index.ts, in practice) forces Rollup to
        // emit a plain cross-chunk `import("b360-bridge-<hash>.js")`, no query
        // string, because inter-chunk references are resolved by Vite/Rollup
        // itself, never through this PHP layer. If THIS tag appended `?v=...`,
        // that import would resolve to a *different* URL than the one the
        // browser already has loaded, so the browser's module registry (keyed
        // on exact URL) treats it as an unrelated second module and re-executes
        // the entire entry graph, a second createApp()/router/useCart/
        // useMemberships/useCheckout instance, each with its own module-scope
        // singletons. Every on-mount fetch in that graph (cart, upcoming-
        // shipments, checkout/summary, clubs) then fires twice, even though
        // each composable is individually memoised, memoisation only dedupes
        // callers *within* one module instance, not across two of them.
        // Confirmed via `assets/dist/.vite/manifest.json`: StoreListing.vue's
        // "imports" includes "shared/bridge.ts" for exactly this reason.
        //
        // The content hash already changes on every real rebuild, so dropping
        // the query string loses no cache-busting: this URL always matches
        // whatever Rollup's own module graph resolves to.
        $jsFile = $entry['file'];
        $jsUrl = esc_url($distUrl . $jsFile);
        $html .= "<script type=\"module\" src=\"{$jsUrl}\"></script>";

        return $html;
    }

    /**
     * Loads and caches the Vite manifest.
     */
    private static function loadManifest(): ?array
    {
        if (self::$manifest !== null) {
            return self::$manifest;
        }
        $path = B360_BRIDGE_DIR . 'assets/dist/.vite/manifest.json';
        if (!file_exists($path)) {
            return null;
        }
        $json = file_get_contents($path);
        self::$manifest = json_decode($json, true) ?: [];
        return self::$manifest;
    }

    /**
     * Returns true when any source under frontend/ is newer than the
     * built manifest. Gated on WP_DEBUG so production gets no I/O cost.
     * Result is cached for the request.
     */
    private static function manifestIsStale(): bool
    {
        if (self::$manifestStale !== null) return self::$manifestStale;
        if (!defined('WP_DEBUG') || !WP_DEBUG) return self::$manifestStale = false;

        $manifestPath = B360_BRIDGE_DIR . 'assets/dist/.vite/manifest.json';
        if (!file_exists($manifestPath)) return self::$manifestStale = false;
        $manifestMtime = filemtime($manifestPath);

        // After the monorepo split the Vue sources live in ../shared (a sibling
        // of the plugin dir), not inside the plugin. This dev-only staleness
        // check therefore looks one level up; in a shipped ZIP ../shared does
        // not exist, so is_dir() fails closed to "not stale".
        $frontendDir = B360_BRIDGE_DIR . '../shared';
        if (!is_dir($frontendDir)) return self::$manifestStale = false;

        try {
            $it = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($frontendDir, \FilesystemIterator::SKIP_DOTS)
            );
            foreach ($it as $file) {
                if (!$file->isFile()) continue;
                if ($file->getMTime() > $manifestMtime) {
                    return self::$manifestStale = true;
                }
            }
        } catch (\Throwable $e) {
            // Best-effort. Don't block rendering on a filesystem hiccup.
            return self::$manifestStale = false;
        }
        return self::$manifestStale = false;
    }

    /**
     * Recursively collects all CSS files for an entry and its imports.
     */
    private static function collectCss(string $key, array $manifest, array &$visited = []): array
    {
        if (isset($visited[$key])) {
            return [];
        }
        $visited[$key] = true;

        if (!isset($manifest[$key])) {
            return [];
        }
        $chunk = $manifest[$key];

        $css = [];

        // CSS declared directly on this chunk
        if (!empty($chunk['css'])) {
            foreach ($chunk['css'] as $file) {
                $css[] = $file;
            }
        }

        // Recurse into static imports
        if (!empty($chunk['imports'])) {
            foreach ($chunk['imports'] as $imp) {
                $css = array_merge($css, self::collectCss($imp, $manifest, $visited));
            }
        }

        return $css;
    }
}
