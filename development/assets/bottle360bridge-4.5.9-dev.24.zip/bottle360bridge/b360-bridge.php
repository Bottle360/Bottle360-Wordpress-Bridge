<?php
/**
 * Plugin Name: Bottle360 Bridge
 * Description: Bring your Bottle360 store into WordPress: shop, cart, checkout, customer accounts, wine clubs, and forms, all on your own site. It stays in sync with Bottle360 automatically and includes a built-in styling studio so the store matches your brand.
 * Version: 4.5.9-dev.24
 * Author: Bottle360
 * Text Domain: b360-bridge
 * Requires at least: 6.3
 * Requires PHP: 7.4
 * Update URI: https://github.com/Bottle360/Bottle360-Wordpress-Bridge
 */
if (!defined('ABSPATH')) exit;

define('B360_BRIDGE_FILE', __FILE__);
define('B360_BRIDGE_DIR',  plugin_dir_path(__FILE__));
define('B360_BRIDGE_URL',  plugins_url('', __FILE__));
define('B360_BRIDGE_VER',  '4.5.9-dev.24');

// Vite dev-mode toggle. When B360_DEV is a non-empty string, ViteAssets
// emits <script>/<link> tags pointing at that origin (e.g. the Vite dev
// server) instead of the built manifest. Read from the env so docker-compose
// can flip the local stack into dev mode without touching code. Truthy
// shorthand values ('1', 'true', 'yes', 'on') map to the default origin.
if (!defined('B360_DEV')) {
    $b360_dev_env = getenv('B360_DEV');
    if (is_string($b360_dev_env) && $b360_dev_env !== '' && $b360_dev_env !== '0' && strcasecmp($b360_dev_env, 'false') !== 0) {
        $b360_dev_truthy = ['1', 'true', 'yes', 'on'];
        if (in_array(strtolower($b360_dev_env), $b360_dev_truthy, true)) {
            define('B360_DEV', 'http://localhost:5173');
        } else {
            define('B360_DEV', $b360_dev_env);
        }
    }
    unset($b360_dev_env);
}

/** Load Composer autoloader if present */
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require __DIR__ . '/vendor/autoload.php';
} else {
    // Optional: warn if someone installs a source ZIP without vendor/
    add_action('admin_notices', static function () {
        if (!current_user_can('manage_options')) return;
        echo '<div class="notice notice-error"><p><strong>Bottle360 Bridge:</strong> Missing <code>vendor/autoload.php</code>. '
           . 'Install the official release ZIP or run <code>composer install --no-dev</code>.</p></div>';
    });
}

spl_autoload_register(static function ($class) {
    $prefix = 'Bottle360\\Bridge\\';
    $len = strlen($prefix);
    if (strncmp($class, $prefix, $len) !== 0) return;
    $relative = substr($class, $len);
    $file = B360_BRIDGE_DIR . 'src/' . str_replace('\\', '/', $relative) . '.php';
    if (file_exists($file)) require $file;
});

add_action('plugins_loaded', static function () {
    (new \Bottle360\Bridge\Plugin())->boot();
});

register_activation_hook(__FILE__, ['\Bottle360\Bridge\Lifecycle\Activator', 'activate']);
register_deactivation_hook(__FILE__, ['\Bottle360\Bridge\Lifecycle\Activator', 'deactivate']);
