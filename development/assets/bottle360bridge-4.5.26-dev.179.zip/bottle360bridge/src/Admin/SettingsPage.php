<?php

namespace Bottle360\Bridge\Admin;

use Bottle360\Bridge\Settings\Options;

final class SettingsPage
{
    public function register_settings(): void
    {
        \add_action('admin_init', [$this, 'settings']);
    }

    public function add_menu(): void
    {
        \add_menu_page(
            __('Bottle360 Bridge', 'b360-bridge'),
            __('Bottle360', 'b360-bridge'),
            'manage_options',
            'b360_bridge',
            [$this, 'render'],
            'dashicons-store',
            58
        );
    }

    public function settings(): void
    {
        // --- Connection ---
        \register_setting('b360_bridge', Options::OPT_BASE_URL, [
            'type' => 'string', 'sanitize_callback' => [$this, 'sanitize_url'], 'default' => '',
        ]);
        \register_setting('b360_bridge', Options::OPT_PUBLIC_URL, [
            'type' => 'string', 'sanitize_callback' => [$this, 'sanitize_url'], 'default' => '',
        ]);
        \register_setting('b360_bridge', Options::OPT_BRIDGE_CLIENT_ID, [
            'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '',
        ]);
        \register_setting('b360_bridge', Options::OPT_BRIDGE_CLIENT_SECRET, [
            'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '',
        ]);

        // --- Squarespace embed (public values only) ---
        \register_setting('b360_bridge', Options::OPT_EMBED_CLIENT_ID, [
            'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '',
        ]);
        \register_setting('b360_bridge', Options::OPT_EMBED_KEY, [
            'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '',
        ]);
        \register_setting('b360_bridge', Options::OPT_EMBED_BUNDLE_URL, [
            'type' => 'string', 'sanitize_callback' => [$this, 'sanitize_url'], 'default' => '',
        ]);

        // --- Storefront ---
        \register_setting('b360_bridge', Options::OPT_GOOGLE_FONTS_API_KEY, [
            'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '',
        ]);
        \register_setting('b360_bridge', Options::OPT_GOOGLE_ADDRESS_API_KEY, [
            'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '',
        ]);
        \register_setting('b360_bridge', Options::OPT_MEMBERSHIP_PAUSE, [
            'type' => 'boolean', 'sanitize_callback' => [$this, 'sanitize_bool'], 'default' => true,
        ]);
        // The pause flag rides in the /bootstrap payload, which is cached for 5
        // minutes. Flush that cache the instant the toggle changes so the
        // storefront reflects it on the next load instead of up to 5 min later.
        \add_action('update_option_' . Options::OPT_MEMBERSHIP_PAUSE, ['\\Bottle360\\Bridge\\Rest\\BootstrapController', 'flushCache'], 10, 0);
        \add_action('add_option_' . Options::OPT_MEMBERSHIP_PAUSE, ['\\Bottle360\\Bridge\\Rest\\BootstrapController', 'flushCache'], 10, 0);

        // --- Advanced ---
        \register_setting('b360_bridge', Options::OPT_DISABLE_CACHE, [
            'type' => 'boolean', 'sanitize_callback' => [$this, 'sanitize_bool'], 'default' => false,
        ]);
        \register_setting('b360_bridge', Options::OPT_DEBUG, [
            'type' => 'boolean', 'sanitize_callback' => [$this, 'sanitize_bool'], 'default' => false,
        ]);

        // --- Sections ---
        \add_settings_section('b360_connection', __('Bridge Connection', 'b360-bridge'), function () {
            echo '<p class="description">'
                . \esc_html__('Connect this WordPress site to the Bottle360 admin site.', 'b360-bridge')
                . '</p>';
        }, 'b360_bridge');

        \add_settings_section('b360_squarespace', __('Squarespace embed', 'b360-bridge'), function () {
            echo '<p class="description" style="max-width: 680px;">'
                . \esc_html__('Create a public-embed client in the B360 admin (Settings → Bridge API → API Clients), paste its Client ID + Embed Key here, and add your Squarespace domain(s) to that client\'s allowed origins. These public values are baked into the "Export for Squarespace" snippet in the Styling Studio. The confidential Client Secret above is never used here.', 'b360-bridge')
                . '</p>';
        }, 'b360_bridge');

        \add_settings_section('b360_storefront', __('Storefront', 'b360-bridge'), fn() => null, 'b360_bridge');

        \add_settings_section('b360_advanced', __('Advanced', 'b360-bridge'), fn() => null, 'b360_bridge');

        // --- Fields: Connection ---
        \add_settings_field(Options::OPT_BASE_URL, __('Admin Site URL', 'b360-bridge'), function () {
            $val = \esc_attr(Options::get_base_url());
            echo '<input type="url" name="' . \esc_attr(Options::OPT_BASE_URL) . '" value="' . $val . '" class="regular-text" placeholder="http://host.containers.internal:9001" />';
            echo '<p class="description">' . \esc_html__('Internal URL to the B360 admin site (server-to-server). Used by the plugin for API calls.', 'b360-bridge') . '</p>';
        }, 'b360_bridge', 'b360_connection');

        \add_settings_field(Options::OPT_PUBLIC_URL, __('Public Asset URL', 'b360-bridge'), function () {
            $val = \esc_attr(Options::get_public_url());
            echo '<input type="url" name="' . \esc_attr(Options::OPT_PUBLIC_URL) . '" value="' . $val . '" class="regular-text" placeholder="http://dev.bottle360.local:9001" />';
            echo '<p class="description">' . \esc_html__('Browser-facing URL for product images. Must be accessible from the visitor\'s browser.', 'b360-bridge') . '</p>';
        }, 'b360_bridge', 'b360_connection');

        \add_settings_field(Options::OPT_BRIDGE_CLIENT_ID, __('Client ID', 'b360-bridge'), function () {
            $val = \esc_attr(Options::get_bridge_client_id());
            echo '<input type="text" name="' . \esc_attr(Options::OPT_BRIDGE_CLIENT_ID) . '" value="' . $val . '" class="regular-text" placeholder="b360-xxxxxxxxxxxxxxxx" />';
            echo '<p class="description">' . \esc_html__('From Settings → Bridge API → API Clients in the admin panel.', 'b360-bridge') . '</p>';
        }, 'b360_bridge', 'b360_connection');

        \add_settings_field(Options::OPT_BRIDGE_CLIENT_SECRET, __('Client Secret', 'b360-bridge'), function () {
            $val = \esc_attr(Options::get_bridge_client_secret());
            echo '<input type="password" name="' . \esc_attr(Options::OPT_BRIDGE_CLIENT_SECRET) . '" value="' . $val . '" class="regular-text" autocomplete="off" />';
            echo '<p class="description">' . \esc_html__('Keep this private. Regenerate from the admin panel if compromised.', 'b360-bridge') . '</p>';
        }, 'b360_bridge', 'b360_connection');

        // --- Fields: Squarespace embed ---
        \add_settings_field(Options::OPT_EMBED_CLIENT_ID, __('Embed Client ID', 'b360-bridge'), function () {
            $val = \esc_attr(Options::get_embed_client_id());
            echo '<input type="text" name="' . \esc_attr(Options::OPT_EMBED_CLIENT_ID) . '" value="' . $val . '" class="regular-text" placeholder="b360-xxxxxxxxxxxxxxxx" />';
            echo '<p class="description">' . \esc_html__('The public-embed client\'s Client ID. Distinct from the confidential Client ID above.', 'b360-bridge') . '</p>';
        }, 'b360_bridge', 'b360_squarespace');

        \add_settings_field(Options::OPT_EMBED_KEY, __('Embed Key', 'b360-bridge'), function () {
            $val = \esc_attr(Options::get_embed_key());
            echo '<input type="text" name="' . \esc_attr(Options::OPT_EMBED_KEY) . '" value="' . $val . '" class="regular-text" placeholder="b360e_xxxxxxxxxxxxxxxx" />';
            echo '<p class="description">' . \esc_html__('The public embed key (b360e_…). Public by design, safe to expose in the browser.', 'b360-bridge') . '</p>';
        }, 'b360_bridge', 'b360_squarespace');

        \add_settings_field(Options::OPT_EMBED_BUNDLE_URL, __('Embed Bundle URL', 'b360-bridge'), function () {
            $val = \esc_attr(Options::get_embed_bundle_url());
            echo '<input type="url" name="' . \esc_attr(Options::OPT_EMBED_BUNDLE_URL) . '" value="' . $val . '" class="regular-text" placeholder="https://cdn.example.com/b360-embed.js" />';
            echo '<p class="description">' . \esc_html__('Evergreen hosted embed bundle URL. Leave blank to keep the placeholder in the exported snippet.', 'b360-bridge') . '</p>';
        }, 'b360_bridge', 'b360_squarespace');

        // --- Fields: Storefront (read-only) ---
        \add_settings_field('b360_app_base_path_display', __('Current Storefront Path', 'b360-bridge'), function () {
            $disconnected = Options::is_app_disconnected();
            $page_id      = (int) \get_option('b360_app_page_id', 0);
            $setup_slug   = Options::get_app_setup_slug();

            if ($disconnected) {
                $reconnect_nonce = \wp_create_nonce('b360_reconnect_app_page');
                echo '<p><strong>' . \esc_html__('Disconnected.', 'b360-bridge') . '</strong> ';
                echo \esc_html__('The plugin is not attached to a WordPress page. The storefront is not live until you reconnect.', 'b360-bridge') . '</p>';
                echo '<button type="button" class="button button-primary" id="b360-reconnect-btn" data-nonce="' . \esc_attr($reconnect_nonce) . '" data-slug="' . \esc_attr(trim($setup_slug, '/')) . '">'
                    . \esc_html__('Reconnect (create app page at', 'b360-bridge') . ' <code>' . \esc_html($setup_slug) . '</code>)'
                    . '</button>';
                echo ' <span id="b360-reconnect-status" style="margin-left: 8px;"></span>';
                echo '<p class="description">'
                    . \esc_html__('Creates a fresh page at the setup slug with the required shortcodes. If a page already exists at that slug, it will be adopted instead.', 'b360-bridge')
                    . '</p>';
                return;
            }

            $path = Options::get_app_base_path();
            $url  = \home_url($path . '/');
            echo '<code>' . \esc_html($path) . '</code> ';
            echo '<a href="' . \esc_url($url) . '" target="_blank" rel="noopener">' . \esc_html__('View storefront', 'b360-bridge') . ' &rarr;</a>';
            if ($page_id && \get_post_status($page_id) === 'publish') {
                echo ' &middot; ';
                echo '<a href="' . \esc_url(\get_edit_post_link($page_id)) . '">' . \esc_html__('Edit app page', 'b360-bridge') . '</a>';
            }
            echo '<p class="description">'
                . \esc_html__('Resolved from the app page\'s slug. To change it, rename or move the app page in the Pages admin.', 'b360-bridge')
                . '</p>';
            echo '<p class="description" style="color: #888;">'
                . \esc_html__('Setup slug (used on activation): ', 'b360-bridge')
                . '<code>' . \esc_html($setup_slug) . '</code>'
                . '</p>';

            // Disconnect controls. Two variants, keep the page, or also trash it.
            // Trashing is what most admins actually want when they're done with the plugin;
            // the "keep" variant exists so someone reorganizing pages manually doesn't lose work.
            $disc_nonce = \wp_create_nonce('b360_disconnect_app_page');
            echo '<div style="margin-top: 12px; padding: 12px; background: #fff7f7; border-left: 3px solid #c33; max-width: 600px;">';
            echo '<p style="margin-top: 0;"><strong>' . \esc_html__('Disconnect app page', 'b360-bridge') . '</strong></p>';
            echo '<p class="description">'
                . \esc_html__('Detach the plugin from this page so it stops auto-healing. The storefront will stop working until you reconnect. Useful when migrating to a different page or uninstalling.', 'b360-bridge')
                . '</p>';
            echo '<button type="button" class="button" id="b360-disconnect-btn" data-nonce="' . \esc_attr($disc_nonce) . '">'
                . \esc_html__('Disconnect (keep page)', 'b360-bridge')
                . '</button> ';
            echo '<button type="button" class="button button-link-delete" id="b360-disconnect-delete-btn" data-nonce="' . \esc_attr($disc_nonce) . '">'
                . \esc_html__('Disconnect and trash page', 'b360-bridge')
                . '</button>';
            echo ' <span id="b360-disconnect-status" style="margin-left: 8px;"></span>';
            echo '</div>';
        }, 'b360_bridge', 'b360_storefront');

        \add_settings_field(Options::OPT_MEMBERSHIP_PAUSE, __('Membership Pause', 'b360-bridge'), function () {
            $checked = Options::is_membership_pause_enabled() ? 'checked' : '';
            echo '<label><input type="checkbox" name="' . \esc_attr(Options::OPT_MEMBERSHIP_PAUSE) . '" value="1" ' . $checked . ' /> ';
            echo \esc_html__('Let members pause their own memberships from the account area.', 'b360-bridge') . '</label>';
            echo '<p class="description">'
                . \esc_html__('When unchecked, the “Pause Membership” button is hidden site-wide. Resume and cancel are unaffected. Individual clubs can also disable pause from the admin panel.', 'b360-bridge')
                . '</p>';
        }, 'b360_bridge', 'b360_storefront');

        \add_settings_field(Options::OPT_GOOGLE_FONTS_API_KEY, __('Google Fonts API Key', 'b360-bridge'), function () {
            $val = \esc_attr(Options::get_google_fonts_api_key());
            echo '<input type="password" name="' . \esc_attr(Options::OPT_GOOGLE_FONTS_API_KEY) . '" value="' . $val . '" class="regular-text" autocomplete="off" placeholder="AIza..." />';
            echo '<p class="description">'
                . \esc_html__('Optional. Lets the Styling Studio list every Google font in a dropdown (Styling Studio → Typography → Google Fonts). Create a key at console.cloud.google.com → APIs & Services → Credentials, with the "Web Fonts Developer API" enabled. Restrict it to that API.', 'b360-bridge')
                . '</p>';
            echo '<p class="description">'
                . \esc_html__('The key is used server-side only and is never sent to visitors. It is needed to LIST fonts, serving the font files needs no key.', 'b360-bridge')
                . '</p>';
            if (Options::has_google_fonts_api_key()) {
                echo '<p><button type="button" class="button" id="b360-gfonts-refresh" data-nonce="' . \esc_attr(\wp_create_nonce('wp_rest')) . '">'
                    . \esc_html__('Test key & refresh font list', 'b360-bridge')
                    . '</button> <span id="b360-gfonts-status" style="margin-left:8px;"></span></p>';
            }
        }, 'b360_bridge', 'b360_storefront');

        \add_settings_field(Options::OPT_GOOGLE_ADDRESS_API_KEY, __('Google Address API Key', 'b360-bridge'), function () {
            $val = \esc_attr(Options::get_google_address_api_key());
            echo '<input type="password" name="' . \esc_attr(Options::OPT_GOOGLE_ADDRESS_API_KEY) . '" value="' . $val . '" class="regular-text" autocomplete="off" placeholder="AIza..." />';
            echo '<p class="description">'
                . \esc_html__('Optional. Turns on street address suggestions while the shopper types, and a deliverability check on a finished address that warns without ever blocking the sale. Create a key at console.cloud.google.com with BOTH the "Places API (New)" and the "Address Validation API" enabled, then restrict it to those two.', 'b360-bridge')
                . '</p>';
            echo '<p class="description">'
                . \esc_html__('Used server-side only and never sent to visitors, so it needs no HTTP-referrer restriction. Leave blank to keep plain typed address entry. Google bills both APIs per request. The plugin limits each visitor and caps the whole site per hour, but set both of these in Google Cloud as well: a QUOTA cap on each API (requests per day), which is the hard stop, and a budget with alerts, which only emails you and does not stop spending. Suggestions are shown with a "Powered by Google" line, as Google requires. If your host caches pages, the storefront picks up a change here once that cache refreshes.', 'b360-bridge')
                . '</p>';
        }, 'b360_bridge', 'b360_storefront');

        // --- Fields: Advanced ---
        \add_settings_field(Options::OPT_DISABLE_CACHE, __('Disable Caching', 'b360-bridge'), function () {
            $checked = Options::is_cache_disabled() ? 'checked' : '';
            echo '<label><input type="checkbox" name="' . \esc_attr(Options::OPT_DISABLE_CACHE) . '" value="1" ' . $checked . ' /> ';
            echo \esc_html__('Bypass API response caching (useful during development).', 'b360-bridge') . '</label>';
        }, 'b360_bridge', 'b360_advanced');

        \add_settings_field(Options::OPT_DEBUG, __('Debug Mode', 'b360-bridge'), function () {
            $checked = Options::is_debug_enabled() ? 'checked' : '';
            echo '<label><input type="checkbox" name="' . \esc_attr(Options::OPT_DEBUG) . '" value="1" ' . $checked . ' /> ';
            echo \esc_html__('Enable extra error logging.', 'b360-bridge') . '</label>';
        }, 'b360_bridge', 'b360_advanced');

        \add_settings_field('b360_flush_cache', __('Cache', 'b360-bridge'), function () {
            $nonce = \wp_create_nonce('b360_flush_cache');
            echo '<button type="button" class="button" id="b360-flush-cache-btn" data-nonce="' . \esc_attr($nonce) . '">'
                . \esc_html__('Clear API Cache', 'b360-bridge')
                . '</button>';
            echo ' <span id="b360-flush-cache-status" style="margin-left: 8px; color: #46b450;"></span>';

            // What the last storefront update did to the site's page caches
            // (Lifecycle\PageCachePurge, BD-4783).
            $run = \Bottle360\Bridge\Lifecycle\PageCachePurge::lastRun();
            if ($run !== null) {
                $when = $run['time'] . ' UTC';
                if ($run['skipped']) {
                    $line = sprintf(__('Page cache clearing after a storefront update is turned off on this site (last update %s).', 'b360-bridge'), $when);
                } elseif (!empty($run['purged'])) {
                    $line = sprintf(__('Page caches asked to clear after the last storefront update (%1$s): %2$s.', 'b360-bridge'), $when, implode(', ', $run['purged']));
                } else {
                    $line = sprintf(__('No known page cache plugin was found after the last storefront update (%s). If this site caches pages another way, clear that cache after each plugin update.', 'b360-bridge'), $when);
                }
                if (!empty($run['failed'])) {
                    $line .= ' ' . sprintf(__('Could not clear: %s.', 'b360-bridge'), implode(', ', $run['failed']));
                }
                echo '<p class="description">' . \esc_html($line) . '</p>';
            }
        }, 'b360_bridge', 'b360_advanced');

        // --- AJAX: clear error log ---
        \add_action('wp_ajax_b360_clear_error_log', function () {
            if (!\current_user_can('manage_options')) {
                \wp_send_json_error('Unauthorized', 403);
            }
            \check_ajax_referer('b360_clear_error_log', '_nonce');
            \Bottle360\Bridge\Api\ApiErrorLog::clear();
            \wp_send_json_success();
        });

        // --- AJAX: test connection ---
        \add_action('wp_ajax_b360_test_connection', [$this, 'handle_test_connection_ajax']);

        // --- AJAX: flush cache ---
        \add_action('wp_ajax_b360_flush_cache', function () {
            if (!\current_user_can('manage_options')) {
                \wp_send_json_error('Unauthorized', 403);
            }
            \check_ajax_referer('b360_flush_cache', '_nonce');
            \Bottle360\Bridge\Api\BridgeApiClient::flushCache();
            \wp_send_json_success(['message' => __('Cache cleared.', 'b360-bridge')]);
        });

        // --- AJAX: disconnect app page ---
        // Two modes: keep the WP page as-is, or move it to Trash. Both clear
        // b360_app_page_id and set the disconnect flag so maybeHeal stops
        // re-adopting the page on every init.
        \add_action('wp_ajax_b360_disconnect_app_page', function () {
            if (!\current_user_can('manage_options')) {
                \wp_send_json_error('Unauthorized', 403);
            }
            \check_ajax_referer('b360_disconnect_app_page', '_nonce');
            $deletePage = !empty($_POST['delete_page']);
            \Bottle360\Bridge\Lifecycle\Activator::disconnect($deletePage);
            \wp_send_json_success([
                'message' => $deletePage
                    ? __('Disconnected and moved the page to Trash.', 'b360-bridge')
                    : __('Disconnected. The page was left in place.', 'b360-bridge'),
            ]);
        });

        // --- AJAX: reconnect app page ---
        \add_action('wp_ajax_b360_reconnect_app_page', function () {
            if (!\current_user_can('manage_options')) {
                \wp_send_json_error('Unauthorized', 403);
            }
            \check_ajax_referer('b360_reconnect_app_page', '_nonce');
            \Bottle360\Bridge\Lifecycle\Activator::reconnect();
            $page_id = (int) \get_option('b360_app_page_id', 0);
            if (!$page_id) {
                \wp_send_json_error([
                    'message' => __('Reconnect ran but no app page was created. Check the setup slug.', 'b360-bridge'),
                ]);
            }
            \wp_send_json_success([
                'message' => __('Reconnected.', 'b360-bridge'),
                'page_id' => $page_id,
                'edit_url' => \get_edit_post_link($page_id, 'raw'),
            ]);
        });
    }

    public function handle_test_connection_ajax(): void
    {
        if (!\current_user_can('manage_options')) {
            \wp_send_json_error(['state' => 'unreachable', 'message' => 'Unauthorized'], 403);
        }
        \check_ajax_referer('b360_test_connection', '_nonce');

        $host = Options::get_base_host();

        // Guard: Admin Site URL not set, ping would build a relative URL and
        // hit WordPress itself. Call this out specifically instead of letting
        // BridgeApiClient's generic "not configured" bubble up.
        if ($host === '') {
            \wp_send_json_error(['state' => 'bad_credentials', 'host' => '', 'message' => __('Admin Site URL is not set.', 'b360-bridge')]);
            return;
        }

        if (Options::get_bridge_client_id() === '' || Options::get_bridge_client_secret() === '') {
            \wp_send_json_error(['state' => 'bad_credentials', 'host' => $host, 'message' => __('No client credentials configured.', 'b360-bridge')]);
            return;
        }

        $t_start = microtime(true);
        $result = \Bottle360\Bridge\Api\BridgeApiClient::instance()->get('default/ping', [], ['cache' => 0]);
        $latency_ms = (int) round((microtime(true) - $t_start) * 1000);

        // WP_Error or status 0 → unreachable
        if (isset($result['status']) && $result['status'] === 0) {
            \wp_send_json_error([
                'state'   => 'unreachable',
                'host'    => $host,
                'message' => $result['error'] ?? __('No response from server.', 'b360-bridge'),
            ]);
            return;
        }

        // Bad credentials. BridgeApiClient::maybeRecover401 rewrites the bridge's
        // 401/client_auth_failed response → 500/BRIDGE_NOT_CONFIGURED so this one
        // code is the only signal we need here.
        if (!$result['ok'] && ($result['error_code'] ?? '') === 'BRIDGE_NOT_CONFIGURED') {
            \wp_send_json_error([
                'state'   => 'bad_credentials',
                'host'    => $host,
                'message' => $result['error'] ?? __('Credentials rejected.', 'b360-bridge'),
            ]);
            return;
        }

        // Any other non-OK response → treat as unreachable/generic failure
        if (!$result['ok']) {
            \wp_send_json_error([
                'state'   => 'unreachable',
                'host'    => $host,
                'message' => $result['error'] ?? __('Unexpected error.', 'b360-bridge'),
            ]);
            return;
        }

        // Success
        \wp_send_json_success([
            'state'      => 'ok',
            'host'       => $host,
            'client_name' => $result['data']['client'] ?? '',
            'latency_ms' => $latency_ms,
        ]);
    }

    public function render(): void
    {
        if (!\current_user_can('manage_options')) return;

        $has_creds = Options::get_base_host() !== ''
            && Options::get_bridge_client_id() !== ''
            && Options::get_bridge_client_secret() !== '';
        $test_nonce = \wp_create_nonce('b360_test_connection');

        echo '<div class="wrap">';
        echo '<h1>' . \esc_html__('Bottle360 Bridge', 'b360-bridge') . '</h1>';

        // --- Connection status area ---
        echo '<div id="b360-connection-banner" style="margin: 10px 0;">';
        if (!$has_creds) {
            echo '<div class="notice notice-info inline" style="margin: 0;"><p>'
                . \esc_html__('Not configured yet. Fill in Admin Site URL, Client ID, and Client Secret below, then click Test Connection.', 'b360-bridge')
                . '</p></div>';
        }
        echo '</div>';

        echo '<p style="margin: 10px 0;">'
            . '<button type="button" class="button" id="b360-test-conn-btn"'
            . ' data-nonce="' . \esc_attr($test_nonce) . '"'
            . ' data-autorun="' . ($has_creds ? '1' : '0') . '">'
            . \esc_html__('Test Connection', 'b360-bridge')
            . '</button>'
            . ' <span id="b360-test-conn-status" style="margin-left: 8px;"></span>'
            . '</p>';

        // --- How-to-use blurb ---
        echo '<p class="description" style="max-width: 680px; margin-bottom: 16px;">'
            . \esc_html__('This plugin embeds your Bottle360 storefront into WordPress. Point it at your admin site below, paste the Client ID and Secret from ', 'b360-bridge')
            . '<strong>' . \esc_html__('Settings → Bridge API → API Clients', 'b360-bridge') . '</strong>'
            . \esc_html__(' in the admin panel, then drop ', 'b360-bridge')
            . '<code>[b360_app]</code>'
            . \esc_html__(' on a page. Use ', 'b360-bridge')
            . '<code>[b360_nav]</code>'
            . \esc_html__(' in your header and ', 'b360-bridge')
            . '<code>[b360_product_card]</code>'
            . \esc_html__(' on landing pages.', 'b360-bridge')
            . '</p>';

        echo '<form action="options.php" method="post">';
        \settings_fields('b360_bridge');
        \do_settings_sections('b360_bridge');
        \submit_button();
        echo '</form>';

        $this->render_error_log();
        $this->render_shortcodes_section();

        echo '</div>'; // .wrap

        $this->render_admin_js();
    }

    private function render_error_log(): void
    {
        // Always render (no debug-mode gate), log entries are written regardless of debug mode.
        $entries = \Bottle360\Bridge\Api\ApiErrorLog::get_entries();
        $count = count($entries);
        // Refused request tokens (BD-4921) are kept apart from the upstream
        // errors so they can never crowd them out; same Clear button.
        $refusals = \Bottle360\Bridge\Api\ApiErrorLog::get_token_refusals();
        $nonce = \wp_create_nonce('b360_clear_error_log');
        ?>
        <div id="b360-error-log" style="margin-top: 30px;">
            <h2 style="cursor: pointer; user-select: none;" onclick="document.getElementById('b360-el-body').style.display = document.getElementById('b360-el-body').style.display === 'none' ? '' : 'none';">
                <?php echo \esc_html__('API Error Log', 'b360-bridge'); ?>
                (<?php echo (int) $count; ?>)
                <span style="font-size: 13px; font-weight: normal; color: #888;">&#9660; <?php echo \esc_html__('click to expand', 'b360-bridge'); ?></span>
            </h2>
            <div id="b360-el-body" style="display: none;">
                <?php if ($count > 0 || !empty($refusals)): ?>
                    <p>
                        <button type="button" class="button" id="b360-clear-log-btn" data-nonce="<?php echo \esc_attr($nonce); ?>">
                            <?php echo \esc_html__('Clear Log', 'b360-bridge'); ?>
                        </button>
                    </p>
                <?php endif; ?>
                <?php if ($count === 0): ?>
                    <p class="description"><?php echo \esc_html__('No errors logged.', 'b360-bridge'); ?></p>
                <?php else: ?>
                    <table class="widefat striped" style="max-width: 100%; table-layout: fixed;">
                        <thead>
                            <tr>
                                <th style="width: 160px;"><?php echo \esc_html__('Time (UTC)', 'b360-bridge'); ?></th>
                                <th style="width: 60px;"><?php echo \esc_html__('Method', 'b360-bridge'); ?></th>
                                <th><?php echo \esc_html__('URL', 'b360-bridge'); ?></th>
                                <th style="width: 60px;"><?php echo \esc_html__('Status', 'b360-bridge'); ?></th>
                                <th><?php echo \esc_html__('Error', 'b360-bridge'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($entries as $i => $e): ?>
                                <tr style="cursor: pointer;" onclick="var el = document.getElementById('b360-el-detail-<?php echo (int) $i; ?>'); el.style.display = el.style.display === 'none' ? 'table-row' : 'none';">
                                    <td><?php echo \esc_html($e['time'] ?? ''); ?></td>
                                    <td><code><?php echo \esc_html($e['method'] ?? ''); ?></code></td>
                                    <td style="word-break: break-all;"><?php echo \esc_html($e['url'] ?? ''); ?></td>
                                    <td><?php echo (int) ($e['status'] ?? 0); ?></td>
                                    <td><?php echo \esc_html($e['error'] ?? ''); ?></td>
                                </tr>
                                <tr id="b360-el-detail-<?php echo (int) $i; ?>" style="display: none;">
                                    <td colspan="5">
                                        <pre style="white-space: pre-wrap; word-break: break-all; max-height: 200px; overflow: auto; background: #f5f5f5; padding: 8px; font-size: 12px;"><?php echo \esc_html($e['body'] ?? '(no body)'); ?></pre>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
                <?php if (!empty($refusals)): ?>
                    <h3 style="margin-top: 24px;">
                        <?php echo \esc_html__('Request token refusals', 'b360-bridge'); ?>
                        (<?php echo (int) count($refusals); ?>)
                    </h3>
                    <p class="description"><?php echo \esc_html__('Storefront writes refused with "Invalid or missing nonce", newest first. Retry = Yes means the shopper was refused again with a freshly fetched token.', 'b360-bridge'); ?></p>
                    <table class="widefat striped" style="max-width: 100%; table-layout: fixed;">
                        <thead>
                            <tr>
                                <th style="width: 160px;"><?php echo \esc_html__('Time (UTC)', 'b360-bridge'); ?></th>
                                <th style="width: 60px;"><?php echo \esc_html__('Method', 'b360-bridge'); ?></th>
                                <th><?php echo \esc_html__('Route', 'b360-bridge'); ?></th>
                                <th style="width: 110px;"><?php echo \esc_html__('Reason', 'b360-bridge'); ?></th>
                                <th style="width: 60px;"><?php echo \esc_html__('Retry', 'b360-bridge'); ?></th>
                                <th style="width: 130px;"><?php echo \esc_html__('Token / server tick', 'b360-bridge'); ?></th>
                                <th><?php echo \esc_html__('Cookies present', 'b360-bridge'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($refusals as $r): ?>
                                <?php
                                if (!is_array($r)) continue;
                                $r_cookies = is_array($r['cookies'] ?? null) ? array_keys(array_filter($r['cookies'])) : [];
                                $r_tick    = isset($r['token_tick']) ? (string) (int) $r['token_tick'] : '?';
                                ?>
                                <tr>
                                    <td><?php echo \esc_html((string) ($r['time'] ?? '')); ?></td>
                                    <td><code><?php echo \esc_html((string) ($r['method'] ?? '')); ?></code></td>
                                    <td style="word-break: break-all;"><?php echo \esc_html((string) ($r['route'] ?? '')); ?></td>
                                    <td><?php echo \esc_html((string) ($r['reason'] ?? '')); ?></td>
                                    <td><?php echo !empty($r['retry']) ? \esc_html__('Yes', 'b360-bridge') : \esc_html__('No', 'b360-bridge'); ?></td>
                                    <td><?php echo \esc_html($r_tick . ' / ' . (int) ($r['server_tick'] ?? 0)); ?></td>
                                    <td style="word-break: break-all;"><?php echo \esc_html($r_cookies ? implode(', ', array_map('strval', $r_cookies)) : '(none)'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    private function render_shortcodes_section(): void
    {
        ?>
        <div id="b360-shortcodes" style="margin-top: 30px;">
            <h2 style="cursor: pointer; user-select: none;" onclick="document.getElementById('b360-sc-body').style.display = document.getElementById('b360-sc-body').style.display === 'none' ? '' : 'none';">
                <?php echo \esc_html__('Shortcodes', 'b360-bridge'); ?>
                <span style="font-size: 13px; font-weight: normal; color: #888;">&#9660; <?php echo \esc_html__('click to expand', 'b360-bridge'); ?></span>
            </h2>
            <div id="b360-sc-body" style="display: none;">
                <table class="widefat striped" style="max-width: 1100px;">
                    <thead>
                        <tr>
                            <th style="width: 260px;"><?php echo \esc_html__('Shortcode', 'b360-bridge'); ?></th>
                            <th><?php echo \esc_html__('What it does', 'b360-bridge'); ?></th>
                            <th style="width: 210px;"><?php echo \esc_html__('Attributes', 'b360-bridge'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>[b360_app]</code></td>
                            <td><?php echo \esc_html__('Your store itself. This one is added for you when you first set up the app, on the page at your store slug. It powers the product list page, starting with your default category, and every store page underneath it. You should not normally need to add this by hand.', 'b360-bridge'); ?></td>
                            <td><em><?php echo \esc_html__('(none)', 'b360-bridge'); ?></em></td>
                        </tr>
                        <tr>
                            <td><code>[b360_nav]</code></td>
                            <td><?php echo \esc_html__('A ready-made navigation bar showing your product categories, the sign-in button and the cart button. Designed for simple, fast site builds. Optional: remove it if your own theme menu already covers this. See the variations below for using just one piece of it.', 'b360-bridge'); ?></td>
                            <td>
                                <code>show_shop</code>, <code>show_cart</code>, <code>show_account</code>,
                                <code>show_clubs</code>, <code>show_login</code>, <code>show_logout</code>,
                                <code>class</code>
                            </td>
                        </tr>
                        <tr>
                            <td><code>[b360_product_card sku="yourSKUhere"]</code></td>
                            <td><?php echo \esc_html__('Shows one specific product anywhere on your site, including the homepage, as a card with its teaser, price, quantity box and Add to Cart button. Replace yourSKUhere with the product\'s Bottle360 SKU, keeping the quote marks.', 'b360-bridge'); ?></td>
                            <td>
                                <code>sku</code>, <code>param</code>, <code>class</code>,
                                <code>empty</code>, <code>empty_text</code>
                            </td>
                        </tr>
                        <tr>
                            <td><code>[b360_collections slug="your-category-slug"]</code></td>
                            <td><?php echo \esc_html__('Shows just one collection of products as a grid, on any page. Find the slug in Bottle360 under Products, then Product Categories, in the "slug" column. It usually looks like red-wine or white-wine.', 'b360-bridge'); ?></td>
                            <td>
                                <code>slug</code>, <code>per_page</code>, <code>class</code>
                            </td>
                        </tr>
                        <tr>
                            <td><code>[b360_clubs]</code></td>
                            <td><?php echo \esc_html__('Shows your wine club options in the default design, on a page other than your main Club page. Not required. If you would rather keep your existing WordPress club page, link its buttons straight to a club sign-up URL instead, for example https://www.yourwinery.com/store/clubs/red-wine-club', 'b360-bridge'); ?></td>
                            <td>
                                <code>ids</code>, <code>cols</code>, <code>class</code>
                            </td>
                        </tr>
                        <tr>
                            <td><code>[b360_form slug="your-form-slug"]</code></td>
                            <td><?php echo \esc_html__('Shows one of your forms, such as a newsletter sign-up, on any page or in any widget area. Find the slug in Bottle360 under Website Content, then Forms. For the best sign-up rate we recommend asking for the email address only, or at most first name, last name and email.', 'b360-bridge'); ?></td>
                            <td>
                                <code>slug</code>, <code>submit_label</code>, <code>layout</code>,
                                <code>class</code>
                            </td>
                        </tr>
                        <tr>
                            <td><code>[b360_book room="your-pourup-room"]</code></td>
                            <td><?php echo \esc_html__('Adds a "Book a visit" button that opens your PourUp booking sheet in a pop-up, styled like your store, on any page. Replace your-pourup-room with your room\'s slug from PourUp, keeping the quote marks. Add mode="inline" to show the booking sheet in the page itself instead of a pop-up, and experience="123" or event="your-event-slug" to book one specific experience or event.', 'b360-bridge'); ?></td>
                            <td>
                                <code>room</code>, <code>mode</code>, <code>label</code>,
                                <code>experience</code>, <code>event</code>, <code>locations</code>,
                                <code>host</code>, <code>class</code>, <code>empty</code>,
                                <code>empty_text</code>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <h3 style="margin-bottom: 4px;"><?php echo \esc_html__('Handy variations', 'b360-bridge'); ?></h3>
                <p class="description" style="margin-top: 0;">
                    <?php echo \esc_html__('The nav shortcode can be cut down to a single piece, which is useful in a header or sidebar widget.', 'b360-bridge'); ?>
                </p>
                <table class="widefat striped" style="max-width: 1100px; margin-bottom: 12px;">
                    <tbody>
                        <tr>
                            <td style="width: 260px;"><code>[b360_nav show_login="true"]</code></td>
                            <td><?php echo \esc_html__('Just the Sign in / Welcome section, so visitors can log in or create an account.', 'b360-bridge'); ?></td>
                        </tr>
                        <tr>
                            <td><code>[b360_nav show_cart="true"]</code></td>
                            <td><?php echo \esc_html__('Just the cart icon. The item count updates on its own, and clicking it opens the cart.', 'b360-bridge'); ?></td>
                        </tr>
                    </tbody>
                </table>

                <p class="description" style="margin-top: 8px;">
                    <?php echo \esc_html__('Hyphen spellings work too, so [b360-nav], [b360-product-card], [b360-collections], [b360-clubs] and [b360-form] all behave the same as the underscore versions. The only exception is [b360_app], which has no hyphen form.', 'b360-bridge'); ?>
                </p>
            </div>
        </div>
        <?php
    }

    private function render_admin_js(): void
    {
        ?>
        <script>
        (function () {
            // --- Test Connection ---
            var testBtn = document.getElementById('b360-test-conn-btn');
            var testStatus = document.getElementById('b360-test-conn-status');
            var banner = document.getElementById('b360-connection-banner');

            function runConnectionTest() {
                if (!testBtn) return;
                var nonce = testBtn.dataset.nonce;
                testBtn.disabled = true;
                testStatus.textContent = '<?php echo \esc_js(__('Testing…', 'b360-bridge')); ?>';
                testStatus.style.color = '#888';

                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=b360_test_connection&_nonce=' + encodeURIComponent(nonce)
                })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    testBtn.disabled = false;
                    banner.innerHTML = '';
                    if (d.success && d.data && d.data.state === 'ok') {
                        testStatus.textContent = '';
                        banner.innerHTML = '<div class="notice notice-success inline" style="margin: 0;"><p>'
                            + '&#10003; <?php echo \esc_js(__('Connected to', 'b360-bridge')); ?> ' + escHtml(d.data.host)
                            + ' <?php echo \esc_js(__('as', 'b360-bridge')); ?> ' + escHtml(d.data.client_name)
                            + ' (' + escHtml(String(d.data.latency_ms)) + 'ms)'
                            + '</p></div>';
                    } else if (d.data && d.data.state === 'bad_credentials') {
                        testStatus.textContent = '';
                        banner.innerHTML = '<div class="notice notice-warning inline" style="margin: 0;"><p>'
                            + '&#9888; <?php echo \esc_js(__('Reachable but credentials rejected, check Client ID / Secret', 'b360-bridge')); ?>'
                            + '</p></div>';
                    } else {
                        var msg = (d.data && d.data.message) ? d.data.message : '<?php echo \esc_js(__('Unknown error.', 'b360-bridge')); ?>';
                        var host = (d.data && d.data.host) ? d.data.host : '';
                        testStatus.textContent = '';
                        banner.innerHTML = '<div class="notice notice-error inline" style="margin: 0;"><p>'
                            + '&#10007; <?php echo \esc_js(__('Could not reach', 'b360-bridge')); ?> ' + escHtml(host)
                            + ' &mdash; ' + escHtml(msg)
                            + '</p></div>';
                    }
                })
                .catch(function (err) {
                    testBtn.disabled = false;
                    testStatus.textContent = '<?php echo \esc_js(__('Request failed.', 'b360-bridge')); ?>';
                    testStatus.style.color = '#d63638';
                });
            }

            if (testBtn) {
                testBtn.addEventListener('click', runConnectionTest);
                // Auto-run on page load if creds are configured (button carries a flag)
                if (testBtn.dataset.autorun === '1') {
                    runConnectionTest();
                }
            }

            // --- Clear Error Log ---
            var clearLogBtn = document.getElementById('b360-clear-log-btn');
            if (clearLogBtn) {
                clearLogBtn.addEventListener('click', function () {
                    if (!confirm('<?php echo \esc_js(__('Clear all logged API errors?', 'b360-bridge')); ?>')) return;
                    var nonce = this.dataset.nonce;
                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'action=b360_clear_error_log&_nonce=' + encodeURIComponent(nonce)
                    })
                    .then(function (r) { return r.json(); })
                    .then(function (d) {
                        if (d.success) { location.reload(); }
                        else { alert('<?php echo \esc_js(__('Failed to clear log.', 'b360-bridge')); ?>'); }
                    });
                });
            }

            // --- Flush Cache ---
            var flushBtn = document.getElementById('b360-flush-cache-btn');
            var flushStatus = document.getElementById('b360-flush-cache-status');
            if (flushBtn) {
                flushBtn.addEventListener('click', function () {
                    var nonce = this.dataset.nonce;
                    flushBtn.disabled = true;
                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'action=b360_flush_cache&_nonce=' + encodeURIComponent(nonce)
                    })
                    .then(function (r) { return r.json(); })
                    .then(function (d) {
                        flushBtn.disabled = false;
                        if (d.success) {
                            flushStatus.textContent = '<?php echo \esc_js(__('Cleared', 'b360-bridge')); ?>';
                            flushStatus.style.color = '#46b450';
                            setTimeout(function () { flushStatus.textContent = ''; }, 2000);
                        } else {
                            flushStatus.textContent = '<?php echo \esc_js(__('Failed.', 'b360-bridge')); ?>';
                            flushStatus.style.color = '#d63638';
                        }
                    })
                    .catch(function () {
                        flushBtn.disabled = false;
                        flushStatus.textContent = '<?php echo \esc_js(__('Failed.', 'b360-bridge')); ?>';
                        flushStatus.style.color = '#d63638';
                    });
                });
            }

            // --- Disconnect / Reconnect app page ---
            function postAjax(action, nonce, extra) {
                var body = 'action=' + encodeURIComponent(action)
                         + '&_nonce=' + encodeURIComponent(nonce);
                if (extra) {
                    Object.keys(extra).forEach(function (k) {
                        body += '&' + encodeURIComponent(k) + '=' + encodeURIComponent(extra[k]);
                    });
                }
                return fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: body,
                }).then(function (r) { return r.json(); });
            }

            function wireDisconnect(btn, deletePage) {
                if (!btn) return;
                btn.addEventListener('click', function () {
                    var msg = deletePage
                        ? '<?php echo \esc_js(__('Disconnect and move the app page to Trash? The storefront will stop working until you reconnect.', 'b360-bridge')); ?>'
                        : '<?php echo \esc_js(__('Disconnect the plugin from this page? The page itself will stay in place; the storefront will stop working until you reconnect.', 'b360-bridge')); ?>';
                    if (!window.confirm(msg)) return;

                    var status = document.getElementById('b360-disconnect-status');
                    btn.disabled = true;
                    if (status) { status.textContent = '<?php echo \esc_js(__('Working…', 'b360-bridge')); ?>'; status.style.color = '#666'; }
                    postAjax('b360_disconnect_app_page', btn.dataset.nonce, deletePage ? {delete_page: '1'} : null)
                        .then(function (d) {
                            if (d.success) { location.reload(); }
                            else {
                                btn.disabled = false;
                                if (status) { status.textContent = (d.data && d.data.message) || '<?php echo \esc_js(__('Failed.', 'b360-bridge')); ?>'; status.style.color = '#d63638'; }
                            }
                        })
                        .catch(function () {
                            btn.disabled = false;
                            if (status) { status.textContent = '<?php echo \esc_js(__('Failed.', 'b360-bridge')); ?>'; status.style.color = '#d63638'; }
                        });
                });
            }
            wireDisconnect(document.getElementById('b360-disconnect-btn'), false);
            wireDisconnect(document.getElementById('b360-disconnect-delete-btn'), true);

            var reconnectBtn = document.getElementById('b360-reconnect-btn');
            if (reconnectBtn) {
                reconnectBtn.addEventListener('click', function () {
                    var status = document.getElementById('b360-reconnect-status');
                    reconnectBtn.disabled = true;
                    if (status) { status.textContent = '<?php echo \esc_js(__('Working…', 'b360-bridge')); ?>'; status.style.color = '#666'; }
                    postAjax('b360_reconnect_app_page', reconnectBtn.dataset.nonce)
                        .then(function (d) {
                            if (d.success) { location.reload(); }
                            else {
                                reconnectBtn.disabled = false;
                                if (status) { status.textContent = (d.data && d.data.message) || '<?php echo \esc_js(__('Failed.', 'b360-bridge')); ?>'; status.style.color = '#d63638'; }
                            }
                        })
                        .catch(function () {
                            reconnectBtn.disabled = false;
                            if (status) { status.textContent = '<?php echo \esc_js(__('Failed.', 'b360-bridge')); ?>'; status.style.color = '#d63638'; }
                        });
                });
            }

            // --- HTML escaping helper ---
            function escHtml(str) {
                return String(str)
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;');
            }
        }());
        </script>
        <?php
    }

    // --- Sanitizers ---
    public function sanitize_url($value): string
    {
        $value = trim(\sanitize_text_field((string) $value));
        return $value === '' ? '' : \esc_url_raw($value);
    }

    public function sanitize_bool($value): bool
    {
        return (bool) $value;
    }
}
