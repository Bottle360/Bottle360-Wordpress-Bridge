<?php

namespace Bottle360\Bridge\Shortcodes;

use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * [b360_book] / [b360-book]
 *
 * "Book a visit" on an arbitrary theme/marketing page: renders the
 * [data-b360-widget="book"] placeholder the shared Vue app (Root.vue) fills
 * in with PourUp's booking sheet, loading PourUp's widget.js once per page
 * with the Styling Studio look on the tag so the sheet matches the store.
 * The Squarespace counterpart is the raw div; on WordPress this shortcode
 * emits the same contract.
 *
 * Usage:
 *   [b360_book room="sharma-tasting-room-1403"]
 *   [b360_book room="château-tasting-room-1403"]
 *   [b360_book room="sharma-tasting-room-1403" label="Reserve a tasting"]
 *   [b360_book room="sharma-tasting-room-1403" mode="inline"]
 *   [b360_book room="sharma-tasting-room-1403" experience="42"]
 *   [b360_book room="sharma-tasting-room-1403" event="harvest-dinner"]
 *   [b360_book room="sharma-tasting-room-1403" locations="all"]
 *
 *   room        the PourUp room (location) slug: letters, digits, "_" and "-", lowercased,
 *               Unicode letters included (see slug() for the accepted and rejected cases)
 *   mode        button (default, opens a pop-up) | inline (the sheet in the page)
 *   label       the button text, default "Book a visit"
 *   experience  a specific experience id (digits); wins over event when both are set
 *   event       a specific event slug, same rule as room
 *   locations   "all" lets the sheet offer the winery's other rooms
 *   host        the PourUp origin for a dev/staging site. Accepted: https://pourup.com,
 *               https://*.pourup.com, https://*.pourup.net, and http(s)://localhost or
 *               http(s)://127.0.0.1 with an optional port (a local PourUp app). Anything
 *               else (http://pourup.com, pourup.com.evil.com, evil.com/pourup.com,
 *               javascript:) is dropped silently and https://pourup.com is used.
 *   class       extra classes on the placeholder
 *   empty       hide|message, what to render when no room is given
 *   empty_text  the message for empty="message", default "Missing PourUp room."
 *
 * The placeholder's initial content is a real link to the winery's PourUp
 * page, so the page works before Vue boots and when scripts are blocked.
 */
final class BookShortcode
{
    const DEFAULT_HOST = 'https://pourup.com';

    public function register(): void
    {
        add_shortcode('b360_book', [$this, 'render']);
        add_shortcode('b360-book', [$this, 'render']);
    }

    public function render($atts = []): string
    {
        $raw_atts = is_array($atts) ? $atts : [];

        $atts = shortcode_atts([
            'room'       => '',        // PourUp room (location) slug
            'mode'       => 'button',  // button|inline
            'label'      => '',        // button text (default below when empty)
            'experience' => '',        // specific experience id (digits)
            'event'      => '',        // specific event slug
            'locations'  => '',        // "all" to offer the winery's other rooms
            'host'       => '',        // PourUp origin for dev/staging sites
            'class'      => '',
            'empty'      => 'hide',    // hide|message
            'empty_text' => __('Missing PourUp room.', 'b360-bridge'),
        ], $raw_atts, 'b360_book');

        // The room is required for now; a later slice takes it from the Bridge config when the shortcode leaves it out.
        $room = self::slug((string) $atts['room']);

        if ($room === '') {
            if ((string) $atts['empty'] === 'message') {
                return '<div class="b360-book-container b360-book--empty">' . esc_html((string) $atts['empty_text']) . '</div>';
            }
            return '';
        }

        $mode = strtolower(trim((string) $atts['mode'])) === 'inline' ? 'inline' : 'button';

        $label = trim(sanitize_text_field((string) $atts['label']));
        if ($label === '') $label = __('Book a visit', 'b360-bridge');

        // An experience wins over an event when both are set, the loader's own rule.
        $experience = trim((string) $atts['experience']);
        if (!preg_match('/^\d+$/', $experience)) $experience = '';
        $event = $experience === '' ? self::slug((string) $atts['event']) : '';

        $locations = in_array(strtolower(trim((string) $atts['locations'])), ['1', 'true', 'yes', 'all'], true);

        $host = self::host((string) $atts['host']);

        // Same base-path source every other widget uses (BridgeBoot, AppShortcode).
        // Emitted as data-base-path to keep the placeholder contract identical
        // across shortcodes; the book widget itself does not read it.
        $basePath = Options::get_app_base_path();
        $id = 'b360-book-' . wp_generate_password(6, false);

        $classes = ['b360-book-container', 'b360-bridge-container'];
        $extra = trim((string) $atts['class']);
        if ($extra !== '') {
            foreach (preg_split('/\s+/', $extra) as $token) {
                $clean = sanitize_html_class((string) $token);
                if ($clean !== '') $classes[] = $clean;
            }
        }
        $classes = array_filter($classes, 'strlen');

        // Optional attributes only when set, so the widget's own defaults
        // apply otherwise (mirrors the JS-side reads in BookWidget.vue).
        $extraAttrs = '';
        if ($experience !== '') $extraAttrs .= ' data-b360-experience="' . esc_attr($experience) . '"';
        if ($event !== '') $extraAttrs .= ' data-b360-event="' . esc_attr($event) . '"';
        if ($locations) $extraAttrs .= ' data-b360-locations="all"';
        if ($host !== self::DEFAULT_HOST) $extraAttrs .= ' data-b360-host="' . esc_attr($host) . '"';

        $pageUrl = $host . '/wineries/' . rawurlencode($room);

        ob_start(); ?>
<div id="<?php echo esc_attr($id); ?>"
     class="<?php echo esc_attr(implode(' ', $classes)); ?>"
     data-b360-widget="book"
     data-b360-room="<?php echo esc_attr($room); ?>"
     data-b360-mode="<?php echo esc_attr($mode); ?>"
     data-b360-label="<?php echo esc_attr($label); ?>"<?php echo $extraAttrs; ?>
     data-base-path="<?php echo esc_attr($basePath); ?>">
  <a class="b360-book-fallback" href="<?php echo esc_url($pageUrl); ?>" target="_blank" rel="noopener"><?php echo esc_html($label); ?></a>
</div>
<?php
        return (string) ob_get_clean();
    }

    /**
     * A PourUp room or event slug. PourUp builds slugs Unicode-aware
     * (PourUP.Core/Helper/LocationSlugHelper.cs, char.IsLetterOrDigit), so
     * "château-tasting-room-1403" is a real slug and must survive. The value
     * is lowercased and accepted only when every character is a letter, a
     * digit, "_" or "-" (/^[\p{L}\p{N}_-]+$/u); any other character makes
     * the whole value invalid and the result is empty. Nothing is stripped: a
     * mangled slug is a 404 link to a room that does not exist.
     *
     *   accepted: sharma-tasting-room-1403, château-tasting-room-1403,
     *             Harvest_Dinner (as harvest_dinner)
     *   rejected: "x y", "<x>", "x/y", "" (all give "")
     *
     * Mirrors pourupSlug() in shared/utils/pourupBook.ts.
     */
    private static function slug(string $raw): string
    {
        $value = trim($raw);
        // Without mbstring the strtolower fallback is ASCII-only, so an upper-case accented slug can come out wrong on such a host.
        $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
        return preg_match('/^[\p{L}\p{N}_-]+$/u', $value) === 1 ? $value : '';
    }

    /**
     * The PourUp origin the shortcode may name (see the class docblock for the
     * allowlist). Mirrors pourupHost() in shared/utils/pourupBook.ts. The
     * result is an origin: any path, query or userinfo is dropped.
     */
    private static function host(string $raw): string
    {
        $raw = trim($raw);
        if ($raw === '') return self::DEFAULT_HOST;

        $parts = wp_parse_url($raw);
        if (!is_array($parts) || empty($parts['host']) || empty($parts['scheme'])) return self::DEFAULT_HOST;

        $scheme = strtolower((string) $parts['scheme']);
        $host = strtolower((string) $parts['host']);
        $local = $host === 'localhost' || $host === '127.0.0.1';
        $pourup = $host === 'pourup.com'
            || self::endsWith($host, '.pourup.com')
            || self::endsWith($host, '.pourup.net');

        if ($local) {
            if ($scheme !== 'http' && $scheme !== 'https') return self::DEFAULT_HOST;
        } elseif (!$pourup || $scheme !== 'https') {
            return self::DEFAULT_HOST;
        }

        $origin = $scheme . '://' . $host;
        if (!empty($parts['port'])) $origin .= ':' . (int) $parts['port'];
        return $origin;
    }

    /** PHP 7.4 has no str_ends_with. */
    private static function endsWith(string $haystack, string $needle): bool
    {
        $len = strlen($needle);
        return $len <= strlen($haystack) && substr($haystack, -$len) === $needle;
    }
}
