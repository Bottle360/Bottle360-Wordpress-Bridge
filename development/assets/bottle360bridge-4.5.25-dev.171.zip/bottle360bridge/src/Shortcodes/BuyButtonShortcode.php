<?php

namespace Bottle360\Bridge\Shortcodes;

use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * [b360_buy_button] / [b360-buy-button]
 *
 * A live "buy button" for an arbitrary theme/marketing page, renders the
 * [data-b360-widget="buy-button"] placeholder the shared Vue app (Root.vue)
 * fills in with the SKU's real price, sold-out state, and add-to-cart. The
 * Squarespace counterpart is the raw div; on WordPress this shortcode emits
 * the same contract.
 *
 * Usage:
 *   [b360_buy_button sku="21NCS"]
 *   [b360_buy_button sku="21NCS" label="Add to cart" show_price="1"]
 *   [b360_buy_button]              (with ?sku=21NCS in the URL)
 *
 * BD-5165, members-only and allocated wines:
 *   signin_label="Sign in to acquire"  text when the wine is members-only and
 *                                      the visitor is not signed in; the click
 *                                      opens Sign In and returns to this page
 *   join_url="/wine-club"              a signed-in visitor who is not eligible
 *                                      gets a live button to this page instead
 *                                      of a dead "Members only"
 *   join_label="Join to acquire"       text for that button
 *   qty="1"                            quantity stepper beside the button,
 *                                      seeded at the minimum, capped at the
 *                                      maximum, limit printed underneath
 */
final class BuyButtonShortcode
{
    public function register(): void
    {
        add_shortcode('b360_buy_button', [$this, 'render']);
        add_shortcode('b360-buy-button', [$this, 'render']);
    }

    public function render($atts = []): string
    {
        $raw_atts = is_array($atts) ? $atts : [];

        $atts = shortcode_atts([
            'sku'        => '',
            'param'      => 'sku',   // GET param fallback
            'label'      => '',      // button text (widget default when empty)
            'show_price' => '',      // "1" to append the price to the label
            // BD-5165: members-only wines and an optional quantity stepper.
            'signin_label' => '',    // text when members-only and not signed in
            'join_url'     => '',    // page for a signed-in but ineligible visitor
            'join_label'   => '',    // text for that button
            'qty'          => '',    // "1" shows the quantity stepper
            'class'      => '',
            'empty'      => 'hide',  // hide|message
            'empty_text' => __('Missing product SKU.', 'b360-bridge'),
        ], $raw_atts, 'b360_buy_button');

        // Resolve SKU: shortcode sku wins, else GET[param].
        $sku = '';
        if (!empty($atts['sku']) && is_string($atts['sku'])) {
            $sku = (string) $atts['sku'];
        } else {
            $param = sanitize_key((string) $atts['param']);
            if ($param === '') $param = 'sku';
            if (isset($_GET[$param])) {
                $sku = (string) wp_unslash($_GET[$param]);
            }
        }
        $sku = trim(sanitize_text_field($sku));

        if ($sku === '') {
            if ((string) $atts['empty'] === 'message') {
                return '<div class="b360-buy-button-container b360-buy-button--empty">' . esc_html((string) $atts['empty_text']) . '</div>';
            }
            return '';
        }

        $label = trim(sanitize_text_field((string) $atts['label']));
        $showPrice = in_array(strtolower(trim((string) $atts['show_price'])), ['1', 'true', 'yes'], true);

        // Same base-path source every other widget uses (BridgeBoot, AppShortcode).
        $basePath = Options::get_app_base_path();
        $id = 'b360-buy-button-' . wp_generate_password(6, false);

        $classes = ['b360-buy-button-container', 'b360-bridge-container'];
        $extra = trim((string) $atts['class']);
        if ($extra !== '') {
            foreach (preg_split('/\s+/', $extra) as $token) {
                $clean = sanitize_html_class((string) $token);
                if ($clean !== '') $classes[] = $clean;
            }
        }
        $classes = array_filter($classes, 'strlen');

        // Emit data-b360-label / data-b360-show-price only when set, so the
        // widget's own defaults apply otherwise (mirrors the JS-side reads).
        $labelAttr = $label !== '' ? ' data-b360-label="' . esc_attr($label) . '"' : '';
        $showPriceAttr = $showPrice ? ' data-b360-show-price="1"' : '';

        // BD-5165: the same rule, an attribute only when the shortcode set it.
        // join_url goes through esc_url so a javascript: value is dropped
        // here as well as in the widget.
        $signinLabel = trim(sanitize_text_field((string) $atts['signin_label']));
        $joinUrl = esc_url(trim((string) $atts['join_url']));
        $joinLabel = trim(sanitize_text_field((string) $atts['join_label']));
        $qty = in_array(strtolower(trim((string) $atts['qty'])), ['1', 'true', 'yes'], true);
        $extraAttrs = '';
        if ($signinLabel !== '') $extraAttrs .= ' data-b360-signin-label="' . esc_attr($signinLabel) . '"';
        if ($joinUrl !== '') $extraAttrs .= ' data-b360-join-url="' . esc_attr($joinUrl) . '"';
        if ($joinLabel !== '') $extraAttrs .= ' data-b360-join-label="' . esc_attr($joinLabel) . '"';
        if ($qty) $extraAttrs .= ' data-b360-qty="1"';

        ob_start(); ?>
<div id="<?php echo esc_attr($id); ?>"
     class="<?php echo esc_attr(implode(' ', $classes)); ?>"
     data-b360-widget="buy-button"
     data-b360-sku="<?php echo esc_attr($sku); ?>"<?php echo $labelAttr . $showPriceAttr . $extraAttrs; ?>
     data-base-path="<?php echo esc_attr($basePath); ?>">
  <div class="b360-loading" aria-live="polite"><?php echo esc_html__('Loading…', 'b360-bridge'); ?></div>
</div>
<?php
        return (string) ob_get_clean();
    }
}
