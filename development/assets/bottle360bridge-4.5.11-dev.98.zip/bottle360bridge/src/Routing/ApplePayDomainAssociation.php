<?php

namespace Bottle360\Bridge\Routing;

if (!defined('ABSPATH')) exit;

/**
 * Serves NMI's Apple Pay domain verification file (BD-2276).
 *
 * Apple Pay validates the merchant against the host of the page the shopper is
 * on, so each winery's own domain has to be registered for Apple Pay on that
 * winery's NMI account, and NMI (then Apple) will only accept a domain that
 * answers
 *
 *   GET /.well-known/apple-developer-merchantid-domain-association
 *
 * with HTTP 200 and the file's exact bytes, no redirect. WordPress has nothing
 * at that path (it 404s), and a winery should not need SFTP to add it, so the
 * plugin answers it.
 *
 * The file looks to be NMI's, not the merchant's: decoded it reads
 * {"version":1,"pspId":"...","createdOn":...} with no merchant field, so one
 * copy ships in the plugin for every winery. That is read off the one file
 * downloaded so far (the B360 TEST account); it has not yet been compared
 * with a second NMI account's download. If a winery's file differs, or NMI
 * reissues it before a plugin release carries the new one, replace it with
 * the contents filter.
 *
 * NMI matches the registered domain against the page's exact host, so a
 * winery whose store answers on both the apex and www needs both registered,
 * and this route answers on whichever host reaches WordPress.
 *
 * Rules, all pinned by wordpress/tests/apple-pay-domain-association.php:
 *  - exact match on the request path, query string ignored. No trailing-slash
 *    variant, no case folding, no decoding: anything else is not this file;
 *  - GET and HEAD only, and never from the command line (WP-CLI run with a
 *    --url that ends in the path must not print the file and exit);
 *  - a physical file at that path wins. Normally the web server serves it
 *    without ever starting PHP, so reaching here with one on disk means the
 *    host routed it to WordPress on purpose, and it is still not ours to
 *    replace;
 *  - every other request returns immediately, untouched: one string compare.
 *
 * Runs at the very END of plugins_loaded (priority PHP_INT_MAX), the hook the
 * spike plugin proved on WP Engine staging (200, octet-stream, 228 bytes, no
 * redirect, http and https). That is before WordPress parses the request, so
 * there is no 404 and no canonical redirect to dodge (redirect_canonical runs
 * on template_redirect), and before a theme loads. Last on the hook, not
 * first, so that every plugin has had its say: THE TWO FILTERS CAN BE ADDED
 * FROM ANY PLUGIN OR MU-PLUGIN, at load time or inside its own plugins_loaded
 * callback at any priority. A theme's functions.php is still too late: themes
 * load after plugins_loaded.
 *
 *   // Turn serving off (the site serves its own file some other way):
 *   add_filter('b360_bridge_apple_pay_domain_association_enabled', '__return_false');
 *
 *   // Replace the contents (NMI reissued the file):
 *   add_filter('b360_bridge_apple_pay_domain_association', function ($contents) {
 *       return file_get_contents(WPMU_PLUGIN_DIR . '/nmi-apple-pay-association');
 *   });
 */
final class ApplePayDomainAssociation
{
    /** The one path this class answers. Fixed by Apple. */
    public const PATH = '/.well-known/apple-developer-merchantid-domain-association';

    /** Filter: bool, default true. False (or anything falsy) turns serving off. */
    public const FILTER_ENABLED = 'b360_bridge_apple_pay_domain_association_enabled';

    /**
     * Filter: string, default the shipped file. Return the replacement bytes.
     * A non-string or empty return serves nothing (the request falls through
     * to WordPress), so a broken filter can never publish a corrupt file.
     */
    public const FILTER_CONTENTS = 'b360_bridge_apple_pay_domain_association';

    /**
     * The file exactly as NMI issued it (downloaded 2026-10-05): 228 bytes of
     * hex text, no trailing newline, md5 0db0c9e8afc25e24af5e1034f866ddf5.
     * A constant rather than a file on disk so no editor, line-ending
     * conversion or deploy step can add or strip a byte.
     */
    private const CONTENTS = '7b2276657273696f6e223a312c227073704964223a2234314646313133343946463537334546384444353844463231433430353032424341414634433742383833354337313039464638363746363343333537374630222c22637265617465644f6e223a313738353434303431313338337d';

    public function register(): void
    {
        // Plugin::boot() itself runs inside a plugins_loaded callback (default
        // priority, see b360-bridge.php), so this add_action lands on the hook
        // WHILE it is running. WordPress handles that: WP_Hook re-sorts its
        // live iteration when a callback is added mid-run, and a priority
        // later than the current one still fires in the same run. The test
        // drives the real WP_Hook to prove it.
        if (did_action('plugins_loaded') && !doing_action('plugins_loaded')) {
            // Booted after plugins_loaded finished: the hook will not fire
            // again, so answer now rather than never.
            $this->maybeServe();
            return;
        }
        add_action('plugins_loaded', [$this, 'maybeServe'], PHP_INT_MAX);
    }

    /**
     * Answer the request if it is for the verification file; otherwise return
     * having done nothing.
     */
    public function maybeServe(): void
    {
        // WP-CLI fills REQUEST_URI from --url and REQUEST_METHOD with GET. A
        // command line is never Apple or NMI fetching the file.
        if (PHP_SAPI === 'cli') return;

        $method = isset($_SERVER['REQUEST_METHOD']) ? (string) $_SERVER['REQUEST_METHOD'] : '';
        $uri    = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';

        $roots = [defined('ABSPATH') ? (string) ABSPATH : ''];
        // WordPress installed in its own directory: the site root, where the
        // file would live, is the document root rather than ABSPATH.
        if (!empty($_SERVER['DOCUMENT_ROOT'])) {
            $roots[] = (string) $_SERVER['DOCUMENT_ROOT'];
        }

        $body = self::resolve($method, $uri, $roots);
        if ($body === null) return;

        // Something already wrote to the client: a clean 200 with the exact
        // bytes is no longer possible, so leave the request to WordPress.
        if (headers_sent()) return;

        // The body must be these bytes and nothing else, at this length. So no
        // PHP-level compression (it would change the length under the header
        // below), and nothing an earlier plugin left in an output buffer (a
        // stray newline or BOM). Bounded loop: a buffer that refuses to close
        // is emptied instead, never retried forever.
        @ini_set('zlib.output_compression', '0');
        for ($level = ob_get_level(); $level > 0; $level--) {
            if (!@ob_end_clean()) {
                @ob_clean();
                break;
            }
        }

        status_header(200);
        header('Content-Type: application/octet-stream');
        header('Content-Length: ' . strlen($body));
        header('Cache-Control: public, max-age=300');
        header('X-Robots-Tag: noindex');
        if (strtoupper($method) !== 'HEAD') {
            echo $body;
        }
        exit;
    }

    /**
     * The decision, free of side effects: the bytes to serve, or null to let
     * the request through.
     *
     * @param string   $method     Request method.
     * @param string   $requestUri Raw REQUEST_URI (path plus optional query).
     * @param string[] $roots      Directories a physical copy of the file could
     *                             sit under (ABSPATH, the document root).
     */
    public static function resolve(string $method, string $requestUri, array $roots): ?string
    {
        // Cheapest check first: this runs on every request the site serves.
        if (!self::isAssociationPath($requestUri)) return null;

        $method = strtoupper($method);
        if ($method !== 'GET' && $method !== 'HEAD') return null;

        if (self::physicalFileExists($roots)) return null;

        if (!apply_filters(self::FILTER_ENABLED, true)) return null;

        $contents = apply_filters(self::FILTER_CONTENTS, self::CONTENTS);
        if (!is_string($contents) || $contents === '') return null;

        return $contents;
    }

    /** Exact path match; the query string, if any, is ignored. */
    public static function isAssociationPath(string $requestUri): bool
    {
        // Not strtok(): it skips leading delimiters, so "?x" would read as "x".
        $path = explode('?', $requestUri, 2)[0];
        return $path === self::PATH;
    }

    /**
     * @param string[] $roots
     */
    public static function physicalFileExists(array $roots): bool
    {
        foreach ($roots as $root) {
            if (!is_string($root) || $root === '') continue;
            // @: under open_basedir a root outside the allowed paths makes
            // is_file() emit a warning on every matching request.
            if (@is_file(rtrim($root, '/\\') . self::PATH)) return true;
        }
        return false;
    }

    /** The shipped file, unfiltered. */
    public static function shippedContents(): string
    {
        return self::CONTENTS;
    }
}
