<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Support\ViteAssets;
use WP_REST_Request;

if (!defined('ABSPATH')) exit;

/**
 * GET /b360/v1/boot-assets: the current storefront entry and stylesheets.
 *
 * Read by the inline stale-bundle recovery (Frontend/boot-recovery.js, BD-4783)
 * when a cached page points at a bundle an update removed. Public and
 * read-only: it returns the same URLs a fresh page embeds. RestBase stamps
 * no-store on the whole namespace, which is the point: this answer must never
 * be as stale as the HTML asking for it.
 */
final class BootAssetsController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/boot-assets', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_assets'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function get_assets(WP_REST_Request $request)
    {
        $assets = ViteAssets::bridgeAssetUrls();
        if ($assets === null) {
            return $this->error('No storefront build found.', 503, 'b360_no_build');
        }
        return $this->success($assets);
    }
}
