<?php

namespace Bottle360\Bridge\Lifecycle;

use Bottle360\Bridge\Support\ViteAssets;

if (!defined('ABSPATH')) exit;

/**
 * Asks the site's page caches to clear when the storefront build on disk
 * changes (BD-4783).
 *
 * A plugin update replaces the hashed bundle, and NitroPack, for one, does not
 * purge on a plugin update: it shows the admin a notice and keeps serving the
 * old HTML. Frontend/boot-recovery.js heals a stale page once that page carries
 * it, but HTML cached before the recovery shipped has no such script, and a
 * purge is also what makes new markup and theme output show at once.
 *
 * The trigger is the build signature changing between requests, not an
 * upgrader hook: it runs in the NEW code on the first request after the files
 * change, so it works however the update arrived (wp-admin, auto-update, WP-CLI,
 * a host's git deploy, a restored backup) and in the very release that adds it.
 *
 * It must never become a purge storm or a shopper's problem, so:
 *   - it runs at shutdown, after the response is flushed, and only on a GET or
 *     HEAD (never inside a checkout POST);
 *   - the stamp is the gate: a request purges only when ITS update_option
 *     changed the stored signature, so concurrent requests, a read-only
 *     database and a stale options cache all fall through without purging;
 *   - purges are at least COOLDOWN_SECONDS apart, which bounds a rolling
 *     deploy that serves two builds at once; a build that lands inside the
 *     cooldown is purged for by the first GET after it;
 *   - every vendor call is guarded and isolated: an absent cache plugin is
 *     skipped, and one that throws is recorded instead of ending the request.
 */
final class PageCachePurge
{
    public const OPT_SIGNATURE    = 'b360_bridge_build_signature';
    public const OPT_LOG          = 'b360_bridge_page_cache_purge';
    public const COOLDOWN_SECONDS = 600;

    public function register(): void
    {
        // After WordPress has flushed its output buffers (shutdown priority 1).
        add_action('shutdown', [self::class, 'maybePurge'], 100);
    }

    public static function maybePurge(): void
    {
        if (function_exists('wp_installing') && wp_installing()) return;

        $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper((string) $_SERVER['REQUEST_METHOD']) : '';
        if ($method !== 'GET' && $method !== 'HEAD') return;

        $current = ViteAssets::buildSignature();
        if ($current === null) return;

        $stored = (string) get_option(self::OPT_SIGNATURE, '');
        if ($stored === $current) return;

        // Cooldown, checked BEFORE the stamp: a build that arrives inside it is
        // left unstamped, so the first GET after the cooldown still purges for
        // it. Stamping first would swallow that build for good (a hotfix
        // released minutes after a release would never be purged or logged).
        $previous = get_option(self::OPT_LOG, null);
        $lastAt   = is_array($previous) && isset($previous['at']) ? (int) $previous['at'] : 0;
        if ($lastAt > 0 && (time() - $lastAt) < self::COOLDOWN_SECONDS) return;

        // The gate. update_option() is false when this request did not change
        // the row: another request stamped it first, the database is read-only,
        // or the value read above came from a stale options cache.
        if (!update_option(self::OPT_SIGNATURE, $current, true)) return;

        $log = ['at' => time(), 'time' => gmdate('Y-m-d H:i:s'), 'purged' => [], 'failed' => [], 'skipped' => false];

        /**
         * Return false to keep this plugin from clearing page caches when its
         * build changes (a site that purges in its own deploy pipeline).
         */
        if (!apply_filters('b360_bridge_purge_page_caches_on_update', true)) {
            $log['skipped'] = true;
        } else {
            // Let the visitor go before the vendor calls: some of them make a
            // remote request or delete a cache tree.
            if (function_exists('fastcgi_finish_request')) {
                @fastcgi_finish_request();
            } elseif (function_exists('litespeed_finish_request')) {
                @litespeed_finish_request();
            }

            foreach (self::targets() as $label => $purge) {
                try {
                    if ($purge()) $log['purged'][] = $label;
                } catch (\Throwable $e) {
                    $log['failed'][] = $label;
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log('[B360Bridge] page cache purge failed for ' . $label . ': ' . $e->getMessage());
                    }
                }
            }
        }

        update_option(self::OPT_LOG, $log, false);

        /** For a cache this plugin does not know: purge it from this hook. */
        do_action('b360_bridge_build_changed', $log);
    }

    /**
     * The last run, for the settings page.
     *
     * @return array{time: string, purged: string[], failed: string[], skipped: bool}|null
     */
    public static function lastRun(): ?array
    {
        $log = get_option(self::OPT_LOG, null);
        if (!is_array($log) || empty($log['time'])) return null;
        return [
            'time'    => (string) $log['time'],
            'purged'  => array_values(array_map('strval', (array) ($log['purged'] ?? []))),
            'failed'  => array_values(array_map('strval', (array) ($log['failed'] ?? []))),
            'skipped' => !empty($log['skipped']),
        ];
    }

    /**
     * One closure per known page cache. Each returns true when it found the
     * cache and asked it to clear, false when that cache is not on this site.
     * Page caches only: nothing here may flush an object cache, which would
     * also drop this plugin's own API cache and every other plugin's data.
     *
     * @return array<string, callable(): bool>
     */
    private static function targets(): array
    {
        return [
            'NitroPack' => static function (): bool {
                if (!function_exists('nitropack_sdk_purge')) return false;
                // False when the plugin is installed but not connected.
                return (bool) \nitropack_sdk_purge(null, null, 'Bottle360 Bridge storefront build changed');
            },
            'WP Rocket' => static function (): bool {
                if (!function_exists('rocket_clean_domain')) return false;
                \rocket_clean_domain();
                return true;
            },
            'LiteSpeed Cache' => static function (): bool {
                // The page cache only: the `litespeed_purge_all` action also
                // flushes LiteSpeed's object cache and resets opcache, which
                // would drop this plugin's API cache and every other plugin's
                // data. purge_all_lscache() is the LSCache-only purge.
                if (!class_exists('\LiteSpeed\Purge') || !method_exists('\LiteSpeed\Purge', 'purge_all_lscache')) return false;
                // LiteSpeed purges with a response header, and this runs after
                // the response has gone. Its own delay filter makes it store
                // the purge and send it with the next response instead.
                add_filter('litespeed_delay_purge', '__return_true');
                \LiteSpeed\Purge::purge_all_lscache('Bottle360 Bridge storefront build changed');
                remove_filter('litespeed_delay_purge', '__return_true');
                return true;
            },
            'WP Engine' => static function (): bool {
                // The page cache only. purge_memcached() is the object cache.
                if (!class_exists('\WpeCommon') || !method_exists('\WpeCommon', 'purge_varnish_cache')) return false;
                \WpeCommon::purge_varnish_cache();
                return true;
            },
            'W3 Total Cache' => static function (): bool {
                // w3tc_flush_posts() is the page cache; w3tc_flush_all() would
                // also flush the object, database and minify caches.
                if (!function_exists('w3tc_flush_posts')) return false;
                \w3tc_flush_posts();
                return true;
            },
            'WP Super Cache' => static function (): bool {
                if (!function_exists('wp_cache_clear_cache')) return false;
                // Blog 0 means every blog on a multisite network.
                if (function_exists('is_multisite') && is_multisite()) {
                    \wp_cache_clear_cache(get_current_blog_id());
                } else {
                    \wp_cache_clear_cache();
                }
                return true;
            },
            'SiteGround Optimizer' => static function (): bool {
                if (!function_exists('sg_cachepress_purge_cache')) return false;
                \sg_cachepress_purge_cache();
                return true;
            },
        ];
    }
}
