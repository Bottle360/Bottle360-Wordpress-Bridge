<?php

namespace Bottle360\Bridge\Frontend;

use Bottle360\Bridge\Routing\SpaRoutes;
use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Support\ViteAssets;

if (!defined('ABSPATH')) exit;

/**
 * Bootstraps the unified bridge Vue bundle on every front-end page.
 *
 * Responsibilities:
 *   - Emit window.B360Bridge config (REST URL, base path, route metadata,
 *     site name)
 *   - Load the single bridge.ts bundle (renderBridgeTags is idempotent)
 *   - Emit the sidebar cart-drawer placeholder
 *
 * NOTE: the REST nonce is deliberately NOT emitted here. This footer lands in
 * cacheable page HTML on managed hosts (WP Engine) + CDNs (Cloudflare), so a
 * baked nonce would be served long-expired and every POST would 403. The SPA
 * fetches a live nonce from the cache-excluded /nonce endpoint on boot instead
 * (frontend/api/client.ts → primeNonce()).
 *
 * Page-scoped widgets (like the full SPA mount from [b360_app]) live in
 * their own shortcode classes and emit their own [data-b360-widget="..."]
 * placeholder divs, this class only wires up the one-time page bootstrap.
 *
 * Replaces the previous SidebarInjector class, which had a narrower
 * (sidebar-only) scope and tightly coupled the sidebar bundle to its own
 * Vite entry point.
 */
final class BridgeBoot
{
    public function register(): void
    {
        // Priority 5 so the bundle is defined before any late shortcode output.
        add_action('wp_footer', [$this, 'emit'], 5);
    }

    public function emit(): void
    {
        $basePath = Options::get_app_base_path();

        // JSON_HEX_TAG: the decoded site name below can hold a literal "<",
        // and this lands inside an inline <script>. \u003C reads the same to
        // JavaScript.
        $config = wp_json_encode([
            'restUrl'  => esc_url_raw(rest_url('b360/v1/')),
            'basePath' => $basePath,
            // Server-emitted page titles for client-side route transitions.
            // Consumed by frontend/router/index.ts to build titleMap. The
            // nav active-state map used to live here too; BridgeNav.vue now
            // derives active state directly from the route table.
            'routes'   => [
                'titles' => SpaRoutes::titles(),
            ],
            // The site's display name, shown as the payee line on the Apple
            // Pay sheet ("Pay <name>", BD-2276). WordPress stores blogname
            // entity-encoded ("Smith &amp; Sons"), and the sheet is not HTML,
            // so decode it here. Static per site, so safe in cached page HTML.
            'siteName' => html_entity_decode((string) get_bloginfo('name'), ENT_QUOTES, 'UTF-8'),
        ], JSON_HEX_TAG);

        echo '<script>window.B360Bridge = ' . $config . ';</script>' . "\n";

        // Sidebar cart-drawer placeholder, teleport target for SidebarApp.vue.
        echo '<div data-b360-widget="sidebar" data-base-path="'
            . esc_attr($basePath) . '"></div>' . "\n";

        echo self::recoveryScript();
        echo ViteAssets::renderBridgeTags() . "\n";
    }

    /**
     * Inline stale-bundle recovery (BD-4783).
     *
     * The bundle tag below embeds a content-hashed filename, and a plugin
     * update deletes the previous build. A page cache that outlives the update
     * (NitroPack kept Moshin's store HTML for 17 days) keeps serving HTML that
     * asks for a file that is gone: the script 404s, nothing mounts, and every
     * store route sits on "Loading..." until someone purges the cache by hand.
     * All of the SPA's own recovery lives inside that bundle, so none of it runs.
     *
     * boot-recovery.js is inlined so it travels with the cached HTML. When the
     * bundle has not executed and the embedded file is confirmed missing (a HEAD
     * that answers 404/410, or a soft 404 that is not JavaScript), it asks
     * /b360/v1/boot-assets, which is never cached, for the current entry and
     * stylesheets and loads those. When the bundle runs normally it makes no
     * request. It acts only on a confirmed missing file, never on a timeout.
     *
     * The probe asks the origin while the page's own tag can still be answered
     * by a browser or CDN copy, so the two can disagree. What keeps that from
     * mounting two apps is not timing but the bundle itself: claimBoot() in
     * shared/bootGuard.ts makes whichever copy runs second stand down.
     *
     * Emitted before the bundle tag so its capture-phase `error` listener is in
     * place when the tag fails. Skipped in dev mode (no hashed files).
     */
    public static function recoveryScript(): string
    {
        $assets = ViteAssets::bridgeAssetUrls();
        if ($assets === null) return '';

        $js = self::recoverySource();
        if ($js === '') return '';

        $config = wp_json_encode([
            'entry' => $assets['entry'],
            'api'   => esc_url_raw(rest_url('b360/v1/boot-assets')),
        ]);

        return '<script>window.B360BootRecovery = ' . $config . ';' . $js . '</script>' . "\n";
    }

    /**
     * boot-recovery.js as it is inlined: comments stripped, lines joined. It
     * goes on every front-end page, so it ships small, and a single line is
     * also what an HTML minifier that collapses newlines would make of it. The
     * file is written for this (semicolons everywhere, block comments only),
     * and its tests run against this same form.
     */
    public static function recoverySource(): string
    {
        $js = @file_get_contents(__DIR__ . '/boot-recovery.js');
        if (!is_string($js)) return '';
        $js = (string) preg_replace('#/\*.*?\*/#s', '', $js);
        $js = (string) preg_replace('/\s*\n\s*/', ' ', $js);
        return trim($js);
    }
}
