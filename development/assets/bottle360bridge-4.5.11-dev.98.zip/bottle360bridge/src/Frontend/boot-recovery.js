/*
 * Stale-bundle recovery (BD-4783). Inlined by BridgeBoot; the why is in its
 * docblock. Rules for this file, because BridgeBoot strips the comments and
 * joins the lines before inlining it, and HTML minifiers do the same:
 * ES5 only, every statement ends in a semicolon, block comments only.
 */
(function () {
  'use strict';

  var cfg = window.B360BootRecovery || {};
  var entry = cfg.entry;
  var api = cfg.api;
  if (!entry || !api || !window.fetch || !window.URL) return;

  /* After window load, how long to wait before asking whether the bundle ran. */
  var PROBE_DELAY_MS = 1500;
  /* idle -> probing -> recovering -> done. 'done' is terminal for this page. */
  var state = 'idle';
  var entryUrl;

  try {
    entryUrl = new URL(entry, window.location.href);
  } catch (e) {
    return;
  }
  var distPath = entryUrl.pathname.slice(0, entryUrl.pathname.lastIndexOf('/') + 1);

  function booted() {
    return !!window.__b360BridgeBooted;
  }

  function parse(url) {
    try {
      return new URL(url, window.location.href);
    } catch (e) {
      return null;
    }
  }

  /* Only ever load a file from the folder the page's own bundle came from. */
  function trusted(url, pattern) {
    var u = parse(url);
    if (!u || u.origin !== entryUrl.origin) return null;
    if (u.pathname.indexOf(distPath) !== 0) return null;
    if (!pattern.test(u.pathname.slice(distPath.length))) return null;
    return u;
  }
  var ENTRY_FILE = /^b360-bridge-[A-Za-z0-9_-]+\.js$/;
  var CSS_FILE = /^b360-[A-Za-z0-9_.-]+\.css$/;

  function warn(reason) {
    if (window.console && window.console.warn) {
      window.console.warn('[b360:boot] stale bundle not recovered (' + reason + ')');
    }
  }

  function giveUp(reason) {
    state = 'done';
    warn(reason);
  }

  /*
   * Missing means the server answered and the answer cannot be a module:
   * gone, or a soft 404 that returns an HTML page with a 200. Anything else
   * (an error status, no content type) is not proof, so it is not acted on.
   */
  function isMissing(res) {
    if (res.status === 404 || res.status === 410) return true;
    if (!res.ok) return false;
    var type = (res.headers && res.headers.get && res.headers.get('content-type')) || '';
    return type !== '' && !/(javascript|ecmascript)/i.test(type);
  }

  function swapCss(list) {
    var old = [];
    var links = document.getElementsByTagName('link');
    var i;
    for (i = 0; i < links.length; i++) {
      var rel = (links[i].getAttribute('rel') || '').toLowerCase();
      if (rel === 'stylesheet' && links[i].href && trusted(links[i].href, CSS_FILE)) old.push(links[i]);
    }
    /* Put the new sheets where the old ones were, so the cascade order a fresh page has is kept. */
    var anchor = old.length ? old[0] : null;
    var parent = anchor ? anchor.parentNode : document.body || document.documentElement;
    for (i = 0; i < (list || []).length; i++) {
      var u = trusted(list[i], CSS_FILE);
      if (!u) continue;
      var link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = u.href;
      parent.insertBefore(link, anchor);
    }
    for (i = 0; i < old.length; i++) {
      if (old[i].parentNode) old[i].parentNode.removeChild(old[i]);
    }
  }

  function loadEntry(u) {
    var s = document.createElement('script');
    s.type = 'module';
    /* No query string: a module's identity is its exact URL (see ViteAssets::renderEntry). */
    s.src = u.origin + u.pathname;
    s.onerror = function () {
      warn('current bundle failed to load');
    };
    (document.body || document.documentElement).appendChild(s);
  }

  function recover() {
    state = 'recovering';
    var url = api + (api.indexOf('?') === -1 ? '?' : '&') + '_=' + new Date().getTime();
    return window
      .fetch(url, { cache: 'no-store', credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then(function (res) {
        return res.ok ? res.json() : null;
      })
      .then(function (data) {
        if (booted()) {
          state = 'done';
          return;
        }
        if (!data || typeof data.entry !== 'string') return giveUp('no build info');
        var next = trusted(data.entry, ENTRY_FILE);
        if (!next) return giveUp('untrusted entry');
        /* Same file the page already asked for: nothing newer to load. */
        if (next.pathname === entryUrl.pathname) return giveUp('no newer build');
        state = 'done';
        swapCss(data.css);
        loadEntry(next);
        document.documentElement.setAttribute('data-b360-boot-recovered', '1');
        if (window.console && window.console.info) {
          window.console.info('[b360:boot] cached page pointed at a removed bundle, loaded the current one');
        }
      })
      .catch(function () {
        giveUp('build info request failed');
      });
  }

  function ask(init) {
    init.cache = 'no-store';
    init.credentials = 'same-origin';
    return window.fetch(entryUrl.href, init);
  }

  function probe() {
    if (state !== 'idle' || booted()) return;
    state = 'probing';
    ask({ method: 'HEAD' })
      .then(function (res) {
        /* A server that refuses HEAD: ask for the first byte instead. */
        if (res.status === 405 || res.status === 501) {
          return ask({ method: 'GET', headers: { Range: 'bytes=0-0' } });
        }
        return res;
      })
      .then(function (res) {
        if (booted()) {
          state = 'idle';
          return;
        }
        if (isMissing(res)) return recover();
        /*
         * The file is there (slow network, a script-delay optimizer, a
         * blocker): not this script's problem. A later error can re-probe.
         */
        state = 'idle';
      })
      .catch(function () {
        state = 'idle';
      });
  }

  /*
   * A failed <script> fires `error` on the element, which does not bubble, so
   * listen in the capture phase. Matching on the path also covers a tag an
   * optimizer stripped and re-inserted later.
   */
  window.addEventListener(
    'error',
    function (e) {
      var t = e && e.target;
      if (!t || t.tagName !== 'SCRIPT' || !t.src) return;
      var u = parse(t.src);
      if (u && u.pathname === entryUrl.pathname) probe();
    },
    true
  );

  /* Backstop for a failure that happened before this script ran. */
  function afterLoad() {
    window.setTimeout(probe, PROBE_DELAY_MS);
  }
  if (document.readyState === 'complete') afterLoad();
  else window.addEventListener('load', afterLoad);
})();
