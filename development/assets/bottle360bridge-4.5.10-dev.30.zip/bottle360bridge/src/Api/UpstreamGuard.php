<?php

namespace Bottle360\Bridge\Api;

if (!defined('ABSPATH')) exit;

/**
 * Upstream guard — keeps a slow/failing Bottle360 admin from taking the
 * WHOLE WordPress site down with it.
 *
 * Incident 2026-08-17 (Moshin Vineyards): an email blast + a slow upstream
 * turned every bridge REST call into a PHP-FPM worker parked for up to 20–25s
 * (the old wp_remote_* timeouts). The pool drained and the site 504'd —
 * including pages that never touch Bottle360. Three guardrails:
 *
 *   1. SHORT TIMEOUTS — a bridge call may hold a worker for seconds, not
 *      tens of seconds. Payment / order-placing routes keep a longer budget
 *      (a gateway round-trip is legitimately slow); everything else is short.
 *   2. CIRCUIT BREAKER — after N upstream failures (timeouts / connection
 *      errors / 5xx) inside a short window, the breaker OPENS for a cool-down:
 *      non-critical calls fail FAST (no socket, no worker parked) and GETs
 *      serve their last-known-good copy where one exists. The first call
 *      after the cool-down is the half-open probe: success closes the
 *      breaker, failure re-opens it immediately.
 *   3. PER-REQUEST BUDGET — one WordPress request may spend at most B ms
 *      waiting on upstream in total; past that, further upstream calls in the
 *      same request fail fast instead of stacking timeouts.
 *
 * All knobs are filterable; defaults are conservative. Counters live in
 * transients (object cache when present) so every PHP worker sees the same
 * breaker state.
 */
final class UpstreamGuard
{
    /** Default wall-clock ceilings, seconds. */
    public const TIMEOUT_GET_DEFAULT      = 6;
    public const TIMEOUT_POST_DEFAULT     = 8;
    public const TIMEOUT_MINT_DEFAULT     = 4;
    public const TIMEOUT_PAYMENT_DEFAULT  = 25;

    /** Breaker tuning. */
    public const FAILURE_THRESHOLD = 5;   // failures inside FAILURE_WINDOW → open
    public const FAILURE_WINDOW    = 60;  // seconds
    public const OPEN_SECONDS      = 30;  // cool-down while open

    /** Per-request upstream time budget, ms. */
    public const REQUEST_BUDGET_MS_DEFAULT = 8000;

    private const T_FAILS  = 'b360_upstream_fail_count';
    private const T_OPEN   = 'b360_upstream_breaker_open';

    /** Upstream ms spent so far in THIS PHP request. */
    private static int $spentMs = 0;

    /**
     * Routes whose calls are allowed a long timeout and are never failed fast
     * by the breaker or the budget: money is moving, an honest slow answer
     * beats a fast synthetic one. Prefix match on the bridge route.
     */
    private const PAYMENT_ROUTES = [
        'checkout/confirmOrder',
        'checkout/setPayment',
        'payment/',
        'club/join',
        'wallet/redeem',
    ];

    public static function isPaymentRoute(string $route): bool
    {
        foreach (self::PAYMENT_ROUTES as $prefix) {
            if (strpos($route, $prefix) === 0) {
                return true;
            }
        }
        return (bool) apply_filters('b360_bridge_is_payment_route', false, $route);
    }

    /**
     * Timeout (seconds) for a call on $route by $method ('GET'|'POST'|'MINT').
     * Non-payment calls are ALSO capped by what is left of this request's
     * upstream budget, so a session mint + the real call together never hold a
     * worker past the budget.
     */
    public static function timeoutFor(string $method, string $route): int
    {
        if ($route === 'default/initSession') {
            $method = 'MINT';
        }
        if (self::isPaymentRoute($route)) {
            $t = self::TIMEOUT_PAYMENT_DEFAULT;
        } elseif ($method === 'MINT') {
            $t = self::TIMEOUT_MINT_DEFAULT;
        } elseif ($method === 'POST') {
            $t = self::TIMEOUT_POST_DEFAULT;
        } else {
            $t = self::TIMEOUT_GET_DEFAULT;
        }
        $t = (int) apply_filters('b360_bridge_upstream_timeout', $t, $method, $route);
        if (!self::isPaymentRoute($route)) {
            $budget = (int) apply_filters('b360_bridge_request_budget_ms', self::REQUEST_BUDGET_MS_DEFAULT);
            if ($budget > 0) {
                $t = min($t, (int) ceil(max(0, $budget - self::$spentMs) / 1000));
            }
        }
        return max(1, $t);
    }

    /**
     * Should this call be refused BEFORE opening a socket? True when the
     * breaker is open (and this isn't the half-open probe) or the request's
     * upstream budget is spent. Payment routes are never refused here.
     */
    public static function shouldFailFast(string $route): bool
    {
        if (self::isPaymentRoute($route)) {
            return false;
        }
        if (self::budgetExhausted()) {
            return true;
        }
        // While OPEN nothing non-critical goes upstream. The half-open probe
        // is the FIRST call after the open transient expires: it pays one
        // timeout; on failure the (still-fresh) failure count re-opens the
        // breaker at once, on success the breaker closes.
        return self::isOpen();
    }

    public static function isOpen(): bool
    {
        if (defined('B360_BRIDGE_BREAKER_DISABLED') && B360_BRIDGE_BREAKER_DISABLED) {
            return false;
        }
        return get_transient(self::T_OPEN) !== false;
    }

    public static function budgetExhausted(): bool
    {
        $budget = (int) apply_filters('b360_bridge_request_budget_ms', self::REQUEST_BUDGET_MS_DEFAULT);
        return $budget > 0 && self::$spentMs >= $budget;
    }

    /** Record the outcome of an upstream call. */
    public static function record(bool $upstreamFailure, int $ms): void
    {
        self::$spentMs += max(0, $ms);
        if (!$upstreamFailure) {
            // A success while open/half-open closes the breaker.
            if (get_transient(self::T_OPEN) !== false) {
                delete_transient(self::T_OPEN);
                delete_transient(self::T_FAILS);
            }
            return;
        }
        $n = (int) get_transient(self::T_FAILS);
        $n++;
        set_transient(self::T_FAILS, $n, self::FAILURE_WINDOW);
        $threshold = (int) apply_filters('b360_bridge_breaker_threshold', self::FAILURE_THRESHOLD);
        if ($n >= max(1, $threshold) && get_transient(self::T_OPEN) === false) {
            set_transient(self::T_OPEN, time(), self::OPEN_SECONDS);
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('[B360Bridge] upstream breaker OPEN after ' . $n . ' failures — failing fast for ' . self::OPEN_SECONDS . 's');
            }
        }
    }

    /**
     * Was this parseResponse envelope an UPSTREAM failure (the kind that
     * should trip the breaker)? Connection errors / timeouts (status 0) and
     * 5xx count; 4xx are the caller's problem, not the upstream's health.
     */
    public static function isUpstreamFailure(array $result): bool
    {
        $status = (int) ($result['status'] ?? 0);
        return $status === 0 || $status >= 500;
    }

    /** The fast-fail envelope (parseResponse-shaped). */
    public static function failFastResult(string $route): array
    {
        $why = self::budgetExhausted() ? 'BRIDGE_UPSTREAM_BUDGET' : 'BRIDGE_UPSTREAM_OPEN';
        return [
            'ok'            => false,
            'status'        => 503,
            'data'          => null,
            'meta'          => null,
            'error'         => 'The store service is busy right now. Please try again in a moment.',
            'error_code'    => $why,
            'error_context' => ['route' => $route],
        ];
    }

    /** Test / diagnostics hook: reset the per-request budget counter. */
    public static function resetRequestBudget(): void
    {
        self::$spentMs = 0;
    }

    public static function spentMs(): int
    {
        return self::$spentMs;
    }
}
