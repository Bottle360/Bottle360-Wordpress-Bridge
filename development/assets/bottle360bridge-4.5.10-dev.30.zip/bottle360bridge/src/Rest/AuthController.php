<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Api\BridgeApiClient;
use Bottle360\Bridge\Api\BridgeSession;
use Bottle360\Bridge\Settings\Options;
use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class AuthController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/auth/login', [
            'methods'             => 'POST',
            'callback'            => [$this, 'login'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/register', [
            'methods'             => 'POST',
            'callback'            => [$this, 'do_register'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/logout', [
            'methods'             => 'POST',
            'callback'            => [$this, 'logout'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/profile', [
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'get_profile'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods'             => 'POST',
                'callback'            => [$this, 'update_profile'],
                'permission_callback' => '__return_true',
            ],
        ]);

        register_rest_route(self::NAMESPACE, '/auth/change-password', [
            'methods'             => 'POST',
            'callback'            => [$this, 'change_password'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/forgot-password', [
            'methods'             => 'POST',
            'callback'            => [$this, 'forgot_password'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/reset-password', [
            'methods'             => 'POST',
            'callback'            => [$this, 'reset_password'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/auth/request-claim', [
            'methods'             => 'POST',
            'callback'            => [$this, 'request_claim'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function login(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $form = $params['form'] ?? $params;

        $username = sanitize_text_field(wp_unslash($form['UserLogin[username]'] ?? $form['username'] ?? ''));
        $password = $form['UserLogin[password]'] ?? $form['password'] ?? '';

        if ($username === '' || $password === '') {
            return $this->error('Username and password are required.', 422);
        }

        $client = BridgeApiClient::instance();
        $result = $client->post('auth/login', [
            'username' => $username,
            'password' => $password,
        ], $this->withRecaptcha($request));

        if ($result['ok'] && isset($result['data']['token'])) {
            BridgeSession::setToken(
                $result['data']['token'],
                $result['data']['expires_at'] ?? ''
            );
            BridgeSession::setAuthenticated(true);

            return $this->success([
                'message' => 'Login successful',
                'user'    => $result['data']['user'] ?? [],
            ]);
        }

        return $this->proxy_error($result, 'Login failed', 401);
    }

    public function do_register(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $form = $params['form'] ?? $params;

        $client = BridgeApiClient::instance();
        $result = $client->post('auth/register', [
            'email'      => sanitize_email(wp_unslash($form['CustomerRegistrationForm[email]'] ?? $form['email'] ?? '')),
            'password'   => $form['CustomerRegistrationForm[password]'] ?? $form['password'] ?? '',
            'first_name' => sanitize_text_field(wp_unslash($form['Profile[firstname]'] ?? $form['firstname'] ?? $form['first_name'] ?? '')),
            'last_name'  => sanitize_text_field(wp_unslash($form['Profile[lastname]'] ?? $form['lastname'] ?? $form['last_name'] ?? '')),
            'phone'      => sanitize_text_field(wp_unslash($form['phone'] ?? '')),
            'dob'        => sanitize_text_field(wp_unslash($form['Profile[birthdate]'] ?? $form['dob'] ?? '')),
            'timezone'   => sanitize_text_field(wp_unslash($form['CustomerRegistrationForm[timezone]'] ?? $form['timezone'] ?? '')),
            'company'    => sanitize_text_field(wp_unslash($form['company'] ?? '')),
            'marketing_opt_in' => !empty($form['marketing_opt_in']) ? 1 : 0,
        ], $this->withRecaptcha($request));

        if ($result['ok'] && isset($result['data']['token'])) {
            BridgeSession::setToken(
                $result['data']['token'],
                $result['data']['expires_at'] ?? ''
            );
            BridgeSession::setAuthenticated(true);

            return $this->success([
                'message' => 'Registration successful',
                'user'    => $result['data']['user'] ?? [],
            ]);
        }

        return $this->proxy_error($result, 'Registration failed', 422);
    }

    public function logout(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        BridgeApiClient::instance()->post('auth/logout');

        BridgeSession::setAuthenticated(false);
        BridgeSession::clearToken();

        return $this->success(['message' => 'Logged out']);
    }

    public function get_profile(WP_REST_Request $request)
    {
        $client = BridgeApiClient::instance();
        $result = $client->get('auth/profile');

        if ($result['ok']) {
            return $this->success(['user' => $result['data']]);
        }

        return $this->proxy_error($result, 'Not authenticated', 401);
    }

    public function update_profile(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $body = [];

        if (isset($params['email'])) {
            $body['email'] = sanitize_email(wp_unslash($params['email']));
        }
        foreach (['first_name', 'last_name', 'company', 'dob'] as $f) {
            if (isset($params[$f])) {
                $body[$f] = sanitize_text_field(wp_unslash($params[$f]));
            }
        }

        $client = BridgeApiClient::instance();
        $result = $client->post('auth/updateProfile', $body);

        if ($result['ok']) {
            return $this->success(['user' => $result['data']]);
        }

        return $this->proxy_error($result, 'Failed to update profile', 500);
    }

    public function change_password(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $currentPassword = wp_unslash($params['current_password'] ?? '');
        $newPassword = wp_unslash($params['new_password'] ?? '');

        if ($currentPassword === '' || $newPassword === '') {
            return $this->error('Current and new password are required', 422);
        }

        $client = BridgeApiClient::instance();
        $result = $client->post('auth/changePassword', [
            'current_password' => $currentPassword,
            'new_password'     => $newPassword,
        ]);

        if ($result['ok']) {
            return $this->success(['message' => 'Password changed successfully']);
        }

        return $this->proxy_error($result, 'Failed to change password', 500);
    }

    public function forgot_password(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $email = sanitize_email(wp_unslash($params['email'] ?? ''));

        if ($email === '') {
            return $this->error('Email is required', 422);
        }

        $return_url = home_url(Options::get_app_base_path() . '/recovery/reset');
        $result = BridgeApiClient::instance()->post('auth/forgotPassword', [
            'email'      => $email,
            'return_url' => $return_url,
        ], $this->withRecaptcha($request));

        if (!$result['ok']) {
            return $this->proxy_error($result, 'Failed to send recovery email.', 500);
        }

        return $this->success(['message' => 'If that email exists, a recovery link has been sent.']);
    }

    /**
     * Confirmation-page "create an account" offer after a passwordless guest
     * order. Mirrors forgot_password: same nonce gate, same reCAPTCHA
     * forwarding, same return_url (the claim link lands on the SPA's recovery
     * page to set a password). The core always answers { email_sent: true } and
     * only actually sends for a passwordless bridge-guest shell, so the reply
     * never reveals whether an email has an account or order history.
     */
    public function request_claim(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params = $request->get_json_params();
        $email = sanitize_email(wp_unslash($params['email'] ?? ''));

        if ($email === '') {
            return $this->error('Email is required', 422);
        }

        $return_url = home_url(Options::get_app_base_path() . '/recovery/reset');
        $result = BridgeApiClient::instance()->post('auth/requestClaim', [
            'email'      => $email,
            'return_url' => $return_url,
        ], $this->withRecaptcha($request));

        if (!$result['ok']) {
            return $this->proxy_error($result, 'Failed to send the account link.', 500);
        }

        return $this->success(['email_sent' => true]);
    }

    public function reset_password(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params       = $request->get_json_params();
        $email        = sanitize_email(wp_unslash($params['email'] ?? ''));
        $activkey     = sanitize_text_field(wp_unslash($params['activkey'] ?? ''));
        $new_password = $params['new_password'] ?? '';

        if ($email === '' || $activkey === '' || $new_password === '') {
            return $this->error('Email, activation key, and new password are required.', 422);
        }

        $result = BridgeApiClient::instance()->post('auth/resetPassword', [
            'email'        => $email,
            'activkey'     => $activkey,
            'new_password' => $new_password,
        ], $this->withRecaptcha($request));

        if ($result['ok']) {
            if (!empty($result['data']['token'])) {
                BridgeSession::setToken(
                    $result['data']['token'],
                    $result['data']['expires_at'] ?? ''
                );
                BridgeSession::setAuthenticated(true);
            }

            return $this->success([
                'password_reset' => true,
                'user'           => $result['data']['user'] ?? null,
            ]);
        }

        return $this->proxy_error($result, 'Failed to reset password', 500);
    }
}
