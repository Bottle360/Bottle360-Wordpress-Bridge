<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Api\BridgeApiClient;
use Bottle360\Bridge\Support\Nonce;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

if (!defined('ABSPATH')) exit;

abstract class RestBase
{
    protected const NAMESPACE = 'b360/v1';

    abstract public function register_routes(): void;

    public function register(): void
    {
        add_action('rest_api_init', [$this, 'register_routes']);
        // Only wire the no-cache filter once; it's namespace-wide, not per-controller.
        if (!has_filter('rest_post_dispatch', [self::class, 'force_nocache'])) {
            add_filter('rest_post_dispatch', [self::class, 'force_nocache'], 10, 3);
        }
    }

    /**
     * Managed WP hosts (WP Engine, Kinsta, Pantheon) default to caching REST
     * responses at the edge unless the response explicitly forbids it. A cached
     * REST response is catastrophic for us because:
     *   1) the cached body is shared across visitors, leaking cart/auth data, and
     *   2) the cached Set-Cookie header is replayed to later visitors, which
     *      overwrites their real session token and silently logs them out.
     *
     * WP core doesn't send no-store by default, so we stamp the headers ourselves
     * on every response in our namespace. Runs late in the dispatch so our values
     * win over any earlier filter.
     */
    public static function force_nocache($response, $server, $request)
    {
        if (!($response instanceof \WP_REST_Response) && !($response instanceof \WP_HTTP_Response)) {
            return $response;
        }
        // Only our namespace — don't override other plugins' caching decisions.
        $route = $request instanceof \WP_REST_Request ? (string) $request->get_route() : '';
        if (strpos($route, '/' . self::NAMESPACE . '/') !== 0) {
            return $response;
        }
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0, private');
        $response->header('Pragma', 'no-cache');
        $response->header('Expires', 'Wed, 11 Jan 1984 05:00:00 GMT');
        // WP Engine / nginx respect X-Accel-Expires for edge caching.
        $response->header('X-Accel-Expires', '0');
        // Belt-and-braces for a cache that ignores no-store but honours Vary:
        // the answer depends on the session cookie, never share it across cookies.
        $response->header('Vary', 'Cookie');
        return $response;
    }

    protected function success($data, int $status = 200): WP_REST_Response
    {
        return new WP_REST_Response($data, $status);
    }

    /**
     * Build a WP_Error response. Optional $context is merged flat into the error
     * data array so the frontend can read fields like `address_id` directly off
     * `errorData.<key>` (matching the bridge admin's error.context shape after
     * WP serializes WP_Error into `{code, message, data:{status, ...context}}`).
     */
    protected function error(string $message, int $status = 400, string $code = 'b360_error', array $context = []): WP_Error
    {
        $data = ['status' => $status];
        if (!empty($context)) {
            // Context keys win over status if they collide — but the only reserved
            // key is 'status', and bridge endpoints don't put 'status' in context.
            $data = array_merge($data, $context);
        }
        return new WP_Error($code, $message, $data);
    }

    protected function check_nonce(WP_REST_Request $request): ?WP_Error
    {
        $nonce = $request->get_header('X-B360-Nonce');
        if (!$nonce || !wp_verify_nonce($nonce, Nonce::ACTION)) {
            return $this->error('Invalid or missing nonce', 403, 'b360_invalid_nonce');
        }
        return null;
    }

    /**
     * Lift the reCAPTCHA v3 headers off the incoming WP REST request so
     * controllers don't have to plumb them manually on every proxy_* call.
     * Merges with any explicit opts the caller set (explicit values win).
     */
    protected function withRecaptcha(WP_REST_Request $request, array $opts = []): array
    {
        $token  = trim((string) $request->get_header('X-Recaptcha-Token'));
        $action = trim((string) $request->get_header('X-Recaptcha-Action'));
        if ($token !== '' && !isset($opts['recaptcha_token'])) {
            $opts['recaptcha_token'] = $token;
        }
        if ($action !== '' && !isset($opts['recaptcha_action'])) {
            $opts['recaptcha_action'] = $action;
        }
        return $opts;
    }

    protected function proxy_get(string $route, array $params = [], array $opts = [])
    {
        $result = BridgeApiClient::instance()->get($route, $params, $opts);
        return $this->proxy_result($result);
    }

    /**
     * Build a WP_Error from a BridgeApiClient result, preserving the upstream
     * error code (BRIDGE_NOT_CONFIGURED, INVALID_PASSWORD, etc.) so the SPA
     * can branch on it. Use this from controllers that handle success
     * themselves but want proxy_result-style error passthrough on failure.
     */
    protected function proxy_error(array $result, string $fallbackMessage, int $fallbackStatus): WP_Error
    {
        $code = $result['error_code'] ?? 'b360_error';
        $context = is_array($result['error_context'] ?? null) ? $result['error_context'] : [];
        return $this->error(
            $result['error'] ?? $fallbackMessage,
            $result['status'] ?: $fallbackStatus,
            $code,
            $context
        );
    }

    protected function proxy_post(string $route, array $body = [], array $opts = [])
    {
        $result = BridgeApiClient::instance()->post($route, $body, $opts);
        return $this->proxy_result($result);
    }

    private function proxy_result(array $result)
    {
        if (!$result['ok']) {
            // Forward the upstream error code (e.g. LEGACY_ADDRESS_PHONE_MISSING)
            // and context (e.g. {address_id: 12518}) so the Vue frontend can
            // branch on them. WP would otherwise collapse the rich error envelope
            // into {code:'b360_error', message, data:{status}} and lose both.
            $upstreamCode = $result['error_code'] ?? 'b360_error';
            $context = is_array($result['error_context'] ?? null) ? $result['error_context'] : [];
            $err = $this->error(
                $result['error'] ?? 'Request failed',
                $result['status'] ?: 500,
                $upstreamCode,
                $context
            );
            // Timing header fires even on error paths so we can see whether
            // the slow leg was the upstream call or local work.
            $this->emitServerTiming($result);
            return $err;
        }

        $data = $result['data'];

        // Include pagination meta in both body and headers
        if (!empty($result['meta'])) {
            if (is_array($data)) {
                $data['meta'] = $result['meta'];
            }
        }

        $response = $this->success($data);

        if (!empty($result['meta'])) {
            if (isset($result['meta']['total_items'])) {
                $response->header('X-WP-Total', (string) $result['meta']['total_items']);
            }
            if (isset($result['meta']['total_pages'])) {
                $response->header('X-WP-TotalPages', (string) $result['meta']['total_pages']);
            }
        }

        $this->emitServerTiming($result, $response);
        return $response;
    }

    /**
     * Emit a Server-Timing response header so latency shows up in browser
     * devtools natively. Fields:
     *   - wp=<ms>         wall-clock around wp_remote_* (WP↔admin network+admin total)
     *   - <admin fields>  whatever the admin site emitted in its own Server-Timing,
     *                     re-emitted verbatim so breakdowns like
     *                     "recaptcha=450, service=800, total=1350" appear inline.
     *
     * If the admin didn't set its own Server-Timing (older build), only wp=
     * is emitted. Works whether we're emitting on success (WP_REST_Response)
     * or error (WP_Error — we have to hook rest_post_dispatch instead since
     * WP_Error has no header API).
     */
    private function emitServerTiming(array $result, $response = null): void
    {
        $timing = isset($result['timing']) && is_array($result['timing']) ? $result['timing'] : [];
        if (empty($timing)) return;

        $parts = [];
        $parts[] = 'wp;dur=' . (int) ($timing['wp_remote_ms'] ?? 0);
        $admin = trim((string) ($timing['admin_server_timing'] ?? ''));
        $header = implode(', ', $parts) . ($admin !== '' ? ', ' . $admin : '');

        if ($response instanceof \WP_REST_Response) {
            $response->header('Server-Timing', $header);
            return;
        }
        // Error path: WP_Error has no header API. Piggy-back on the
        // rest_post_dispatch filter to set it once the final response is
        // materialized — by then we have a WP_HTTP_Response we can mutate.
        add_filter('rest_post_dispatch', function ($resp) use ($header) {
            if ($resp instanceof \WP_HTTP_Response) {
                $resp->header('Server-Timing', $header);
            }
            return $resp;
        }, 99);
    }
}
