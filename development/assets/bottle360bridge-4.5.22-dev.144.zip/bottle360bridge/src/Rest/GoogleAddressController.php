<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Api\ApiErrorLog;
use Bottle360\Bridge\Settings\Options;
use WP_Error;
use WP_REST_Request;

if (!defined('ABSPATH')) exit;

/**
 * Google address intelligence: Places Autocomplete (New) suggestions while the
 * shopper types, and an Address Validation verdict on the finished address.
 *
 * Why all three calls are proxied rather than made from the browser:
 *   - The Maps Platform key never reaches the client. Places Autocomplete is
 *     routinely done browser-side with an HTTP-referrer-restricted key, but a
 *     referrer restriction is a soft control (referrers are forgeable outside
 *     a browser) and it would put a live billable key in a storefront bundle
 *     that is ALSO served into Squarespace pages we do not control. Keeping it
 *     here costs one hop and removes the class of problem.
 *   - Address Validation must be server-side regardless: its verdict is the
 *     anti-bot signal, and a signal the client computes is a signal an
 *     attacker edits.
 *   - It gives us one throttle point (see check_rate_limit) instead of an open
 *     Google-billing relay. These routes are public by necessity (guest
 *     checkout is the main caller), so without a limiter anyone could burn
 *     the tenant's Maps quota with a loop.
 *
 * Who can call: anyone who can read the site's request token, which is anyone
 * (see Support\Nonce: the token stops a cross-site page, not a script). The
 * per-visitor limiter below and the budget cap the operator sets in Google
 * Cloud are what bound the spend.
 *
 * Degradation: with no key configured every route answers 200 with
 * `{"available": false}` rather than an error. The SPA is told the feature is
 * off before it ever calls (BridgeBoot emits `addressIntel` only when a key is
 * saved), and latches off on this answer if it calls anyway, so an
 * unconfigured site sees plain typed entry and never a console full of 5xx.
 *
 * Enforcement: the validate route reports; it never blocks. It returns a
 * verdict plus Google's corrected address and lets the UI soft-warn. Deciding
 * deliverability for the customer is a revenue risk (Google is confidently
 * wrong about new-construction and rural addresses), so the block/allow call
 * stays a human one.
 */
final class GoogleAddressController extends RestBase
{
    private const AUTOCOMPLETE_URL = 'https://places.googleapis.com/v1/places:autocomplete';
    private const PLACE_URL        = 'https://places.googleapis.com/v1/places/';
    private const VALIDATE_URL     = 'https://addressvalidation.googleapis.com/v1:validateAddress';

    private const TIMEOUT = 6;

    /** Longest value forwarded to Google for any one typed field. */
    private const MAX_FIELD_CHARS = 200;

    /** Primary types that can fill an address form. */
    private const ADDRESS_TYPES = ['street_address', 'premise', 'subpremise'];

    /**
     * Per-visitor budgets, counted in a fixed window. Autocomplete is called
     * on a debounce as the shopper types, so its budget is generous; validate
     * fires once per finished address, so its budget is tight. Both are far
     * above any real session and far below a useful scraping rate.
     */
    private const LIMITS = [
        'autocomplete'  => ['max' => 150, 'window' => 600],
        'place-details' => ['max' => 40,  'window' => 600],
        'validate'      => ['max' => 30,  'window' => 600],
    ];

    /**
     * Site-wide budgets per route per hour, on top of the per-visitor ones.
     * The per-visitor budget alone does not bound the spend: many addresses
     * (a botnet, or many IPv6 /64s) each get a full one, and a visitor with no
     * resolvable IP gets none at all. Over the cap the routes go quiet exactly
     * as over a visitor's budget. Roughly a busy store's peak hour with room to
     * spare; a site that needs more raises them with the
     * `b360_google_address_site_limits` filter (route => max per hour).
     */
    private const SITE_LIMITS = [
        'autocomplete'  => 2000,
        'place-details' => 400,
        'validate'      => 300,
    ];
    private const SITE_WINDOW = 3600;

    /** The type filter was refused and the unfiltered retry worked: send no filter for a day. */
    private const FILTER_REJECTED_KEY = 'b360_addr_type_filter_rejected';
    private const FILTER_REJECTED_TTL = 86400;
    /** The unfiltered retry was refused too (not the filter): do not retry for 10 minutes. */
    private const NO_RETRY_KEY = 'b360_addr_type_filter_no_retry';
    private const NO_RETRY_TTL = 600;

    /** One line per route and upstream status in the API Error Log per this many seconds. */
    private const LOG_THROTTLE = 600;

    /** Upstream HTTP status of the most recent Google call, for the retry in autocomplete(). */
    private int $last_http_status = 0;

    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/address/autocomplete', [
            'methods'             => 'POST',
            'callback'            => [$this, 'autocomplete'],
            'permission_callback' => '__return_true',
            'args'                => [
                'input'        => ['type' => 'string', 'required' => true],
                'sessionToken' => ['type' => 'string', 'required' => false],
                'regionCode'   => ['type' => 'string', 'required' => false],
            ],
        ]);

        register_rest_route(self::NAMESPACE, '/address/place-details', [
            'methods'             => 'POST',
            'callback'            => [$this, 'place_details'],
            'permission_callback' => '__return_true',
            'args'                => [
                'placeId'      => ['type' => 'string', 'required' => true],
                'sessionToken' => ['type' => 'string', 'required' => false],
            ],
        ]);

        register_rest_route(self::NAMESPACE, '/address/validate', [
            'methods'             => 'POST',
            'callback'            => [$this, 'validate'],
            'permission_callback' => '__return_true',
            'args'                => [
                'address'    => ['type' => 'object', 'required' => true],
                'regionCode' => ['type' => 'string', 'required' => false],
            ],
        ]);
    }

    // ---------------------------------------------------------------- routes

    public function autocomplete(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;
        if (!Options::has_google_address_api_key()) return $this->unavailable();
        $limit_err = $this->check_rate_limit('autocomplete');
        if ($limit_err) return $limit_err;

        $input = $this->clip(trim((string) $request->get_param('input')));
        // Two characters suggest nothing useful and still bill. Not an error:
        // the field is simply quiet until the shopper has typed enough.
        if (mb_strlen($input) < 3) {
            return $this->success(['available' => true, 'predictions' => []]);
        }

        $region = $this->region_code($request);

        $body = [
            'input' => $input,
            // RESTRICTS results to the country. `regionCode` alone does NOT:
            // it only biases ranking and formats the response, so without this
            // a search for "531 Jeff" could surface addresses abroad.
            'includedRegionCodes' => [strtolower($region)],
            // Formatting/biasing. Keep both: they do different jobs.
            'regionCode' => $region,
        ];
        // Street addresses only, or Places suggests restaurants and airports,
        // which cannot fill an address form. Left off once Google has refused
        // it (see below).
        $filtered = !get_transient(self::FILTER_REJECTED_KEY);
        if ($filtered) $body['includedPrimaryTypes'] = self::ADDRESS_TYPES;
        $token = $this->session_token($request);
        if ($token !== '') $body['sessionToken'] = $token;

        $res = $this->post_json(self::AUTOCOMPLETE_URL, $body);

        // Google rejects the WHOLE request with INVALID_REQUEST if any entry in
        // includedPrimaryTypes is not a filterable type, which would make
        // autocomplete silently dead rather than merely unfiltered. The docs are
        // ambiguous about whether these three qualify, so rather than bet on
        // them: retry once without the filter and take unfiltered suggestions
        // over none. `filtered` tells the loop below which happened.
        //
        // Both outcomes of the retry are remembered, so neither doubles every
        // later call: the retry worked (the filter is what Google refused, so
        // stop sending it for a day), or the retry was refused too (it was
        // not the filter, a bad key say, so stop retrying for a while).
        if ($filtered && $this->is_invalid_request($res) && !get_transient(self::NO_RETRY_KEY)) {
            unset($body['includedPrimaryTypes']);
            $res = $this->post_json(self::AUTOCOMPLETE_URL, $body);
            $filtered = false;
            if (!is_wp_error($res)) {
                set_transient(self::FILTER_REJECTED_KEY, 1, self::FILTER_REJECTED_TTL);
            } elseif ($this->is_invalid_request($res)) {
                set_transient(self::NO_RETRY_KEY, 1, self::NO_RETRY_TTL);
            }
        }

        if (is_wp_error($res)) return $res;

        $out = [];
        $suggestions = isset($res['suggestions']) && is_array($res['suggestions']) ? $res['suggestions'] : [];
        foreach ($suggestions as $s) {
            if (!is_array($s)) continue;
            $p = $s['placePrediction'] ?? null;
            if (!is_array($p)) continue;

            $placeId = isset($p['placeId']) && is_string($p['placeId']) ? $p['placeId'] : '';
            $text    = '';
            if (isset($p['text']['text']) && is_string($p['text']['text'])) {
                $text = $p['text']['text'];
            }
            if ($placeId === '' || $text === '') continue;

            // Unfiltered fallback: drop anything that is not address-shaped,
            // using the types Google echoes on the prediction itself.
            if (!$filtered && !$this->looks_like_address($p)) continue;

            $out[] = ['placeId' => $placeId, 'text' => $text];
        }

        return $this->success(['available' => true, 'predictions' => $out]);
    }

    public function place_details(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;
        if (!Options::has_google_address_api_key()) return $this->unavailable();
        $limit_err = $this->check_rate_limit('place-details');
        if ($limit_err) return $limit_err;

        $placeId = (string) $request->get_param('placeId');
        // Place ids are opaque tokens; anything outside this alphabet is not
        // one, and we will not interpolate it into a URL to find out.
        if (!preg_match('/\A[A-Za-z0-9_\-]{1,255}\z/', $placeId)) {
            return $this->error('Invalid place id', 400, 'b360_bad_place_id');
        }

        $url = self::PLACE_URL . rawurlencode($placeId);
        $qs  = ['fields' => 'addressComponents,formattedAddress'];
        $token = $this->session_token($request);
        // Closing the session token on the details call is what makes the
        // preceding keystrokes bill as one Autocomplete session rather than
        // per request.
        if ($token !== '') $qs['sessionToken'] = $token;

        $res = $this->get_json($url, $qs);
        if (is_wp_error($res)) return $res;

        return $this->success([
            'available' => true,
            'address'   => $this->components_to_address(
                isset($res['addressComponents']) && is_array($res['addressComponents']) ? $res['addressComponents'] : []
            ),
            // Google's own one-line rendering. The form reads the unit's
            // wording from it ("#4", "Apt 4") when the components carry only
            // a bare number.
            'formatted' => isset($res['formattedAddress']) && is_string($res['formattedAddress']) ? $res['formattedAddress'] : '',
        ]);
    }

    public function validate(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;
        if (!Options::has_google_address_api_key()) return $this->unavailable();
        $limit_err = $this->check_rate_limit('validate');
        if ($limit_err) return $limit_err;

        $addr = $request->get_param('address');
        if (!is_array($addr)) {
            return $this->error('Invalid address', 400, 'b360_bad_address');
        }

        $lines = [];
        foreach (['street1', 'street2'] as $k) {
            $v = $this->field($addr, $k);
            if ($v !== '') $lines[] = $v;
        }
        if (!$lines) {
            return $this->error('Address line required', 400, 'b360_bad_address');
        }

        $region = $this->region_code($request);

        $body = ['address' => array_filter([
            'regionCode'         => $region,
            'addressLines'       => $lines,
            'locality'           => $this->field($addr, 'city'),
            'administrativeArea' => $this->field($addr, 'state'),
            'postalCode'         => $this->field($addr, 'zip'),
        ], static function ($v) { return $v !== '' && $v !== []; })];

        // CASS is US/PR only and errors elsewhere. It is what yields
        // dpvConfirmation, the strongest "this mailbox exists" signal we get.
        if ($region === 'US' || $region === 'PR') {
            $body['enableUspsCass'] = true;
        }

        $res = $this->post_json(self::VALIDATE_URL, $body);
        if (is_wp_error($res)) return $res;

        return $this->success(['available' => true] + $this->summarize_verdict($res));
    }

    // --------------------------------------------------------------- helpers

    /**
     * Flatten Google's verdict into the few booleans the UI and any downstream
     * fraud scoring actually consume. Everything is defensively read: this is
     * third-party JSON and a missing branch must degrade to "we don't know",
     * never to a PHP notice or a false accusation.
     *
     * `deliverable` is deliberately three-state (true/false/null): null means
     * Google did not tell us, which must NOT be rendered as a warning.
     */
    private function summarize_verdict(array $res): array
    {
        $result  = isset($res['result']) && is_array($res['result']) ? $res['result'] : [];
        $verdict = isset($result['verdict']) && is_array($result['verdict']) ? $result['verdict'] : [];
        $usps    = isset($result['uspsData']) && is_array($result['uspsData']) ? $result['uspsData'] : [];
        $address = isset($result['address']) && is_array($result['address']) ? $result['address'] : [];

        $dpv = isset($usps['dpvConfirmation']) && is_string($usps['dpvConfirmation'])
            ? $usps['dpvConfirmation']
            : '';

        // Y = primary+secondary confirmed, D = primary confirmed/secondary
        // missing, S = secondary present but unconfirmed, N = failed.
        // D and S are deliverable mail-wise; only N is a real negative.
        $deliverable = null;
        if ($dpv !== '') {
            $deliverable = in_array($dpv, ['Y', 'D', 'S'], true);
        }

        $formatted = isset($address['formattedAddress']) && is_string($address['formattedAddress'])
            ? $address['formattedAddress']
            : '';

        $suggested = [];
        if (isset($address['postalAddress']) && is_array($address['postalAddress'])) {
            $suggested = $this->postal_to_address($address['postalAddress']);
        }

        return [
            'verdict' => [
                'complete'       => (bool) ($verdict['addressComplete'] ?? false),
                'unconfirmed'    => (bool) ($verdict['hasUnconfirmedComponents'] ?? false),
                'inferred'       => (bool) ($verdict['hasInferredComponents'] ?? false),
                'replaced'       => (bool) ($verdict['hasReplacedComponents'] ?? false),
                'spellCorrected' => (bool) ($verdict['hasSpellCorrectedComponents'] ?? false),
                'granularity'    => isset($verdict['validationGranularity']) && is_string($verdict['validationGranularity'])
                    ? $verdict['validationGranularity']
                    : 'GRANULARITY_UNSPECIFIED',
                'dpv'            => $dpv,
                'deliverable'    => $deliverable,
            ],
            'formatted' => $formatted,
            // (object): an address with nothing in it must reach the SPA as
            // {}, not as the [] an empty PHP array encodes to.
            'suggested' => (object) $suggested,
        ];
    }

    /** Google PostalAddress -> our address field names. */
    private function postal_to_address(array $pa): array
    {
        $lines = isset($pa['addressLines']) && is_array($pa['addressLines']) ? $pa['addressLines'] : [];

        return array_filter([
            'street1' => isset($lines[0]) && is_string($lines[0]) ? $lines[0] : '',
            'street2' => isset($lines[1]) && is_string($lines[1]) ? $lines[1] : '',
            'city'    => isset($pa['locality']) && is_string($pa['locality']) ? $pa['locality'] : '',
            'state'   => isset($pa['administrativeArea']) && is_string($pa['administrativeArea']) ? $pa['administrativeArea'] : '',
            'zip'     => isset($pa['postalCode']) && is_string($pa['postalCode']) ? $pa['postalCode'] : '',
        ], static function ($v) { return $v !== ''; });
    }

    /**
     * Places addressComponents -> our address field names. street1 is composed
     * from street_number + route because Places returns them separately and an
     * address form wants one line.
     */
    private function components_to_address(array $components)
    {
        $by = [];
        foreach ($components as $c) {
            if (!is_array($c)) continue;
            $types = isset($c['types']) && is_array($c['types']) ? $c['types'] : [];
            $long  = isset($c['longText']) && is_string($c['longText']) ? $c['longText'] : '';
            $short = isset($c['shortText']) && is_string($c['shortText']) ? $c['shortText'] : '';
            foreach ($types as $t) {
                if (!is_string($t) || isset($by[$t])) continue;
                $by[$t] = ['long' => $long, 'short' => $short];
            }
        }

        $num   = $by['street_number']['long'] ?? '';
        $route = $by['route']['long'] ?? '';
        $line1 = trim($num . ' ' . $route);

        // (object) for the same reason as `suggested` above.
        return (object) array_filter([
            'street1' => $line1,
            'street2' => $by['subpremise']['long'] ?? '',
            'city'    => $by['locality']['long']
                ?? ($by['postal_town']['long'] ?? ($by['sublocality']['long'] ?? '')),
            // Short form: our State dropdown matches on the 2-letter code.
            'state'   => $by['administrative_area_level_1']['short'] ?? '',
            'zip'     => $by['postal_code']['long'] ?? '',
            'country' => $by['country']['short'] ?? '',
        ], static function ($v) { return $v !== ''; });
    }

    /**
     * True when Google rejected the request shape itself (HTTP 400), as
     * opposed to being unreachable or refusing the key. Only that case is
     * worth retrying with a smaller body.
     */
    private function is_invalid_request($res): bool
    {
        return is_wp_error($res)
            && $res->get_error_code() === 'b360_google_error'
            && $this->last_http_status === 400;
    }

    /**
     * Does this prediction look like something that can fill an address form?
     * Used only on the unfiltered retry path.
     */
    private function looks_like_address(array $prediction): bool
    {
        $types = isset($prediction['types']) && is_array($prediction['types']) ? $prediction['types'] : [];
        foreach ($types as $t) {
            if (is_string($t) && in_array($t, self::ADDRESS_TYPES, true)) return true;
        }
        // No types echoed: keep it rather than silently hiding a real address.
        return $types === [];
    }

    /**
     * Per-visitor fixed-window counter in a transient, then the site-wide
     * hourly cap (SITE_LIMITS).
     *
     * Fixed window, not sliding: a shopper can burst at a boundary, which is
     * fine, this exists to stop a relay loop, not to shape traffic. When no
     * per-visitor IP is resolvable the per-visitor limiter is SKIPPED rather
     * than applied to the whole tenant (the site-wide cap still applies), matching sensitiveClientIp()'s reasoning in
     * docs/carding-defense-layer0.md: one shared egress IP must never let one
     * shopper lock out the rest.
     *
     * The window's end travels inside the stored value. set_transient re-arms
     * its TTL on every write, and where the remaining TTL can be read back
     * depends on whether the site has a persistent object cache, so the
     * counter does not ask: it carries its own reset time and each write is
     * given exactly the seconds that are left.
     *
     * Best effort, like every transient counter here: WordPress offers no
     * lock, so requests that arrive together can each read the count before
     * any of them has written it, and a burst can exceed the budget by about
     * its own concurrency.
     */
    private function check_rate_limit(string $bucket): ?WP_Error
    {
        $limit = self::LIMITS[$bucket] ?? null;
        if ($limit === null) return null;

        // The visitor first, so one visitor over their own budget does not
        // also spend the site's.
        $who = $this->client_bucket();
        if ($who !== '' && !$this->take('b360_addr_rl_' . $bucket . '_' . md5($who), $limit['max'], $limit['window'])) {
            return $this->rate_limited();
        }

        $site = $this->site_limit($bucket);
        if ($site > 0 && !$this->take('b360_addr_site_' . $bucket, $site, self::SITE_WINDOW)) {
            return $this->rate_limited();
        }
        return null;
    }

    /** The site-wide hourly cap for a route, after the filter. 0 or less turns it off. */
    private function site_limit(string $bucket): int
    {
        $limits = apply_filters('b360_google_address_site_limits', self::SITE_LIMITS);
        if (!is_array($limits) || !isset($limits[$bucket]) || !is_numeric($limits[$bucket])) {
            return self::SITE_LIMITS[$bucket] ?? 0;
        }
        return (int) $limits[$bucket];
    }

    /**
     * Count one use against a fixed-window counter. False when the window is
     * already full (nothing is counted then).
     */
    private function take(string $key, int $max, int $window): bool
    {
        $now   = time();
        $state = get_transient($key);

        $n     = is_array($state) && isset($state['n']) ? (int) $state['n'] : 0;
        $reset = is_array($state) && isset($state['reset']) ? (int) $state['reset'] : 0;
        if ($reset <= $now) {
            $n     = 0;
            $reset = $now + $window;
        }

        if ($n >= $max) return false;

        set_transient($key, ['n' => $n + 1, 'reset' => $reset], max(1, $reset - $now));
        return true;
    }

    private function rate_limited(): WP_Error
    {
        return $this->error(
            'Too many address lookups. Please try again shortly.',
            429,
            'b360_rate_limited'
        );
    }

    /**
     * What one visitor's budget is counted against: the IPv4 address, or the
     * /64 of an IPv6 address. A single IPv6 subscriber is routinely handed a
     * whole /64, so counting each of its addresses separately would give one
     * machine an unlimited supply of fresh budgets.
     *
     * REMOTE_ADDR only, deliberately NOT X-Forwarded-For, which a client can
     * spoof freely and would let an attacker mint a new bucket per request.
     * Tenants behind a proxy that rewrites REMOTE_ADDR are already handled by
     * that proxy; behind one that does not, every visitor shares the proxy's
     * bucket, and the cost of that is suggestions going quiet early, never a
     * blocked form.
     */
    private function client_bucket(): string
    {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
        if (!filter_var($ip, FILTER_VALIDATE_IP)) return '';

        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $packed = @inet_pton($ip);
            if (is_string($packed) && strlen($packed) === 16) {
                // An IPv4 visitor seen through a dual-stack socket arrives as
                // ::ffff:a.b.c.d. Counted per /64 that would put every IPv4
                // visitor in one bucket, so it is counted as the IPv4 address.
                if (substr($packed, 0, 12) === str_repeat("\0", 10) . "\xff\xff") {
                    $v4 = @inet_ntop(substr($packed, 12));
                    if (is_string($v4) && $v4 !== '') return $v4;
                }
                return 'v6:' . bin2hex(substr($packed, 0, 8));
            }
        }
        return $ip;
    }

    private function region_code(WP_REST_Request $request): string
    {
        $r = strtoupper(trim((string) $request->get_param('regionCode')));
        return preg_match('/\A[A-Z]{2}\z/', $r) ? $r : 'US';
    }

    private function session_token(WP_REST_Request $request): string
    {
        $t = trim((string) $request->get_param('sessionToken'));
        // Google's own constraint: URL-safe base64, <= 36 chars.
        return preg_match('/\A[A-Za-z0-9_\-]{1,36}\z/', $t) ? $t : '';
    }

    /** One typed address field: a trimmed string, clipped, '' for anything else. */
    private function field(array $addr, string $key): string
    {
        return isset($addr[$key]) && is_string($addr[$key]) ? $this->clip(trim($addr[$key])) : '';
    }

    /** No real address line is longer than this; a megabyte of input is not forwarded. */
    private function clip(string $value): string
    {
        return mb_substr($value, 0, self::MAX_FIELD_CHARS);
    }

    private function unavailable(): \WP_REST_Response
    {
        return $this->success(['available' => false]);
    }

    // ------------------------------------------------------------ transport

    private function post_json(string $url, array $body)
    {
        return $this->request($url, [
            'method'  => 'POST',
            'headers' => [
                'Content-Type'   => 'application/json',
                'X-Goog-Api-Key' => Options::get_google_address_api_key(),
            ],
            'body'    => wp_json_encode($body),
            'timeout' => self::TIMEOUT,
        ]);
    }

    private function get_json(string $url, array $query)
    {
        return $this->request(add_query_arg($query, $url), [
            'method'  => 'GET',
            'headers' => [
                'X-Goog-Api-Key'   => Options::get_google_address_api_key(),
                // Places (New) requires an explicit field mask; the `fields`
                // query arg alone is not honored on the details endpoint.
                'X-Goog-FieldMask' => 'addressComponents,formattedAddress',
            ],
            'timeout' => self::TIMEOUT,
        ]);
    }

    /**
     * One place where a Google call can fail. Every failure mode collapses to
     * a 502 with a generic message: Google's error bodies can quote the key
     * back and must never reach a storefront visitor. The detail goes to the
     * logs for the operator.
     */
    private function request(string $url, array $args)
    {
        $this->last_http_status = 0;
        $res = wp_remote_request($url, $args);

        if (is_wp_error($res)) {
            $this->log_failure($args['method'], $url, 0, $res->get_error_message());
            return $this->error('Address lookup unavailable', 502, 'b360_google_unreachable');
        }

        $code = (int) wp_remote_retrieve_response_code($res);
        $this->last_http_status = $code;
        $raw  = (string) wp_remote_retrieve_body($res);

        if ($code < 200 || $code >= 300) {
            $this->log_failure($args['method'], $url, $code, substr($raw, 0, 500));
            return $this->error('Address lookup unavailable', 502, 'b360_google_error');
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            $this->log_failure($args['method'], $url, $code, 'Unparseable body: ' . substr($raw, 0, 200));
            return $this->error('Address lookup unavailable', 502, 'b360_google_bad_body');
        }

        return $decoded;
    }

    /**
     * Record a failed Google call where the operator will look for it: the
     * PHP error log, and the API Error Log on the settings page (a rejected
     * or unbilled key is an operator fix, and that page is where the other
     * upstream failures already are).
     *
     * The key travels in a request header, never in the URL, but the detail
     * is Google's own text: the key and the session token are struck out of
     * it before it is stored anywhere.
     *
     * The settings-page list holds 50 lines shared with the bridge API's
     * errors, and a Google outage fails every keystroke of every shopper, so
     * that write is throttled to one line per route and status per
     * LOG_THROTTLE seconds.
     */
    private function log_failure(string $method, string $url, int $status, string $detail): void
    {
        $key = Options::get_google_address_api_key();
        if ($key !== '') {
            $detail = str_replace($key, '[redacted]', $detail);
        }
        $safe_url = (string) preg_replace('/(key|sessionToken)=[^&\s]+/i', '$1=[redacted]', $url);
        $route    = (string) preg_replace('/\?.*\z/s', '', $safe_url);
        // A place id is not a secret, but one line per place would defeat the throttle.
        if (strpos($route, self::PLACE_URL) === 0) $route = self::PLACE_URL . '{id}';

        error_log('[B360Bridge] Google address call failed: ' . $method . ' ' . $safe_url . ', status ' . $status . ', ' . $detail);

        $throttle = 'b360_addr_log_' . md5($route . '|' . $status);
        if (get_transient($throttle)) return;
        set_transient($throttle, 1, self::LOG_THROTTLE);
        ApiErrorLog::log($method, $route, $status, 'Google address lookup failed', $detail);
    }
}
