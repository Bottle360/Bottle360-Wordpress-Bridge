<?php

namespace Bottle360\Bridge\Rest;

use Bottle360\Bridge\Support\Nonce;
use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class NonceController extends RestBase
{
    public function register_routes(): void
    {
        // POST is what the SPA uses (BD-4921): a page cache or CDN rule that
        // ignores no-store can still answer a GET from a stored copy or strip
        // its cookies, and a POST is not served from cache. GET stays for
        // bundles from before the change and as the SPA's fallback.
        register_rest_route(self::NAMESPACE, '/nonce', [
            [
                'methods'             => 'GET',
                'callback'            => [$this, 'get_nonce'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods'             => 'POST',
                'callback'            => [$this, 'get_nonce'],
                'permission_callback' => '__return_true',
            ],
        ]);
    }

    public function get_nonce(WP_REST_Request $request)
    {
        return $this->success(['nonce' => Nonce::value()]);
    }
}
