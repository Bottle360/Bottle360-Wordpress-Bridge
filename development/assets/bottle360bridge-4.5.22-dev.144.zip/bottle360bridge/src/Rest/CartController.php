<?php

namespace Bottle360\Bridge\Rest;

use WP_REST_Request;

if (!defined('ABSPATH')) exit;

final class CartController extends RestBase
{
    public function register_routes(): void
    {
        register_rest_route(self::NAMESPACE, '/cart', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_cart'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/cart/add', [
            'methods'             => 'POST',
            'callback'            => [$this, 'add_item'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/cart/update-qty', [
            'methods'             => 'POST',
            'callback'            => [$this, 'update_qty'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE, '/cart/remove', [
            'methods'             => 'POST',
            'callback'            => [$this, 'remove_item'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function get_cart(WP_REST_Request $request)
    {
        return $this->proxy_get('cart/get');
    }

    public function add_item(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params  = $request->get_json_params();
        $skuCode = sanitize_text_field(wp_unslash($params['sku_code'] ?? ''));
        $qty     = max(1, (int) ($params['qty'] ?? 1));

        if ($skuCode === '') {
            return $this->error('sku_code is required', 400);
        }

        $body = ['sku_code' => $skuCode, 'qty' => $qty];

        if (isset($params['vintage_id'])) {
            $body['vintage_id'] = (int) $params['vintage_id'];
        }
        if (isset($params['product_id'])) {
            $body['product_id'] = (int) $params['product_id'];
        }

        // Optional customer-chosen price for open-amount gift-card SKUs. Core
        // owns every rule (CUSTOM_PRICE_FORBIDDEN for an ineligible SKU,
        // INVALID_CUSTOM_PRICE for zero, negative or more than 2 decimals,
        // CUSTOM_PRICE_TOO_LARGE above its cap), so any numeric value is
        // forwarded and the shopper sees core's own 422. BD-5014: this used
        // to drop anything outside 0 < price <= 10000, which turned a bad
        // amount into a silent price-less add. Non-numeric or empty input is
        // still dropped. A numeric string too large for a float is passed on
        // as the string (json_encode cannot encode INF); core reads it as
        // over the cap.
        if (isset($params['price']) && $params['price'] !== '' && !is_bool($params['price'])
            && is_numeric($params['price'])
        ) {
            $price = floatval($params['price']);
            $body['price'] = is_finite($price) ? $price : trim((string) $params['price']);
        }

        return $this->proxy_post('cart/add', $body);
    }

    public function update_qty(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params  = $request->get_json_params();
        $skuCode = sanitize_text_field(wp_unslash($params['sku_code'] ?? ''));
        $qty     = max(1, (int) ($params['qty'] ?? 1));

        if ($skuCode === '') {
            return $this->error('sku_code is required', 400);
        }

        return $this->proxy_post('cart/updateQty', [
            'sku_code' => $skuCode,
            'qty'      => $qty,
        ]);
    }

    public function remove_item(WP_REST_Request $request)
    {
        $nonce_err = $this->check_nonce($request);
        if ($nonce_err) return $nonce_err;

        $params  = $request->get_json_params();
        $skuCode = sanitize_text_field(wp_unslash($params['sku_code'] ?? ''));

        if ($skuCode === '') {
            return $this->error('sku_code is required', 400);
        }

        return $this->proxy_post('cart/remove', ['sku_code' => $skuCode]);
    }
}
