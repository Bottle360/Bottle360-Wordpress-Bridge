<?php
namespace Bottle360\Bridge\Support;

if (!defined('ABSPATH')) exit;

/**
 * The request token every mutating REST call carries in `X-B360-Nonce`
 * (BD-4921).
 *
 * What it is: a site-wide value that rotates every 12 hours,
 * `b1.<tick>.<mac>`, where the mac is an HMAC of the tick keyed with this
 * site's nonce salt. Anyone can read the current value from GET or POST
 * /b360/v1/nonce. That is what the WordPress nonce already was for store
 * members: they are not WordPress users, so core computed it for user 0 with
 * an empty session token, one value per site per tick.
 *
 * What it is not: a secret, a per-visitor value, or proof of who is calling.
 * Identity is the bridge session cookie, never this.
 *
 * Why it is not a WordPress nonce any more. On 2026-10-06 members of one
 * site were shown this plugin's "Invalid or missing nonce" 403. Those
 * failures were not reproduced and their cause is not known. What was
 * measured on that site the next day: the WordPress nonce minted for a
 * request carrying a `wordpress_logged_in_*` cookie differed from the one
 * minted for a request without it, and the value did not rotate on the 12
 * hour schedule. What makes that happen there was not identified. A
 * WordPress nonce is in any case not a function of this plugin alone
 * (wp_create_nonce / wp_verify_nonce read the `nonce_life` and
 * `nonce_user_logged_out` filters and WordPress's own login cookie), so this
 * token takes those inputs away: it depends on the clock and the nonce salt
 * and on nothing in the request. Whether that ends the 403s on that site is
 * something the refusal log in RestBase::check_nonce has to show.
 *
 * Where the cross-site protection comes from: the header, not the value. A
 * page on another origin cannot attach a custom `X-B360-Nonce` header without
 * a CORS preflight, and WordPress answers that preflight with an
 * Access-Control-Allow-Headers list that does not contain it
 * (WP_REST_Server::serve_request: Authorization, X-WP-Nonce,
 * Content-Disposition, Content-MD5, Content-Type). rest_send_cors_headers
 * does reflect any Origin with credentials allowed, so that header list is
 * the only thing standing in the way: this plugin must never add
 * `X-B360-Nonce` through the `rest_allowed_cors_headers` filter, and a site
 * where some other plugin allows every request header has no cross-site
 * protection on these routes, with this token or with the WordPress nonce.
 */
final class Nonce
{
    public const ACTION = 'b360_nonce';

    /** Seconds per tick, the same 12 hours WordPress uses by default. */
    private const TICK_SECONDS = 43200;

    /**
     * \A and \z, not ^ and $: `$` would let a trailing newline through. The
     * tick is canonical decimal (no leading zeros), so one tick has one
     * spelling.
     */
    private const FORMAT = '/\Ab1\.(0|[1-9]\d{0,9})\.([0-9a-f]{32})\z/';

    public static function value(): string
    {
        $tick = self::currentTick();
        return 'b1.' . $tick . '.' . self::mac($tick);
    }

    public static function verify(string $token): bool
    {
        return self::refusalReason($token) === '';
    }

    /**
     * Why a token is refused, or '' when it is accepted. One of `empty`,
     * `malformed`, `bad_mac`, `expired`, `legacy_invalid`. RestBase adds
     * `missing` for a request with no header at all and records the reason.
     *
     * Accepted ticks: the current one, the previous one (a token lives 12 to
     * 24 hours, as a WordPress nonce does) and the next one, so a token
     * minted by a node whose clock runs slightly ahead is not refused by a
     * node that has not reached the boundary yet.
     */
    public static function refusalReason(string $token): string
    {
        if ($token === '') return 'empty';

        if (strncmp($token, 'b1.', 3) !== 0) {
            // TRANSITIONAL (BD-4921): a tab or a cached bundle from before the
            // update still holds a WordPress nonce. Keep accepting it so the
            // update does not fail writes that are already in flight. Remove
            // one release after every site is on a version that mints b1
            // tokens.
            return wp_verify_nonce($token, self::ACTION) ? '' : 'legacy_invalid';
        }

        if (!preg_match(self::FORMAT, $token, $m)) return 'malformed';

        $tick = (int) $m[1];
        if (!hash_equals(self::mac($tick), $m[2])) return 'bad_mac';

        if (abs($tick - self::currentTick()) > 1) return 'expired';

        return '';
    }

    /** The tick a well-formed token claims, null for anything else (legacy values included). */
    public static function tickOf(string $token): ?int
    {
        return preg_match(self::FORMAT, $token, $m) ? (int) $m[1] : null;
    }

    public static function currentTick(): int
    {
        return intdiv(time(), self::TICK_SECONDS);
    }

    private static function mac(int $tick): string
    {
        return substr(hash_hmac('sha256', 'b360_request|' . $tick, wp_salt('nonce')), 0, 32);
    }
}
