<?php

namespace Bottle360\Bridge\Seo;

use Bottle360\Bridge\Settings\Options;
use Bottle360\Bridge\Api\BridgeApiClient;
use Bottle360\Bridge\Routing\SpaRoutes;

if (!defined('ABSPATH')) exit;

/**
 * Outputs SEO meta tags (description, Open Graph, Twitter Card, canonical)
 * for the B360 app page on initial page load.
 *
 * For product and club detail pages the Bridge API is called (with transient
 * caching) so crawlers see real titles, descriptions, and images in the HTML
 * head, even though the Vue SPA hasn't mounted yet.
 */
final class MetaTags
{
    /** @var array|null Cached meta for the current request (computed once). */
    private ?array $meta = null;

    public function register(): void
    {
        add_action('wp_head', [$this, 'render'], 1);
        add_filter('get_canonical_url', [$this, 'filterCanonical'], 10, 2);
        add_filter('document_title_parts', [$this, 'filterTitle'], 20);

        // SEO plugins print their own canonical and og:url and never read
        // get_canonical_url, so every sub-route of the app page (e.g.
        // /store/wine/<slug>/<id>/) told Google it was a copy of /store/ and
        // wine pages could not be indexed (BD-5029, hertelendy.com on Yoast).
        // Registering is harmless when the plugin is absent: nothing fires.
        add_filter('wpseo_canonical', [$this, 'filterSeoPluginUrl'], 20, 1);
        add_filter('wpseo_opengraph_url', [$this, 'filterSeoPluginUrl'], 20, 1);
        add_filter('rank_math/frontend/canonical', [$this, 'filterSeoPluginUrl'], 20, 1);
        add_filter('rank_math/opengraph/url', [$this, 'filterSeoPluginUrl'], 20, 1);

        // The same plugins print their own <title>, description, Open Graph and
        // Twitter tags too (the landing page's, on every sub-route), so on a
        // product or club route we hand them our values instead of printing a
        // second copy of each tag. Filter names and arguments checked against
        // Yoast SEO 28.7 and Rank Math 1.0.280 source.
        add_filter('wpseo_title', [$this, 'seoDocumentTitle'], 20, 1);
        add_filter('wpseo_metadesc', [$this, 'seoDescription'], 20, 1);
        add_filter('wpseo_opengraph_title', [$this, 'seoTitle'], 20, 1);
        add_filter('wpseo_opengraph_desc', [$this, 'seoDescription'], 20, 1);
        add_filter('wpseo_opengraph_type', [$this, 'seoOgType'], 20, 1);
        add_filter('wpseo_twitter_title', [$this, 'seoTitle'], 20, 1);
        add_filter('wpseo_twitter_description', [$this, 'seoDescription'], 20, 1);
        add_filter('wpseo_twitter_image', [$this, 'seoImage'], 20, 1);
        add_filter('wpseo_frontend_presenters', [$this, 'yoastPresenters'], 20, 1);
        add_filter('rank_math/frontend/title', [$this, 'seoDocumentTitle'], 20, 1);
        add_filter('rank_math/frontend/description', [$this, 'seoDescription'], 20, 1);
        add_filter('rank_math/opengraph/facebook/og_title', [$this, 'seoTitle'], 20, 1);
        add_filter('rank_math/opengraph/facebook/og_description', [$this, 'seoDescription'], 20, 1);
        add_filter('rank_math/opengraph/type', [$this, 'seoOgType'], 20, 1);
        add_filter('rank_math/opengraph/twitter/twitter_title', [$this, 'seoTitle'], 20, 1);
        add_filter('rank_math/opengraph/twitter/twitter_description', [$this, 'seoDescription'], 20, 1);
        add_filter('rank_math/opengraph/facebook/image_array', [$this, 'rankMathImageArray'], 20, 1);
        add_filter('rank_math/opengraph/twitter/image_array', [$this, 'rankMathImageArray'], 20, 1);
    }

    // ------------------------------------------------------------------
    // SEO plugin hand-off (Yoast SEO, Rank Math)
    // ------------------------------------------------------------------

    /**
     * Our resolved value for $key on an app page sub-route, or null to leave
     * the SEO plugin's own value. Null on every other page, on the store
     * landing route (the operator's SEO plugin settings stay in charge there),
     * on a path outside the base path, and whenever we have no value.
     */
    private function handOff(string $key): ?string
    {
        if (!$this->isAppPage()) return null;
        $sub = $this->subPath();
        if ($sub === null || $sub === '') return null;
        $meta = $this->resolveMeta();
        $val  = $meta[$key] ?? '';
        return is_string($val) && $val !== '' ? $val : null;
    }

    /**
     * <title>: our title plus the site name, as WordPress's own document title
     * would read without the plugin ("Legend 2019 - Hertelendy").
     *
     * @param mixed $title
     * @return mixed
     */
    public function seoDocumentTitle($title)
    {
        $ours = $this->handOff('title');
        if ($ours === null) return $title;
        return $ours . ' ' . self::titleSeparator() . ' ' . get_bloginfo('name');
    }

    /**
     * The active SEO plugin's own title separator (as it stores it, e.g.
     * `&#8211;`, which its title output already handles), else WordPress's
     * document_title_separator. Every plugin call is guarded: a missing or
     * changed API falls back, never fatals.
     */
    private static function titleSeparator(): string
    {
        try {
            if (defined('WPSEO_VERSION') && function_exists('YoastSEO')) {
                // isset() first: Yoast's Main and helper surface implement
                // __isset, and a missing surface makes __get throw.
                $yoast   = YoastSEO();
                $helpers = is_object($yoast) && isset($yoast->helpers) ? $yoast->helpers : null;
                $options = is_object($helpers) && isset($helpers->options) ? $helpers->options : null;
                if (is_object($options) && method_exists($options, 'get_title_separator')) {
                    $sep = $options->get_title_separator();
                    if (is_string($sep) && trim($sep) !== '') return $sep;
                }
            }
            if (defined('RANK_MATH_VERSION') && class_exists('RankMath\\Helper') && method_exists('RankMath\\Helper', 'get_settings')) {
                $sep = \RankMath\Helper::get_settings('titles.title_separator');
                if (is_string($sep) && trim($sep) !== '') return $sep;
            }
        } catch (\Throwable $e) {
            // Fall through to the WordPress separator.
        }
        return (string) apply_filters('document_title_separator', '-');
    }

    /**
     * Plain one-line text for a meta / og / twitter description. Teasers are
     * operator HTML (Hertelendy's carry <p> and <br>), which must not reach a
     * content attribute as markup.
     *
     * @param mixed $html
     */
    private static function plainText($html): string
    {
        if (!is_string($html) || $html === '') return '';
        // A line or block break is a word break: "<p>Bold</p><p>Red</p>" must
        // read "Bold Red", not "BoldRed".
        $html = (string) preg_replace('#<(br|/p|/div|/li|/h[1-6])\b[^>]*>#i', ' $0', $html);
        return trim((string) preg_replace('/\s+/u', ' ', wp_strip_all_tags($html)));
    }

    /** og:title / twitter:title. @param mixed $title @return mixed */
    public function seoTitle($title)
    {
        return $this->handOff('title') ?? $title;
    }

    /** Meta description, og:description, twitter:description. @param mixed $desc @return mixed */
    public function seoDescription($desc)
    {
        return $this->handOff('description') ?? $desc;
    }

    /** og:type ("product" on product routes). @param mixed $type @return mixed */
    public function seoOgType($type)
    {
        return $this->handOff('og_type') ?? $type;
    }

    /** Yoast twitter:image (a plain string it prints when non-empty). @param mixed $url @return mixed */
    public function seoImage($url)
    {
        return $this->handOff('image') ?? $url;
    }

    /**
     * Yoast's og:image cannot be replaced through a filter: wpseo_opengraph_image
     * only rewrites images Yoast already has (none, or the page's own), and
     * wpseo_add_opengraph_images adds beside the page's own image. So when we
     * have a product image we drop Yoast's og:image presenter and render()
     * prints ours, one tag either way.
     *
     * @param mixed $presenters
     * @return mixed
     */
    public function yoastPresenters($presenters)
    {
        if (!is_array($presenters) || $this->handOff('image') === null) return $presenters;
        return array_values(array_filter($presenters, function ($p) {
            return !is_a($p, 'Yoast\\WP\\SEO\\Presenters\\Open_Graph\\Image_Presenter');
        }));
    }

    /**
     * Rank Math adds the page's own images (and its default) one by one; with
     * a product image we drop each of them and render() prints ours. Dropping
     * rather than adding ours here, because Rank Math re-validates an added
     * URL and strips its query string.
     *
     * @param mixed $attachment
     * @return mixed
     */
    public function rankMathImageArray($attachment)
    {
        return $this->handOff('image') === null ? $attachment : [];
    }

    /**
     * Sub-route canonical / og:url for Yoast SEO and Rank Math.
     *
     * Only touches the Bridge app page, and only its sub-routes: the store
     * landing route keeps whatever the plugin computed (including a custom
     * canonical the operator typed into the plugin's page settings). An empty
     * value is the plugin deciding to print no tag (a noindex page, say) and is
     * passed through rather than turned into one. A request path that is not
     * under the base path (a WPML / Polylang language prefix, a case variant)
     * is also passed through: we cannot say which sub-route it is.
     *
     * @param string|false $url
     * @return string|false
     */
    public function filterSeoPluginUrl($url)
    {
        if (!is_string($url) || $url === '') return $url;
        if (!$this->isAppPage()) return $url;
        $sub = $this->subPath();
        if ($sub === null || $sub === '') return $url;

        return $this->buildCanonical();
    }

    /**
     * Override the <title> tag for dynamic pages (products, clubs, collections).
     *
     * Runs at priority 20 so it overrides AppRoute::setTitle (priority 10).
     */
    public function filterTitle(array $title): array
    {
        if (!$this->isAppPage()) return $title;

        $meta = $this->resolveMeta();
        if (!empty($meta['title'])) {
            $title['title'] = $meta['title'];
        }

        return $title;
    }

    public function render(): void
    {
        if (!$this->isAppPage()) return;

        $meta = $this->resolveMeta();
        if (empty($meta)) return;

        $siteName = get_bloginfo('name');

        // Product detail LCP: the gallery's lead image only starts downloading
        // once the SPA has booted, fetched the product and mounted the gallery.
        // A preload here starts it during HTML parse. Same URL the gallery picks
        // (galleryLeadImage), so the browser reuses this response.
        if (!empty($meta['lcp_image'])) {
            echo '<link rel="preload" as="image" href="' . esc_url($meta['lcp_image']) . '" fetchpriority="high" />' . "\n";
        }

        // With Yoast / Rank Math active they print the description, Open Graph
        // and Twitter tags (fed our values through the hand-off filters above
        // on sub-routes), so ours would be a second copy. The image is the
        // exception: we suppress theirs and print ours (see yoastPresenters,
        // rankMathImageArray), except Yoast's twitter:image, which takes a
        // plain filter.
        $owns     = $this->seoPluginOwnership();
        $handOff  = $owns['plugin'] !== '' && $this->subPath() !== '';
        $hasImage = !empty($meta['image']);

        if (!empty($meta['description']) && !$owns['description']) {
            echo '<meta name="description" content="' . esc_attr($meta['description']) . '" />' . "\n";
        }

        // Open Graph
        if (!$owns['og']) {
            echo '<meta property="og:site_name" content="' . esc_attr($siteName) . '" />' . "\n";
            echo '<meta property="og:type" content="' . esc_attr($meta['og_type'] ?? 'website') . '" />' . "\n";
            if (!empty($meta['title'])) {
                echo '<meta property="og:title" content="' . esc_attr($meta['title']) . '" />' . "\n";
            }
            if (!empty($meta['description'])) {
                echo '<meta property="og:description" content="' . esc_attr($meta['description']) . '" />' . "\n";
            }
        }
        if ($hasImage && (!$owns['og'] || $handOff)) {
            echo '<meta property="og:image" content="' . esc_url($meta['image']) . '" />' . "\n";
        }
        if (!empty($meta['canonical']) && !$owns['og']) {
            echo '<meta property="og:url" content="' . esc_url($meta['canonical']) . '" />' . "\n";
        }

        // Twitter Card
        if (!$owns['twitter']) {
            $cardType = $hasImage ? 'summary_large_image' : 'summary';
            echo '<meta name="twitter:card" content="' . esc_attr($cardType) . '" />' . "\n";
            if (!empty($meta['title'])) {
                echo '<meta name="twitter:title" content="' . esc_attr($meta['title']) . '" />' . "\n";
            }
            if (!empty($meta['description'])) {
                echo '<meta name="twitter:description" content="' . esc_attr($meta['description']) . '" />' . "\n";
            }
        }
        if ($hasImage && (!$owns['twitter'] || ($handOff && $owns['plugin'] === 'rankmath'))) {
            echo '<meta name="twitter:image" content="' . esc_url($meta['image']) . '" />' . "\n";
        }
    }

    /**
     * Fix WP's canonical URL for SPA sub-routes.
     *
     * Without this, every sub-route (e.g. /store/clubs/) gets a canonical
     * pointing back to the base page (/store/).
     *
     * @param string   $canonical
     * @param \WP_Post $post
     */
    public function filterCanonical(string $canonical, $post): string
    {
        $page_id = (int) get_option('b360_app_page_id', 0);
        if ($page_id <= 0 || (int) $post->ID !== $page_id) return $canonical;

        $built = $this->buildCanonical();
        return $built !== '' ? $built : $canonical;
    }

    // ------------------------------------------------------------------
    // Internal
    // ------------------------------------------------------------------

    /**
     * Which head tags an active SEO plugin prints itself on this page. Yoast
     * always prints the description; Open Graph and Twitter can each be
     * switched off in its settings, and then it prints none and ours stay.
     * Rank Math always prints all three.
     *
     * @return array{plugin: string, description: bool, og: bool, twitter: bool}
     */
    private function seoPluginOwnership(): array
    {
        if (defined('WPSEO_VERSION')) {
            $hasOptions = class_exists('WPSEO_Options') && method_exists('WPSEO_Options', 'get');
            return [
                'plugin'      => 'yoast',
                'description' => true,
                'og'          => $hasOptions ? (bool) \WPSEO_Options::get('opengraph', true) : true,
                'twitter'     => $hasOptions ? (bool) \WPSEO_Options::get('twitter', true) : true,
            ];
        }
        if (defined('RANK_MATH_VERSION')) {
            return ['plugin' => 'rankmath', 'description' => true, 'og' => true, 'twitter' => true];
        }
        return ['plugin' => '', 'description' => false, 'og' => false, 'twitter' => false];
    }

    private function isAppPage(): bool
    {
        $page_id = (int) get_option('b360_app_page_id', 0);
        return $page_id > 0 && is_page($page_id);
    }

    /** Compute or return cached meta for the current request. */
    private function resolveMeta(): array
    {
        if ($this->meta !== null) return $this->meta;
        // Not under the base path: we do not know the route, so claim nothing.
        if ($this->subPath() === null) return $this->meta = [];
        $this->meta = $this->buildMeta($this->parseRoute());
        return $this->meta;
    }

    /**
     * Strip the SPA base path off the current REQUEST_URI, returning the
     * trimmed sub-path (e.g. "clubs/test-club"), or null when the request is
     * not under the base path at all. Uses anchored prefix strips, str_replace
     * would also hit mid-URL matches of $basePath.
     *
     * The base path is relative to home (get_page_uri), so the home path of a
     * WordPress installed in a subdirectory (/wp/) comes off first. Anything
     * else in front of the base (a /fr/ language prefix, a case variant) is
     * null rather than the whole URI, which used to come back as the "sub-path"
     * and produce a doubled canonical like /acquire/fr/acquire/.
     */
    private function subPath(): ?string
    {
        $basePath = rtrim(Options::get_app_base_path(), '/');
        $uri      = (string) (parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '');

        $homePath = rtrim((string) (parse_url(home_url('/'), PHP_URL_PATH) ?: ''), '/');
        if ($homePath !== '' && strpos($uri . '/', $homePath . '/') === 0) {
            $uri = substr($uri, strlen($homePath));
        }

        $uri = rtrim($uri, '/');
        if ($uri !== $basePath && strpos($uri, $basePath . '/') !== 0) return null;
        return trim(substr($uri, strlen($basePath)), '/');
    }

    private function parseRoute(): array
    {
        $path     = (string) $this->subPath();
        $segments = array_values(array_filter(explode('/', $path)));

        return [
            'type'      => $segments[0] ?? '',
            'segments'  => $segments,
            'full_path' => $path,
        ];
    }

    /** Empty when the request is not under the base path (see subPath()). */
    private function buildCanonical(): string
    {
        $basePath = Options::get_app_base_path();
        $path     = $this->subPath();
        if ($path === null) return '';
        $full     = $path !== '' ? $basePath . '/' . $path : $basePath;
        return rtrim(home_url($full), '/') . '/';
    }

    private function buildMeta(array $route): array
    {
        $type     = $route['type'];
        $segments = $route['segments'];
        $canonical = $this->buildCanonical();

        // ---- Static pages ----
        // Titles live in SpaRoutes (shared with AppRoute::setTitle and the
        // Vue router). Descriptions are meta-tag-specific, declared here.
        $descriptions = [
            ''         => __('Browse our wine selection.', 'b360-bridge'),
            'checkout' => __('Complete your purchase.', 'b360-bridge'),
            'login'    => __('Sign in to your account.', 'b360-bridge'),
            'register' => __('Create a new account.', 'b360-bridge'),
            'account'  => __('Manage your account.', 'b360-bridge'),
            'recovery' => __('Reset your password.', 'b360-bridge'),
        ];

        if (isset($descriptions[$type])) {
            return [
                'title'       => SpaRoutes::titleFor($type),
                'description' => $descriptions[$type],
                'canonical'   => $canonical,
            ];
        }

        // ---- Dynamic pages ----
        switch ($type) {
            case 'wine':
            case 'product':
            case 'bundle':
                return $this->productMeta($segments, $canonical);

            case 'collection':
                $slug = $segments[1] ?? '';
                $name = ucwords(str_replace('-', ' ', $slug)) ?: 'Shop';
                return [
                    'title'       => $name,
                    'description' => 'Browse our ' . $name . ' collection.',
                    'canonical'   => $canonical,
                ];

            case 'clubs':
                if (isset($segments[1])) {
                    return $this->clubMeta($segments[1], $canonical);
                }
                return [
                    'title'       => SpaRoutes::titleFor('clubs'),
                    'description' => __('Explore our wine club memberships.', 'b360-bridge'),
                    'canonical'   => $canonical,
                ];

            default:
                return ['canonical' => $canonical];
        }
    }

    private function productMeta(array $segments, string $canonical): array
    {
        // Read like CatalogController::product reads it (WP slashes $_GET), so
        // a sku with a quote is the same string the SPA's own lookup sends.
        $rawSku = $_GET['sku'] ?? '';
        $sku    = is_string($rawSku) ? sanitize_text_field(wp_unslash($rawSku)) : '';
        $params = self::productLookupParams($segments, $sku);
        if ($params === null) return ['canonical' => $canonical];

        $client = BridgeApiClient::instance();
        $res    = $client->get('catalog/product', $params, ['cache' => 0]);

        if (!$res['ok'] || empty($res['data'])) {
            return ['canonical' => $canonical];
        }

        $p       = $res['data'];
        $title   = $p['display_name'] ?? $p['name'] ?? '';
        $vintage = $p['vintage'] ?? '';
        // Append vintage only if it's meaningful and not already in the display name
        if ($vintage !== '' && $vintage !== 'NV' && strpos($title, $vintage) === false) {
            $title .= ' ' . $vintage;
        }

        $description = self::plainText($p['teaser'] ?? '');
        if ($description === '' && !empty($p['description'])) {
            $description = wp_trim_words(wp_strip_all_tags($p['description']), 30, '…');
        }

        $image = '';
        if (!empty($p['images'])) {
            $image = $p['images'][0]['url'] ?? '';
            if ($image !== '' && strpos($image, 'http') !== 0) {
                // Bridge API returns absolute URLs; this branch is defensive.
                // Without a configured public host we'd emit a relative path
                // in og:image / schema, which breaks social shares, drop it.
                $host = Options::get_public_url();
                $image = $host !== '' ? $host . $image : '';
            }
        }

        return [
            'title'       => $title,
            'description' => $description,
            'image'       => $image,
            'lcp_image'   => self::galleryLeadImage($p),
            'og_type'     => 'product',
            'canonical'   => $canonical,
        ];
    }

    /**
     * catalog/product params for a detail route, built exactly like the SPA's
     * productRequestFor() (shared/utils/productPrefetch.ts), or null where the
     * SPA would show an error without asking. Core's actionProduct reads only
     * sku, vintage_id and slug, and a slug lookup excludes wines, so a wine
     * MUST go by vintage_id: the old slug + `vintage` shape 404'd on every wine
     * page, which silently dropped its title, og tags and image preload.
     *
     * Extra trailing segments (/wine/<slug>/<id>/more, /product/<slug>/more)
     * match no SPA route, so the page is the router's 404: no lookup.
     *
     * @param string $sku the unslashed, sanitized ?sku= query value
     */
    private static function productLookupParams(array $segments, string $sku): ?array
    {
        $maxSegments = ($segments[0] ?? '') === 'wine' ? 3 : 2;
        if (count($segments) > $maxSegments) return null;

        if ($sku !== '') {
            return ['sku' => $sku];
        }
        if (($segments[0] ?? '') === 'wine') {
            $id = $segments[2] ?? '';
            if (!is_string($id) || !ctype_digit($id) || (int) $id <= 0) return null;
            return ['vintage_id' => (int) $id];
        }
        $slug = $segments[1] ?? '';
        return $slug !== '' ? ['slug' => $slug] : null;
    }

    /**
     * The image BridgeProductGallery.vue shows first, by the same rule: the
     * first `images` entry with a url, skipping `low_res` when any `high_res`
     * exists, else `image_url`. Empty unless absolute http(s): a URL the
     * gallery would resolve differently must not be preloaded, or the browser
     * downloads the bottle twice.
     */
    private static function galleryLeadImage(array $p): string
    {
        $images = isset($p['images']) && is_array($p['images']) ? $p['images'] : [];
        $url = '';
        if ($images) {
            $hasHighRes = false;
            foreach ($images as $img) {
                if (is_array($img) && ($img['type'] ?? '') === 'high_res') { $hasHighRes = true; break; }
            }
            foreach ($images as $img) {
                if (!is_array($img) || empty($img['url']) || !is_string($img['url'])) continue;
                if ($hasHighRes && ($img['type'] ?? '') === 'low_res') continue;
                $url = $img['url'];
                break;
            }
        } elseif (!empty($p['image_url']) && is_string($p['image_url'])) {
            $url = $p['image_url'];
        }
        return preg_match('#^https?://#i', $url) ? $url : '';
    }

    private function clubMeta(string $slug, string $canonical): array
    {
        $client = BridgeApiClient::instance();
        $res    = $client->get('club/detail', ['seo_url' => $slug], ['cache' => 300]);

        if (!$res['ok'] || empty($res['data'])) {
            return ['canonical' => $canonical];
        }

        $c           = $res['data'];
        $title       = $c['name'] ?? '';
        $description = self::plainText($c['meta_description'] ?? $c['teaser'] ?? '');
        if ($description === '' && !empty($c['description'])) {
            $description = wp_trim_words(wp_strip_all_tags($c['description']), 30, '…');
        }

        return [
            'title'       => $title,
            'description' => $description,
            'canonical'   => $canonical,
        ];
    }
}
