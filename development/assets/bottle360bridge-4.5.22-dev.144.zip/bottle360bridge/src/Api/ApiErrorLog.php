<?php

namespace Bottle360\Bridge\Api;

if (!defined('ABSPATH')) exit;

final class ApiErrorLog
{
    private const OPTION_KEY  = 'b360_bridge_error_log';
    private const MAX_ENTRIES = 50;

    private const TOKEN_REFUSAL_KEY      = 'b360_bridge_token_refusals';
    private const TOKEN_REFUSAL_MAX      = 20;
    private const TOKEN_REFUSAL_RATE     = 10;
    private const TOKEN_REFUSAL_WINDOW   = 3600;
    private const TOKEN_REFUSAL_RATE_KEY = 'b360_token_refusal_rate_';

    public static function log(string $method, string $url, int $status, string $error, string $body = ''): void
    {
        $log = get_option(self::OPTION_KEY, []);
        array_unshift($log, [
            'time'   => gmdate('Y-m-d H:i:s'),
            'method' => $method,
            'url'    => $url,
            'status' => $status,
            'error'  => $error,
            'body'   => substr($body, 0, 5000),
        ]);
        $log = array_slice($log, 0, self::MAX_ENTRIES);
        update_option(self::OPTION_KEY, $log, false);
    }

    /**
     * Record one refused request token (BD-4921, see RestBase::check_nonce).
     *
     * These live in their own option, not in the list above: any visitor or
     * bot can cause one at will, and they must never push an upstream error
     * out of that list.
     *
     * $line carries a boolean `retry`: true when the SPA had already fetched
     * a fresh token and was refused again. Those are the lines that mean a
     * shopper was actually blocked; a first refusal that the retry then
     * heals is routine (a tab left open overnight). So a retry line is only
     * ever displaced by a newer retry line, and first-attempt lines make
     * room for it.
     *
     * Rate limited, best effort. Retry lines and first-attempt lines each
     * get TOKEN_REFUSAL_RATE per TOKEN_REFUSAL_WINDOW seconds, whatever the
     * reason, and the counter is written before the line is. WordPress
     * offers no lock here, so requests that arrive together can each read
     * the counter before any of them has written it and a burst can exceed
     * the limit by about its own concurrency; likewise two concurrent
     * writers of the list can lose one of the two lines. The 20 line cap
     * holds regardless. Past the limit nothing is written, but the check
     * itself still reads a transient, which is a database query on a site
     * without a persistent object cache.
     */
    public static function log_token_refusal(array $line): void
    {
        $retry = !empty($line['retry']);
        $key   = self::TOKEN_REFUSAL_RATE_KEY . ($retry ? 'retry' : 'first');
        $now   = time();
        $state = get_transient($key);
        if (!is_array($state) || !isset($state['start'], $state['n']) || $now - (int) $state['start'] >= self::TOKEN_REFUSAL_WINDOW) {
            $state = ['start' => $now, 'n' => 0];
        }
        if ((int) $state['n'] >= self::TOKEN_REFUSAL_RATE) return;

        $state['n'] = (int) $state['n'] + 1;
        // Expire with the window, not a full window from now, or steady
        // traffic would keep pushing the reset out.
        set_transient($key, $state, (int) $state['start'] + self::TOKEN_REFUSAL_WINDOW - $now);

        $lines = self::get_token_refusals();
        if (count($lines) >= self::TOKEN_REFUSAL_MAX) {
            // Newest first, so the last first-attempt line is the oldest one.
            $drop = null;
            foreach ($lines as $i => $l) {
                if (empty($l['retry'])) $drop = $i;
            }
            if ($drop === null) {
                // Nothing but retry lines: only another retry line gets in.
                if (!$retry) return;
                $drop = count($lines) - 1;
            }
            array_splice($lines, $drop, 1);
        }
        array_unshift($lines, ['time' => gmdate('Y-m-d H:i:s')] + $line);
        update_option(self::TOKEN_REFUSAL_KEY, array_slice($lines, 0, self::TOKEN_REFUSAL_MAX), false);
    }

    /** Refused request tokens, newest first. */
    public static function get_token_refusals(): array
    {
        $lines = get_option(self::TOKEN_REFUSAL_KEY, []);
        return is_array($lines) ? array_values($lines) : [];
    }

    public static function get_entries(): array
    {
        return get_option(self::OPTION_KEY, []);
    }

    public static function clear(): void
    {
        delete_option(self::OPTION_KEY);
        delete_option(self::TOKEN_REFUSAL_KEY);
        delete_transient(self::TOKEN_REFUSAL_RATE_KEY . 'retry');
        delete_transient(self::TOKEN_REFUSAL_RATE_KEY . 'first');
    }

    public static function count(): int
    {
        return count(self::get_entries());
    }
}
