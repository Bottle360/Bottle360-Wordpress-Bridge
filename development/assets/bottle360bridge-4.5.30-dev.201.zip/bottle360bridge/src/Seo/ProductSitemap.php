<?php

namespace Bottle360\Bridge\Seo;

use Bottle360\Bridge\Api\ApiErrorLog;
use Bottle360\Bridge\Api\BridgeApiClient;
use Bottle360\Bridge\Api\UpstreamGuard;
use Bottle360\Bridge\Settings\Options;

if (!defined('ABSPATH')) exit;

/**
 * Product sitemap (BD-5261): the store URL of every product the public can
 * buy, so search engines find wine pages that only exist as SPA routes.
 *
 * Where it is served:
 *  - WordPress core sitemaps: a provider, listed in /wp-sitemap.xml as
 *    /wp-sitemap-storeproducts-<n>.xml.
 *  - Always, by this plugin, at /?b360_sitemap=<n> (a query URL: it needs no
 *    rewrite rule, so nothing has to be flushed). Yoast SEO and Rank Math
 *    switch core sitemaps off and serve their own index; each page of ours is
 *    appended to that index through the filter each one has for it. A
 *    sitemap index cannot point at another index, so pages are listed one by
 *    one there and in robots.txt (one page holds 2000 URLs; a second page is
 *    rare for a winery).
 *  - robots.txt: a Sitemap line, which also reaches sites on SEOPress, All in
 *    One SEO or The SEO Framework.
 *
 * A request never calls the backend. It reads the cached list (fresh, else
 * the last complete one, else nothing) and, when the fresh copy is gone,
 * schedules a refresh in WP-Cron. So on a new install the sitemap is an
 * empty urlset until its first refresh has finished. Page 1 of the plugin
 * served sitemap is listed (index entries, robots.txt) from the start, so an
 * index or robots.txt cached that early already points at it. Core's own
 * index is different: core answers 404 for a provider page with no URLs, so
 * the provider reports no pages until there is something to list.
 *
 * The refresh reads catalog/products, the endpoint the store grid uses, as a
 * guest, for the root category and then every category (core lists products
 * per category; catalog/categories is a flat list that includes nested
 * categories, so those are read too). It works in slices: each cron run does a bounded part, saves
 * a cursor and schedules the next run, and only a finished crawl replaces the
 * list. A failed crawl is retried with a doubling delay (15 minutes up to 6
 * hours). On a site with DISABLE_WP_CRON the events run whenever the site's
 * real cron hits wp-cron.php, as for every other scheduled event.
 */
final class ProductSitemap
{
    /** Core sitemap provider name. Letters only (core's rewrite rule). */
    public const PROVIDER = 'storeproducts';

    public const OBJECT_TYPE = 'b360_product';

    /** Query var of the plugin served sitemap: /?b360_sitemap=<page>. */
    public const QUERY_VAR = 'b360_sitemap';

    /** WP-Cron hook of the refresh. */
    public const CRON_HOOK = 'b360_bridge_sitemap_refresh';

    public const TTL       = 21600;   // 6 hours, the fresh list
    public const GOOD_TTL  = 2592000; // 30 days, the last complete list
    public const RETRY_MIN = 900;     // first retry after a failed crawl
    public const RETRY_MAX = 21600;   // retries double up to this

    /** The sitemap protocol's limit for one file. */
    private const MAX_URLS_PER_PAGE = 50000;

    private const PER_PAGE       = 100;
    private const SLICE_SECONDS  = 15;
    private const SLICE_REQUESTS = 25;
    private const CRAWL_REQUESTS = 600;  // a whole crawl; past this it is a failure
    private const CRAWL_TTL      = 86400; // the cursor; CRAWL_REQUESTS bounds the crawl
    private const LOCK_SECONDS   = 120;

    /** The refresh lock: an options row, or an object cache key in group b360_bridge. */
    public const LOCK_NAME = 'b360_sitemap_lock';

    /** @var array<int, string>|null Product paths for this request (read once). */
    private $paths = null;

    public function register(): void
    {
        add_action('init', [$this, 'registerProvider']);
        add_action('parse_request', [$this, 'serveStandalone'], 1);
        add_action(self::CRON_HOOK, [$this, 'refresh']);
        add_filter('robots_txt', [$this, 'robotsTxt'], 20, 2);
        // Harmless when the plugin is absent: nothing fires.
        add_filter('wpseo_sitemap_index', [$this, 'indexEntries'], 10, 1);
        add_filter('rank_math/sitemap/index', [$this, 'indexEntries'], 10, 1);
    }

    // ------------------------------------------------------------------
    // Serving (cache only)
    // ------------------------------------------------------------------

    /** Core sitemaps (WordPress 5.5+). A no-op where they are switched off. */
    public function registerProvider(): void
    {
        if (!function_exists('wp_register_sitemap_provider') || !class_exists('WP_Sitemaps_Provider')) return;
        try {
            wp_register_sitemap_provider(self::PROVIDER, new ProductSitemapProvider($this));
        } catch (\Throwable $e) {
            // Never take the site down over a sitemap.
        }
    }

    /**
     * Yoast SEO (wpseo_sitemap_index) and Rank Math (rank_math/sitemap/index)
     * both pass the XML to append to their index, '' by default.
     *
     * @param mixed $xml
     * @return mixed
     */
    public function indexEntries($xml)
    {
        if (!is_string($xml)) return $xml;
        try {
            if (!self::isConfigured()) return $xml;
            $pages = $this->listedPages();
            for ($n = 1; $n <= $pages; $n++) {
                $xml .= '<sitemap><loc>' . self::xml(self::standaloneUrl($n)) . '</loc></sitemap>' . "\n";
            }
        } catch (\Throwable $e) {
            // Leave their index as it was.
        }
        return $xml;
    }

    /**
     * robots.txt: where the product sitemap is. With core sitemaps on, core's
     * index lists our provider and core prints its own Sitemap line, so ours
     * is added only if that line is missing. Otherwise each page of the
     * plugin served sitemap gets a line.
     *
     * @param mixed $output
     * @param mixed $public the blog_public option
     * @return mixed
     */
    public function robotsTxt($output, $public = true)
    {
        if (!is_string($output) || !$public) return $output;
        try {
            if (!self::isConfigured()) return $output;
            $lines = [];
            if (self::coreSitemapsEnabled()) {
                $lines[] = home_url('/wp-sitemap.xml');
            } else {
                $pages = $this->listedPages();
                for ($n = 1; $n <= $pages; $n++) $lines[] = self::standaloneUrl($n);
            }
            foreach ($lines as $url) {
                if (stripos($output, $url) !== false) continue;
                $output = rtrim($output, "\n") . "\nSitemap: " . $url . "\n";
            }
        } catch (\Throwable $e) {
            // robots.txt stays as it was.
        }
        return $output;
    }

    /** The plugin served sitemap. Runs on parse_request. */
    public function serveStandalone(): void
    {
        if (!isset($_GET[self::QUERY_VAR]) || !self::isSitemapRequest()) return;

        $response = $this->standaloneResponse($_GET[self::QUERY_VAR]);
        if (!headers_sent()) {
            status_header($response['status']);
            header('Content-Type: ' . $response['type'] . '; charset=UTF-8');
            header('X-Robots-Tag: noindex');
            header('Cache-Control: ' . $response['cache']);
        }
        if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'HEAD') {
            echo $response['body'];
        }
        exit;
    }

    /**
     * A front end GET or HEAD of the home URL itself: not wp-admin, the REST
     * API or cron, and not ?b360_sitemap= on some other page.
     */
    private static function isSitemapRequest(): bool
    {
        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        if ($method !== 'GET' && $method !== 'HEAD') return false;
        if (function_exists('is_admin') && is_admin()) return false;
        if (defined('REST_REQUEST') && REST_REQUEST) return false;
        if (function_exists('wp_doing_cron') && wp_doing_cron()) return false;
        if (function_exists('wp_doing_ajax') && wp_doing_ajax()) return false;

        $path = (string) (parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH) ?: '/');
        $home = (string) (parse_url(home_url('/'), PHP_URL_PATH) ?: '/');
        return rtrim($path, '/') === rtrim($home, '/');
    }

    /**
     * What /?b360_sitemap=<value> answers. Only a plain page number (no
     * leading zero) on a store that is set up and open to search engines is
     * a sitemap; anything else is a 404, never the home page. Page 1 always
     * answers, with an empty urlset when there is nothing to list; that one
     * is not cacheable, so the list shows up as soon as the crawl is done.
     *
     * @param mixed $value the raw query value
     * @return array{status: int, type: string, body: string, cache: string}
     */
    public function standaloneResponse($value): array
    {
        $notFound = ['status' => 404, 'type' => 'text/plain', 'body' => "Not found\n", 'cache' => 'no-store'];
        if (!is_string($value) || !preg_match('/^[1-9][0-9]{0,5}$/', $value)) return $notFound;
        if (!self::isConfigured()) return $notFound;

        $page = (int) $value;
        if ($page > max(1, $this->pageCount())) return $notFound;

        $body = '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
            . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        $urls = $this->page($page);
        foreach ($urls as $url) {
            $body .= '<url><loc>' . self::xml($url) . '</loc></url>' . "\n";
        }
        $body .= '</urlset>' . "\n";

        return ['status' => 200, 'type' => 'application/xml', 'body' => $body, 'cache' => $urls ? 'public, max-age=3600' : 'no-store'];
    }

    public static function standaloneUrl(int $page): string
    {
        return home_url('/?' . self::QUERY_VAR . '=' . $page);
    }

    public function pageCount(): int
    {
        return (int) ceil(count($this->paths()) / self::perPage());
    }

    /**
     * Rank Math keeps its built sitemap index in a transient for months and
     * nothing of ours expires it, so an index built before our entry existed
     * (or with another number of our pages) would stay that way. Its own
     * cache reset is the fix. Yoast builds its index on request: nothing to
     * do there. Every call is guarded: a missing or changed API is skipped.
     */
    public static function invalidateSeoPluginIndex(): void
    {
        try {
            if (class_exists('RankMath\\Sitemap\\Cache') && method_exists('RankMath\\Sitemap\\Cache', 'invalidate_storage')) {
                \RankMath\Sitemap\Cache::invalidate_storage();
            }
        } catch (\Throwable $e) {
            // Their index refreshes on its own schedule instead.
        }
    }

    /**
     * Pages of the plugin served sitemap to list in an index or robots.txt:
     * always page 1 (it answers 200 even when empty), so an entry cached
     * before the first crawl has finished is already the right one.
     */
    private function listedPages(): int
    {
        return max(1, $this->pageCount());
    }

    /** @return array<int, string> the URLs of one sitemap page (1-based) */
    public function page(int $page): array
    {
        if ($page < 1) return [];
        $size = self::perPage();
        $urls = [];
        foreach (array_slice($this->paths(), ($page - 1) * $size, $size) as $path) {
            // Built now, not stored: the scheme and host are this request's.
            $url = self::urlForPath($path);
            if ($url !== '') $urls[] = $url;
        }
        return $urls;
    }

    /** @return array<int, string> every product URL */
    public function urls(): array
    {
        $urls = [];
        foreach ($this->paths() as $path) {
            $url = self::urlForPath($path);
            if ($url !== '') $urls[] = $url;
        }
        return $urls;
    }

    /**
     * The cached product paths: the fresh list, else the last complete one
     * (and a refresh is scheduled), else none. Never calls the backend,
     * never throws.
     *
     * @return array<int, string>
     */
    private function paths(): array
    {
        if ($this->paths !== null) return $this->paths;
        $this->paths = [];
        try {
            if (!self::isConfigured()) return $this->paths;
            $key   = self::cacheKey();
            $fresh = self::stored(get_transient(self::freshKey($key)));
            if ($fresh !== null) return $this->paths = $fresh;

            $this->paths = self::stored(get_transient(self::goodKey($key))) ?? [];
            self::schedule(self::retryDelay($key));
        } catch (\Throwable $e) {
            // Serve what we have.
        }
        return $this->paths;
    }

    // ------------------------------------------------------------------
    // Which products, which URLs
    // ------------------------------------------------------------------

    /**
     * The store URL for a listing row, or '' when the product stays out.
     */
    public static function productUrl(array $p): string
    {
        return self::urlForPath(self::productPath($p));
    }

    /**
     * The store path for a listing row, or '' when the product stays out:
     * not buyable by the public (locked, or every SKU access controlled),
     * or it has a page link (BD-5228: its store route redirects away). A
     * link back into the store is no link, as in the storefront.
     */
    public static function productPath(array $p): string
    {
        if (!ProductSchema::isPublic($p)) return '';
        $link = MetaTags::pageLink($p['page_url'] ?? null);
        if ($link !== '' && !self::linksIntoStore($link)) return '';
        return self::cleanPath($p['detail_path'] ?? null);
    }

    /**
     * The absolute URL for a product's `detail_path`, or '' when the path is
     * not a detail route. Built like MetaTags::buildCanonical(), trailing
     * slash included, so the sitemap URL is the page's canonical.
     *
     * @param mixed $path
     */
    public static function urlForPath($path): string
    {
        $clean = self::cleanPath($path);
        if ($clean === '') return '';
        return rtrim(home_url(Options::get_app_base_path() . $clean), '/') . '/';
    }

    /**
     * A `detail_path` as the path of a detail route, or ''. The storefront
     * links to `detail_path` as core sends it (BridgeProductCard.vue), and
     * the router knows exactly three shapes (shared/router/index.ts):
     *   /wine/<slug>/<vintage id>   /product/<slug>   /bundle/<slug>
     *
     * @param mixed $path
     */
    private static function cleanPath($path): string
    {
        if (!is_string($path)) return '';
        if (!preg_match('#^/(wine)/([^/?\#\s]+)/([1-9][0-9]*)$#', $path, $m)
            && !preg_match('#^/(product|bundle)/([^/?\#\s]+)$#', $path, $m)) {
            return '';
        }
        // Slugs are plain in practice; anything else is percent-encoded once.
        return '/' . $m[1] . '/' . rawurlencode(rawurldecode($m[2])) . (isset($m[3]) ? '/' . $m[3] : '');
    }

    /**
     * True when $url (absolute) is on this site and at or under the store
     * base path. Host compared as MetaTags::isSelfLink() does: lowercased,
     * a leading "www." dropped, scheme ignored.
     */
    private static function linksIntoStore(string $url): bool
    {
        $target = parse_url($url);
        $home   = parse_url(home_url('/'));
        if (!is_array($target) || empty($target['host']) || !is_array($home)) return false;
        $host = function ($h) { return (string) preg_replace('/^www\./', '', strtolower((string) $h)); };
        if ($host($target['host']) !== $host($home['host'] ?? '')) return false;

        $path = rtrim((string) ($target['path'] ?? '/'), '/');
        $base = rtrim(rtrim((string) ($home['path'] ?? ''), '/') . Options::get_app_base_path(), '/');
        return $base !== '' && ($path === $base || strpos($path, $base . '/') === 0);
    }

    /**
     * Connected to a backend, the store page exists and is published, and
     * the site is open to search engines (core's own sitemap condition).
     */
    private static function isConfigured(): bool
    {
        if (Options::get_base_host() === '' || Options::get_bridge_client_id() === '' || Options::get_bridge_client_secret() === '') return false;
        if (Options::is_app_disconnected()) return false;
        $pageId = (int) get_option('b360_app_page_id', 0);
        if ($pageId <= 0 || get_post_status($pageId) !== 'publish') return false;
        return (bool) get_option('blog_public', 1);
    }

    private static function coreSitemapsEnabled(): bool
    {
        if (!function_exists('wp_sitemaps_get_server')) return false;
        $server = wp_sitemaps_get_server();
        return is_object($server) && method_exists($server, 'sitemaps_enabled') && $server->sitemaps_enabled();
    }

    /** URLs per sitemap page: core's limit (2000, filterable), never above the protocol's 50,000. */
    private static function perPage(): int
    {
        $max = function_exists('wp_sitemaps_get_max_urls') ? (int) wp_sitemaps_get_max_urls(self::OBJECT_TYPE) : 2000;
        if ($max < 1) $max = 2000;
        return min($max, self::MAX_URLS_PER_PAGE);
    }

    // ------------------------------------------------------------------
    // Cache
    // ------------------------------------------------------------------

    /**
     * Cache key suffix. The backend connection, the site address and the
     * store base path are all in it, so changing any of them starts a new
     * list. The raw `home` option, not home_url(): that one varies with the
     * request's scheme and with translation plugins' filters.
     */
    private static function cacheKey(): string
    {
        return md5(implode('|', [
            Options::get_base_host(),
            Options::get_bridge_client_id(),
            (string) get_option('home', ''),
            Options::get_app_base_path(),
        ]));
    }

    /**
     * The fresh list. The b360_api_ prefix puts it under the settings page's
     * "clear cache" (BridgeApiClient::flushCache); the last complete list is
     * kept through that, on purpose.
     */
    private static function freshKey(string $key): string { return 'b360_api_sitemap_' . $key; }
    private static function goodKey(string $key): string { return 'b360_sitemap_good_' . $key; }
    private static function crawlKey(string $key): string { return 'b360_sitemap_crawl_' . $key; }
    /** The run marker: tells a lost cursor from a first run, and counts losses in a row. */
    private static function runKey(string $key): string { return 'b360_sitemap_run_' . $key; }
    /** Under b360_api_ too: "clear cache" ends the retry hold. */
    private static function failKey(string $key): string { return 'b360_api_sitemap_fail_' . $key; }

    /**
     * @param mixed $value a transient value
     * @return array<int, string>|null
     */
    private static function stored($value): ?array
    {
        if (!is_array($value) || !isset($value['paths']) || !is_array($value['paths'])) return null;
        return array_values(array_filter($value['paths'], 'is_string'));
    }

    // ------------------------------------------------------------------
    // Refresh (WP-Cron)
    // ------------------------------------------------------------------

    /**
     * Queue one refresh run. A run already queued for that time or sooner
     * stands; one queued for later (the end of a retry hold that "clear
     * cache" has since ended) is moved up.
     */
    private static function schedule(int $delay): void
    {
        if (!function_exists('wp_next_scheduled') || !function_exists('wp_schedule_single_event')) return;
        $at   = time() + max(0, $delay);
        $next = wp_next_scheduled(self::CRON_HOOK);
        if ($next) {
            if ((int) $next <= $at) return;
            if (function_exists('wp_unschedule_event')) wp_unschedule_event($next, self::CRON_HOOK);
        }
        wp_schedule_single_event($at, self::CRON_HOOK);
    }

    /** Seconds until a refresh may run again after failures; 0 when there were none. */
    private static function retryDelay(string $key): int
    {
        $fail = get_transient(self::failKey($key));
        if (!is_array($fail) || empty($fail['until'])) return 0;
        return max(0, (int) $fail['until'] - time());
    }

    /**
     * One cron run: a slice of the crawl. Finished: the new list replaces
     * the fresh and the last complete copy. Not finished: the cursor is
     * saved and the next run is queued. Failed: nothing is replaced, the
     * cursor is dropped and a retry is queued with a doubling delay.
     */
    public function refresh(): void
    {
        try {
            if (!self::isConfigured()) return;
            $key = self::cacheKey();
            if (self::stored(get_transient(self::freshKey($key))) !== null) return;
            if (self::retryDelay($key) > 0) { self::schedule(self::retryDelay($key)); return; }
            if (!self::lock()) return;
        } catch (\Throwable $e) {
            return;
        }

        // The crawl's calls each get the site's normal upstream budget and
        // leave the request's own counter as they found it.
        $guard = class_exists(UpstreamGuard::class) && method_exists(UpstreamGuard::class, 'restoreRequestBudget');
        $spent = $guard ? UpstreamGuard::spentMs() : 0;
        // The client keeps a last known good copy of catalog GETs under a key
        // with no viewer in it. The crawl neither reads nor feeds that store.
        $noStale = function () { return false; };
        add_filter('b360_bridge_stale_eligible', $noStale, 99);

        try {
            // The run marker: `expect` is set while a crawl is between
            // slices, `restarts` counts cursor losses in a row.
            $run      = get_transient(self::runKey($key));
            $expect   = is_array($run) && !empty($run['expect']);
            $restarts = is_array($run) ? (int) ($run['restarts'] ?? 0) : 0;

            $state = get_transient(self::crawlKey($key));
            if (self::validState($state)) {
                $restarts = 0;
            } else {
                if ($expect) {
                    // The cursor is gone (cache eviction, a cleaned options
                    // table). Start over once, saying so once. A second loss
                    // in a row means it never persists here: starting over
                    // every run would crawl forever, so that is a failure,
                    // retried with the growing delay like any other.
                    $restarts++;
                    if ($restarts === 1 && class_exists(ApiErrorLog::class)) {
                        ApiErrorLog::log('GET', 'catalog/products (product sitemap refresh)', 0, 'Product sitemap refresh lost its place between runs and started over.');
                    }
                    if ($restarts >= 2) {
                        set_transient(self::runKey($key), ['expect' => false, 'restarts' => $restarts], 2 * self::CRAWL_TTL);
                        $this->failed($key, 'its place between runs keeps getting lost (the cursor transient does not persist)');
                        return;
                    }
                }
                $state = self::newState();
            }
            $result = $this->crawlSlice($state, $guard);

            if ($result === 'done') {
                $list = ['paths' => array_keys($state['paths'])];
                $was  = self::stored(get_transient(self::goodKey($key)));
                set_transient(self::freshKey($key), $list, (int) apply_filters('b360_bridge_sitemap_ttl', self::TTL));
                set_transient(self::goodKey($key), $list, self::GOOD_TTL);
                delete_transient(self::crawlKey($key));
                delete_transient(self::runKey($key));
                delete_transient(self::failKey($key));
                // First list ever, or another number of pages: the entries
                // we add to an SEO plugin's index have changed.
                $pages = function (array $paths): int { return max(1, (int) ceil(count($paths) / self::perPage())); };
                if ($was === null || $pages($was) !== $pages($list['paths'])) self::invalidateSeoPluginIndex();
            } elseif ($result === 'more') {
                set_transient(self::runKey($key), ['expect' => true, 'restarts' => $restarts], 2 * self::CRAWL_TTL);
                if (set_transient(self::crawlKey($key), $state, self::CRAWL_TTL)) {
                    self::schedule(0);
                } else {
                    $this->failed($key, 'its place between runs could not be saved');
                }
            } else {
                // The next crawl starts from the top and expects no cursor.
                if ($restarts > 0) {
                    set_transient(self::runKey($key), ['expect' => false, 'restarts' => $restarts], 2 * self::CRAWL_TTL);
                } else {
                    delete_transient(self::runKey($key));
                }
                $this->failed($key, $result);
            }
        } catch (\Throwable $e) {
            try { $this->failed($key, 'error: ' . $e->getMessage()); } catch (\Throwable $e2) { /* nothing left to do */ }
        } finally {
            remove_filter('b360_bridge_stale_eligible', $noStale, 99);
            if ($guard) UpstreamGuard::restoreRequestBudget($spent);
            // Results are written above, before the lock goes.
            self::unlock();
        }
    }

    /** Record a failed crawl, log the first of a run of failures, queue the retry. */
    private function failed(string $key, string $why): void
    {
        delete_transient(self::crawlKey($key));
        $fail  = get_transient(self::failKey($key));
        $count = is_array($fail) ? (int) ($fail['count'] ?? 0) + 1 : 1;
        $delay = (int) min(self::RETRY_MAX, self::RETRY_MIN * pow(2, min($count - 1, 10)));
        set_transient(self::failKey($key), ['count' => $count, 'until' => time() + $delay], 2 * self::RETRY_MAX);
        if ($count === 1 && class_exists(ApiErrorLog::class)) {
            ApiErrorLog::log('GET', 'catalog/products (product sitemap refresh)', 0, 'Product sitemap refresh failed: ' . $why . '. The last complete list stays in place; retrying with a growing delay.');
        }
        self::schedule($delay);
    }

    /** @return array{paths: array<string, int>, slug: string, page: int, queue: ?array, root: ?int, requests: int} */
    private static function newState(): array
    {
        // slug '' is the root category; queue is null until the categories are read.
        return ['paths' => [], 'slug' => '', 'page' => 1, 'queue' => null, 'root' => null, 'requests' => 0];
    }

    /** @param mixed $s */
    private static function validState($s): bool
    {
        return is_array($s) && isset($s['paths'], $s['slug'], $s['page'], $s['requests'])
            && is_array($s['paths']) && is_string($s['slug']) && is_int($s['page']) && is_int($s['requests'])
            && array_key_exists('queue', $s) && ($s['queue'] === null || is_array($s['queue']))
            && array_key_exists('root', $s);
    }

    /**
     * Read listing pages from the cursor on, until the crawl is done or the
     * slice is used up. Returns 'done', 'more', or the reason it failed.
     */
    private function crawlSlice(array &$state, bool $guard): string
    {
        $client   = BridgeApiClient::instance();
        $deadline = microtime(true) + self::SLICE_SECONDS;
        $requests = 0;

        // Guest view on purpose ('token' => ''): no session ever decides
        // what the public sitemap lists.
        $opts = ['token' => '', 'cache' => 0];

        $get = function (string $route, array $params) use ($client, $opts, $guard, &$state, &$requests) {
            $requests++;
            $state['requests']++;
            if ($guard) UpstreamGuard::resetRequestBudget();
            $res = $client->get($route, $params, $opts);
            // A stale copy is the client's stand-in for a failed call, and
            // may have been stored from another viewer's request.
            if (!is_array($res) || empty($res['ok']) || !empty($res['stale']) || !is_array($res['data'] ?? null)) return null;
            // catalog/products sends its paging inside data (CatalogService
            // getProducts). Take the envelope's meta too, in case the route
            // ever moves to BridgeResponse::paginated().
            $data = $res['data'];
            if (!is_array($data['meta'] ?? null) && is_array($res['meta'] ?? null)) $data['meta'] = $res['meta'];
            return $data;
        };

        while (true) {
            if ($state['requests'] >= self::CRAWL_REQUESTS) return 'cut short after ' . $state['requests'] . ' requests';
            if ($requests >= self::SLICE_REQUESTS || microtime(true) >= $deadline) return 'more';

            $params = ['page' => $state['page'], 'per_page' => self::PER_PAGE];
            if ($state['slug'] !== '') $params['category_slug'] = $state['slug'];
            $data = $get('catalog/products', $params);
            if ($data === null) return 'catalog/products failed (category "' . $state['slug'] . '", page ' . $state['page'] . ')';

            $category = is_array($data['category'] ?? null) ? $data['category'] : [];
            if ($state['slug'] === '' && isset($category['category_id'])) $state['root'] = (int) $category['category_id'];

            // A locked category locks everything listed under it.
            // A 200 without the product list is a broken answer, not an
            // empty category: counting it as empty would drop real pages.
            if (!is_array($data['products'] ?? null)) return 'catalog/products sent no product list (category "' . $state['slug'] . '", page ' . $state['page'] . ')';

            $locked = !empty($category['locked']);
            if (!$locked) {
                foreach ($data['products'] as $p) {
                    if (!is_array($p)) continue;
                    $path = self::productPath($p);
                    if ($path !== '') $state['paths'][$path] = 1;
                }
            }

            $pages = (int) ($data['meta']['total_pages'] ?? 1);
            if (!$locked && $state['page'] < $pages) {
                $state['page']++;
                continue;
            }

            // This category is finished: the next one, after reading the list once.
            if ($state['queue'] === null) {
                $data = $get('catalog/categories', []);
                if ($data === null) return 'catalog/categories failed';
                if (!is_array($data['categories'] ?? null)) return 'catalog/categories sent no category list';
                $state['queue'] = [];
                foreach ($data['categories'] as $cat) {
                    if (!is_array($cat) || !empty($cat['locked'])) continue;
                    $slug = isset($cat['slug']) && is_string($cat['slug']) ? $cat['slug'] : '';
                    if ($slug === '' || (int) ($cat['category_id'] ?? 0) === $state['root']) continue;
                    $state['queue'][] = $slug;
                }
            }
            if (!$state['queue']) return 'done';
            $state['slug'] = (string) array_shift($state['queue']);
            $state['page'] = 1;
        }
    }

    /**
     * One refresh at a time. With a persistent object cache wp_cache_add is
     * atomic and expires by itself. Otherwise a row in the options table,
     * taken the way WP_Upgrader::create_lock() does: INSERT IGNORE, which
     * the unique option_name index makes atomic (add_option is not: it
     * checks, then inserts with ON DUPLICATE KEY UPDATE). A lock older than
     * LOCK_SECONDS was left by a run that died; it is taken over with an
     * UPDATE that names the old value, so only one contender gets it.
     */
    private static function lock(): bool
    {
        if (function_exists('wp_using_ext_object_cache') && wp_using_ext_object_cache()) {
            return (bool) wp_cache_add(self::LOCK_NAME, time(), 'b360_bridge', self::LOCK_SECONDS);
        }
        global $wpdb;
        if (!is_object($wpdb)) return false;

        $now = (string) time();
        $got = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO `{$wpdb->options}` (`option_name`, `option_value`, `autoload`) VALUES (%s, %s, 'no') /* LOCK */",
            self::LOCK_NAME,
            $now
        ));
        if ($got) return true;

        $held = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM `{$wpdb->options}` WHERE option_name = %s", self::LOCK_NAME));
        if (!is_string($held) || time() - (int) $held < self::LOCK_SECONDS) return false;
        $taken = $wpdb->query($wpdb->prepare(
            "UPDATE `{$wpdb->options}` SET option_value = %s WHERE option_name = %s AND option_value = %s",
            $now,
            self::LOCK_NAME,
            $held
        ));
        return $taken === 1;
    }

    private static function unlock(): void
    {
        if (function_exists('wp_using_ext_object_cache') && wp_using_ext_object_cache()) {
            wp_cache_delete(self::LOCK_NAME, 'b360_bridge');
            return;
        }
        global $wpdb;
        if (!is_object($wpdb)) return;
        $wpdb->query($wpdb->prepare("DELETE FROM `{$wpdb->options}` WHERE option_name = %s", self::LOCK_NAME));
    }

    private static function xml(string $url): string
    {
        return htmlspecialchars($url, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }
}
