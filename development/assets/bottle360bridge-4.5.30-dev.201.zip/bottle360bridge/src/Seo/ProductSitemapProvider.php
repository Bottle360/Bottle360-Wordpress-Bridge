<?php

namespace Bottle360\Bridge\Seo;

if (!defined('ABSPATH')) exit;

/**
 * WordPress core sitemap provider for store products (BD-5261): adds
 * /wp-sitemap-storeproducts-<n>.xml to /wp-sitemap.xml. All the work is in
 * ProductSitemap; this is the shape core asks for.
 *
 * Loaded only when core's WP_Sitemaps_Provider exists (WordPress 5.5+), see
 * ProductSitemap::registerProvider().
 */
final class ProductSitemapProvider extends \WP_Sitemaps_Provider
{
    /** @var ProductSitemap */
    private $sitemap;

    public function __construct(ProductSitemap $sitemap)
    {
        // Core matches the name with [a-z]+ in its rewrite rule: letters only.
        $this->name        = ProductSitemap::PROVIDER;
        $this->object_type = ProductSitemap::OBJECT_TYPE;
        $this->sitemap     = $sitemap;
    }

    /**
     * @param int    $page_num
     * @param string $object_subtype
     * @return array<int, array{loc: string}>
     */
    public function get_url_list($page_num, $object_subtype = '')
    {
        $out = [];
        foreach ($this->sitemap->page((int) $page_num) as $url) {
            $out[] = ['loc' => $url];
        }
        return $out;
    }

    /**
     * @param string $object_subtype
     * @return int
     */
    public function get_max_num_pages($object_subtype = '')
    {
        return $this->sitemap->pageCount();
    }
}
