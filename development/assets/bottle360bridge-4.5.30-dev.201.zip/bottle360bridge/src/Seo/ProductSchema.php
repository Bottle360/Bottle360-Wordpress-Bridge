<?php

namespace Bottle360\Bridge\Seo;

if (!defined('ABSPATH')) exit;

/**
 * schema.org Product structured data (JSON-LD) for a product detail page
 * (BD-5261), built from the catalog/product payload MetaTags already holds.
 *
 * Pure: no request, no option read. Every value in the payload is untrusted
 * and only ever leaves through script(), which encodes it so that no value
 * can close the script element.
 */
final class ProductSchema
{
    public const CURRENCY = 'USD';

    /** Google reads at most a handful of images; the gallery can hold many. */
    private const MAX_IMAGES = 10;

    private const MAX_DESCRIPTION = 5000;

    /**
     * The Product node, or null when there is nothing to print.
     *
     * $ctx keys:
     *   name        string  page title (MetaTags' rule, vintage appended)
     *   description string  text (tags and entities are removed here)
     *   url         string  the product's store URL
     *   brand       string  site (winery) name
     *   guest       bool    the payload was fetched with no session at all
     *
     * Google only accepts a Product that carries offers, review or
     * aggregateRating, and offers is the only one we have. So there is a node
     * only when there is a price the public can buy at:
     *  - the payload is a guest's. It is fetched with the visitor's session,
     *    and a member's copy can carry unlocked members-only SKUs and prices.
     *    Crawlers hold no session, so this costs nothing in search.
     *  - the product is not locked (members-only category).
     *  - at least one SKU is not access controlled (secure_sku, the flag
     *    every viewer gets, or locked) and has a fixed price (not an
     *    open-amount gift card, not zero).
     *
     * @return array<string, mixed>|null
     */
    public static function build(array $p, array $ctx): ?array
    {
        $name = self::text($ctx['name'] ?? '');
        $url  = self::text($ctx['url'] ?? '');
        if ($name === '' || $url === '') return null;

        $offerSkus = empty($ctx['guest']) ? [] : self::offerSkus($p);
        $offers    = self::offers($offerSkus, $url);
        if ($offers === null) return null;

        $node = [
            '@context' => 'https://schema.org',
            '@type'    => 'Product',
            '@id'      => $url . '#product',
            'name'     => $name,
        ];

        $description = self::text($ctx['description'] ?? '');
        if ($description !== '') {
            $node['description'] = function_exists('mb_substr')
                ? mb_substr($description, 0, self::MAX_DESCRIPTION)
                : substr($description, 0, self::MAX_DESCRIPTION);
        }

        $images = self::images($p);
        if ($images) $node['image'] = $images;

        // One priced SKU: its code. Otherwise the product's primary SKU.
        $sku = count($offerSkus) === 1 ? self::text($offerSkus[0]['sku_code'] ?? '') : '';
        if ($sku === '') $sku = self::text($p['primary_sku_code'] ?? '');
        if ($sku !== '') $node['sku'] = $sku;

        $brand = self::text($ctx['brand'] ?? '');
        if ($brand !== '') $node['brand'] = ['@type' => 'Brand', 'name' => $brand];

        $node['url']    = $url;
        $node['offers'] = $offers;

        return $node;
    }

    /**
     * The <script> element for a node, or '' when it cannot be encoded.
     * JSON_HEX_TAG turns every < and > into \u003C / \u003E, so a value
     * holding "</script>" stays inside the JSON string.
     */
    public static function script(array $node): string
    {
        $json = wp_json_encode($node, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP);
        if (!is_string($json) || $json === '') return '';
        return '<script type="application/ld+json">' . $json . '</script>' . "\n";
    }

    /**
     * True when the public can buy this product: not locked, and at least
     * one SKU that is not access controlled. Stock does not matter here.
     * Used by the product sitemap too.
     */
    public static function isPublic(array $p): bool
    {
        if (!empty($p['locked'])) return false;
        foreach (self::skus($p) as $sku) {
            if (!self::skuRestricted($sku)) return true;
        }
        return false;
    }

    /**
     * Same rule as skuPurchasable() in shared/utils/stock.ts, which decides
     * the storefront's out of stock state: the server's `purchasable` when it
     * is a boolean, else in_stock === true (a missing in_stock is out).
     */
    public static function skuPurchasable(array $sku): bool
    {
        if (isset($sku['purchasable']) && is_bool($sku['purchasable'])) return $sku['purchasable'];
        return ($sku['in_stock'] ?? null) === true;
    }

    /**
     * The price the product page shows for a SKU (SkuOption.vue:
     * display_price, else price), or null when it is not a positive number.
     * A display_price that is not a number falls back to price.
     */
    public static function skuPrice(array $sku): ?float
    {
        $price = $sku['display_price'] ?? null;
        if (!is_numeric($price)) $price = $sku['price'] ?? null;
        if (!is_numeric($price)) return null;
        $price = (float) $price;
        return $price > 0 ? $price : null;
    }

    /** @return array<int, array> the payload's SKU rows that are arrays */
    private static function skus(array $p): array
    {
        $skus = isset($p['skus']) && is_array($p['skus']) ? $p['skus'] : [];
        return array_values(array_filter($skus, 'is_array'));
    }

    /**
     * Access controlled for the public. `secure_sku` is sent to every viewer;
     * `locked` is the per-viewer gate (skuLocked() in shared/utils/stock.ts).
     * Either one keeps the SKU out, so the answer does not depend on who the
     * payload was fetched for.
     */
    private static function skuRestricted(array $sku): bool
    {
        return !empty($sku['secure_sku']) || !empty($sku['locked']);
    }

    /** @return array<int, array> SKUs with a public, fixed price */
    private static function offerSkus(array $p): array
    {
        if (!empty($p['locked'])) return [];
        $out = [];
        foreach (self::skus($p) as $sku) {
            if (self::skuRestricted($sku)) continue;
            if (!empty($sku['custom_amount_allowed'])) continue;
            if (self::skuPrice($sku) === null) continue;
            $out[] = $sku;
        }
        return $out;
    }

    /**
     * One SKU: an Offer. Several (sizes or formats of one product, all on
     * this one URL): an AggregateOffer with the price range, which is the
     * shape schema.org and Google define for several offers of one product on
     * one page, and it never presents one option's price as the price.
     * The range covers the SKUs in stock when any is, else all of them.
     *
     * @param array<int, array> $skus
     * @return array<string, mixed>|null
     */
    private static function offers(array $skus, string $url): ?array
    {
        if (!$skus) return null;

        $inStock = array_values(array_filter($skus, [self::class, 'skuPurchasable']));
        $availability = 'https://schema.org/' . ($inStock ? 'InStock' : 'OutOfStock');

        if (count($skus) === 1) {
            return [
                '@type'         => 'Offer',
                'price'         => self::money((float) self::skuPrice($skus[0])),
                'priceCurrency' => self::CURRENCY,
                'availability'  => $availability,
                'url'           => $url,
            ];
        }

        $priced = $inStock ?: $skus;
        $prices = [];
        foreach ($priced as $sku) $prices[] = (float) self::skuPrice($sku);

        return [
            '@type'         => 'AggregateOffer',
            'lowPrice'      => self::money(min($prices)),
            'highPrice'     => self::money(max($prices)),
            'priceCurrency' => self::CURRENCY,
            'offerCount'    => count($priced),
            'availability'  => $availability,
            'url'           => $url,
        ];
    }

    /**
     * Gallery images as absolute http(s) URLs, in gallery order: `low_res`
     * entries are skipped when a `high_res` exists (BridgeProductGallery's
     * rule), `image_url` is the fallback. A relative URL is dropped.
     *
     * @return array<int, string>
     */
    private static function images(array $p): array
    {
        $images = isset($p['images']) && is_array($p['images']) ? $p['images'] : [];
        $urls = [];
        $hasHighRes = false;
        foreach ($images as $img) {
            if (is_array($img) && ($img['type'] ?? '') === 'high_res') { $hasHighRes = true; break; }
        }
        foreach ($images as $img) {
            if (!is_array($img) || empty($img['url']) || !is_string($img['url'])) continue;
            if ($hasHighRes && ($img['type'] ?? '') === 'low_res') continue;
            $urls[] = trim($img['url']);
        }
        if (!$urls && !empty($p['image_url']) && is_string($p['image_url'])) {
            $urls[] = trim($p['image_url']);
        }

        $out = [];
        foreach ($urls as $u) {
            if (!preg_match('#^https?://#i', $u) || in_array($u, $out, true)) continue;
            $out[] = $u;
            if (count($out) >= self::MAX_IMAGES) break;
        }
        return $out;
    }

    private static function money(float $amount): string
    {
        return number_format($amount, 2, '.', '');
    }

    /**
     * A scalar as real plain text, anything else as ''. Tags are stripped,
     * then entities are decoded (core's plain text teaser still carries
     * &nbsp; and &rsquo;, and JSON-LD is not HTML), a non-breaking space
     * becomes a space, and runs of whitespace collapse to one space.
     * Decoding can bring back a "<": script() encodes it.
     *
     * @param mixed $v
     */
    private static function text($v): string
    {
        if (!is_scalar($v) || is_bool($v)) return '';
        $text = html_entity_decode(wp_strip_all_tags((string) $v), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = str_replace("\xC2\xA0", ' ', $text);
        $out  = preg_replace('/\s+/u', ' ', $text);
        // Invalid UTF-8 makes the /u pattern fail: fall back to bytes.
        if (!is_string($out)) $out = (string) preg_replace('/\s+/', ' ', $text);
        return trim($out);
    }
}
